package net.sf.l2j.gameserver.instancemanager.offlinefarm;

import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.l2j.gameserver.ThreadPoolManager;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.instancemanager.autofarm.AutofarmManager;
import net.sf.l2j.gameserver.instancemanager.autofarmsecondary.AutofarmSecondaryManager;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.model.item.kind.Item;
import net.sf.l2j.gameserver.model.zone.ZoneId;
import net.sf.l2j.gameserver.network.L2GameClient;
import net.sf.l2j.gameserver.network.serverpackets.ExShowScreenMessage;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;

public final class OfflineFarm
{
    private static final Logger LOG = Logger.getLogger(OfflineFarm.class.getName());
    private static final Path REPORTS = Paths.get("data", "offlinefarm", "reports");
    private static final ZoneId[] FORBIDDEN = {
        ZoneId.PEACE, ZoneId.TOWN, ZoneId.PVP, ZoneId.SIEGE, ZoneId.JAIL,
        ZoneId.BOSS_AREA, ZoneId.SPECIAL_BOSS_AREA, ZoneId.ZAKEN, ZoneId.ANDREAS,
        ZoneId.FRINTEZZA, ZoneId.FLAG_AREA, ZoneId.FLAG_AREA_SELF, ZoneId.ZONE_PVP,
        ZoneId.AUTO_PVP_ZONE, ZoneId.TOURNAMENT, ZoneId.ARENA_EVENT, ZoneId.OLYMPIAD,
        ZoneId.FARM_INSTANCE_ZONE, ZoneId.TIME_INSTANCE_ZONE, ZoneId.NO_RESTART
    };
    private static final OfflineFarm INSTANCE = new OfflineFarm();

    private final Map<Integer, Session> sessions = new ConcurrentHashMap<>();
    private final Map<String, Session> accounts = new ConcurrentHashMap<>();
    private final List<int[]> spots = new ArrayList<>();
    private final boolean enabled;
    private volatile boolean shuttingDown;
    private final int ticketId, minutes, minLevel, maxLevel, maxSessions, maxPlayersPerSpot, radius, maxZ, respawnSeconds;

    private OfflineFarm()
    {
        final Properties p = new Properties();
        final Path config = Paths.get("config", "custom", "OfflineFarm.properties");
        if (Files.isRegularFile(config))
        {
            try (java.io.InputStream input = Files.newInputStream(config))
            {
                p.load(input);
            }
            catch (IOException e)
            {
                LOG.log(Level.WARNING, "Could not load OfflineFarm.properties.", e);
                p.clear();
            }
        }
        ticketId = number(p, "TicketItemId", 0, 0, Integer.MAX_VALUE);
        minutes = number(p, "MinutesPerTicket", 60, 1, 1440);
        minLevel = number(p, "MinLevel", 20, 1, 100);
        maxLevel = number(p, "MaxLevel", 100, minLevel, 100);
        maxSessions = number(p, "MaxSessions", 100, 1, 1000);
        maxPlayersPerSpot = number(p, "MaxPlayersPerSpot", 1, 1, 100);
        radius = number(p, "Radius", 850, 1, 3000);
        maxZ = number(p, "MaxZDifference", 300, 1, 1500);
        respawnSeconds = number(p, "RespawnSeconds", 300, 1, 3600);
        for (String spot : p.getProperty("Spots", "").split("\\|"))
        {
            if (spot.trim().isEmpty())
                continue;
            final String[] xyz = spot.split(",");
            try
            {
                if (xyz.length != 3)
                    throw new IllegalArgumentException("Expected X,Y,Z.");
                spots.add(new int[] { Integer.parseInt(xyz[0].trim()), Integer.parseInt(xyz[1].trim()), Integer.parseInt(xyz[2].trim()) });
            }
            catch (IllegalArgumentException e)
            {
                LOG.warning("Offline Farm: invalid spot " + spot);
            }
        }
        enabled = Boolean.parseBoolean(p.getProperty("Enabled", "false").trim()) && ticketId > 0 && !spots.isEmpty();
        if (enabled)
            ThreadPoolManager.getInstance().scheduleGeneralAtFixedRate(this::tick, 1000, 1000);
    }

    public static OfflineFarm getInstance()
    {
        return INSTANCE;
    }

    private static int number(Properties p, String key, int fallback, int min, int max)
    {
        try
        {
            return Math.max(min, Math.min(max, Integer.parseInt(p.getProperty(key, String.valueOf(fallback)).trim())));
        }
        catch (NumberFormatException e)
        {
            return fallback;
        }
    }

    public boolean handle(L2PcInstance player, String command)
    {
        if ("offlinefarm status".equals(command))
            sendStatus(player);
        else if ("offlinefarm menu".equals(command))
            showMenu(player);
        else if ("offlinefarm start".equals(command))
            start(player);
        else
            return false;
        return true;
    }

    private void sendStatus(L2PcInstance player)
    {
        final ItemInstance ticket = enabled ? player.getInventory().getItemByItemId(ticketId) : null;
        final int seconds = ticket != null && ticket.getCount() > 0 ? minutes * 60 : 0;
        player.sendPacket(new ExShowScreenMessage("CustomEvent=OfflineFarmV1|" + seconds, 1));
    }

    private void showMenu(L2PcInstance player)
    {
        sendStatus(player);
        final String denied = rejection(player);
        final StringBuilder body = new StringBuilder("<center><font color=LEVEL>AutoFarm Offline</font></center><br>");
        body.append("Custo: 1 ticket (ID ").append(ticketId).append(").<br1>Dura\u00e7\u00e3o: ").append(minutes)
            .append(" min por sess\u00e3o.<br>Usa as skills e as op\u00e7\u00f5es do AutoFarm atual. Ao iniciar, voc\u00ea ser\u00e1 desconectado. Ao voltar, o farm offline para e o relat\u00f3rio abre. O ticket vale para uma sess\u00e3o.<br>");
        if (denied != null)
            body.append("<font color=FF7777>").append(denied).append("</font>");
        else
            body.append("<center><button value=\"Ativar e desconectar\" action=\"bypass -h offlinefarm start\" width=160 height=25 back=\"L2UI_CH3.bigbutton2_down\" fore=\"L2UI_CH3.bigbutton2\"></center>");
        sendHtml(player, body.toString());
    }

    private String rejection(L2PcInstance player)
    {
        if (!enabled || shuttingDown || ItemTable.getInstance().getTemplate(ticketId) == null)
            return "Offline Farm indispon\u00edvel.";
        if (!validLocation(player) || nearestSpot(player) == null)
            return "V\u00e1 a um spot autorizado do Offline Farm.";
        if (player.getLevel() < minLevel || player.getLevel() > maxLevel || player.isAlikeDead()
            || player.isInCombat() || player.getPvpFlag() != 0 || player.isCastingNow() || player.isAttackingNow()
            || player.isInParty() || player.isInStoreMode() || player.isInOlympiadMode() || player.inObserverMode()
            || player.isInDuel() || player.isInArenaEvent() || player.isInFunEvent() || player.isFishing()
            || player.isLocked() || player.isMounted() || player.isPveModeActive() || player.isSitting()
            || player.isTeleporting() || player.getKarma() != 0 || player.getVehicle() != null
            || player.isCursedWeaponEquipped() || player.isFestivalParticipant() || player.isProcessingRequest()
            || player.getActiveTradeList() != null || player.getAppearance().getInvisible() || player.isInvul())
            return "Saia de combate, grupos e eventos para ativar.";
        if (player.isNoBuffProtected() && player.getAllEffects().length <= 8)
            return "A prote\u00e7\u00e3o de buffs do seu AutoFarm est\u00e1 ativa e faltam buffs.";
        if (AutofarmManager.INSTANCE.isAutofarming(player) || AutofarmSecondaryManager.INSTANCE.isAutofarming(player))
            return "Desative o AutoFarm online antes de iniciar.";
        if (player.getInventory().getItemByItemId(ticketId) == null)
            return "Voc\u00ea precisa do ticket Offline Farm.";
        return null;
    }

    private static boolean validLocation(L2PcInstance player)
    {
        for (ZoneId zone : FORBIDDEN)
        {
            if (player.isInsideZone(zone))
                return false;
        }
        return true;
    }

    private long distance(L2PcInstance player, int[] spot)
    {
        final long dx = (long) player.getX() - spot[0], dy = (long) player.getY() - spot[1];
        return dx * dx + dy * dy;
    }

    private int[] nearestSpot(L2PcInstance player)
    {
        int[] nearest = null;
        long threshold = (long) radius * radius;
        for (int[] spot : spots)
        {
            final long distance = distance(player, spot);
            if (distance <= threshold && Math.abs((long) player.getZ() - spot[2]) <= maxZ)
            {
                nearest = spot;
                threshold = distance;
            }
        }
        return nearest;
    }

    private void start(L2PcInstance player)
    {
        synchronized (player)
        {
            final String denied = rejection(player);
            if (denied != null)
            {
                player.sendMessage(denied);
                return;
            }
            final L2GameClient client = player.getClient();
            if (client == null || client.isDetached() || client.getActiveChar() != player
                || client.getState() != L2GameClient.GameClientState.IN_GAME)
                return;
            final int[] spot = nearestSpot(player);
            if (spot == null)
                return;
            if (Files.isRegularFile(reportPath(player.getObjectId())))
            {
                player.sendMessage("Aguarde o relat\u00f3rio da sess\u00e3o anterior.");
                onEnterWorld(player);
                return;
            }
            final Session session = new Session(player, client, spot, minutes);
            synchronized (sessions)
            {
                if (shuttingDown || sessions.size() >= maxSessions
                    || sessions.values().stream().filter(active -> active.spot == spot).count() >= maxPlayersPerSpot
                    || accounts.putIfAbsent(session.account, session) != null)
                {
                    player.sendMessage("Offline Farm sem vagas ou j\u00e1 ativo nesta conta.");
                    return;
                }
                sessions.put(player.getObjectId(), session);
            }
            try
            {
                Files.createDirectories(REPORTS);
                AutofarmSecondaryManager.INSTANCE.startFarm(player);
                if (!AutofarmSecondaryManager.INSTANCE.isAutofarming(player))
                    return;
                if (!player.destroyItemByItemId("OfflineFarm", ticketId, 1, player, true))
                    return;
                session.charged = true;
                player.store();
                session.initialItems = inventory(player);
                saveReport(session, "Em andamento");
                if (!client.detachForOfflineFarm(player))
                    return;
                session.running = true;
            }
            catch (IOException | RuntimeException e)
            {
                LOG.log(Level.WARNING, "Could not start Offline Farm.", e);
                player.sendMessage("N\u00e3o foi poss\u00edvel iniciar o Offline Farm.");
            }
            finally
            {
                if (!session.running)
                {
                    remove(session);
                    try
                    {
                        AutofarmSecondaryManager.INSTANCE.stopFarm(player);
                    }
                    finally
                    {
                        if (session.charged)
                            player.addItem("OfflineFarmRefund", ticketId, 1, player, true);
                    }
                    if (session.charged)
                    {
                        try { Files.deleteIfExists(reportPath(player.getObjectId())); }
                        catch (IOException e) { LOG.log(Level.WARNING, "Could not remove aborted Offline Farm report.", e); }
                    }
                }
            }
        }
    }

    public L2PcInstance reconnect(L2PcInstance player, String account)
    {
        synchronized (player)
        {
            final Session session = sessions.get(player.getObjectId());
            if (session == null || !session.running || !session.account.equals(account))
                return null;
            finish(session, "Reconex\u00e3o", true);
            return player;
        }
    }

    public void recordKill(L2PcInstance player)
    {
        final Session session = sessions.get(player.getObjectId());
        if (session != null && session.running)
            session.kills.incrementAndGet();
    }

    private void tick()
    {
        for (Session session : sessions.values())
        {
            final L2PcInstance player = session.player;
            synchronized (player)
            {
                if (!session.running || sessions.get(player.getObjectId()) != session)
                    continue;
                try
                {
                    final long now = System.currentTimeMillis();
                    if (now >= session.until || !player.isOnline() || !validLocation(player))
                    {
                        finish(session, now >= session.until ? "Tempo esgotado" : "Sess\u00e3o interrompida", false);
                        continue;
                    }
                    if (player.isAlikeDead())
                    {
                        if (session.reviveAt == 0)
                        {
                            session.deaths++;
                            session.reviveAt = now + TimeUnit.SECONDS.toMillis(respawnSeconds);
                            AutofarmSecondaryManager.INSTANCE.stopFarm(player);
                        }
                        if (now >= session.reviveAt)
                        {
                            player.doRevive();
                            player.teleToLocation(session.spot[0], session.spot[1], session.spot[2], 0);
                            session.reviveAt = 0;
                        }
                    }
                    else if (distance(player, session.spot) > (long) radius * radius
                        || Math.abs((long) player.getZ() - session.spot[2]) > maxZ)
                    {
                        AutofarmSecondaryManager.INSTANCE.stopFarm(player);
                        player.teleToLocation(session.spot[0], session.spot[1], session.spot[2], 0);
                    }
                    else if (!AutofarmSecondaryManager.INSTANCE.isAutofarming(player) && !player.isTeleporting())
                    {
                        if (player.isNoBuffProtected() && player.getAllEffects().length <= 8)
                        {
                            finish(session, "Prote\u00e7\u00e3o de buffs", false);
                            continue;
                        }
                        AutofarmSecondaryManager.INSTANCE.startFarm(player);
                    }
                    if (now >= session.checkpoint)
                    {
                        session.checkpoint = now + 15000;
                        player.store();
                        saveReport(session, "Em andamento");
                    }
                }
                catch (IOException | RuntimeException e)
                {
                    LOG.log(Level.WARNING, "Offline Farm session failed for " + player.getObjectId(), e);
                    finish(session, "Sess\u00e3o interrompida", false);
                }
            }
        }
    }

    public void shutdown()
    {
        synchronized (sessions)
        {
            shuttingDown = true;
        }
        for (Session session : sessions.values())
        {
            synchronized (session.player)
            {
                if (session.running)
                    finish(session, "Rein\u00edcio do servidor", false);
            }
        }
    }

    private void finish(Session session, String reason, boolean reconnect)
    {
        session.running = false;
        final L2PcInstance player = session.player;
        try
        {
            AutofarmSecondaryManager.INSTANCE.stopFarm(player);
            player.store();
            saveReport(session, reason);
        }
        catch (IOException | RuntimeException e)
        {
            LOG.log(Level.WARNING, "Could not finalize Offline Farm report.", e);
        }
        finally
        {
            session.client.setActiveChar(null);
            player.setClient(null);
            remove(session);
            if (!reconnect && player.isOnline())
                player.deleteMe();
        }
    }

    private void remove(Session session)
    {
        sessions.remove(session.player.getObjectId(), session);
        accounts.remove(session.account, session);
    }

    private static Map<Integer, Long> inventory(L2PcInstance player)
    {
        final Map<Integer, Long> counts = new HashMap<>();
        for (ItemInstance item : player.getInventory().getItems())
        {
            if (item != null)
                counts.merge(item.getItemId(), (long) item.getCount(), Long::sum);
        }
        return counts;
    }

    private static Path reportPath(int objectId)
    {
        return REPORTS.resolve(objectId + ".properties");
    }

    private static void saveReport(Session session, String reason) throws IOException
    {
        final L2PcInstance player = session.player;
        final Properties p = new Properties();
        p.setProperty("reason", reason);
        p.setProperty("seconds", Long.toString(Math.max(0, Math.min(System.currentTimeMillis(), session.until) - session.start) / 1000));
        p.setProperty("xp", Long.toString(Math.max(0, player.getExp() - session.xp)));
        p.setProperty("sp", Long.toString(Math.max(0, (long) player.getSp() - session.sp)));
        p.setProperty("deaths", Integer.toString(session.deaths));
        p.setProperty("kills", Integer.toString(session.kills.get()));
        for (Map.Entry<Integer, Long> entry : inventory(player).entrySet())
        {
            final long gain = entry.getValue() - session.initialItems.getOrDefault(entry.getKey(), 0L);
            if (gain > 0)
                p.setProperty("item." + entry.getKey(), Long.toString(gain));
        }
        final Path report = reportPath(player.getObjectId());
        final Path temp = Files.createTempFile(REPORTS, player.getObjectId() + "-", ".tmp");
        try
        {
            try (java.io.OutputStream output = Files.newOutputStream(temp))
            {
                p.store(output, "Offline Farm");
            }
            try { Files.move(temp, report, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temp, report, StandardCopyOption.REPLACE_EXISTING); }
        }
        finally
        {
            Files.deleteIfExists(temp);
        }
    }

    public void onEnterWorld(L2PcInstance player)
    {
        final L2GameClient client = player.getClient();
        final Path path = reportPath(player.getObjectId());
        if (client == null || !Files.isRegularFile(path))
            return;
        ThreadPoolManager.getInstance().scheduleGeneral(() ->
        {
            synchronized (player)
            {
                if (!player.isOnline() || player.getClient() != client || client.isDetached())
                    return;
                try
                {
                    final Properties p = new Properties();
                    try (java.io.InputStream input = Files.newInputStream(path)) { p.load(input); }
                    final String reason = p.getProperty("reason", "");
                    final StringBuilder body = new StringBuilder("<center><font color=LEVEL>Relat\u00f3rio do Offline Farm</font></center><br>");
                    body.append("Motivo: ").append("Em andamento".equals(reason) ? "Sess\u00e3o interrompida" : reason)
                        .append("<br1>Tempo: ").append(p.getProperty("seconds", "0")).append(" s<br1>XP: ")
                        .append(p.getProperty("xp", "0")).append("<br1>SP: ").append(p.getProperty("sp", "0"))
                        .append("<br1>Monstros abatidos: ").append(p.getProperty("kills", "0")).append("<br1>Mortes: ").append(p.getProperty("deaths", "0")).append("<br><font color=LEVEL>Itens ganhos</font><br1>");
                    final Map<Integer, String> loot = new TreeMap<>();
                    for (String key : p.stringPropertyNames())
                    {
                        if (key.startsWith("item."))
                            loot.put(Integer.parseInt(key.substring(5)), p.getProperty(key));
                    }
                    int displayed = 0;
                    for (Map.Entry<Integer, String> item : loot.entrySet())
                    {
                        if (displayed++ >= 40)
                        {
                            body.append("Mais itens no invent\u00e1rio.<br1>");
                            break;
                        }
                        final Item template = ItemTable.getInstance().getTemplate(item.getKey());
                        final String name = template == null ? "Item " + item.getKey() : template.getName();
                        body.append(name.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))
                            .append(" x").append(item.getValue()).append("<br1>");
                    }
                    if (loot.isEmpty())
                        body.append("Nenhum item ganho nesta sess\u00e3o.");
                    sendHtml(player, body.toString());
                    Files.deleteIfExists(path);
                }
                catch (IOException | RuntimeException e)
                {
                    LOG.log(Level.WARNING, "Could not show Offline Farm report.", e);
                }
            }
        }, 1500);
    }

    private static void sendHtml(L2PcInstance player, String body)
    {
        final NpcHtmlMessage html = new NpcHtmlMessage(0);
        html.setHtml("<html><title>Offline Farm</title><body>" + body + "</body></html>");
        player.sendPacket(html);
    }

    private static final class Session
    {
        final L2PcInstance player;
        final L2GameClient client;
        final String account;
        final int[] spot;
        final long start = System.currentTimeMillis();
        final long until, xp;
        final int sp;
        Map<Integer, Long> initialItems;
        long checkpoint = start + 15000, reviveAt;
        int deaths;
        final java.util.concurrent.atomic.AtomicInteger kills = new java.util.concurrent.atomic.AtomicInteger();
        boolean charged;
        volatile boolean running;

        Session(L2PcInstance player, L2GameClient client, int[] spot, int minutes)
        {
            this.player = player;
            this.client = client;
            account = client.getAccountName();
            this.spot = spot;
            until = start + TimeUnit.MINUTES.toMillis(minutes);
            xp = player.getExp();
            sp = player.getSp();
        }
    }
}
