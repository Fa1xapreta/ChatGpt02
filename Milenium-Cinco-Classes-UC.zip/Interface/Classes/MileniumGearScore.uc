class MileniumGearScore extends UICommonAPI;

struct PlayerRankingInfo
{
    var int RankingDiff;
    var string Name;
    var int ClassId;
    var string ClanName;
    var int Score;
};
struct PlayerGearItem
{
    var int ServerID;
    var int ItemID;
    var int Enchant;
    var int RefineryOp1;
    var int RefineryOp2;
    var int SlotBitType;
    var int GearScore;
};
var Color BrightWhite;
var Color BrightYellow;
var Color Blue;
var Color Red;
var Color Gold;
var Color Yellow03;
var Color ColorGold;
var Color ColorYellow;
var Color White;
var Color Gray;
var array<string> Fields;
var array<PlayerGearItem> ItemScores;
var string GearToken;
var string PvpToken;
var string InspectToken;
var int LastTargetID;
var bool ScoreClickGuard;
var string ContextInspectName;

function OnLoad()
{
    RegisterEvent(140);
    RegisterEvent(160);
    RegisterEvent(980);
    RegisterEvent(990);
    RegisterEvent(88857);
    RegisterEvent(94600);
    ResetGearData();
    GetHandle("StatusWnd.ScoreWnd").SetAnchor("StatusWnd", "BottomLeft", "TopLeft", 60, -38);
    GetHandle("StatusWnd.ScoreWnd.btnScoreRank").SetTooltipType("Text");
    GetHandle("StatusWnd.ScoreWnd.btnScoreRank").SetTooltipText("Gear Score");
}
function OnEvent(int Event_ID, string param)
{
    local string Message;
    local int Score;
    if (Event_ID == 160) { ResetGearData(); return; }
    if (Event_ID == 980 || Event_ID == 990) { CheckTarget(); return; }
    if (Event_ID == 94600)
    {
        if (!ParseString(param, "Payload", Message)) return;
        HandleGearMessage(Message);
        return;
    }
    if (Event_ID == 88857)
    {
        if (!ParseInt(param, "Gear", Score)) return;
        OnUpdateUserScore(Score);
        return;
    }
    if (Event_ID != 140) return;
    if (!ParseString(param, "Msg", Message)) return;
    HandleGearMessage(Message);
}
function ResetGearData()
{
    GetHandle("ContextMenuWnd").HideWindow();
    GetHandle("MileniumGearScore").KillTimer(9170002);
    ContextInspectName = "";

    ScoreClickGuard = false;
    GetHandle("MileniumGearScore").KillTimer(9170001);
    Fields.Length = 0;
    ItemScores.Length = 0;
    GearToken = "";
    PvpToken = "";
    InspectToken = "";
    LastTargetID = 0;
    TextBoxHandle(GetHandle("StatusWnd.ScoreWnd.txtScore")).SetText("--");
    GetHandle("TargetStatusWnd.ScoreWnd").HideWindow();
    if (RankingWnd(GetScript("RankingWnd")) != None)
    {
        RankingWnd(GetScript("RankingWnd")).GearScoreList.Length = 0;
        RankingWnd(GetScript("RankingWnd")).PvPScoreList.Length = 0;
        RankingWnd(GetScript("RankingWnd")).zz_PlayerGearRank = 0;
        RankingWnd(GetScript("RankingWnd")).zz_PlayerGearRankingDiff = 0;
        RankingWnd(GetScript("RankingWnd")).zz_PlayerPvPRank = 0;
        RankingWnd(GetScript("RankingWnd")).zz_PlayerPvPRankingDiff = 0;
        GetHandle("RankingWnd").HideWindow();
    }
    if (InspectWnd(GetScript("InspectWnd")) != None)
    {
        InspectWnd(GetScript("InspectWnd")).zz_InspectItensList.Length = 0;
        GetHandle("InspectWnd").HideWindow();
    }
    if (DetailStatusWnd(GetScript("DetailStatusWnd")) != None)
    {
        DetailStatusWnd(GetScript("DetailStatusWnd")).zzgearequip = 0;
        TextBoxHandle(GetHandle("DetailStatusWnd.txtScore")).SetText("--");
    }
}
function OnTimer(int TimerID)
{
    if (TimerID == 9170002) { FinishContextInspect(); return; }

    if (TimerID != 9170001) return;
    ScoreClickGuard = false;
    GetHandle("MileniumGearScore").KillTimer(9170001);
}
function OnClickButton(string strID)
{
    if (strID != "btnScoreRank" || ScoreClickGuard) return;
    if (RankingWnd(GetScript("RankingWnd")) == None) return;
    ScoreClickGuard = true;
    GetHandle("MileniumGearScore").SetTimer(9170001,250);
    if (GetHandle("RankingWnd").IsShowWindow())
    {
        RankingWnd(GetScript("RankingWnd")).StopGSDrag();
        GetHandle("InspectWnd").HideWindow();
        GetHandle("RankingWnd").HideWindow();
        return;
    }
    ShowWindowWithFocus("RankingWnd");
    if (RankingWnd(GetScript("RankingWnd")).GearScoreTree == None)
        RankingWnd(GetScript("RankingWnd")).OnLoad();
    RequestBypassToServer("RankingOpen");
}
function OnUpdateUserScore(int Score)
{
    if (Score < 0) return;
    TextBoxHandle(GetHandle("StatusWnd.ScoreWnd.txtScore")).SetInt(Score);
    TextBoxHandle(GetHandle("DetailStatusWnd.txtScore")).SetInt(Score);
    if (DetailStatusWnd(GetScript("DetailStatusWnd")) == None) return;
    DetailStatusWnd(GetScript("DetailStatusWnd")).zzgearequip = Score;
}
function OnUpdateTargetScore(int Score)
{
    if (Score < 0) return;
    TextBoxHandle(GetHandle("TargetStatusWnd.ScoreWnd.txtScore")).SetInt(Score);
    CheckTarget();
}
function CheckTarget()
{
    local UserInfo Info;

    HideStaleTargetContext();
    if (!GetTargetInfo(Info) || Info.bNpc)
    {
        GetHandle("TargetStatusWnd.ScoreWnd").HideWindow();
        return;
    }
    if (Info.nID != LastTargetID)
        TextBoxHandle(GetHandle("TargetStatusWnd.ScoreWnd.txtScore")).SetText("--");
    if (TargetStatusWnd(GetScript("TargetStatusWnd")).m_bExpand)
        GetHandle("TargetStatusWnd.ScoreWnd").ShowWindow();
    else
        GetHandle("TargetStatusWnd.ScoreWnd").HideWindow();
}
function CacheItemScore(int ObjectID, int ItemID, int Enchant, int Score)
{
    local int i, Slot;
    if (ObjectID < 0 || ItemID <= 0 || Enchant < 0 || Score < 0) return;
    i = 0;
    Slot = -1;
    while (i < ItemScores.Length)
    {
        if (ItemScores[i].ServerID == ObjectID)
        {
            if (ObjectID > 0) { Slot = i; break; }
            if (ItemScores[i].ItemID == ItemID && ItemScores[i].Enchant == Enchant)
            { Slot = i; break; }
        }
        i++;
    }
    if (Slot < 0)
    {
        if (ItemScores.Length >= 2048) return;
        Slot = ItemScores.Length;
        ItemScores.Length++;
    }
    ItemScores[Slot].ServerID = ObjectID;
    ItemScores[Slot].ItemID = ItemID;
    ItemScores[Slot].Enchant = Enchant;
    ItemScores[Slot].GearScore = Score;
}
function int GetItemScore(int ObjectID, int ItemID, int Enchant)
{
    local int i;
    i = 0;
    while (i < ItemScores.Length)
    {
        if (ObjectID > 0)
        {
            if (ItemScores[i].ServerID == ObjectID) return ItemScores[i].GearScore;
        }
        else if (ItemScores[i].ServerID == 0 && ItemScores[i].ItemID == ItemID && ItemScores[i].Enchant == Enchant)
            return ItemScores[i].GearScore;
        i++;
    }
    return -1;
}
function AppendItemScoreTooltip(out CustomTooltip Tip, ItemInfo Item, bool Preview)
{
    local int Score, Row;
    Score = GetItemScore(Item.ServerID, Item.ClassID, Item.Enchanted);
    if (Score < 0 && Preview) Score = GetItemScore(0, Item.ClassID, Item.Enchanted);
    if (Score <= 0) return;
    Row = Tip.DrawList.Length;
    Tip.DrawList.Length++;
    Tip.DrawList[Row].eType = DIT_TEXTURE;
    Tip.DrawList[Row].u_strTexture = "MUI_GEAR.AugBG";
    Tip.DrawList[Row].u_nTextureWidth = 242;
    Tip.DrawList[Row].u_nTextureHeight = 25;
    Tip.DrawList[Row].nOffSetX = 0;
    Tip.DrawList[Row].nOffSetY = 0;
    Tip.DrawList[Row].bLineBreak = true;
    Tip.DrawList[Row].t_bDrawOneLine = true;
    Row = Tip.DrawList.Length;
    Tip.DrawList.Length++;
    Tip.DrawList[Row].eType = DIT_TEXTURE;
    Tip.DrawList[Row].u_strTexture = "MUI_GEAR.gearscore";
    Tip.DrawList[Row].u_nTextureWidth = 18;
    Tip.DrawList[Row].u_nTextureHeight = 18;
    Tip.DrawList[Row].nOffSetX = 3;
    Tip.DrawList[Row].nOffSetY = -23;
    Tip.DrawList[Row].bLineBreak = true;
    Tip.DrawList[Row].t_bDrawOneLine = true;
    Row = Tip.DrawList.Length;
    Tip.DrawList.Length++;
    Tip.DrawList[Row].eType = DIT_TEXT;
    Tip.DrawList[Row].t_strText = "Gear Score: ";
    Tip.DrawList[Row].t_color = Gold;
    Tip.DrawList[Row].nOffSetX = 3;
    Tip.DrawList[Row].nOffSetY = -21;
    Tip.DrawList[Row].bLineBreak = false;
    Tip.DrawList[Row].t_bDrawOneLine = true;
    Row = Tip.DrawList.Length;
    Tip.DrawList.Length++;
    Tip.DrawList[Row].eType = DIT_TEXT;
    Tip.DrawList[Row].t_strText = "+" $ string(Score);
    Tip.DrawList[Row].t_color = ColorYellow;
    Tip.DrawList[Row].nOffSetX = 2;
    Tip.DrawList[Row].nOffSetY = -21;
    Tip.DrawList[Row].bLineBreak = false;
    Tip.DrawList[Row].t_bDrawOneLine = true;

}
function HandleGearMessage(string Message)
{
    local string Kind, Type, Token;
    local int Row;
    local UserInfo Info;
    if (Len(Message) > 8192) return;
    Fields.Length = 0;
    GearSplit(Message, "|", Fields);
    if (Fields.Length < 2 || Fields[0] != "CustomEvent=GearScoreV1") return;
    Kind = Fields[1];
    if (Kind == "Self")
    {
        if (Fields.Length != 4) return;
        if (!GetPlayerInfo(Info) || Info.nID != int(Fields[2])) return;
        OnUpdateUserScore(int(Fields[3]));
        return;
    }
    if (Kind == "Target")
    {
        if (Fields.Length != 4) return;
        if (!GetTargetInfo(Info) || Info.bNpc || Info.nID != int(Fields[2])) return;
        LastTargetID = int(Fields[2]);
        OnUpdateTargetScore(int(Fields[3]));
        return;
    }
    if (Kind == "RankBegin")
    {
        if (Fields.Length != 6 || RankingWnd(GetScript("RankingWnd")) == None || Len(Fields[3]) == 0) return;
        Type = Fields[2];
        if (Type == "Gear")
        {
            GearToken = Fields[3];
            RankingWnd(GetScript("RankingWnd")).GearScoreList.Length = 0;
            RankingWnd(GetScript("RankingWnd")).zz_PlayerGearRank = int(Fields[4]);
            RankingWnd(GetScript("RankingWnd")).zz_PlayerGearRankingDiff = int(Fields[5]);
        }
        else if (Type == "PvP")
        {
            PvpToken = Fields[3];
            RankingWnd(GetScript("RankingWnd")).PvPScoreList.Length = 0;
            RankingWnd(GetScript("RankingWnd")).zz_PlayerPvPRank = int(Fields[4]);
            RankingWnd(GetScript("RankingWnd")).zz_PlayerPvPRankingDiff = int(Fields[5]);
        }
        return;
    }
    if (Kind == "RankRow")
    {
        if (Fields.Length != 9 || RankingWnd(GetScript("RankingWnd")) == None) return;
        if (int(Fields[8]) <= 0 || int(Fields[6]) < 0 || int(Fields[6]) > 255 || Len(Fields[5]) == 0) return;
        Type = Fields[2];
        Token = Fields[3];
        if (Type == "Gear")
        {
            if (Len(GearToken) == 0 || Token != GearToken) return;
            Row = RankingWnd(GetScript("RankingWnd")).GearScoreList.Length;
            if (Row >= 200) return;
            RankingWnd(GetScript("RankingWnd")).GearScoreList.Length++;
            RankingWnd(GetScript("RankingWnd")).GearScoreList[Row].RankingDiff = int(Fields[4]);
            RankingWnd(GetScript("RankingWnd")).GearScoreList[Row].Name = Fields[5];
            RankingWnd(GetScript("RankingWnd")).GearScoreList[Row].ClassId = int(Fields[6]);
            RankingWnd(GetScript("RankingWnd")).GearScoreList[Row].ClanName = Fields[7];
            RankingWnd(GetScript("RankingWnd")).GearScoreList[Row].Score = int(Fields[8]);
        }
        else if (Type == "PvP")
        {
            if (Len(PvpToken) == 0 || Token != PvpToken) return;
            Row = RankingWnd(GetScript("RankingWnd")).PvPScoreList.Length;
            if (Row >= 200) return;
            RankingWnd(GetScript("RankingWnd")).PvPScoreList.Length++;
            RankingWnd(GetScript("RankingWnd")).PvPScoreList[Row].RankingDiff = int(Fields[4]);
            RankingWnd(GetScript("RankingWnd")).PvPScoreList[Row].Name = Fields[5];
            RankingWnd(GetScript("RankingWnd")).PvPScoreList[Row].ClassId = int(Fields[6]);
            RankingWnd(GetScript("RankingWnd")).PvPScoreList[Row].ClanName = Fields[7];
            RankingWnd(GetScript("RankingWnd")).PvPScoreList[Row].Score = int(Fields[8]);
        }
        return;
    }
    if (Kind == "RankEnd")
    {
        if (Fields.Length != 4 || RankingWnd(GetScript("RankingWnd")) == None) return;
        Type = Fields[2];
        Token = Fields[3];
        if (Type == "Gear")
        {
            if (Len(GearToken) == 0 || Token != GearToken) return;
            GearToken = "";
        }
        else if (Type == "PvP")
        {
            if (Len(PvpToken) == 0 || Token != PvpToken) return;
            PvpToken = "";
        }
        else return;
        if (!GetHandle("RankingWnd").IsShowWindow()) return;
        RankingWnd(GetScript("RankingWnd")).xxSetRankingData();
        ShowWindowWithFocus("RankingWnd");
        return;
    }
    if (Kind == "InspectBegin")
    {
        if (Fields.Length != 6 || InspectWnd(GetScript("InspectWnd")) == None || Len(Fields[2]) == 0) return;
        InspectToken = Fields[2];
        InspectWnd(GetScript("InspectWnd")).zz_PlayerNickname = Fields[3];
        InspectWnd(GetScript("InspectWnd")).zz_PlayerClassID = int(Fields[4]);
        InspectWnd(GetScript("InspectWnd")).zz_PlayerGearScore = int(Fields[5]);
        InspectWnd(GetScript("InspectWnd")).zz_InspectItensList.Length = 0;
        return;
    }
    if (Kind == "InspectItem")
    {
        if (Fields.Length != 10 || InspectWnd(GetScript("InspectWnd")) == None) return;
        if (Len(InspectToken) == 0 || Fields[2] != InspectToken) return;
        Row = InspectWnd(GetScript("InspectWnd")).zz_InspectItensList.Length;
        if (Row >= 64 || int(Fields[4]) <= 0 || int(Fields[9]) < 0) return;
        InspectWnd(GetScript("InspectWnd")).zz_InspectItensList.Length++;
        InspectWnd(GetScript("InspectWnd")).zz_InspectItensList[Row].ServerID = int(Fields[3]);
        InspectWnd(GetScript("InspectWnd")).zz_InspectItensList[Row].ItemID = int(Fields[4]);
        InspectWnd(GetScript("InspectWnd")).zz_InspectItensList[Row].Enchant = int(Fields[5]);
        InspectWnd(GetScript("InspectWnd")).zz_InspectItensList[Row].RefineryOp1 = int(Fields[6]);
        InspectWnd(GetScript("InspectWnd")).zz_InspectItensList[Row].RefineryOp2 = int(Fields[7]);
        InspectWnd(GetScript("InspectWnd")).zz_InspectItensList[Row].SlotBitType = int(Fields[8]);
        InspectWnd(GetScript("InspectWnd")).zz_InspectItensList[Row].GearScore = int(Fields[9]);
        CacheItemScore(int(Fields[3]), int(Fields[4]), int(Fields[5]), int(Fields[9]));
        return;
    }
    if (Kind == "InspectEnd")
    {
        if (Fields.Length != 3 || InspectWnd(GetScript("InspectWnd")) == None) return;
        if (Len(InspectToken) == 0 || Fields[2] != InspectToken) return;
        InspectToken = "";
        InspectWnd(GetScript("InspectWnd")).xxSetInspectItens();
        return;
    }
    if (Kind == "Item")
    {
        if (Fields.Length != 6) return;
        CacheItemScore(int(Fields[2]), int(Fields[3]), int(Fields[4]), int(Fields[5]));
        return;
    }
    if (Kind == "ClearItems")
    {
        if (Fields.Length != 2) return;
        ItemScores.Length = 0;
    }
}

function MileniumGearScore getInstanceL2Util()
{
    return self;
}

function string xxGetDetailedClassIconName(int zz_ClassID, int zz_iconType)
{
	local string zz_iconSize, zz_iconPrefix;
	
	zz_iconPrefix = "MUI_GEAR.ClassMark.PlayerStatusWnd_ClassMark_";

	if (zz_iconType == 1) zz_iconSize = "_Big";
	if (zz_iconType == 2) zz_iconSize = "_Small";

	switch (zz_ClassID)
	{
		case 0:
		case 10:	//Human
			return zz_iconPrefix $ "human" $ zz_iconSize;
		break;
		case 18:
		case 25:	//Elf
			return zz_iconPrefix $ "elf" $ zz_iconSize;
		break;
		case 31:
		case 38:	//DarkElf
			return zz_iconPrefix $ "darkelf" $ zz_iconSize;
		break;
		case 44:
		case 49:	//Orc
			return zz_iconPrefix $ "orc" $ zz_iconSize;
		break;
		case 53:	//Dwarf
			return zz_iconPrefix $ "dwarf" $ zz_iconSize;
		break;
		
		default:	//Class Icon
			return zz_iconPrefix $ zz_classID $ zz_iconSize;
		break;
	}
}

function bool xxGetItemInfo( int zz_ClassID, out ItemInfo zz_info )
{
	local ItemInfo zz_clsInfo;

	zz_info = zz_clsInfo;

	if( !class'UIDATA_ITEM'.static.GetItemInfo( zz_ClassID, zz_info ) )
		return false;

	if( zz_info.PhysicalDamage > 0 || zz_info.MagicalDamage > 0 )
	{
		zz_info.ItemType = 0;
	}else if( zz_info.PhysicalDefense > 0 )
	{
		zz_info.ItemType = 1;
	}else if( zz_info.MagicalDefense > 0 )
	{
		zz_info.ItemType = 2;
	}else
	{
		zz_info.ItemType = 5;
	}

	return true;
}

function xxtoServer(string zzstr)
{
	RequestBypassToServer(zzstr);
}



function color GearColorRGBA(int R, int G, int B, int A)
{
    local color Result;
    Result.R = byte(R);
    Result.G = byte(G);
    Result.B = byte(B);
    Result.A = byte(A);
    return Result;
}

function int GearSplit(string Input, string Delimiter, out array<string> Tokens)
{
    local int Position, Row;
    Tokens.Length = 0;
    while (Len(Delimiter) > 0)
    {
        Position = InStr(Input, Delimiter);
        if (Position < 0) break;
        Row = Tokens.Length;
        Tokens.Length++;
        Tokens[Row] = Left(Input, Position);
        Input = Mid(Input, Position + Len(Delimiter));
    }
    Row = Tokens.Length;
    Tokens.Length++;
    Tokens[Row] = Input;
    return Tokens.Length;
}

function GearRowBackground(TreeHandle RowTree, string NodeName, int Index)
{
    if ((Index & 1) == 0)
        RowTree.InsertSimpleButton(NodeName, "MUI_GEAR.etc.GroupBox_df_LineBack");
    else
        RowTree.InsertSimpleButton(NodeName, "MUI_GEAR.null.null");
}

function GearSearchButton(TreeHandle RowTree, string NodeName)
{
    RowTree.InsertTexture(NodeName, "MUI_GEAR.null.null", "MUI_GEAR.RankingWnd.RankingWnd_SearchBtn", 28, 44, 5, "CenterRight", "CenterRight", 0, 0, true, true);
}

function AppendShopItemScore(string NodeName, ItemInfo Item)
{
    local int Score;
    Score = GetItemScore(0, Item.ClassID, Item.Enchanted);
    if (Score <= 0) return;
    TreeInsertNodeItemColor("MultiSellWnd.ItemListInfo", NodeName,
        "Gear Score: +" $ string(Score), 7, 5, GearColorRGBA(255,221,0,255), true, true);
}

function OpenTargetContext(int X, int Y)
{
    local UserInfo Info, SelfInfo;
    local Rect Bounds;
    local int ScreenW, ScreenH, MenuX, MenuY;
    if (ContextMenuWnd(GetScript("ContextMenuWnd")) == None) return;
    if (!GetTargetInfo(Info) || !GetPlayerInfo(SelfInfo)) return;
    if (Info.nID <= 0 || Info.nID == SelfInfo.nID || Info.bNpc || Info.bPet) return;
    Bounds = GetHandle("TargetStatusWnd").GetRect();
    if (X < Bounds.nX || X > Bounds.nX + Bounds.nWidth - 10) return;
    MenuX = X - 30; MenuY = Y - 40;
    GetCurrentResolution(ScreenW, ScreenH);
    if (MenuX + 128 > ScreenW) MenuX = ScreenW - 128;
    if (MenuX < 0) MenuX = 0;
    if (MenuY + 170 > ScreenH) MenuY = ScreenH - 170;
    if (MenuY < 0) MenuY = 0;
    ContextMenuWnd(GetScript("ContextMenuWnd")).contextType = 1;
    ContextMenuWnd(GetScript("ContextMenuWnd")).targetID = Info.nID;
    ContextMenuWnd(GetScript("ContextMenuWnd")).TargetName = Info.Name;
    TextBoxHandle(GetHandle("ContextMenuWnd.textContestName")).SetText(Info.Name);
    GetHandle("ContextMenuWnd").SetAnchor("TargetStatusWnd", "TopLeft", "TopLeft", MenuX - Bounds.nX, MenuY - Bounds.nY);
    GetHandle("ContextMenuWnd").ShowWindow();
    GetHandle("ContextMenuWnd").SetFocus();
}
function HideStaleTargetContext()
{
    local UserInfo Info;
    if (!GetHandle("ContextMenuWnd").IsShowWindow()) return;
    if (!GetTargetInfo(Info) || Info.nID != ContextMenuWnd(GetScript("ContextMenuWnd")).targetID)
        GetHandle("ContextMenuWnd").HideWindow();
}
function TargetContextAction(string ID)
{
    local UserInfo Info;
    if (!GetHandle("ContextMenuWnd").IsShowWindow()) return;
    if (ID == "btnClose") { GetHandle("ContextMenuWnd").HideWindow(); return; }
    if (ContextMenuWnd(GetScript("ContextMenuWnd")).contextType != 1) return;
    if (!GetTargetInfo(Info) || Info.nID != ContextMenuWnd(GetScript("ContextMenuWnd")).targetID || Info.bNpc || Info.bPet)
    { GetHandle("ContextMenuWnd").HideWindow(); return; }
    GetHandle("ContextMenuWnd").HideWindow();
    if (ID == "btnContext0")
        RequestInviteParty(ContextMenuWnd(GetScript("ContextMenuWnd")).TargetName);
    else if (ID == "btnContext1")
        ExecuteCommand("/trade");
    else if (ID == "btnContext2")
        SetChatMessage("\"" $ ContextMenuWnd(GetScript("ContextMenuWnd")).TargetName $ " ");
    else if (ID == "btnContext3")
        ExecuteCommand("/friendinvite " $ ContextMenuWnd(GetScript("ContextMenuWnd")).TargetName);
    else if (ID == "btnContext4")
    {
        if (RankingWnd(GetScript("RankingWnd")) == None) return;
        if (!GetHandle("RankingWnd").IsShowWindow()) OnClickButton("btnScoreRank");
        if (!GetHandle("RankingWnd").IsShowWindow()) return;
        ContextInspectName = ContextMenuWnd(GetScript("ContextMenuWnd")).TargetName;
        GetHandle("MileniumGearScore").SetTimer(9170002,1200);
    }
}
function bool TargetContextMouse(WindowHandle Handle)
{
    if (Handle == None) return false;
    if (Right(Handle.GetWindowName(),10) == "MenuLabel0") { TargetContextAction("btnContext0"); return true; }
    if (Right(Handle.GetWindowName(),10) == "MenuLabel1") { TargetContextAction("btnContext1"); return true; }
    if (Right(Handle.GetWindowName(),10) == "MenuLabel2") { TargetContextAction("btnContext2"); return true; }
    if (Right(Handle.GetWindowName(),10) == "MenuLabel3") { TargetContextAction("btnContext3"); return true; }
    if (Right(Handle.GetWindowName(),10) == "MenuLabel4") { TargetContextAction("btnContext4"); return true; }
    return false;
}
function FinishContextInspect()
{
    GetHandle("MileniumGearScore").KillTimer(9170002);
    if (InspectWnd(GetScript("InspectWnd")) != None && GetHandle("RankingWnd").IsShowWindow() && Len(ContextInspectName) > 0)
    {
        if (InspectWnd(GetScript("InspectWnd")).zz_Me == None)
            InspectWnd(GetScript("InspectWnd")).OnLoad();
        RequestBypassToServer("InspectPlayer?name=" $ ContextInspectName);
    }
    ContextInspectName = "";
}

defaultproperties
{
    BrightWhite=(R=255,G=255,B=255,A=255)
    BrightYellow=(R=230,G=217,B=190,A=255)
    Blue=(R=102,G=150,B=253,A=255)
    Red=(R=250,G=50,B=0,A=255)
    Gold=(R=176,G=153,B=121,A=255)
    Yellow03=(R=255,G=204,B=0,A=255)
    ColorGold=(R=176,G=153,B=121,A=255)
    ColorYellow=(R=255,G=221,B=102,A=255)
    White=(R=170,G=170,B=170,A=255)
    Gray=(R=120,G=120,B=120,A=255)
}
