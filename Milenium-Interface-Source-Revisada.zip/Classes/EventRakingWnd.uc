class EventRakingWnd extends UICommonAPI;

function OnLoad()
{
    // Registramos o evento diretamente sem depender da atribuição de handle global
    RegisterEvent(88900); 
}

function OnEvent(int Event_ID, string param)
{
    local int rankPos;
    local string playerName;

    if (Event_ID == 88900)
    {
        ParseInt(param, "Rank", rankPos);
        ParseString(param, "Name", playerName);

        if (rankPos >= 1 && rankPos <= 10)
        {
            AplicarIconeCabeca(playerName, rankPos);
        }
    }
}

function AplicarIconeCabeca(string alvoNome, int posicaoRank)
{
    local string nomeTextura;
    
    nomeTextura = "L2UI_CH3.AbnormalWnd.head_rank_" $ string(posicaoRank);

    // SetPawnHeadIcon(alvoNome, nomeTextura);
    
    Debug("Textura aplicada: " $ nomeTextura $ " para o player " $ alvoNome);
}