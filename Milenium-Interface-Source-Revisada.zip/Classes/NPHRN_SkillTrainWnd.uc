//================================================================================
// NPHRN_SkillTrainWnd.
//================================================================================

class NPHRN_SkillTrainWnd extends UICommonAPI;

var WindowHandle Me;
var bool IsMinimized;
var ItemWindowHandle SkillBox;
var ItemWindowHandle SkillActiveitemW[7];
var ItemInfo m_SkillInfo;
var bool EnableSkillProcess;
var int ComboEnchantSelect;
var int EnchantSkillLimit;
var TextBoxHandle Instruction;
var int TIMER_ENCHANTSKILL_DELAY;
var string SkillInstruction_Result;
var int m_Level;
var SkillTrainListWnd SkillTrainListWnd;
const MULTY_LS_SlIDER= 250;
const TIMER_SKILL_ID= 10500;

function OnLoad ()
{
  SkillTrainListWnd = SkillTrainListWnd(GetScript("SkillTrainListWnd"));

  RegisterXmls();
  Innit();
  Reset();
}

function RegisterXmls ()
{
  Me = GetHandle("NPHRN_SkillTrainWnd");
  SkillBox = ItemWindowHandle(GetHandle("NPHRN_SkillTrainWnd.SkillBox"));
  Instruction = TextBoxHandle(GetHandle("NPHRN_SkillTrainWnd.Instruction"));
}

function RegisterEvents ()
{
}

function OnHide ()
{
  if (  !IsMinimized )
  {
    Reset();
  }
}

function OnShow ()
{
  local UserInfo info;

  if ( GetPlayerInfo(info) )
  {
    m_Level = info.nLevel;
    if ( IsMinimized )
    {
      IsMinimized = False;
    } else {
      Reset();
      IsMinimized = False;
    }
    if (  SkillTrainListWnd.EnchantDialogOpened )
    {
      Instruction.SetText("Talk to the NPC Magister.");
    }
    if ( m_Level < 76 )
    {
      Instruction.SetText("You have not reached Lv 76.");
      Class'UIAPI_WINDOW'.static.ShowWindow("NPHRN_SkillTrainWnd.SkillBox_Lock");
      Class'UIAPI_WINDOW'.static.ShowWindow("NPHRN_SkillTrainWnd.SkillMod_Lock");
    } else {
      Class'UIAPI_WINDOW'.static.HideWindow("NPHRN_SkillTrainWnd.SkillBox_Lock");
      Class'UIAPI_WINDOW'.static.HideWindow("NPHRN_SkillTrainWnd.SkillMod_Lock");
    }
  }
}

function OnMinimize ()
{
  IsMinimized = True;
}

function OnEvent (int a_EventID, string a_Param)
{
  switch (a_EventID)
  {
    default:
  }
}

function Reset ()
{
  Instruction.SetText("Please select the skill.");
  Class'UIAPI_TEXTBOX'.static.SetText("NPHRN_SkillTrainWnd.valRecord","");
  Class'UIAPI_EDITBOX'.static.SetString("NPHRN_SkillTrainWnd.editCount","0");
  Class'UIAPI_EDITBOX'.static.SetString("NPHRN_SkillTrainWnd.editEnchantLvl","0");
  ComboEnchantSelect = 0;
  UpdateEnchantSkillParam();
}

function Innit ()
{
  local int CurrentTick;

  GetINIInt("AutoEnchantSkill","Delay_SkillEnchant",CurrentTick,"Option");
  SetDelay("Delay_SkillEnchant",CurrentTick,TIMER_ENCHANTSKILL_DELAY);
  Class'UIAPI_SLIDERCTRL'.static.SetCurrentTick("NPHRN_SkillTrainWnd.Enchant_Slider",CurrentTick);
}

function OnClickButton (string strID)
{
  switch (strID)
  {
    case "BtnEnchant":
    OnClickEnchantSkillStart();
    ExecuteCommand("/target verdure elder elikia");
    
    break;
    case "BtnPause":
    OnClickEnchantSkillCancel();
    RequestSelfTarget();
    break;
    default:
  }
}

function OnClickEnchantSkillStart ()
{
   
  if ( EnchantSkillLimit != 0 )
  {
		if ( !EnableSkillProcess)
		{
			EnchantSkill();
			EnableSkillProcess = True;
		}
  } else {
    Instruction.SetText("This skill can no longer be enchanted.");
  }
}

function OnClickEnchantSkillCancel ()
{
  StopEnchantSkill();
}

function SetDelay (string resultStr, int CurrentTick, out int Time)
{
  Time = 3300 - CurrentTick * 300;
  switch (resultStr)
  {
    case "Delay_SkillEnchant":
    SetINIInt("AutoEnchantSkill",resultStr,CurrentTick,"Option");
    break;
    default:
  }
}

function OnComboBoxItemSelected (string a_ControlID, int a_SelectedIndex)
{
  if ( a_ControlID == "TypeBox" )
  {
    ComboEnchantSelect = a_SelectedIndex;
  }
  Class'UIAPI_TEXTBOX'.static.SetText("NPHRN_SkillTrainWnd.SkillMod_State","+1 " $ Class'UIAPI_COMBOBOX'.static.GetString("NPHRN_SkillTrainWnd.TypeBox",a_SelectedIndex));
  Class'UIAPI_TEXTBOX'.static.SetText("NPHRN_SkillTrainWnd.Desc_SkillMod",Getm_SkillInfoString(Class'UIAPI_COMBOBOX'.static.GetString("NPHRN_SkillTrainWnd.TypeBox",a_SelectedIndex),1));
  class'UIAPI_TEXTURECTRL'.static.SetTexture("NPHRN_SkillTrainWnd.SkillType","clan.MS_Type_" $ Class'UIAPI_COMBOBOX'.static.GetString("NPHRN_SkillTrainWnd.TypeBox",a_SelectedIndex));
}

function OnChangeEditBox (string strID)
{
  switch (strID)
  {
    case "Enchant_Edit":
    EnchantSkillLimit = int(Class'UIAPI_EDITBOX'.static.GetString("NPHRN_SkillTrainWnd.Enchant_Edit"));
    break;
    default:
  }
}

function OnModifyCurrentTickSliderCtrl (string strID, int iCurrentTick)
{
  switch (strID)
  {
    case "Enchant_Slider":
    SetDelay("Delay_SkillEnchant",iCurrentTick,TIMER_ENCHANTSKILL_DELAY);
    break;
    default:
  }
}

function OnDropItem (string strID, ItemInfo a_ItemInfo, int X, int Y)
{
  if ( m_Level < 76 )
  {
    return;
  }
  switch (strID)
  {
    case "Skillbox":
    InsertDragSkill(a_ItemInfo);
    break;
    default:
  }
}

function InsertDragSkill (ItemInfo a_ItemInfo)
{
  local string EnchantString;

  EnchantString = Class'UIDATA_SKILL'.static.GetEnchantName(a_ItemInfo.ClassID,101);
  if ( EnchantString != "" )
  {
    m_SkillInfo = a_ItemInfo;
    DragSkill(m_SkillInfo);
    Instruction.SetText("Select Enchant Options");
    UpdateEnchantSkillParam();
    Handlem_SkillInfo(a_ItemInfo);
  } else {
    Instruction.SetText("This skill can not be enchanted.");
  }
}

function DragSkill (ItemInfo a_ItemInfo)
{
  SkillBox.Clear();
  SkillBox.AddItem(a_ItemInfo);
  UpdateCombobox(a_ItemInfo);
}

function AlarmWindow ()
{
  if ( IsMinimized )
  {
    Me.NotifyAlarm();
  }
}

  function GetSkillItemInfo(out ItemInfo Info)
{
  local int index;
  local ItemInfo Skill;
  local string classPath;
  local int foundIndex;

  
  RequestSkillList();

  
  for (index = 0; index <= 6; ++index)
  {
   
    
    
    if (index == 0)
    classPath = "MagicSkillWnd.ASkillScroll.ASkill" $ ".ASkill.ASkill" $ string(0) $ ".SkillItem";
    else
    classPath = "MagicSkillWnd.ASkillScroll.ASkill"$ ".ASkill.ASkill" $ string(index) $ "." $ GetItemTypeString(index);

    
    
    foundIndex = Class'UIAPI_ITEMWINDOW'.static.FindItemWithClassID(classPath, m_SkillInfo.ClassID);

    
    if (foundIndex != -1 && Class'UIAPI_ITEMWINDOW'.static.GetItem(classPath, foundIndex, Skill))
    {
      
      Info = Skill;
      
      
      SkillActiveitemW[index] = xxGetItemWindowHandle(classPath);
    }
  }


}


function string GetItemTypeString(int Index)
{
  switch (Index)
  {
    case 1: return "ActionBasicItem";
    case 2: return "MacroItem";
    case 3: return "ActionPartyItem";
    case 4: return "ActionSocialItem";
    case 5: return "SummonedActionWnd";
    case 6: return "PetActionWnd";
    default: return ""; 
  }
}


function UpdateEnchantSkillParam ()
{
  local UserInfo MyInfo;

  if ( GetPlayerInfo(MyInfo) )
  {
    Class'UIAPI_TEXTBOX'.static.SetText("NPHRN_SkillTrainWnd.SP_Count",MakeCostString("" $ string(MyInfo.nSP)));
  }
  Class'UIAPI_TEXTBOX'.static.SetText("NPHRN_SkillTrainWnd.Codex_Count","x " $ string(UpdateGiantBookCount()));
}

function int UpdateGiantBookCount ()
{
  local int BookCount;
  local int index;
  local int InvetoryItems;
  local int i;
  local ItemInfo BookInfo;
  local ItemInfo Info;

  BookCount = 0;
  InvetoryItems = Class'UIAPI_ITEMWINDOW'.static.GetItemNum("InventoryWnd.InventoryItem");
  index = Class'UIAPI_ITEMWINDOW'.static.FindItemWithClassID("InventoryWnd.InventoryItem",6622);
  if ( Class'UIAPI_ITEMWINDOW'.static.GetItem("InventoryWnd.InventoryItem",index,BookInfo) )
  {
    if ( BookInfo.ItemNum == 1 )
    {
      i = 0;
	  JL00BD:
      if ( i <= InvetoryItems )
      {
        if ( Class'UIAPI_ITEMWINDOW'.static.GetItem("InventoryWnd.InventoryItem",InvetoryItems,Info) )
        {
          if ( Info.ClassID == 6622 )
          {
            BookCount++;
          }
        }
        ++i;
        goto JL00BD;
      }
    } else {
      if ( BookInfo.ItemNum == 0 )
      {
        BookCount = 0;
      } else {
        BookCount = BookInfo.ItemNum;
      }
    }
  }
  return BookCount;
}

function EnchantSkill ()
{
  Class'UIAPI_WINDOW'.static.SetUITimer("NPHRN_SkillTrainWnd",10500,TIMER_ENCHANTSKILL_DELAY);
  GetSkillItemInfo(m_SkillInfo);
  if ( (m_SkillInfo.Level == EnchantSkillLimit + 100) || (m_SkillInfo.Level == EnchantSkillLimit + 140) )
  {
    StopEnchantSkill();
    Instruction.SetText("This Skill can not be enchanted.");
    AlarmWindow();
    Instruction.SetText(((SkillInstruction_Result @ Class'UIDATA_SKILL'.static.GetName(m_SkillInfo.ClassID,m_SkillInfo.Level)) $ " ") $ Class'UIDATA_SKILL'.static.GetEnchantName(m_SkillInfo.ClassID,m_SkillInfo.Level)); //$ "!");
    PlaySound("ItemSound3.Sys_Enchant_Success");
  } else {
    if ( (m_SkillInfo.Level < 100) && (ComboEnchantSelect == 0) )
    {
      RequestExEnchantSkill(m_SkillInfo.ClassID,101);
      Instruction.SetText("In process...");
    } else {
      if ( (m_SkillInfo.Level < 100) && (ComboEnchantSelect == 1) )
      {
        RequestExEnchantSkill(m_SkillInfo.ClassID,141);
        Instruction.SetText("In process...");
      } else {
        RequestExEnchantSkill(m_SkillInfo.ClassID,m_SkillInfo.Level + 1);
        Instruction.SetText("In process...");
      }
    }
  }
  GetSkillItemInfo(m_SkillInfo);
  DragSkill(m_SkillInfo);
  UpdateEnchantSkillParam();
  Handlem_SkillInfo(m_SkillInfo);
}

function StopEnchantSkill ()
{
  Class'UIAPI_WINDOW'.static.KillUITimer("NPHRN_SkillTrainWnd",10500);
  EnableSkillProcess = False;
  Instruction.SetText("Stop process...");
  return;
}

function UpdateCombobox (ItemInfo Skill)
{
  local string Enchant1Full;
  local string Enchant2Full;
  local array<string> Enchant1Name;
  local array<string> Enchant2Name;
  local int TempInt;
  local int tempInt2;

  Class'UIAPI_COMBOBOX'.static.Clear("NPHRN_SkillTrainWnd.TypeBox");
  Class'UIAPI_WINDOW'.static.EnableWindow("NPHRN_SkillTrainWnd.TypeBox");
  Class'UIAPI_COMBOBOX'.static.SetSelectedNum("NPHRN_SkillTrainWnd.TypeBox",ComboEnchantSelect);
  Enchant1Name.Length = 0;
  Enchant2Name.Length = 0;
  Enchant1Full = Class'UIDATA_SKILL'.static.GetEnchantName(Skill.ClassID,101);
  Enchant2Full = Class'UIDATA_SKILL'.static.GetEnchantName(Skill.ClassID,141);
  TempInt = Split(Enchant1Full," ",Enchant1Name);
  tempInt2 = Split(Enchant2Full," ",Enchant2Name);
  if ( Enchant1Name[1] != "" )
  {
    Class'UIAPI_COMBOBOX'.static.AddString("NPHRN_SkillTrainWnd.TypeBox",Enchant1Name[1]);
  }
  if ( Enchant2Name[1] != "" )
  {
    Class'UIAPI_COMBOBOX'.static.AddString("NPHRN_SkillTrainWnd.TypeBox",Enchant2Name[1]);
  }
  if ( (m_SkillInfo.Level > 100) && (m_SkillInfo.Level < 131) )
  {
    Class'UIAPI_COMBOBOX'.static.SetSelectedNum("NPHRN_SkillTrainWnd.TypeBox",ComboEnchantSelect);
    Class'UIAPI_WINDOW'.static.DisableWindow("NPHRN_SkillTrainWnd.TypeBox");
  }
  if ( m_SkillInfo.Level > 131 )
  {
    Class'UIAPI_COMBOBOX'.static.SetSelectedNum("NPHRN_SkillTrainWnd.TypeBox",ComboEnchantSelect);
    Class'UIAPI_WINDOW'.static.DisableWindow("NPHRN_SkillTrainWnd.TypeBox");
  }
  class'UIAPI_TEXTURECTRL'.static.SetTexture("NPHRN_SkillTrainWnd.SkillType","clan.MS_Type_" $ Class'UIAPI_COMBOBOX'.static.GetString("NPHRN_SkillTrainWnd.TypeBox",ComboEnchantSelect));
}

function OnTimer (int TimerID)
{
  switch (TimerID)
  {
    case 10500:
    Class'UIAPI_WINDOW'.static.KillUITimer("NPHRN_SkillTrainWnd",10500);
    EnchantSkill();
    break;
    default:
  }
}

function SetFirstOption ()
{
  SetINIInt("AutoEnchantSkill","Delay_SkillEnchant",3,"Option");
}

function Handlem_SkillInfo (ItemInfo a_ItemInfo)
{
  class'UIAPI_TEXTURECTRL'.static.SetTexture("NPHRN_SkillTrainWnd.SkillMod",a_ItemInfo.IconName);
  Class'UIAPI_TEXTBOX'.static.SetText("NPHRN_SkillTrainWnd.SkillBox_Name",a_ItemInfo.Name);
  Class'UIAPI_TEXTBOX'.static.SetText("NPHRN_SkillTrainWnd.SkillMod_Name",a_ItemInfo.Name);
  if ( a_ItemInfo.Level > 100 )
  {
    Class'UIAPI_TEXTBOX'.static.SetText("NPHRN_SkillTrainWnd.SkillBox_Lv","Lv " $ string(Class'UIDATA_SKILL'.static.GetEnchantSkillLevel(a_ItemInfo.ClassID,a_ItemInfo.Level)));
    Class'UIAPI_TEXTBOX'.static.SetText("NPHRN_SkillTrainWnd.SkillMod_Lv","Lv " $ string(Class'UIDATA_SKILL'.static.GetEnchantSkillLevel(a_ItemInfo.ClassID,a_ItemInfo.Level)));
  } else {
    Class'UIAPI_TEXTBOX'.static.SetText("NPHRN_SkillTrainWnd.SkillBox_Lv","Lv " $ string(a_ItemInfo.Level));
    Class'UIAPI_TEXTBOX'.static.SetText("NPHRN_SkillTrainWnd.SkillMod_Lv","Lv " $ string(a_ItemInfo.Level));
  }
  Class'UIAPI_TEXTBOX'.static.SetText("NPHRN_SkillTrainWnd.SkillBox_State",a_ItemInfo.AdditionalName);
  Class'UIAPI_TEXTBOX'.static.SetText("NPHRN_SkillTrainWnd.SkillMod_State","+" $ string(UnkFunc(a_ItemInfo.AdditionalName) + 1) $ " " $ EnchantSkillType(a_ItemInfo.AdditionalName));
  Class'UIAPI_TEXTBOX'.static.SetText("NPHRN_SkillTrainWnd.Desc_SkillBox",Getm_SkillInfoString(EnchantSkillType(a_ItemInfo.AdditionalName),0));
  Class'UIAPI_TEXTBOX'.static.SetText("NPHRN_SkillTrainWnd.Desc_SkillMod",Getm_SkillInfoString(EnchantSkillType(a_ItemInfo.AdditionalName),1));
  Class'UIAPI_TEXTBOX'.static.SetText("NPHRN_SkillTrainWnd.SuccessRate","Success " $ string(UnkFunc2QWQ(m_Level,UnkFunc(a_ItemInfo.AdditionalName) + 1)) $ " %");
  if ( Class'UIAPI_TEXTBOX'.static.GetText("NPHRN_SkillTrainWnd.Desc_SkillBox") == "" )
  {
    Class'UIAPI_TEXTBOX'.static.SetText("NPHRN_SkillTrainWnd.Desc_SkillBox","This skill is currently not enchanted.");
    Class'UIAPI_TEXTBOX'.static.SetText("NPHRN_SkillTrainWnd.SkillMod_State","");
  }
}

function string EnchantSkillType (string a_Param)
{
  local string resultStr;

  if ( Right(a_Param,5) == "Power" )
  {
    resultStr = "Power";
  } else {
    if ( Right(a_Param,6) == "Chance" )
    {
      resultStr = "Chance";
    } else {
      if ( Right(a_Param,4) == "Cost" )
      {
        resultStr = "Cost";
      } else {
        if ( Right(a_Param,4) == "Time" )
        {
          resultStr = "Time";
        } else {
          if ( Right(a_Param,8) == "Recovery" )
          {
            resultStr = "Recovery";
          }
        }
      }
    }
  }
  return resultStr;
}

function int UnkFunc (string a_Param)
{
  local int resultInt;

  resultInt = int(a_Param);
  return resultInt;
}

function int GetIniInfo (string a_Param, int i)
{
  local int resultInt;

  GetINIInt(m_SkillInfo.Name $ " " $ a_Param $ "","" $ string(i),resultInt,"Skillgrp");
  return resultInt;
}

function string Getm_SkillInfoString (string a_Param, int i)
{
  local string text;
  local int resultInt;
  local string resultStr;

  switch (m_SkillInfo.Name)
  {
    case "Soul of Sagittarius":
    case "Mass Slow":
    case "Sacrifice":
    resultStr = "HP";
    break;
    default:
    resultStr = "MP";
    break;
  }
  resultInt = GetIniInfo(a_Param,UnkFunc(m_SkillInfo.AdditionalName) + i);
  switch (a_Param)
  {
    case "Power":
    if ( resultInt != 0 )
    {
      text = "Maximizes power of skill. Power increases to " $ string(resultInt) $ ".";
    } else {
      text = "Maximizes power of skill. Power increases.";
    }
    break;
    case "Chance":
    if ( resultInt != 0 )
    {
      text = "Maximizes the skills success rate. Success rate increases to " $ string(resultInt) $ "%.";
    } else {
      text = "Maximizes the skills success rate. Success rate increases.";
    }
    break;
    case "Cost":
    if ( resultInt != 0 )
    {
      text = "Maximizes efficiency of skill. Consumption decreases to " $ string(resultInt) $ " " $ resultStr $ ".";
    } else {
      text = "Maximizes efficiency of skill. MP consumption decreases.";
    }
    break;
    case "Time":
    if ( resultInt != 0 )
    {
      text = "Maximizes the duration of skill. Increases the duration to " $ string(resultInt) $ " sec.";
    } else {
      text = "Maximizes the duration of skill. Increases the duration.";
    }
    break;
    case "Recovery":
    if ( resultInt != 0 )
    {
      text = "Minimizes the skill's re-use time. The re-use time is decreases to " $ string(resultInt) $ " sec.";
    } else {
      text = "Minimizes the skill's re-use time. The re-use time is decreases.";
    }
    break;
    default:
  }
  return text;
}

function int UnkFunc2QWQ (int i, int j)
{
  local int resultInt;

  if ( i >= 78 )
  {
    switch (j)
    {
      case 1:
      resultInt = 97;
      break;
      case 2:
      resultInt = 95;
      break;
      case 3:
      resultInt = 93;
      break;
      case 4:
      resultInt = 92;
      break;
      case 5:
      resultInt = 90;
      break;
      case 6:
      resultInt = 88;
      break;
      case 7:
      resultInt = 82;
      break;
      case 8:
      resultInt = 80;
      break;
      case 9:
      resultInt = 78;
      break;
      case 10:
      resultInt = 40;
      break;
      case 11:
      resultInt = 30;
      break;
      case 12:
      resultInt = 20;
      break;
      case 13:
      resultInt = 14;
      break;
      case 14:
      resultInt = 10;
      break;
      case 15:
      resultInt = 6;
      break;
      case 16:
      resultInt = 2;
      break;
      case 17:
      resultInt = 2;
      break;
      case 18:
      resultInt = 2;
      break;
      case 19:
      resultInt = 1;
      break;
      case 20:
      resultInt = 1;
      break;
      default:
    }
  }
  if ( i == 77 )
  {
    switch (j)
    {
      case 1:
      resultInt = 92;
      break;
      case 2:
      resultInt = 90;
      break;
      case 3:
      resultInt = 88;
      break;
      case 4:
      resultInt = 82;
      break;
      case 5:
      resultInt = 80;
      break;
      case 6:
      resultInt = 78;
      break;
      case 7:
      resultInt = 40;
      break;
      case 8:
      resultInt = 30;
      break;
      case 9:
      resultInt = 20;
      break;
      case 10:
      resultInt = 14;
      break;
      case 11:
      resultInt = 10;
      break;
      case 12:
      resultInt = 6;
      break;
      case 13:
      case 14:
      case 15:
      resultInt = 2;
      break;
      case 16:
      case 17:
      case 18:
      case 19:
      case 20:
      resultInt = 1;
      break;
      default:
    }
  }
  if ( i == 76 )
  {
    switch (j)
    {
      case 1:
      resultInt = 82;
      break;
      case 2:
      resultInt = 80;
      break;
      case 3:
      resultInt = 78;
      break;
      case 4:
      resultInt = 40;
      break;
      case 5:
      resultInt = 30;
      break;
      case 6:
      resultInt = 20;
      break;
      case 7:
      resultInt = 14;
      break;
      case 8:
      resultInt = 10;
      break;
      case 9:
      resultInt = 6;
      break;
      case 10:
      resultInt = 2;
      break;
      case 11:
      resultInt = 2;
      break;
      case 12:
      case 13:
      case 14:
      case 15:
      case 16:
      case 17:
      case 18:
      case 19:
      case 20:
      resultInt = 1;
      break;
      default:
    }
  }
  return resultInt;
}
defaultproperties
{
}
