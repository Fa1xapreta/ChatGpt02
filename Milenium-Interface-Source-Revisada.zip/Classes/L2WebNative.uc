class L2WebNative extends Object;
native static final function int PrepareSurface(Texture surface);
native static final function int Open(WindowHandle viewport,Texture surface,int tab,string url);
native static final function int Tick();
native static final function int Hide();
native static final function int Focus(bool focused);
native static final function int Mouse(int eventType,int x,int y);
native static final function int PollHotkey();
native static final function int ReportState(int stateCode);
native static final function int SetVolume(int percent);
native static final function int SetCaption(WindowHandle button,string caption);
native static final function int HasFocus();
native static final function int ClearData();
native static final function int ClearState();
native static final function int SetFrameRect(WindowHandle control,int u,int v,int width,int height);
defaultproperties
{
}
