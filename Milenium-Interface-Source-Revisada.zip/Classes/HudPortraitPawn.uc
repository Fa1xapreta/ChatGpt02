class HudPortraitPawn extends Pawn;

var bool ClassicPoseReady,PortraitFocusValid;
var vector PortraitFocus;
var name PortraitIdleSequence;
var float PortraitIdleFrame,PortraitIdleRate;

static function string AppearanceKey(Pawn source)
{
 local string value;local int i;
 if(source==None||source.Mesh==None)return "";
 value=string(source.Mesh)$":"$string(source.DrawScale)$":"$string(source.DrawScale3D);
 for(i=0;i<source.Skins.Length;i++)value=value$":"$string(source.Skins[i]);
 for(i=0;i<9;i++)value=value$":"$string(source.SubMeshes[i])$":"$string(source.SubSkins[i]);
 for(i=0;i<source.ExtraMeshDatas.Length;i++)if(source.ExtraMeshDatas[i]!=None)
  value=value$":"$string(source.ExtraMeshDatas[i].ExtraMesh)$":"$string(source.ExtraMeshDatas[i].ExtraTex);
 return value;
}
function PrepareClassicAppearance(Pawn source)
{
 SetOwner(None);Instigator=None;SetRotation(rot(0,0,0));DesiredRotation=rot(0,0,0);
 bOwnerNoSee=False;bOnlyOwnerSee=False;bNeedSetPawnResource=False;
 SetCollisionSize(source.CollisionRadius,source.CollisionHeight);
 SetDrawScale(source.DrawScale);SetDrawScale3D(source.DrawScale3D);
 LoadingResourceRef=0;bCreatedResource=False;ClassicPoseReady=False;PortraitFocusValid=False;
}
static function name PortraitIdleFor(string family)
{
 switch(Caps(family))
 {
  case "FFIGHTER":return 'Wait_Hand_FFighter';
  case "MFIGHTER":return 'Wait_Hand_MFighter';
  case "FMAGIC":return 'Wait_Hand_FMagic';
  case "MMAGIC":return 'Wait_Hand_MMagic';
  case "FELF":return 'Wait_Hand_FElf';
  case "MELF":return 'Wait_Hand_MElf';
  case "FDARKELF":return 'Wait_Hand_FDarkElf';
  case "MDARKELF":return 'Wait_Hand_MDarkElf';
  case "FORC":return 'Wait_Hand_FOrc';
  case "MORC":return 'Wait_Hand_MOrc';
  case "FSHAMAN":return 'Wait_Hand_FShaman';
  case "MSHAMAN":return 'Wait_Hand_MShaman';
  case "FDWARF":return 'Wait_Hand_FDwarf';
  case "MDWARF":return 'Wait_Hand_MDwarf';
 }
 return '';
}
function UpdateClassicPose()
{
 local MeshAnimation animation;local string family,packageName;local int separator;local name idle;local coords head;
 SetRotation(rot(0,0,0));DesiredRotation=rot(0,0,0);
 LastRenderTime=Level.TimeSeconds;
 if(Mesh==None||LoadingResourceRef>0)return;
 GetAnimParams(0,PortraitIdleSequence,PortraitIdleFrame,PortraitIdleRate);
 // Keep the idle animation, but refresh world-space head focus on every poll.
 if(!(ClassicPoseReady&&IsAnimating()))
 {
 family=string(Mesh.Name);separator=InStr(family,"_");if(separator>0)family=Left(family,separator);
 if(InStr(family,"Fighter")>=0)packageName="Fighter";
 else if(InStr(family,"Magic")>=0)packageName="Magic";
 else if(InStr(family,"DarkElf")>=0)packageName="DarkElf";
 else if(InStr(family,"Elf")>=0)packageName="Elf";
 else if(InStr(family,"Shaman")>=0)packageName="Shaman";
 else if(InStr(family,"Orc")>=0)packageName="Orc";
 else packageName="Dwarf";
 animation=MeshAnimation(DynamicLoadObject(packageName$"."$family$"_anim",class'MeshAnimation',true));
 if(animation!=None)LinkSkelAnim(animation);
 idle=PortraitIdleFor(family);
 if(idle==''||!HasAnim(idle))return;
 LoopAnim(idle,1.0,0.0);
 }
 BoneRefresh();head=GetBoneCoords(HeadBone);PortraitFocus=head.Origin;
 PortraitFocusValid=VSize(PortraitFocus-Location)>1.0&&VSize(PortraitFocus-Location)<500.0;
 GetAnimParams(0,PortraitIdleSequence,PortraitIdleFrame,PortraitIdleRate);
 ClassicPoseReady=True;
}

defaultproperties
{
 DrawType=DT_Mesh
 RemoteRole=ROLE_None
 Physics=PHYS_None
 bCollideActors=False
 bCollideWorld=False
 bBlockActors=False
 bBlockPlayers=False
 bProjTarget=False
 bUnlit=True
 bHidden=True
 bOwnerNoSee=False
 bOnlyOwnerSee=False
 bNeedSetPawnResource=False
 LoadingResourceRef=-1
 bCheckChangableLevel=False
 bUpdateSimulatedPosition=False
 bShouldBaseAtStartup=False
 ControllerClass=None
 bAlwaysRelevant=False
 bNetTemporary=True
 bStatic=False
 bNoDelete=False
 bStasis=False
 bAlwaysTick=True
 bClientAnim=True
 bUpdateMovementAnim=False
 bFaceRotation=False
 bEnableFaceRotation=False
 LifeSpan=0.0
 AmbientGlow=255
}
