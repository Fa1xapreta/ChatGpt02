class TargetHeaderPlayer extends UICommonAPI;

var TextureHandle zzplayerclass;
var TextureHandle zzhpbar;
var TextureHandle zzcpbar;
var TextureHandle zzoverlay;
var TextureHandle zzbgbar;
var WindowHandle zzme;
var int zzTargetVip;
var int zzisadmin;
var int zzgearcore, zzgeartarget;
var string zzcastlename, zzrankgeneral, zzrankrace, zzrankclass;
var int zzpvptarget;
var int zzpktarget;
var int zzdeathstarget;

var int zzTargetClassId;
var int zzTargetLevel;
var int zzTargetFlag;
var UserInfo zzTargetInfo;

function OnLoad()
{
    RegisterEvent(88521);
    RegisterEvent(88522);
    RegisterEvent(88523);
    RegisterEvent(140);

    zzisadmin = 0;
    zzTargetVip = -1;

    zzme = GetHandle("TargetHeaderPlayer");

    zzplayerclass = xxGetTextureHandle(
        "TargetHeaderPlayer.BarraHud.PlayerClass"
    );

    zzhpbar = xxGetTextureHandle(
        "TargetHeaderPlayer.BarraHud.HPBar_HP"
    );

    zzcpbar = xxGetTextureHandle(
        "TargetHeaderPlayer.BarraHud.HPBar_CP"
    );

    zzoverlay = xxGetTextureHandle(
        "TargetHeaderPlayer.BarraHud.HPBar_Overlay"
    );

    zzbgbar = xxGetTextureHandle(
        "TargetHeaderPlayer.BarraHud.HPBar_BG"
    );
}

function OnEvent(int Event_ID, string param)
{
    local string zztext;

    switch (Event_ID)
    {
        case 140:
            ReceiveTargetPlayerInfo(param);
            break;

        case 88521:
            ParseInt(param, "ClassId", zzTargetClassId);
            ParseInt(param, "Level", zzTargetLevel);
            ParseInt(param, "Flag", zzTargetFlag);

            zztext = GetClassIconTexture(
                zzTargetClassId,
                zzTargetFlag,
                zzTargetInfo.nCriminalRate
            );

            zzplayerclass.SetTexture(zztext);

            UpdatePlayerTooltip();
            break;

        case 88522:
            ParseInt(param, "isadmin", zzisadmin);
            break;
    }
}

function xxsetinico(int TargetClassId,int TargetLevel,int TargetFlag,UserInfo zzinfo)
{
    local string zztext;

    // Limpa os dados quando troca de personagem selecionado.
        if (zzTargetInfo.nID != zzinfo.nID)
    {
        zzpvptarget = 0;
        zzpktarget = 0;
        zzdeathstarget = 0;
        zzTargetVip = -1;
        zzcastlename = "...";
    }

    zzTargetClassId = TargetClassId;
    zzTargetLevel = TargetLevel;
    zzTargetFlag = TargetFlag;
    zzTargetInfo = zzinfo;

    zztext = GetClassIconTexture(
        TargetClassId,
        TargetFlag,
        zzinfo.nCriminalRate
    );

    zzplayerclass.SetTexture(zztext);
    zzme.ShowWindow();

    UpdatePlayerTooltip();

    if (zzinfo.nID > 0)
    {
        RequestBypassToServer(
            "TargetPlayerInfo "$string(zzinfo.nID)
        );
    }
}

// Função Auxiliar para centralizar a lógica do ícone
function string GetClassIconTexture(int classId, int flag, int criminalRate)
{
    local int isFlagged;
    
    isFlagged = 0;
    if (flag > 0 || criminalRate > 0)
        isFlagged = 1;

    if(isMage(classId))
    {
        if (isFlagged > 0) return "LotusHead.icon_red_classtype_3";
        return "LotusHead.icon_green_classtype_3";
    }
    else if(isTankes(classId))
    {
        if (isFlagged > 0) return "LotusHead.icon_red_classtype_6";
        return "LotusHead.icon_green_classtype_6";
    }
    else if(isArco(classId))
    {
        if (isFlagged > 0) return "LotusHead.icon_red_classtype_2";
        return "LotusHead.icon_green_classtype_2";
    }
    else if(isHealer(classId))
    {
        if (isFlagged > 0) return "LotusHead.icon_red_classtype_5";
        return "LotusHead.icon_green_classtype_5";
    }
    else if(isDuales(classId))
    {
        if (isFlagged > 0) return "LotusHead.icon_red_classtype_7";
        return "LotusHead.icon_green_classtype_7";
    }
    else
    {
        if (isFlagged > 0) return "LotusHead.icon_red_classtype_1";
        return "LotusHead.icon_green_classtype_1";
    }
}

function CustomTooltip xxMakeTooltipItens(string zztitulo, string strItens, string itemCounts, string chance, string Name, string GearPoint, string PvP, string PK, string Deaths, string ClanName) 
{
    local CustomTooltip zzToolTip;
    local Color LabelColor, VipColor;
    local string VipText;
    local int ContentWidth, TextWidth, NameOffsetX;

    LabelColor = GetColortool(210, 210, 210, 255);
    ContentWidth = 142;

    if (zzTargetVip == 1)
    {
        VipText = "Ativo";
        VipColor = GetColortool(95, 215, 105, 255);
    }
    else if (zzTargetVip == 0)
    {
        VipText = "Inativo";
        VipColor = GetColortool(255, 95, 95, 255);
    }
    else
    {
        VipText = "Aguardando...";
        VipColor = LabelColor;
    }

    if (
        ClanName == "" ||
        ClanName == "No_Clan" ||
        ClanName == "No Clan"
    )
        ClanName = "Sem clan";

    TextWidth = GetTextWidth(Name) + 6;

    if (TextWidth > ContentWidth)
        ContentWidth = TextWidth;

    TextWidth = GetTextWidth(chance) + 40;

    if (TextWidth > ContentWidth)
        ContentWidth = TextWidth;

    TextWidth = GetTextWidth("Clan: "$ClanName) + 12;

    if (TextWidth > ContentWidth)
        ContentWidth = TextWidth;

    TextWidth = GetTextWidth(
        "PvP:"$PvP$"PK:"$PK$"Mortes:"$Deaths
    ) + 38;

    if (TextWidth > ContentWidth)
        ContentWidth = TextWidth;

    TextWidth = GetTextWidth("Premium: "$VipText) + 12;

    if (TextWidth > ContentWidth)
        ContentWidth = TextWidth;

    NameOffsetX = 3 + (
        (ContentWidth - GetTextWidth(Name)) / 2
    );

    zzToolTip.MinimumWidth = ContentWidth + 6;
    zzToolTip.DrawList.Length = 20;

    // Nome centralizado.
    zzToolTip.DrawList[0] = xxDrawText(
        Name,
        xxgetInstanceL2Util().HotPink,
        True, True, NameOffsetX, 3
    );

    zzToolTip.DrawList[1] = DrawTex(
        "L2UI_CH3.tooltip_line",
        ContentWidth, 1, 1, 1, 1, 8, True, True
    );

    // Classe e nivel.
    zzToolTip.DrawList[2] = DrawTex(
        "L2UI_CH3.Tooltip.lifeBG",
        26, 26, 18, 18, 3, 8, True, True
    );

    zzToolTip.DrawList[3] = DrawTex(
        strItens,
        24, 24, 24, 24, -25, 9, True, False
    );

    zzToolTip.DrawList[4] = xxDrawText(
        chance,
        GetColortool(206, 185, 151, 255),
        True, False, 5, 7
    );

    zzToolTip.DrawList[5] = xxDrawText(
        "Lv: "$itemCounts,
        xxgetInstanceL2Util().Yellow,
        True, True, 33, -14
    );

    zzToolTip.DrawList[6] = DrawTex(
        "L2UI_CH3.tooltip_line",
        ContentWidth, 1, 1, 1, 1, 8, True, True
    );

    // PvP, PK e Mortes.
    zzToolTip.DrawList[7] = xxDrawText(
        "PvP:", LabelColor,
        True, True, 3, 3
    );

    zzToolTip.DrawList[8] = xxDrawText(
        PvP,
        GetColortool(80, 170, 255, 255),
        True, False, 3, 3
    );

    zzToolTip.DrawList[9] = xxDrawText(
        "PK:", LabelColor,
        True, False, 10, 3
    );

    zzToolTip.DrawList[10] = xxDrawText(
        PK,
        GetColortool(255, 95, 95, 255),
        True, False, 3, 3
    );

    zzToolTip.DrawList[11] = xxDrawText(
        "Mortes:", LabelColor,
        True, False, 10, 3
    );

    zzToolTip.DrawList[12] = xxDrawText(
        Deaths,
        GetColortool(235, 205, 110, 255),
        True, False, 3, 3
    );

    // Separador entre os contadores e o Premium.
    zzToolTip.DrawList[13] = DrawTex(
        "L2UI_CH3.tooltip_line",
        ContentWidth, 1, 1, 1, 1, 8, True, True
    );

    // Premium.
    zzToolTip.DrawList[14] = xxDrawText(
        "Premium:", LabelColor,
        True, True, 3, 4
    );

    zzToolTip.DrawList[15] = xxDrawText(
        VipText, VipColor,
        True, False, 3, 4
    );

    zzToolTip.DrawList[16] = DrawTex(
        "L2UI_CH3.tooltip_line",
        ContentWidth, 1, 1, 1, 1, 8, True, True
    );

    // Clan.
    zzToolTip.DrawList[17] = xxDrawText(
        "Clan:", LabelColor,
        True, True, 3, 4
    );

    zzToolTip.DrawList[18] = xxDrawText(
        ClanName,
        GetColortool(145, 210, 165, 255),
        True, False, 3, 4
    );

    zzToolTip.DrawList[19] = xxDrawBlank(3);

    return zzToolTip;
}

function ReceiveTargetPlayerInfo(string Params)
{
    local string Message;
    local array<string> Fields;
    local int TargetId;

    ParseString(Params, "Msg", Message);

    Split(Message, "|", Fields);

    if (Fields.Length != 6 && Fields.Length != 7)
        return;

    if (Fields[0] != "CustomEvent=TargetPlayerV1")
        return;

    TargetId = int(Fields[1]);

    if (TargetId <= 0 || TargetId != zzTargetInfo.nID)
        return;

    zzpvptarget = int(Fields[2]);
    zzpktarget = int(Fields[3]);
    zzdeathstarget = int(Fields[4]);
    zzcastlename = Fields[5];

    zzTargetVip = -1;

    if (Fields.Length == 7)
    {
        if (Fields[6] == "1")
            zzTargetVip = 1;
        else if (Fields[6] == "0")
            zzTargetVip = 0;
    }

    if (zzcastlename == "No_Clan" || zzcastlename == "")
        zzcastlename = "No Clan";

    UpdatePlayerTooltip();
}

function UpdatePlayerTooltip()
{
    local string levelReal;
    local CustomTooltip zzToolTip;

    if (zzTargetInfo.nID <= 0)
        return;

    if (zzTargetLevel > 0)
        levelReal = string(zzTargetLevel);
    else
        levelReal = string(zzTargetInfo.nLevel);

    zzToolTip = xxMakeTooltipItens(
        xxgetInstanceL2Util().xxgetAD(),
        xxgetcosaku211a(zzTargetClassId),
        levelReal,
        GetClassType(zzTargetClassId),
        zzTargetInfo.Name,
        "",
        string(zzpvptarget),
        string(zzpktarget),
        string(zzdeathstarget),
        zzcastlename
    );

    xxGetWindowHandle(
        "TargetHeaderPlayer.BarraHud"
    ).SetTooltipCustomType(zzToolTip);
}
