class InteractionWnd extends UICommonAPI;

const MINING_TIMER = 78120;
const MINING_RANGE = 200.0;
const E_KEY = 69;

// Intervalo desejado entre cada ponto percentual.
const PERCENT_STEP_TIME = 0.02;

// Tempo que mostra 100% antes de esconder.
const COMPLETE_DISPLAY_TIME = 0.25;

var WindowHandle Me;
var WindowHandle KeyWnd;
var WindowHandle LoadWnd;
var WindowHandle TextWnd;

var TextBoxHandle PercentText;

var TextureHandle Circle;
var TextureHandle Letters[20];

var EditBoxHandle ChatInput;

// 0 = oculto
// 1 = disponivel
// 2 = aguardando servidor
// 3 = minerando
// 4 = concluindo animacao depois do sucesso
var int MiningState;
var int RockId;
var int RequestId;

var int LastPercent;
var int TargetPercent;

var float NextPercentTime;
var float CompleteUntil;

var float RequestTime;
var float LastHoldTime;
var float LastServerTime;

var bool bPreviousE;
var bool bRequireRelease;
var bool bInitialized;

function DrawMiningText(optional string Title)
{
    local int i, Code, Width, X;

    if (Title == "")
    {
        Title = "Minerar";
    }

    Title = Left(Title, 20);
    X = 0;

    for (i = 0; i < 20; i++)
    {
        Letters[i].HideWindow();
    }

    for (i = 0; i < Len(Title); i++)
    {
        Code = Asc(Mid(Title, i, 1));

        switch (Code)
        {
            case 77:
                Width = 23;
                break;

            case 105:
                Width = 7;
                break;

            case 110:
                Width = 14;
                break;

            case 101:
                Width = 11;
                break;

            case 114:
                Width = 10;
                break;

            case 97:
                Width = 11;
                break;

            case 100:
                Width = 13;
                break;

            case 111:
                Width = 13;
                break;

            case 32:
                Width = 8;
                break;

            case 46:
                Width = 7;
                break;

            default:
                Width = 16;
                break;
        }

        Letters[i].ClearAnchor();

        Letters[i].SetAnchor(
            "InteractionWnd.text_interaction_box",
            "TopLeft",
            "TopLeft",
            X,
            0
        );

        Letters[i].SetUV(
            (Code - int(float(Code) / 32.0) * 32) * 25,
            int(float(Code) / 32.0) * 30
        );

        Letters[i].SetWindowSize(Width, 30);
        Letters[i].ShowWindow();

        X += Width;
    }
}

function UpdatePercent(int Value)
{
    if (Value < 0)
    {
        Value = 0;
    }

    if (Value > 100)
    {
        Value = 100;
    }

    if (Value == LastPercent)
    {
        return;
    }

    LastPercent = Value;

    Circle.SetTexture(
        "L2UI_CH3.InteractionLoad.circle_" $ string(Value)
    );

    PercentText.SetText(string(Value) $ "%");
}

function SendMiningCommand(string Command)
{
    RequestBypassToServer(
        Command
        $ " "
        $ string(RockId)
        $ " "
        $ string(RequestId)
    );
}

function NotifyCancel()
{
    if (RockId > 0
        && (MiningState == 2 || MiningState == 3))
    {
        SendMiningCommand("MiningCancel");
    }
}

function ClearMining(bool bNotify)
{
    if (bNotify)
    {
        NotifyCancel();
    }

    RockId = 0;
    MiningState = 0;

    TargetPercent = 0;
    NextPercentTime = 0.0;
    CompleteUntil = 0.0;

    bRequireRelease = true;

    KeyWnd.HideWindow();
    LoadWnd.HideWindow();
    Me.HideWindow();
}

function ShowAvailable()
{
    MiningState = 1;

    KeyWnd.ShowWindow();
    LoadWnd.HideWindow();

    TextWnd.ClearAnchor();

    TextWnd.SetAnchor(
        "InteractionWnd.key_state.key",
        "TopRight",
        "TopLeft",
        5,
        2
    );

    DrawMiningText();

    Me.SetAlpha(255);
    Me.ShowWindow();
}

function CancelAttempt()
{
    NotifyCancel();

    TargetPercent = Max(0, LastPercent);
    NextPercentTime = 0.0;
    CompleteUntil = 0.0;

    bRequireRelease = true;

    ShowAvailable();
}

function bool MiningAltDown()
{
    return IsKeyDown(EInputKey(18))
        || IsKeyDown(EInputKey(164))
        || IsKeyDown(EInputKey(165));
}

function bool MiningKeysDown()
{
    return MiningAltDown()
        && IsKeyDown(EInputKey(E_KEY));
}

function bool ChatIsFocused()
{
    if (MiningAltDown())
    {
        return false;
    }

    if (ChatInput == None)
    {
        return false;
    }

    return ChatInput.IsFocused();
}

function bool StoneIsNear()
{
    local Actor PlayerActor;
    local Pawn StonePawn;
    local UserInfo PlayerInfo;

    if (RockId <= 0)
    {
        return false;
    }

    if (!GetPlayerInfo(PlayerInfo))
    {
        return false;
    }

    if (PlayerInfo.nCurHP <= 0)
    {
        return false;
    }

    if (!GetPlayerActor(PlayerActor))
    {
        return false;
    }

    foreach PlayerActor.CollidingActors(
        class'Engine.Pawn',
        StonePawn,
        MINING_RANGE,
        PlayerInfo.Loc)
    {
        if (StonePawn.CreatureID == RockId)
        {
            return VSize(
                StonePawn.Location - PlayerInfo.Loc
            ) <= MINING_RANGE;
        }
    }

    return false;
}

function PositionMining()
{
    local float X, Y;
    local int Width, Height;

    X = -10000.0;
    Y = -10000.0;

    xxheaderhpplayerByID(RockId, X, Y);

    GetCurrentResolution(Width, Height);

    if (X < 0.0
        || Y < 0.0
        || X > float(Width)
        || Y > float(Height))
    {
        Me.MoveTo(-10000, -10000);
        return;
    }

    Me.MoveTo(
        int(X + 24.0),
        int(Y - 24.0)
    );
}

function StartMining()
{
    local Actor PlayerActor;

    if (MiningState != 1
        || bRequireRelease
        || ChatIsFocused())
    {
        return;
    }

    if (!MiningKeysDown()
        || !StoneIsNear())
    {
        return;
    }

    if (!GetPlayerActor(PlayerActor))
    {
        return;
    }

    RequestId++;

    if (RequestId <= 0)
    {
        RequestId = 1;
    }

    MiningState = 2;
    RequestTime = PlayerActor.Level.TimeSeconds;

    SendMiningCommand("MiningStart");
}

function HandleOffer(string Param)
{
    local int ObjectId;

    // Deixa a animacao de sucesso terminar.
    if (MiningState == 4)
    {
        return;
    }

    ParseInt(Param, "ObjID", ObjectId);

    if (ObjectId <= 0)
    {
        ClearMining(true);
        return;
    }

    if (ObjectId == RockId)
    {
        return;
    }

    if (MiningState == 2 || MiningState == 3)
    {
        return;
    }

    ClearMining(true);

    RockId = ObjectId;

    if (!StoneIsNear())
    {
        ClearMining(false);
        return;
    }

    bPreviousE = MiningKeysDown();
    bRequireRelease = bPreviousE;

    LastPercent = -1;
    TargetPercent = 0;
    NextPercentTime = 0.0;
    CompleteUntil = 0.0;

    UpdatePercent(0);
    PositionMining();
    ShowAvailable();
}

function HandleMiningUpdate(string Action, string Param)
{
    local int ObjectId;
    local int ResponseRequest;
    local int Value;
    local Actor PlayerActor;

    ParseInt(Param, "ObjID", ObjectId);
    ParseInt(Param, "Request", ResponseRequest);

    if (ObjectId != RockId
        || ResponseRequest != RequestId)
    {
        return;
    }

    if (MiningState != 2 && MiningState != 3)
    {
        return;
    }

    if (Action == "End")
    {
        ParseInt(Param, "Success", Value);

        if (Value == 1)
        {
            // A mineracao real ja terminou no servidor.
            // Agora conclui apenas o indicador visual.
            MiningState = 4;

            TargetPercent = 100;
            CompleteUntil = 0.0;

            KeyWnd.HideWindow();
            LoadWnd.ShowWindow();

            TextWnd.ClearAnchor();

            TextWnd.SetAnchor(
                "InteractionWnd.load_state",
                "TopRight",
                "TopLeft",
                5,
                9
            );

            DrawMiningText("Minerando ...");
        }
        else
        {
            ClearMining(false);
        }

        return;
    }

    if (Action != "Start" && Action != "Progress")
    {
        return;
    }

    if (!MiningKeysDown()
        || ChatIsFocused())
    {
        CancelAttempt();
        return;
    }

    if (!StoneIsNear()
        || !GetPlayerActor(PlayerActor))
    {
        ClearMining(true);
        return;
    }

    if (MiningState == 2)
    {
        if (Action != "Start")
        {
            return;
        }

        MiningState = 3;

        TargetPercent = Max(0, LastPercent);
        NextPercentTime = PlayerActor.Level.TimeSeconds;
        CompleteUntil = 0.0;

        LastHoldTime = PlayerActor.Level.TimeSeconds;

        KeyWnd.HideWindow();
        LoadWnd.ShowWindow();

        TextWnd.ClearAnchor();

        TextWnd.SetAnchor(
            "InteractionWnd.load_state",
            "TopRight",
            "TopLeft",
            5,
            9
        );

        DrawMiningText("Minerando ...");
    }

    LastServerTime = PlayerActor.Level.TimeSeconds;

    ParseInt(Param, "Percent", Value);

    if (Value > 99)
    {
        Value = 99;
    }

    // Recebe o destino, sem saltar diretamente para ele.
    if (Value > TargetPercent)
    {
        TargetPercent = Value;
    }
}

function OnLoad()
{
    local int i;

    Me = GetHandle("InteractionWnd");

    KeyWnd = GetHandle(
        "InteractionWnd.key_state"
    );

    LoadWnd = GetHandle(
        "InteractionWnd.load_state"
    );

    TextWnd = GetHandle(
        "InteractionWnd.text_interaction_box"
    );

    Circle = TextureHandle(GetHandle(
        "InteractionWnd.load_state.load_bar"
    ));

    PercentText = TextBoxHandle(GetHandle(
        "InteractionWnd.load_state.load_percent"
    ));

    ChatInput = EditBoxHandle(GetHandle(
        "ChatWnd.ChatEditBox"
    ));

    for (i = 0; i < 20; i++)
    {
        Letters[i] = TextureHandle(GetHandle(
            "InteractionWnd.text_interaction_box.interaction_name_"
            $ string(i)
        ));

        Letters[i].SetTexture(
            "L2UI_CH3.Fonts.font_lineageii"
        );

        Letters[i].HideWindow();
    }

    KeyWnd.SetWindowSize(105, 32);

    TextureHandle(GetHandle(
        "InteractionWnd.key_state.sub_key"
    )).SetTexture(
        "L2UI_CH3.InteractionWnd.interac_ALT"
    );

    GetHandle(
        "InteractionWnd.key_state.sub_key"
    ).ClearAnchor();

    GetHandle(
        "InteractionWnd.key_state.sub_key"
    ).SetAnchor(
        "InteractionWnd.key_state",
        "TopLeft",
        "TopLeft",
        0,
        0
    );

    GetHandle(
        "InteractionWnd.key_state.sub_key"
    ).SetWindowSize(73, 32);

    GetHandle(
        "InteractionWnd.key_state.sub_key"
    ).ShowWindow();

    GetHandle(
        "InteractionWnd.key_state.key"
    ).ClearAnchor();

    GetHandle(
        "InteractionWnd.key_state.key"
    ).SetAnchor(
        "InteractionWnd.key_state.sub_key",
        "TopRight",
        "TopLeft",
        0,
        0
    );

    RegisterEvent(140);
    RegisterEvent(40);
    RegisterEvent(50);

    bInitialized = true;
    LastPercent = -1;

    ClearMining(false);

    Me.SetTimer(MINING_TIMER, 50);
}

function OnEnterState(name PreviousState)
{
    if (!bInitialized)
    {
        return;
    }

    ClearMining(false);

    Me.KillTimer(MINING_TIMER);
    Me.SetTimer(MINING_TIMER, 50);
}

function OnHide()
{
    if (bInitialized && RockId > 0)
    {
        ClearMining(true);
    }
}

function OnEvent(int EventId, string Param)
{
    local string Message;
    local array<string> Parts;

    if (!bInitialized)
    {
        return;
    }

    if (EventId == 40 || EventId == 50)
    {
        ClearMining(true);
        return;
    }

    if (EventId != 140)
    {
        return;
    }

    ParseString(Param, "Msg", Message);
    Split(Message, "|", Parts);

    if (Parts.Length != 3)
    {
        return;
    }

    if (Parts[0] != "CustomEvent=MiningV1")
    {
        return;
    }

    if (Parts[1] == "Offer")
    {
        HandleOffer(Parts[2]);
    }
    else
    {
        HandleMiningUpdate(Parts[1], Parts[2]);
    }
}

function OnTimer(int TimerId)
{
    local Actor PlayerActor;
    local float Now;
    local bool bDown;
    local bool bPressed;

    if (TimerId != MINING_TIMER
        || !bInitialized
        || RockId <= 0)
    {
        return;
    }

    // O servidor ja confirmou o sucesso.
    // A pedra pode ter desaparecido durante a animacao final.
    if (MiningState == 4)
    {
        return;
    }

    if (!StoneIsNear()
        || !GetPlayerActor(PlayerActor))
    {
        ClearMining(true);
        return;
    }

    Now = PlayerActor.Level.TimeSeconds;

    bDown = MiningKeysDown();
    bPressed = bDown && !bPreviousE;
    bPreviousE = bDown;

    if (!bDown)
    {
        bRequireRelease = false;
    }

    PositionMining();

    if (ChatIsFocused())
    {
        if (MiningState == 2 || MiningState == 3)
        {
            CancelAttempt();
        }

        bRequireRelease = bDown;
        return;
    }

    if (MiningState == 1)
    {
        if (bPressed && !bRequireRelease)
        {
            StartMining();
        }

        return;
    }

    if (!bDown)
    {
        CancelAttempt();
        return;
    }

    if (MiningState == 2)
    {
        if (Now < RequestTime
            || Now - RequestTime > 4.0)
        {
            CancelAttempt();
        }

        return;
    }

    if (MiningState != 3)
    {
        return;
    }

    if (Now < LastServerTime
        || Now - LastServerTime > 5.0)
    {
        CancelAttempt();
        return;
    }

    if (Now - LastHoldTime >= 0.5)
    {
        LastHoldTime = Now;

        SendMiningCommand("MiningHold");
    }
}

event OnTick()
{
    local Actor PlayerActor;
    local float Now;

    if (!bInitialized
        || (MiningState != 3 && MiningState != 4))
    {
        return;
    }

    if (!GetPlayerActor(PlayerActor))
    {
        ClearMining(false);
        return;
    }

    Now = PlayerActor.Level.TimeSeconds;

    if (LastPercent < TargetPercent)
    {
        if (NextPercentTime <= 0.0)
        {
            NextPercentTime = Now;
        }

        if (Now >= NextPercentTime)
        {
            // Avanca somente um numero por quadro.
            UpdatePercent(LastPercent + 1);

            NextPercentTime += PERCENT_STEP_TIME;

            // Evita acumular atraso depois de uma pausa.
            if (NextPercentTime < Now - 0.2)
            {
                NextPercentTime = Now + PERCENT_STEP_TIME;
            }
        }
    }
    else
    {
        NextPercentTime = Now;
    }

    if (MiningState == 4 && LastPercent >= 100)
    {
        if (CompleteUntil <= 0.0)
        {
            CompleteUntil = Now + COMPLETE_DISPLAY_TIME;
        }
        else if (Now >= CompleteUntil)
        {
            ClearMining(false);
        }
    }
}