//================================================================================
// KillLogWnd — feed de PvP com retratos, portado do KillLog do Essence.
//
// O original Essence depende de coisas que NAO existem no Interlude e foram
// substituidas, nao "traduzidas":
//   L2UITween / L2UITweenObject / L2UITimer -> SetTimer/KillTimer + SetAlpha
//   CallGFxFunction("KillLogCenter", ...)   -> removido (nao ha Scaleform no IL)
//   _S_EX_ENEMY_KILL_LOG / UIPacket.Decode  -> CustomEvent 88546 (KillFeedHud.java)
//   m_hOwnerWnd.m_WindowNameWithFullPath    -> GetHandle("KillLogWnd...")
//   L2UI_NewTex.KillLog.*                   -> L2UI_CH3.KillLog.*
//
// Em vez de mover janela (o tween do Essence deslizava cada linha), as linhas
// ficam PARADAS no XDAT e o conteudo e que desce: entrada nova sempre na linha 0.
// Menos coisa pra dar errado no engine antigo e nao depende de Local2Global.
//
// Controles FLAT de proposito ("S0_bg", "S0_killName", ...) em vez de uma Window
// por linha: o add_killfeed_wnd.groovy deste projeto diz "single-level controls
// (no nested Window rows)" e chega a remover KillFeedRow0-2, e o CLAUDE.md marca
// GPF NCTabControl::AddTabControl ao clonar janela com muitos filhos Window.
// Sem Window por linha, show/hide/alpha e aplicado nos 7 controles (SlotShow/
// SlotHide/SlotAlpha) — TextureHandle e TextBoxHandle herdam de WindowHandle.
//
// XDAT gerado por tools/xdat/add_killlog_wnd.groovy.
// Entra pelo despachante: PCCafeEventWnd chama HandleKill(a_Param) no evento 88546.
//================================================================================
class KillLogWnd extends UICommonAPI;

// Linhas visiveis. O XDAT precisa ter S0_*..S<SLOT_MAX-1>_*. Pra crescer ate 7
// (como o Essence) basta subir esse numero E gerar as linhas no XDAT — os arrays
// ja sao dimensionados em 7.
const SLOT_MAX = 4;

const TIMER_TICK = 1;
const TICK_MS = 250;
const LIFE_MS = 6000;
const FADE_MS = 750;

// Opacidade do fundo preto (L2UI.SquareBlack e chapado, 255 fica duro demais).
// Acompanha o fade da linha proporcionalmente.
const BG_ALPHA = 185;

// Nome de quem matou x nome de quem morreu (pedido: azul e vermelho fixos).
var Color COLOR_KILLER;
var Color COLOR_VICTIM;

// Auditado com umodel em L2UI_CH3.utx, grupo KillLog (2026-08-22, apos o usuario
// completar o pacote): KillLogCenterBg, PortraitBg_Red/Blue, SideBg_Red/Blue,
// Attack e os FaceIcon_* das 5 racas do IL em soldier/magician x M/W.
//
// Azul/vermelho seguem a MINHA perspectiva, igual ao bEnemyDied do Essence.
// PortraitBg_Red/Blue (8x8) NAO sao usadas: a UI do IL nao escala textura, e uma
// moldura de 8x8 numa caixa de 32x32 vira grade de quadradinhos. O lado agora e
// indicado so pelo fundo da linha (SideBg_*) e pela cor do nome.
const TEX_SIDE_BLUE = "L2UI_CH3.KillLog.SideBg_Blue";
const TEX_SIDE_RED = "L2UI_CH3.KillLog.SideBg_Red";

struct KillEntry
{
	var string killerName;
	var string victimName;
	var string killerTex;
	var string victimTex;
	var bool bMineKill;
	var bool bMineDeath;
	var int lifeMs;
	var bool bUsed;
};

var WindowHandle Me;
var TextureHandle SlotBg[7];
var TextureHandle SlotSide[7];
var TextureHandle SlotAtk[7];
var TextureHandle SlotKillFace[7];
var TextureHandle SlotDeadFace[7];
var TextBoxHandle SlotKillName[7];
var TextBoxHandle SlotDeadName[7];
var KillEntry Entries[7];

function OnLoad()
{
	local int i;
	local string base;

	COLOR_KILLER = GetColortool(105, 165, 255, 255);
	COLOR_VICTIM = GetColortool(255, 102, 102, 255);

	Me = GetHandle("KillLogWnd");
	for (i = 0; i < SLOT_MAX; i++)
	{
		base = "KillLogWnd.S" $ string(i) $ "_";
		SlotBg[i] = TextureHandle(GetHandle(base $ "bg"));
		SlotSide[i] = TextureHandle(GetHandle(base $ "side"));
		SlotAtk[i] = TextureHandle(GetHandle(base $ "atk"));
		SlotKillFace[i] = TextureHandle(GetHandle(base $ "killFace"));
		SlotDeadFace[i] = TextureHandle(GetHandle(base $ "deadFace"));
		SlotKillName[i] = TextBoxHandle(GetHandle(base $ "killName"));
		SlotDeadName[i] = TextBoxHandle(GetHandle(base $ "deadName"));
		Entries[i].bUsed = false;
		SlotHide(i);
	}
	if (Me != None)
		Me.HideWindow();
}

//--------------------------------------------------------------------------------
// Sem Window por linha, cada operacao de linha percorre os 7 controles.
//--------------------------------------------------------------------------------
function SlotHide(int i)
{
	if (SlotBg[i] != None)
		SlotBg[i].HideWindow();
	if (SlotSide[i] != None)
		SlotSide[i].HideWindow();
	if (SlotAtk[i] != None)
		SlotAtk[i].HideWindow();
	if (SlotKillFace[i] != None)
		SlotKillFace[i].HideWindow();
	if (SlotDeadFace[i] != None)
		SlotDeadFace[i].HideWindow();
	if (SlotKillName[i] != None)
		SlotKillName[i].HideWindow();
	if (SlotDeadName[i] != None)
		SlotDeadName[i].HideWindow();
}

function SlotShow(int i)
{
	if (SlotBg[i] != None)
		SlotBg[i].ShowWindow();
	if (SlotSide[i] != None)
		SlotSide[i].ShowWindow();
	if (SlotAtk[i] != None)
		SlotAtk[i].ShowWindow();
	if (SlotKillFace[i] != None)
		SlotKillFace[i].ShowWindow();
	if (SlotDeadFace[i] != None)
		SlotDeadFace[i].ShowWindow();
	if (SlotKillName[i] != None)
		SlotKillName[i].ShowWindow();
	if (SlotDeadName[i] != None)
		SlotDeadName[i].ShowWindow();
}

function SlotAlpha(int i, int a)
{
	if (SlotBg[i] != None)
		SlotBg[i].SetAlpha((a * BG_ALPHA) / 255);
	if (SlotSide[i] != None)
		SlotSide[i].SetAlpha(a);
	if (SlotAtk[i] != None)
		SlotAtk[i].SetAlpha(a);
	if (SlotKillFace[i] != None)
		SlotKillFace[i].SetAlpha(a);
	if (SlotDeadFace[i] != None)
		SlotDeadFace[i].SetAlpha(a);
	if (SlotKillName[i] != None)
		SlotKillName[i].SetAlpha(a);
	if (SlotDeadName[i] != None)
		SlotDeadName[i].SetAlpha(a);
}

//--------------------------------------------------------------------------------
// Payload do KillFeedHud.java (88546):
//   Killer= Victim= ClassK= ClassV= RaceK= RaceV= SexK= SexV=
// Nomes vem com "_" no lugar do espaco (o parser nativo separa token por espaco).
//--------------------------------------------------------------------------------
function HandleKill(string a_Param)
{
	local string killer, victim, myName;
	local int classK, classV, raceK, raceV, sexK, sexV, i;
	local UserInfo myInfo;
	
	if(GetOptionBool("Lotus_Custom", "DisableKillFeed"))
    {
        ClearKillFeed();
        return;
    }

	killer = "";
	victim = "";
	classK = 0;
	classV = 0;
	raceK = 0;
	raceV = 0;
	sexK = 0;
	sexV = 0;

	ParseString(a_Param, "Killer", killer);
	ParseString(a_Param, "Victim", victim);
	ParseInt(a_Param, "ClassK", classK);
	ParseInt(a_Param, "ClassV", classV);
	ParseInt(a_Param, "RaceK", raceK);
	ParseInt(a_Param, "RaceV", raceV);
	ParseInt(a_Param, "SexK", sexK);
	ParseInt(a_Param, "SexV", sexV);

	killer = ReplaceText(killer, "_", " ");
	victim = ReplaceText(victim, "_", " ");

	if (Len(killer) == 0 || Len(victim) == 0)
		return;

	myName = "";
	if (GetPlayerInfo(myInfo))
		myName = myInfo.Name;

	// Empurra a lista: o mais novo sempre na linha 0, como no feed do Essence.
	for (i = SLOT_MAX - 1; i > 0; i--)
		Entries[i] = Entries[i - 1];

	Entries[0].killerName = killer;
	Entries[0].victimName = victim;
	Entries[0].killerTex = FaceIcon(raceK, classK, sexK);
	Entries[0].victimTex = FaceIcon(raceV, classV, sexV);
	Entries[0].bMineKill = (myName != "" && myName == killer);
	Entries[0].bMineDeath = (myName != "" && myName == victim);
	Entries[0].lifeMs = LIFE_MS;
	Entries[0].bUsed = true;

	// ShowWindow da janela ANTES do Repaint: com a pai escondida, o ShowWindow dos
	// filhos nao pega e os TextBox ficam invisiveis (os nomes sumiam). As Texture
	// escapavam porque nao tem a propriedade "hidden" — HideWindow nelas e no-op,
	// entao nunca estiveram escondidas. Inverter a ordem resolve os dois.
	if (Me != None)
	{
		Me.ShowWindow();
		Me.KillTimer(TIMER_TICK);
		Me.SetTimer(TIMER_TICK, TICK_MS);
	}

	Repaint();
}

function Repaint()
{
	local int i;
	local string sideBg;

 if(GetOptionBool("Lotus_Custom", "DisableKillFeed"))
    {
        ClearKillFeed();
        return;
    }

	for (i = 0; i < SLOT_MAX; i++)
	{
		if (!Entries[i].bUsed)
		{
			SlotHide(i);
		}
		else
		{
			// Cor por PAPEL, nao por perspectiva: killer sempre azul, vitima sempre
			// vermelho (fixo em COLOR_KILLER/COLOR_VICTIM). O acento lateral e que
			// continua dizendo se a briga foi minha.
			if (Entries[i].bMineKill)
				sideBg = TEX_SIDE_BLUE;
			else
				sideBg = TEX_SIDE_RED;

			if (SlotKillName[i] != None)
			{
				SlotKillName[i].SetText(Entries[i].killerName);
				SlotKillName[i].SetTextColor(COLOR_KILLER);
			}
			if (SlotDeadName[i] != None)
			{
				SlotDeadName[i].SetText(Entries[i].victimName);
				SlotDeadName[i].SetTextColor(COLOR_VICTIM);
			}
			if (SlotKillFace[i] != None)
				SlotKillFace[i].SetTexture(Entries[i].killerTex);
			if (SlotDeadFace[i] != None)
				SlotDeadFace[i].SetTexture(Entries[i].victimTex);
			// O fundo preto (SlotBg = L2UI.SquareBlack) e fixo; quem indica o lado
			// e o acento lateral.
			if (SlotSide[i] != None)
				SlotSide[i].SetTexture(sideBg);

			SlotShow(i);
			SlotAlpha(i, 255);
		}
	}
}

function OnTimer(int TimerID)
{
	local int i, alive, a;

	if(GetOptionBool("Lotus_Custom", "DisableKillFeed"))
{
    ClearKillFeed();
    return;
}

	if (TimerID != TIMER_TICK)
		return;

	alive = 0;
	for (i = 0; i < SLOT_MAX; i++)
	{
		if (Entries[i].bUsed)
		{
			Entries[i].lifeMs = Entries[i].lifeMs - TICK_MS;
			if (Entries[i].lifeMs <= 0)
			{
				Entries[i].bUsed = false;
				SlotHide(i);
			}
			else
			{
				alive++;
				if (Entries[i].lifeMs < FADE_MS)
					a = (Entries[i].lifeMs * 255) / FADE_MS;
				else
					a = 255;
				SlotAlpha(i, a);
			}
		}
	}

	if (alive <= 0 && Me != None)
	{
		Me.KillTimer(TIMER_TICK);
		Me.HideWindow();
	}
}

//--------------------------------------------------------------------------------
// L2UI_CH3.KillLog.FaceIcon_<Raca>_<soldier|magician>_<M|W>
//--------------------------------------------------------------------------------
function string FaceIcon(int nRace, int nClassID, int nSex)
{
	local string raceStr, typeStr, sexStr;

	raceStr = RaceString(nRace);

	if (IsMysticClass(nClassID))
		typeStr = "magician";
	else
		typeStr = "soldier";

	// aCis manda getAppearance().getSex(): true(1) = feminino.
	if (nSex == 1)
		sexStr = "W";
	else
		sexStr = "M";

	// Anao nao tem mistico no Interlude — e nao existe FaceIcon_Dwarf_magician_*.
	if (raceStr == "Dwarf")
		typeStr = "soldier";

	return "L2UI_CH3.KillLog.FaceIcon_" $ raceStr $ "_" $ typeStr $ "_" $ sexStr;
}

// Ordem do enum Race do aCis: Human, Elf, DarkElf, Orc, Dwarf.
// O nome da textura usa "Darkelf" (k minusculo), nao "DarkElf".
function string RaceString(int nRace)
{
	switch (nRace)
	{
		case 0: return "Human";
		case 1: return "Elf";
		case 2: return "Darkelf";
		case 3: return "Orc";
		case 4: return "Dwarf";
	}
	return "Human";
}

// Classes misticas do Interlude (1a/2a/3a profissao).
function bool IsMysticClass(int nClassID)
{
	// Human mystic 10-17 · Elf mystic 25-30 · DarkElf mystic 38-43 · Orc mystic 49-52
	if (nClassID >= 10 && nClassID <= 17)
		return true;
	if (nClassID >= 25 && nClassID <= 30)
		return true;
	if (nClassID >= 38 && nClassID <= 43)
		return true;
	if (nClassID >= 49 && nClassID <= 52)
		return true;
	// 3a profissao: 94-98 Human · 103-105 Elf · 110-112 DarkElf · 115-116 Orc
	if (nClassID >= 94 && nClassID <= 98)
		return true;
	if (nClassID >= 103 && nClassID <= 105)
		return true;
	if (nClassID >= 110 && nClassID <= 112)
		return true;
	if (nClassID >= 115 && nClassID <= 116)
		return true;
	return false;
}

function ClearKillFeed()
{
    local int i;

    if(Me != None)
        Me.KillTimer(TIMER_TICK);

    for(i = 0; i < SLOT_MAX; i++)
    {
        Entries[i].bUsed = false;
        Entries[i].lifeMs = 0;

        SlotAlpha(i, 0);
        SlotHide(i);
    }

    if(Me != None)
        Me.HideWindow();
}

defaultproperties
{
}
