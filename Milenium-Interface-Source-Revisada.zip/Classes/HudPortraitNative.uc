class HudPortraitNative extends Object;
// Requires the R10 companion: 1 = new appearance, 2 = cached, <=0 = failure.
// Only result 1 requires preparing the preview pose again.
native static final function int BindPortrait(WindowHandle control,Actor preview,Texture background,optional int playerID);
native static final function int ReleasePortrait();
native static final function vector GetPointerState();
defaultproperties {}
