class SBlackBrowserWnd extends UICommonAPI;
const FRAME_TIMER=6640;
const DRAG_TIMER=6641;
const CLEAR_DIALOG=6642;
var bool Clearing,VideoFullscreen;
var string ClearReturnPath;
var WindowHandle Me,Owner;
var TextureHandle Viewport;
var Texture Surface;
var int EnabledTab[2];
var string TabURL[2];
var string ActivePath;
var bool ConfigReady,ContentFocused,Dragging,SurfaceReady,VolumeSync;
var int SelectedTab,WaitTicks,DragX,DragY,DragMouseX,DragMouseY,VolumeValue,VolumeBeforeMute;
function OnRegisterEvent(){RegisterEvent(EV_GamingStateExit);RegisterEvent(EV_Restart);RegisterEvent(EV_DialogOK);RegisterEvent(EV_DialogCancel);}
function OnLoad()
{
 OnRegisterEvent();Me=GetHandle("SBlackBrowserWnd");Me.SetDraggable(False);Me.HideWindow();
 VolumeValue=100;if(!GetINIInt("Audio","Volume",VolumeValue,"L2CefAudio.ini"))VolumeValue=100;
 VolumeValue=Clamp(VolumeValue,0,100);if(VolumeValue>0)VolumeBeforeMute=VolumeValue;else VolumeBeforeMute=100;
}
function PollHotkey(){if(class'L2WebNative'.static.PollHotkey()==1)ToggleBrowser();}
function ToggleBrowser()
{
 class'L2WebNative'.static.ReportState(10);
 if(Caps(GetUIState())!="GAMINGSTATE")return;
 if(ConfigReady&&EnabledTab[0]==0&&EnabledTab[1]==0)return;
 if(Me.IsShowWindow())Me.HideWindow();else OpenExpanded();
}
function OpenExpanded()
{
 if(Caps(GetUIState())!="GAMINGSTATE")return;
 if(ConfigReady&&EnabledTab[0]==0&&EnabledTab[1]==0)return;
 // One viewport owns the native surface; both browser pages stay alive.
 EndView();HideWindow("SystemMenuWnd");ShowWindowWithFocus("SBlackBrowserWnd");
}
function OnShow()
{
 local int sw,sh,w,h;local Rect bounds;
 GetCurrentResolution(sw,sh);w=Min(640,sw-40);h=Min(440,sh-60);if(w<440)w=440;if(h<300)h=300;
 Me.SetWindowSize(w,h);Me.SetDraggable(False);
 TextureHandle(GetHandle("SBlackBrowserWnd.BrowserViewport")).SetWindowSize(w-28,h-84);
 ResizeBrowserFrame(w,h);
 TextBoxHandle(GetHandle("SBlackBrowserWnd.TitleText")).SetText("Navegador");
 bounds=Me.GetRect();
 if(bounds.nX<0||bounds.nY<0||bounds.nX+w>sw||bounds.nY+h>sh){Me.ClearAnchor();Me.MoveTo(Max(0,(sw-w)/2),Max(0,(sh-h)/2));}
 BeginView("SBlackBrowserWnd");
}
function SetFramePart(string id,int x,int y,int w,int h)
{
 local TextureHandle part;
 part=TextureHandle(GetHandle("SBlackBrowserWnd."$id));part.ClearAnchor();part.SetAnchor("SBlackBrowserWnd","TopLeft","TopLeft",x,y);part.SetWindowSize(w,h);
}
function ResizeBrowserFrame(int w,int h)
{
 SetFramePart("FrameBody",4,4,w-8,h-12);SetFramePart("FrameTopCenter",3,0,w-6,4);
 SetFramePart("FrameLeft",0,1,4,h-9);SetFramePart("FrameRight",w-4,1,4,h-9);
 GetHandle("SBlackBrowserWnd.CloseBrowser").ClearAnchor();GetHandle("SBlackBrowserWnd.CloseBrowser").SetAnchor("SBlackBrowserWnd","TopLeft","TopLeft",w-40,6);GetHandle("SBlackBrowserWnd.CloseBrowser").SetWindowSize(26,26);
 SetFramePart("FrameBottomLeft",0,h-16,8,16);SetFramePart("FrameBottomCenter",8,h-16,w-16,16);SetFramePart("FrameBottomRight",w-8,h-16,8,16);
}
function OpenEmbedded(){if(Me.IsShowWindow())Me.HideWindow();BeginView("SystemMenuWnd");}
function BeginView(string path)
{
 EndView();ActivePath=path;Owner=GetHandle(path);Viewport=TextureHandle(GetHandle(path$".BrowserViewport"));
 WaitTicks=0;RepairFrameRects();Owner.SetTimer(FRAME_TIMER,40);UpdateControls();SetStatus("Aguardando configuracao...");
 if(Clearing){SetStatus("Limpando dados de navegacao...");return;}
 RequestBypassToServer("scripts_services.Interface:syncBrowserOptions");if(ConfigReady)SelectTab(SelectedTab);
}
function RepairFrameRects()
{
 class'L2WebNative'.static.SetFrameRect(GetHandle(ActivePath$".FrameBody"),4,5,120,28);
 if(ActivePath=="SystemMenuWnd")class'L2WebNative'.static.SetFrameRect(GetHandle(ActivePath$".FrameTopLeft"),0,0,32,64);
 if(ActivePath=="SBlackBrowserWnd")class'L2WebNative'.static.SetFrameRect(GetHandle(ActivePath$".FrameTopCenter"),0,0,128,4);
 else class'L2WebNative'.static.SetFrameRect(GetHandle(ActivePath$".FrameTopCenter"),0,0,128,64);
 if(ActivePath=="SystemMenuWnd")class'L2WebNative'.static.SetFrameRect(GetHandle(ActivePath$".FrameTopRight"),0,0,32,64);
 class'L2WebNative'.static.SetFrameRect(GetHandle(ActivePath$".FrameLeft"),0,5,4,28);
 class'L2WebNative'.static.SetFrameRect(GetHandle(ActivePath$".FrameRight"),28,5,4,28);
 class'L2WebNative'.static.SetFrameRect(GetHandle(ActivePath$".FrameBottomLeft"),0,0,8,16);
 class'L2WebNative'.static.SetFrameRect(GetHandle(ActivePath$".FrameBottomCenter"),8,0,240,16);
 class'L2WebNative'.static.SetFrameRect(GetHandle(ActivePath$".FrameBottomRight"),248,0,8,16);
}
function EndView()
{
 if(Owner!=None){Owner.KillTimer(FRAME_TIMER);Owner.KillTimer(DRAG_TIMER);}
 Dragging=False;ContentFocused=False;class'L2WebNative'.static.Hide();Owner=None;ActivePath="";
}
function EmbeddedHidden(){if(ActivePath=="SystemMenuWnd")EndView();}
function OnHide(){if(ActivePath=="SBlackBrowserWnd")EndView();}
function OnEvent(int eventID,string data)
{
 local int result;
 if(eventID==EV_DialogOK||eventID==EV_DialogCancel)
 {
  if(!DialogIsMine()||DialogGetID()!=CLEAR_DIALOG)return;
  if(eventID==EV_DialogOK){result=class'L2WebNative'.static.ClearData();Clearing=result==1;}
  if(ClearReturnPath=="SBlackBrowserWnd")OpenExpanded();else ShowWindow("SystemMenuWnd");
  if(eventID==EV_DialogOK&&result!=1)ShowError(result);
  return;
 }
 ConfigReady=False;Me.HideWindow();EndView();
}
function RequestClearData()
{
 if(Clearing||Owner==None)return;
 ClearReturnPath=ActivePath;Owner.HideWindow();EndView();
 DialogShow(DIALOG_OKCancel,"Limpar cookies, logins e cache do navegador? Voce precisara entrar novamente no YouTube e na Twitch.");DialogSetID(CLEAR_DIALOG);
}
function OnExitState(name nextState){ConfigReady=False;Me.HideWindow();EndView();}
function OnReceivedCloseUI(){Me.HideWindow();}
function OnKeyUp(EInputKey key){if(key==IK_Escape&&!VideoFullscreen)Me.HideWindow();}
function ApplyConfig(string data)
{
 EnabledTab[0]=int(ReadField(data,"YOUTUBE"));EnabledTab[1]=int(ReadField(data,"CUSTOM"));
 TabURL[0]="https://www.youtube.com/";TabURL[1]="https://www.twitch.tv/";ConfigReady=True;
 class'L2WebNative'.static.ReportState(100+EnabledTab[0]*10+EnabledTab[1]);UpdateControls();
 if(EnabledTab[0]==0&&EnabledTab[1]==0){class'L2WebNative'.static.Hide();SetStatus("Navegador desativado.");return;}
 if(EnabledTab[SelectedTab]==0)SelectedTab=1-SelectedTab;
 if(!Clearing&&Owner!=None&&Owner.IsShowWindow())SelectTab(SelectedTab);
}
function UpdateControls()
{
 local int i;local string path;
 if(ActivePath=="")return;
 // Native button captions remain visible on hover, press and release.
 class'L2WebNative'.static.SetCaption(GetHandle(ActivePath$".Tab0"),"YouTube");
 class'L2WebNative'.static.SetCaption(GetHandle(ActivePath$".Tab1"),"Twitch");
 if(ActivePath=="SystemMenuWnd")
 {
  class'L2WebNative'.static.SetCaption(GetHandle(ActivePath$".Expand"),"Ampliar");
  class'L2WebNative'.static.SetCaption(GetHandle(ActivePath$".btnOption"),"Options");
  class'L2WebNative'.static.SetCaption(GetHandle(ActivePath$".btnRestart"),"Restart");
  class'L2WebNative'.static.SetCaption(GetHandle(ActivePath$".btnQuit"),"Exit");
  class'L2WebNative'.static.SetCaption(GetHandle(ActivePath$".ClearData"),"Limpar dados");
 }
 else class'L2WebNative'.static.SetCaption(GetHandle(ActivePath$".Compact"),"Menu");
 for(i=0;i<2;i++)
 {
  path=ActivePath$".Tab"$string(i);
  if(!ConfigReady||EnabledTab[i]!=0)ShowWindow(path);else HideWindow(path);
 }
 VolumeSync=True;class'UIAPI_SLIDERCTRL'.static.SetCurrentTick(ActivePath$".Volume",VolumeValue/10);VolumeSync=False;
 class'L2WebNative'.static.SetCaption(GetHandle(ActivePath$".Mute"),"");
 if(VolumeValue==0)
 {
  ButtonHandle(GetHandle(ActivePath$".Mute")).SetTexture("SBlackBrowserButtons.Toolbar.Muted_Normal","SBlackBrowserButtons.Toolbar.Muted_Pressed","SBlackBrowserButtons.Toolbar.Muted_Hover");
  GetHandle(ActivePath$".Mute").SetTooltipText("Ativar som");
 }
 else
 {
  ButtonHandle(GetHandle(ActivePath$".Mute")).SetTexture("SBlackBrowserButtons.Toolbar.Sound_Normal","SBlackBrowserButtons.Toolbar.Sound_Pressed","SBlackBrowserButtons.Toolbar.Sound_Hover");
  GetHandle(ActivePath$".Mute").SetTooltipText("Silenciar");
 }
 GetHandle(ActivePath$".Volume").SetTooltipText("Volume: "$string(VolumeValue)$"%");
}

function SelectTab(int tab)
{
 local int result;
 if(Clearing||Owner==None||!ConfigReady||tab<0||tab>1||EnabledTab[tab]==0)return;
 SetContentFocus(False);SelectedTab=tab;
 UpdateControls();
 if(TabURL[tab]==""){class'L2WebNative'.static.Hide();SetStatus("Navega��o indispon�vel.");return;}
 if(Surface==None)Surface=new(None) class'Texture';
 if(!SurfaceReady){result=class'L2WebNative'.static.PrepareSurface(Surface);if(result!=1){ShowError(result);return;}SurfaceReady=True;}
 result=class'L2WebNative'.static.Open(Viewport,Surface,tab,TabURL[tab]);if(result!=1){ShowError(result);return;}
 class'L2WebNative'.static.SetVolume(VolumeValue);WaitTicks=0;Owner.SetTimer(FRAME_TIMER,40);SetStatus("Carregando...");
}
function SetStatus(string text){if(ActivePath=="")return;TextBoxHandle(GetHandle(ActivePath$".Status")).SetText(text);ShowWindow(ActivePath$".Status");}
function ShowError(int status){SetStatus("Navegador indisponivel. Codigo: "$string(status));Log("[L2CEF IL] browser status "$string(status));if(Owner!=None)Owner.KillTimer(FRAME_TIMER);}
function ApplyVolume(int value){VolumeValue=Clamp(value,0,100);class'L2WebNative'.static.SetVolume(VolumeValue);SetINIInt("Audio","Volume",VolumeValue,"L2CefAudio.ini");UpdateControls();}
function OnModifyCurrentTickSliderCtrl(string id,int tick){if(id=="Volume"&&!VolumeSync)ApplyVolume(Clamp(tick,0,10)*10);}
function OnClickButton(string id)
{
 SetContentFocus(False);
 if(id=="ClearData")RequestClearData();else if(id=="CloseBrowser")Me.HideWindow();else if(id=="Tab0")SelectTab(0);else if(id=="Tab1")SelectTab(1);else if(id=="Expand")OpenExpanded();else if(id=="Compact"){EndView();Me.HideWindow();ShowWindow("SystemMenuWnd");}
 else if(id=="Mute"){if(VolumeValue>0){VolumeBeforeMute=VolumeValue;ApplyVolume(0);}else ApplyVolume(VolumeBeforeMute);}
}
function bool IsBrowserContentFocused(){return Owner!=None&&Owner.IsShowWindow()&&class'L2WebNative'.static.HasFocus()!=0;}
function FocusBrowserContent(){} // Native window input already owns browser typing.
function SetContentFocus(bool focused){ContentFocused=focused;class'L2WebNative'.static.Focus(focused);}
function OnTimer(int timerID)
{
 local int status;local vector pointer;if(Owner==None)return;
 if(timerID==DRAG_TIMER)
 {
  pointer=class'MobPreviewNative'.static.GetPointerState();if(!Dragging||pointer.Z<0.5||!Owner.IsShowWindow()){Dragging=False;Owner.KillTimer(DRAG_TIMER);return;}
  Owner.MoveTo(DragX+int(pointer.X)-DragMouseX,DragY+int(pointer.Y)-DragMouseY);return;
 }
 if(timerID!=FRAME_TIMER)return;
 if(Clearing)
 {
  status=class'L2WebNative'.static.ClearState();
  if(status<0){Clearing=False;ShowError(status);return;}
  if(status==2){Clearing=False;SelectedTab=0;BeginView(ActivePath);}
  return;
 }
 if(!ConfigReady){WaitTicks++;if(WaitTicks==250){SetStatus("Configuracao do navegador indisponivel.");Owner.KillTimer(FRAME_TIMER);}return;}
 ContentFocused=class'L2WebNative'.static.HasFocus()!=0;
 status=class'L2WebNative'.static.Tick();
 if(status==3){VideoFullscreen=True;return;}
 if(status==4){VideoFullscreen=False;return;}
 if(status==2){Owner.HideWindow();return;}if(status<0){ShowError(status);return;}if(status==1)HideWindow(ActivePath$".Status");
}
function OnLButtonDown(WindowHandle window,int x,int y)
{
 local Rect bounds;local vector pointer;if(Owner==None)return;
 if(IsPointInPanelRect(x,y,Viewport.GetRect()))return;
 SetContentFocus(False);if(ActivePath!="SBlackBrowserWnd")return;
 if(IsPointInPanelRect(x,y,GetHandle("SBlackBrowserWnd.CloseBrowser").GetRect()))return;bounds=Owner.GetRect();
 if(x<bounds.nX+4||x>=bounds.nX+bounds.nWidth-32||y<bounds.nY||y>=bounds.nY+28)return;
 pointer=class'MobPreviewNative'.static.GetPointerState();if(pointer.Z<0.5)return;
 Owner.ClearAnchor();DragX=bounds.nX;DragY=bounds.nY;DragMouseX=int(pointer.X);DragMouseY=int(pointer.Y);Dragging=True;Owner.SetTimer(DRAG_TIMER,16);
}
// Page input comes from the native game-window route, never twice from script.
function OnLButtonUp(WindowHandle window,int x,int y){Dragging=False;if(Owner!=None)Owner.KillTimer(DRAG_TIMER);}
function OnLButtonDblClick(int x,int y){}
function OnRButtonDown(int x,int y){}
function OnRButtonUp(int x,int y){}
function OnMouseMove(WindowHandle window,int x,int y){}
// Pure donor helpers kept local for compatibility with the Milenium Source.
static function string ReadField(string data, string key)
{
	local int position;
	local int endPosition;
	local string work;
	local string tag;
	tag = "|" $ key $ "=";
	position = InStr(data, tag);
	if (position < 0) return "";
	work = Mid(data, position + Len(tag));
	endPosition = InStr(work, "|");
	if (endPosition >= 0) return Left(work, endPosition);
	return work;
}

static function bool IsPointInPanelRect(int x,int y,Rect bounds)
{
 return x>=bounds.nX && y>=bounds.nY && x<bounds.nX+bounds.nWidth && y<bounds.nY+bounds.nHeight;
}

defaultproperties
{
}
