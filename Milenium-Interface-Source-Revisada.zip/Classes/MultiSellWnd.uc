class MultiSellWnd extends UICommonAPI;

const TOOLTIP_WIDTH = 250;
const MAX_BUY = 9999;
const MULTISELLWND_DIALOG_OK = 1122;
const DIALOG_ASK_PRICE = 1123;
const TREENeedNAME = "MultiSellWnd.NeedItem";
const TREEInfoNAME = "MultiSellWnd.ItemListInfo";
const TreeName = "MultiSellWnd.MultisellTabTotalWnd.MultisellTabTotalWnd_ListCtrl";
const TREENAMEENABLE = "MultiSellWnd.MultisellTabEnableWnd.MultisellTabEnableWnd_ListCtrl";
const ROOTNeedNAME = "rootNeed";
const ROOTInfoNAME = "rootInfo";
const ROOTNAME = "root";
const ROOTNAMEENABLE = "enableroot";
const OFFSET_Y_ICON_TEXTURE = 4;
const OFFSET_Y_SECONDLINE = -14;

struct NeededItem
{
	var int Id;
	var string Name;
	var int Count;
	var string IconName;
	var string AdditionalName;
	var int Enchant;
	var int CrystalType;
	var int ItemType;
	var int RefineryOp1;
	var int RefineryOp2;
};

struct itemList
{
	var int MultiSellType;
	var int NeededItemNum;
	var array<ItemInfo> OutputItemInfoList;
	var array<NeededItem> InputItemInfoList;
};

var array<itemList> m_MultiSellInfoList;
var int m_shopID;
var int pre_itemList;
var int GlobalItemCount;
var int GlobalAvailable;
var int lastFalseItem;
var int selectedGlobal;
var int indexGlobal;
var bool isExec;
var ItemWindowHandle MultisellTabTotalWnd_ItemWindow;
var ItemWindowHandle MultisellTabEnableWnd_ItemWindow;
var WindowHandle MultisellTabTotalWnd_ListCtrl;
var WindowHandle MultisellTabEnableWnd_ListCtrl;
var WindowHandle listGroupBg_Texture_MultisellTabIistWnd;
var WindowHandle listGroupBg_Texture_MultisellTabIistWnd2;
var TextureHandle listSlotBg1_Texture_MultisellTabIconWnd;
var TextureHandle listSlotBg2_Texture_MultisellTabIconWnd;
var TextureHandle listSlotBg1_Texture_MultisellTabIconWnd2;
var TextureHandle listSlotBg2_Texture_MultisellTabIconWnd2;
var ButtonHandle ListTabIcon_Button;
var ButtonHandle IconTabIcon_Button;
var ButtonHandle MultiSell_Up_Button;
var ButtonHandle MultiSell_Down_Button;
var ButtonHandle MultiSell_Input_Button;
var EditBoxHandle ItemCount_EditBox;
var EditBoxHandle Search_EditBox;
var TabHandle MultisellTab;

function OnLoad()
{
	RegisterEvent(2530);
	RegisterEvent(2540);
	RegisterEvent(2550);
	RegisterEvent(2560);
	RegisterEvent(1710);
	MultisellTabTotalWnd_ItemWindow = xxGetItemWindowHandle("MultiSellWnd.MultisellTabTotalWnd.MultisellTabTotalWnd_ItemWindow");
	MultisellTabEnableWnd_ItemWindow = xxGetItemWindowHandle("MultiSellWnd.MultisellTabEnableWnd.MultisellTabEnableWnd_ItemWindow");
	MultisellTabTotalWnd_ListCtrl = xxGetWindowHandle("MultiSellWnd.MultisellTabTotalWnd.MultisellTabTotalWnd_ListCtrl");
	MultisellTabEnableWnd_ListCtrl = xxGetWindowHandle("MultiSellWnd.MultisellTabEnableWnd.MultisellTabEnableWnd_ListCtrl");
	ListTabIcon_Button = xxGetButtonHandle("MultiSellWnd.ListTabIcon_Button");
	IconTabIcon_Button = xxGetButtonHandle("MultiSellWnd.IconTabIcon_Button");
	MultiSell_Up_Button = xxGetButtonHandle("MultiSellWnd.MultiSell_Up_Button");
	MultiSell_Down_Button = xxGetButtonHandle("MultiSellWnd.MultiSell_Down_Button");
	MultiSell_Input_Button = xxGetButtonHandle("MultiSellWnd.MultiSell_Input_Button");
	listGroupBg_Texture_MultisellTabIistWnd = xxGetWindowHandle("MultiSellWnd.MultisellTabTotalWnd.listGroupBg_Texture_MultisellTabIistWnd");
	listGroupBg_Texture_MultisellTabIistWnd2 = xxGetWindowHandle("MultiSellWnd.MultisellTabEnableWnd.listGroupBg_Texture_MultisellTabIistWnd");
	listSlotBg1_Texture_MultisellTabIconWnd = xxGetTextureHandle("MultiSellWnd.MultisellTabTotalWnd.listSlotBg1_Texture_MultisellTabIconWnd");
	listSlotBg2_Texture_MultisellTabIconWnd = xxGetTextureHandle("MultiSellWnd.MultisellTabTotalWnd.listSlotBg2_Texture_MultisellTabIconWnd");
	listSlotBg1_Texture_MultisellTabIconWnd2 = xxGetTextureHandle("MultiSellWnd.MultisellTabEnableWnd.listSlotBg1_Texture_MultisellTabIconWnd");
	listSlotBg2_Texture_MultisellTabIconWnd2 = xxGetTextureHandle("MultiSellWnd.MultisellTabEnableWnd.listSlotBg2_Texture_MultisellTabIconWnd");
	ItemCount_EditBox = xxGetEditBoxHandle("MultiSellWnd.ItemCount_EditBox");
	Search_EditBox = xxGetEditBoxHandle("MultiSellWnd.Search_EditBox");
	MultisellTab = xxGetTabHandle("MultiSellWnd.MultisellTab");
	ListTabIcon_Button.SetTooltipCustomType(xxMakeTooltipSimpleText("Change List/Icon View"));
	IconTabIcon_Button.SetTooltipCustomType(xxMakeTooltipSimpleText("Change List/Icon View"));
	pre_itemList = -1;
	GlobalItemCount = 1;
	toggleListWithIconWindow(true);
}

function OnEvent(int Event_ID, string param)
{
	switch(Event_ID)
	{
		case 2530:
			HandleShopID(param);
		break;
			
		case 2540:
			HandleItemList(param);
		break;
			
		case 2550:
			HandleNeededItemList(param);
		break;
			
		case 2560:
			HandleItemListEnd(param);
			CheckMS();
		break;
			
		case 1710:
			HandleDialogOK();
		break;
			
		default:
		break;
	}
}

function CheckMS()
{
	local int i, tmpInt;
	local string tmp;

	isExecMultisell(false);
	i = 0;
	J0x0E:
	if(i < m_MultiSellInfoList.Length)
	{
		tmp = string(m_MultiSellInfoList[i].OutputItemInfoList[0].Reserved);
		tmp = Left(tmp, Len(tmp) - 5);
		tmpInt = int(tmp);
		if(tmpInt > (i + 1))
		{
			isExecMultisell(true);
		}
		i++;
		goto J0x0E;
	}
	MultisellTab.InitTabCtrl();
}

function isExecMultisell(bool Exec)
{
	if(!Exec)
	{
		MultisellTab.SetDisable(1, false);
		Search_EditBox.EnableWindow();
		isExec = false;        
	}
	else
	{
		MultisellTab.SetDisable(1, true);
		Search_EditBox.DisableWindow();
		isExec = true;
	}
}

function OnShow()
{
	MultisellTab.InitTabCtrl();
	toggleListWithIconWindow(true);
	ItemCount_EditBox.SetString("1");
	Search_EditBox.SetString("");
	GlobalItemCount = 1;
	GlobalAvailable = 0;
	lastFalseItem = -1;
	MultisellTabTotalWnd_ListCtrl.SetScrollPosition(0);
	MultisellTabEnableWnd_ListCtrl.SetScrollPosition(0);
}

function OnHide()
{
	if(DialogIsMine())
	{
		DialogHide();
	}
	iniListWithItemWindow();
}

function OnClickButton(string Name)
{
	switch(Name)
	{
		case "Close_Button":
			Clear();
			HideWindow("MultiSellWnd");
		break;
			
		case "ExChange_Button":
			HandleOKButton();
		break;
			
		case "IconTabIcon_Button":
		case "ListTabIcon_Button":
			toggleListWithIconWindow();
		break;
			
		case "Search_Button":
			OnSearch_ButtonClick();
		break;
			
		case "Refresh_Button":
			OnRefresh_ButtonClick();
		break;
			
		case "Clear_Button":
			OnClear_ButtonClick();
		break;
			
		case "MultiSell_Up_Button":
			OnMultiSell_Up_ButtonClick();
		break;
			
		case "MultiSell_Down_Button":
			OnMultiSell_Down_ButtonClick();
		break;
			
		case "MultiSell_Input_Button":
			OnPriceEditBtnHandler();
		break;
			
		default:
		break;
	}
	if(Left(Name, 4) == "root")
	{
		OnClickItem("MultisellTabTotalWnd_ItemWindow", int(Mid(Name, 5)) - 1);
		updateUIControl();        
	}
	else
	{
		if(Left(Name, 6) == "enable")
		{
			OnClickItem("MultisellTabEnableWnd_ItemWindow", int(Mid(Name, 11)) - 1);
			updateUIControl();
		}
	}
}

function toggleListWithIconWindow(optional bool bInit)
{
	if(bInit)
	{
		IconTabIcon_Button.ShowWindow();
		ListTabIcon_Button.HideWindow();
	}
	if(ListTabIcon_Button.IsShowWindow())
	{
		IconTabIcon_Button.ShowWindow();
		ListTabIcon_Button.HideWindow();
		MultisellTabTotalWnd_ItemWindow.HideWindow();
		MultisellTabEnableWnd_ItemWindow.HideWindow();
		MultisellTabTotalWnd_ListCtrl.ShowWindow();
		MultisellTabEnableWnd_ListCtrl.ShowWindow();
		listGroupBg_Texture_MultisellTabIistWnd.ShowWindow();
		listGroupBg_Texture_MultisellTabIistWnd2.ShowWindow();
		listSlotBg1_Texture_MultisellTabIconWnd.HideWindow();
		listSlotBg2_Texture_MultisellTabIconWnd.HideWindow();
		listSlotBg1_Texture_MultisellTabIconWnd2.HideWindow();
		listSlotBg2_Texture_MultisellTabIconWnd2.HideWindow();        
	}
	else
	{
		IconTabIcon_Button.HideWindow();
		ListTabIcon_Button.ShowWindow();
		MultisellTabTotalWnd_ListCtrl.HideWindow();
		MultisellTabEnableWnd_ListCtrl.HideWindow();
		MultisellTabTotalWnd_ItemWindow.ShowWindow();
		MultisellTabEnableWnd_ItemWindow.ShowWindow();
		listGroupBg_Texture_MultisellTabIistWnd.HideWindow();
		listGroupBg_Texture_MultisellTabIistWnd2.HideWindow();
		listSlotBg1_Texture_MultisellTabIconWnd.ShowWindow();
		listSlotBg2_Texture_MultisellTabIconWnd.ShowWindow();
		listSlotBg1_Texture_MultisellTabIconWnd2.ShowWindow();
		listSlotBg2_Texture_MultisellTabIconWnd2.ShowWindow();
	}
}

function setEditStateItemCount()
{
	ItemCount_EditBox.SetString("1");
}

function OnClickItem(string strID, int Index)
{
	local string tmp;
	local ItemInfo Info;

	if(strID == "MultisellTabTotalWnd_ItemWindow")
	{
		if(MultisellTabTotalWnd_ItemWindow.GetItem(Index, Info))
		{
			tmp = string(Info.Reserved);
			if(Info.Reserved > 9999)
            {
				tmp = Left(tmp, Len(tmp) - 5);
			}
			if(isExec)
			{
				selectedGlobal = Index;                
			}
			else
			{
				selectedGlobal = int(tmp) - 1;
			}
			indexGlobal = Index;
			updateUIControl();
		}        
	}
	else
	{
		if(strID == "MultisellTabEnableWnd_ItemWindow")
		{
			if(MultisellTabEnableWnd_ItemWindow.GetItem(Index, Info))
			{
				tmp = string(Info.Reserved);
				if(Info.Reserved > 9999)
            {
				tmp = Left(tmp, Len(tmp) - 5);
			}
				if(isExec)
				{
					selectedGlobal = Index;                    
				}
				else
				{
					selectedGlobal = int(tmp) - 1;
				}
				indexGlobal = Index;
				updateUIControl();
			}
		}
	}
}

function updateUIControl()
{
	setEditStateItemCount();
	setTreeNeedItemInfo();
}

function setTreeNeedItemInfo()
{
	local int i, Index, nTmp;
	local string param;
	local XMLTreeNodeInfo infNode;
	local string TextureName, strTmp, strRetName;
	local ItemInfo itemTooltip, cItemInfo, rItemInfo;
	local ClanWnd scriptClan;
	local ExpBarWnd scriptCafe;
	local string iName;
	local Color i_Color;

	if(getCurrentSelectedItemInfo(rItemInfo))
	{
		TreeClear("MultiSellWnd.ItemListInfo");
		TreeClear("MultiSellWnd.NeedItem");
		infNode.strName = "rootNeed";
		infNode.nOffSetX = 0;
		infNode.nOffSetY = 2;
		strTmp = Class'UIAPI_TREECTRL'.static.InsertNode("MultiSellWnd.NeedItem", "", infNode);
		iName = "";
		Index = selectedGlobal;
		itemCountTextEditEnable(true);
		if(!IsStackableItem(rItemInfo.ConsumeType))
		{
			itemCountTextEditEnable(false);
		}
		if((Index >= 0) && Index < m_MultiSellInfoList.Length)
		{
			i = 0;
			J0x107:
			if(i < m_MultiSellInfoList[Index].InputItemInfoList.Length)
			{
				iName = "";
				TextureName = "";
				param = "";
				ParamAdd(param, "Name", m_MultiSellInfoList[Index].InputItemInfoList[i].Name);
				ParamAdd(param, "ID", string(m_MultiSellInfoList[Index].InputItemInfoList[i].Id));
				ParamAdd(param, "Num", string(m_MultiSellInfoList[Index].InputItemInfoList[i].Count));
				ParamAdd(param, "Icon", m_MultiSellInfoList[Index].InputItemInfoList[i].IconName);
				ParamAdd(param, "AdditionalName", m_MultiSellInfoList[Index].InputItemInfoList[i].AdditionalName);
				ParamAdd(param, "Enchant", string(m_MultiSellInfoList[Index].InputItemInfoList[i].Enchant));
				ParamAdd(param, "CrystalType", string(m_MultiSellInfoList[Index].InputItemInfoList[i].CrystalType));
				ParamAdd(param, "ItemType", string(m_MultiSellInfoList[Index].InputItemInfoList[i].ItemType));
				itemTooltip = SetItemTooltip(m_MultiSellInfoList[Index].InputItemInfoList[i].Id);
				TextureName = GetItemGradeTextureName(m_MultiSellInfoList[Index].InputItemInfoList[i].CrystalType);
				infNode.strName = string(itemTooltip.ClassID) $ string(i);
				infNode.bFollowCursor = false;
				infNode.ToolTip = SetTooltip(itemTooltip);
				infNode.nOffSetY = 4;
				infNode.bShowButton = 0;
				strRetName = Class'UIAPI_TREECTRL'.static.InsertNode("MultiSellWnd.NeedItem", "rootNeed", infNode);
				TreeInsertTextureNode("MultiSellWnd.NeedItem", strRetName, "L2UI_CH3.Null", 257, 38);
				TreeInsertTextureNode("MultiSellWnd.NeedItem", strRetName, "L2UI_CH3.InventoryWnd.ItemWindow_DF_Slotbox_2x2", 36, 36, -251, 2);
				TreeInsertTextureNode("MultiSellWnd.NeedItem", strRetName, m_MultiSellInfoList[Index].InputItemInfoList[i].IconName, 32, 32, -34, 4 - 1);
				if(m_MultiSellInfoList[Index].InputItemInfoList[i].Enchant > 0)
				{
					TreeInsertTextNodeItem("MultiSellWnd.NeedItem", strRetName, "+" $ string(m_MultiSellInfoList[Index].InputItemInfoList[i].Enchant), 7, 5, 13, true);
				}
				iName = m_MultiSellInfoList[Index].InputItemInfoList[i].Name;
				i_Color = xxgetInstanceL2Util().getItemNameColor(setTooltipNameColor(iName));
				iName = setTooltipNameItem(iName);
				if(Len((string(m_MultiSellInfoList[Index].InputItemInfoList[i].Enchant) @ iName) @ m_MultiSellInfoList[Index].InputItemInfoList[i].AdditionalName) > 32)
				{
					iName = Left(iName, (31 - Len(m_MultiSellInfoList[Index].InputItemInfoList[i].AdditionalName)) - 4) $ "...";
				}
				TreeInsertNodeItemColor("MultiSellWnd.NeedItem", strRetName, iName, 7, 5, i_Color, true);
				if(m_MultiSellInfoList[Index].InputItemInfoList[i].AdditionalName != "")
				{
					TreeInsertTextNodeItem("MultiSellWnd.NeedItem", strRetName, m_MultiSellInfoList[Index].InputItemInfoList[i].AdditionalName, 5, 5, 4, true);
				}
				if(Len(TextureName) > 0)
				{
					if((m_MultiSellInfoList[Index].InputItemInfoList[i].CrystalType == 6) || m_MultiSellInfoList[Index].InputItemInfoList[i].CrystalType == 7)
					{
						TreeInsertTextureNode("MultiSellWnd.NeedItem", strRetName, TextureName, 32, 16, 2, 5);                        
					}
					else
					{
						TreeInsertTextureNode("MultiSellWnd.NeedItem", strRetName, TextureName, 16, 16, 2, 5);
					}
				}
				TreeInsertTextNodeItem("MultiSellWnd.NeedItem", strRetName, " x " $ MakeCostString(string(GlobalItemCount * m_MultiSellInfoList[Index].InputItemInfoList[i].Count)), 45, -14, 2, false, true);
				if(!IsStackableItem(m_MultiSellInfoList[Index].InputItemInfoList[i].ItemType))
				{
					nTmp = FindNoStackableItem(m_MultiSellInfoList[Index].InputItemInfoList[i].Id);                    
				}
				else
				{
					GetItemInvInfo(m_MultiSellInfoList[Index].InputItemInfoList[i].Id, cItemInfo);
					nTmp = cItemInfo.ItemNum;
				}
				if(m_MultiSellInfoList[Index].InputItemInfoList[i].IconName == "icon.etc_i.etc_bloodpledge_point_i00")
				{
					scriptClan = ClanWnd(GetScript("ClanWnd"));
					nTmp = scriptClan.m_clanNameValue;
					nTmp = 0;
				}
				if(m_MultiSellInfoList[Index].InputItemInfoList[i].IconName == "icon.etc_i.etc_pccafe_point_i00")
				{
					scriptCafe = ExpBarWnd(GetScript("ExpBarWnd"));
					nTmp = scriptCafe.zzcafePoint;
				}
				if(i == 0)
				{
					GlobalAvailable = nTmp / m_MultiSellInfoList[Index].InputItemInfoList[i].Count;
				}
				if(i >= 0)
				{
					if(GlobalAvailable > (nTmp / m_MultiSellInfoList[Index].InputItemInfoList[i].Count))
					{
						GlobalAvailable = nTmp / m_MultiSellInfoList[Index].InputItemInfoList[i].Count;
					}
				}
				if(nTmp < (GlobalItemCount * m_MultiSellInfoList[Index].InputItemInfoList[i].Count))
				{
					TreeInsertTextNodeItem("MultiSellWnd.NeedItem", strRetName, (" (" $ MakeCostString(string(nTmp))) $ ")", 4, -14, 3);
					goto J0x9F5;
				}
				TreeInsertTextNodeItem("MultiSellWnd.NeedItem", strRetName, (" (" $ MakeCostString(string(nTmp))) $ ")", 4, -14, 6);
				J0x9F5:
				++i;
				goto J0x107;
			}
			SetItemInfoList(Index);
			if(pre_itemList != Index)
			{
				if(DialogIsMine())
				{
					DialogHide();
				}
			}
		}
	}
}

function SetItemInfoList(int ItemPos)
{
	local int i;
	local ItemInfo Info;
	local XMLTreeNodeInfo infNode;
	local string NodeName, iName, GradeTexture;
	local Color iColor;
	local ItemWindowHandle hItemWnd;
	local EItemType EItemType;
	local ItemInfo ItemSlot;
	local int ItemValue, ItemCompareValue;
	local string tmpDescription;

	infNode.strName = "rootInfo";
	infNode.nOffSetX = 0;
	infNode.nOffSetY = 2;
	NodeName = Class'UIAPI_TREECTRL'.static.InsertNode("MultiSellWnd.ItemListInfo", "", infNode);
	i = 0;
	J0x6C:
	if(i < m_MultiSellInfoList[ItemPos].NeededItemNum)
	{
		Info = m_MultiSellInfoList[ItemPos].OutputItemInfoList[i];
		GradeTexture = "";
		GradeTexture = GetItemGradeTextureName(Info.CrystalType);
		infNode.strName = string(i);
		infNode.bFollowCursor = false;
		infNode.ToolTip = SetTooltip(Info);
		infNode.nOffSetY = 4;
		infNode.bShowButton = 0;
		NodeName = Class'UIAPI_TREECTRL'.static.InsertNode("MultiSellWnd.ItemListInfo", "rootInfo", infNode);
		EItemType = EItemType(Info.ItemType);
		TreeInsertTextureNode("MultiSellWnd.ItemListInfo", NodeName, "L2UI_CH3.Null", 257, 38);
		TreeInsertTextureNode("MultiSellWnd.ItemListInfo", NodeName, "L2UI_CH3.InventoryWnd.ItemWindow_DF_Slotbox_2x2", 36, 36, -251, 2);
		TreeInsertTextureNode("MultiSellWnd.ItemListInfo", NodeName, Info.IconName, 32, 32, -34, 4 - 1);
		if(Info.Enchanted > 0)
		{
			TreeInsertTextNodeItem("MultiSellWnd.ItemListInfo", NodeName, "+" $ string(Info.Enchanted), 7, 5, 13, true);
		}
		iName = Info.Name;
		iColor = xxgetInstanceL2Util().getItemNameColor(setTooltipNameColor(iName));
		iName = setTooltipNameItem(iName);
		if(Len((string(Info.Enchanted) $ iName) $ Info.AdditionalName) > 32)
		{
			iName = Left(iName, (31 - Len(Info.AdditionalName)) - 4) $ "...";
		}
		TreeInsertNodeItemColor("MultiSellWnd.ItemListInfo", NodeName, iName, 7, 5, iColor, true);
		if(Info.AdditionalName != "")
		{
			TreeInsertTextNodeItem("MultiSellWnd.ItemListInfo", NodeName, Info.AdditionalName, 5, 5, 4, true);
		}
		if(Len(GradeTexture) > 0)
		{
			if((Info.CrystalType == 6) || Info.CrystalType == 7)
			{
				TreeInsertTextureNode("MultiSellWnd.ItemListInfo", NodeName, GradeTexture, 32, 16, 2, 5);                
			}
			else
			{
				TreeInsertTextureNode("MultiSellWnd.ItemListInfo", NodeName, GradeTexture, 16, 16, 2, 5);
			}
		}
		if(Info.ItemNum >= 1)
		{
			TreeInsertTextNodeItem("MultiSellWnd.ItemListInfo", NodeName, "x" $ string(Info.ItemNum), 5, 5, 2, true);
		}
		TreeInsertTextNodeItem("MultiSellWnd.ItemListInfo", NodeName, getSlotTypeWithItemTypeString(Info), 48, -14, 2, false, true);
		if(getItemInveCompare(Info.SlotBitType, hItemWnd))
		{
			hItemWnd.GetItem(0, ItemSlot);
			if(ItemSlot.ClassID > 0)
			{
				if(!(Info.SlotBitType != ItemSlot.SlotBitType) && hItemWnd.GetWindowName() != "EquipItem_RHand")
				{
					switch(EItemType)
					{
						case ITEM_WEAPON:
							ItemValue = EnchantCalculateWeapon(Info);
							ItemCompareValue = EnchantCalculateWeapon(ItemSlot);
						break;
							
						case ITEM_ARMOR:
							ItemValue = EnchantCalculateArmor(Info);
							ItemCompareValue = EnchantCalculateArmor(ItemSlot);
						break;
							
						case ITEM_ACCESSARY:
							ItemValue = EnchantCalculateJewel(Info);
							ItemCompareValue = EnchantCalculateJewel(ItemSlot);
						break;
							
						default:
						break;
					}
					if((ItemValue > ItemCompareValue) && Info.ShieldDefense <= 0)
					{
						TreeInsertTextureNode("MultiSellWnd.ItemListInfo", NodeName, "InterfaceText.ToolTip.up_stats", 14, 8, 3, -10, true, false);
						TreeInsertNodeItemColor("MultiSellWnd.ItemListInfo", NodeName, "+" $ string(ItemValue - ItemCompareValue), 0, -14, GetAColor(96, 182, 9, 255), true, false);                        
					}
					else
					{
						if((ItemValue < ItemCompareValue) && Info.ShieldDefense <= 0)
						{
							TreeInsertTextureNode("MultiSellWnd.ItemListInfo", NodeName, "InterfaceText.ToolTip.down_stats", 14, 8, 3, -10, true, false);
							TreeInsertNodeItemColor("MultiSellWnd.ItemListInfo", NodeName, "" $ string(ItemValue - ItemCompareValue), 0, -14, SetCustomColor("Red"), true, false);
						}
					}
				}                
			}
			else
			{
				switch(EItemType)
				{
					case ITEM_WEAPON:
						ItemValue = EnchantCalculateWeapon(Info);
					break;
						
					case ITEM_ARMOR:
						ItemValue = EnchantCalculateArmor(Info);
					break;
						
					case ITEM_ACCESSARY:
						ItemValue = EnchantCalculateJewel(Info);
					break;
						
					default:
					break;
				}
				if((ItemValue > 0) && Info.ShieldDefense <= 0)
				{
					TreeInsertTextureNode("MultiSellWnd.ItemListInfo", NodeName, "InterfaceText.ToolTip.up_stats", 14, 8, 3, -10, true, false);
					TreeInsertNodeItemColor("MultiSellWnd.ItemListInfo", NodeName, "+" $ string(ItemValue), 0, -14, GetAColor(96, 182, 9, 255), true, false);
				}
			}
		}
		if(Info.PhysicalDamage > 0)
		{
			TreeInsertNodeItemColor("MultiSellWnd.ItemListInfo", NodeName, GetSystemString(94) $ ":", 7, 5, xxgetInstanceL2Util().BrightWhite, true, true);
			TreeInsertNodeItemColor("MultiSellWnd.ItemListInfo", NodeName, string(Info.PhysicalDamage), 5, 5, xxgetInstanceL2Util().ColorYellow, true);
		}
		if(Info.MagicalDamage > 0)
		{
			TreeInsertNodeItemColor("MultiSellWnd.ItemListInfo", NodeName, GetSystemString(98) $ ":", 7, 5, xxgetInstanceL2Util().BrightWhite, true, true);
			TreeInsertNodeItemColor("MultiSellWnd.ItemListInfo", NodeName, string(Info.MagicalDamage), 5, 5, xxgetInstanceL2Util().ColorYellow, true);
		}
		if((Info.SlotBitType == 256) || Info.SlotBitType == 128)
		{
			if(Info.ShieldDefenseRate > 0)
			{
				TreeInsertNodeItemColor("MultiSellWnd.ItemListInfo", NodeName, GetSystemString(317) $ ":", 7, 5, xxgetInstanceL2Util().BrightWhite, true, true);
				TreeInsertNodeItemColor("MultiSellWnd.ItemListInfo", NodeName, string(Info.ShieldDefenseRate), 5, 5, xxgetInstanceL2Util().ColorYellow, true);
			}
			if(Info.AvoidModify > 0)
			{
				TreeInsertNodeItemColor("MultiSellWnd.ItemListInfo", NodeName, GetSystemString(97) $ ":", 7, 5, xxgetInstanceL2Util().BrightWhite, true, true);
				TreeInsertNodeItemColor("MultiSellWnd.ItemListInfo", NodeName, string(Info.AvoidModify), 5, 5, xxgetInstanceL2Util().ColorYellow, true);
			}
		}
		if(Info.PhysicalDefense > 0)
		{
			TreeInsertNodeItemColor("MultiSellWnd.ItemListInfo", NodeName, GetSystemString(95) $ ":", 7, 5, xxgetInstanceL2Util().BrightWhite, true, true);
			TreeInsertNodeItemColor("MultiSellWnd.ItemListInfo", NodeName, string(Info.PhysicalDefense), 5, 5, xxgetInstanceL2Util().ColorYellow, true);
		}
		if(Info.MagicalDefense > 0)
		{
			TreeInsertNodeItemColor("MultiSellWnd.ItemListInfo", NodeName, GetSystemString(99) $ ":", 7, 5, xxgetInstanceL2Util().BrightWhite, true, true);
			TreeInsertNodeItemColor("MultiSellWnd.ItemListInfo", NodeName, string(Info.MagicalDefense), 5, 5, xxgetInstanceL2Util().ColorYellow, true);
		}
		MileniumGearScore(GetScript("MileniumGearScore")).AppendShopItemScore(NodeName, Info);
			if(Info.Description != "")
		{
			TreeInsertNodeItemColor("MultiSellWnd.ItemListInfo", NodeName, setItemDecWidth(info.Description, 256),7 , 5, GetAColor(110,140,160,255),false , true);
		}
		if(((EItemType == ITEM_WEAPON) && Info.AdditionalName != "") || isShowDescription(Info))
		{
			if(InStr(Info.Description, "<Soul Crystal Enhancement>\\n ") > -1)
			{
				tmpDescription =  ReplaceText(Info.Description, "<Soul Crystal Enhancement>\\n ", "");                
			}
			else
			{
				tmpDescription =  ReplaceText(Info.Description, "<Soul Crystal Enhancement>\\n", "");
			}
			bTooltipItem(tmpDescription);
			if(tmpDescription != "")
			{
				TreeInsertNodeItemColor("MultiSellWnd.ItemListInfo", NodeName, setItemDecWidth(tmpDescription, 256), 7, 5, GetAColor(110, 140, 160, 255), false, true);
			}
		}
		++i;
		goto J0x6C;
	}
}

function bool isShowDescription(ItemInfo item)
{
	if(InStr(item.Name, "Enchant") > -1)
	{
		return true;
	}
	if(InStr(item.Name, "Tattoo") > -1)
	{
		return true;
	}
	if(InStr(item.Name, "Glifo") > -1)
	{
		return true;
	}
	if(InStr(item.Name, "Baby") > -1)
	{
		return true;
	}
	switch(m_shopID)
	{
		case setShopItemID("90163"):
		case setShopItemID("085"):
		case setShopItemID("086"):
		case setShopItemID("226"):
			return true;
		break;
		
		default:
			switch(item.ClassID)
			{
				case 9524:
				case 9525:
				case 9526:
				case 10106:
					return true;
				break;
				
				default:
					return false;
				break;
			}
		break;
	}
}

function Print()
{
	local int i, j;

	i = 0;
	J0x07:
	if(i < m_MultiSellInfoList.Length)
	{
		j = 0;
		J0x1E:
		if(j < m_MultiSellInfoList[i].InputItemInfoList.Length)
		{
			xDPatch((((("Print (" $ string(i)) $ ",") $ string(j)) $ "), ") $ m_MultiSellInfoList[i].InputItemInfoList[j].Name);
			++j;
			goto J0x1E;
		}
		++i;
		goto J0x07;
	}
}

function HandleShopID(string param)
{
	Clear();
	ParseInt(param, "shopID", m_shopID);
}

function Clear()
{
	m_MultiSellInfoList.Length = 0;
	TreeClear("MultiSellWnd.ItemListInfo");
	MultisellTabTotalWnd_ItemWindow.Clear();
	MultisellTabEnableWnd_ItemWindow.Clear();
	iniListWithItemWindow();
	itemCountTextEditEnable(false);
}

function HandleItemList(string param)
{
	local ItemInfo Info;
	local int Index, Type, i, ClassID;
	local bool bMatchFound;

	ParseInt(param, "classID", ClassID);
	Class'UIDATA_ITEM'.static.GetItemInfo(ClassID, Info);
	Info.ClassID = ClassID;
	ParseInt(param, "index", Index);
	ParseInt(param, "type", Type);
	ParseInt(param, "ID", Info.Reserved);
	ParseInt(param, "slotBitType", Info.SlotBitType);
	ParseInt(param, "itemType", Info.ItemType);
	ParseInt(param, "itemCount", Info.ItemNum);
	ParseInt(param, "enchant", Info.Enchanted);
	ParseInt(param, "OutputRefineryOp1", Info.RefineryOp1);
	ParseInt(param, "OutputRefineryOp2", Info.RefineryOp2);
	if(0 < Info.Durability)
	{
		Info.CurrentDurability = Info.Durability;
	}
	if(Index == 0)
	{
		i = m_MultiSellInfoList.Length;
		m_MultiSellInfoList.Length = i + 1;
		m_MultiSellInfoList[i].MultiSellType = Type;
		m_MultiSellInfoList[i].NeededItemNum = 1;
		m_MultiSellInfoList[i].OutputItemInfoList.Length = Index + 1;
		m_MultiSellInfoList[i].OutputItemInfoList[Index] = Info;        
	}
	else
	{
		if(Index > 0)
		{
			bMatchFound = false;
			i = m_MultiSellInfoList.Length - 1;
			J0x225:
			if(i >= 0)
			{
				if(((m_MultiSellInfoList[i].OutputItemInfoList[0].Reserved == Info.Reserved) && m_MultiSellInfoList[i].OutputItemInfoList[0].RefineryOp1 == Info.RefineryOp1) && m_MultiSellInfoList[i].OutputItemInfoList[0].RefineryOp2 == Info.RefineryOp2)
				{
					bMatchFound = true;
					goto J0x2BB;
				}
				--i;
				goto J0x225;
			}
			J0x2BB:
			if(bMatchFound)
			{
				if(m_MultiSellInfoList[i].OutputItemInfoList.Length <= Index)
				{
					m_MultiSellInfoList[i].OutputItemInfoList.Length = Index + 1;
				}
				m_MultiSellInfoList[i].MultiSellType = Type;
				m_MultiSellInfoList[i].OutputItemInfoList[Index] = Info;
				++m_MultiSellInfoList[i].NeededItemNum;                
			}
			else
			{
				Debug("MultiSellWnd Error!!");
			}
		}
	}
}

function HandleNeededItemList(string param)
{
	local NeededItem item;
	local ItemInfo Info;
	local int i, Id, Index, RefineryOp1, RefineryOp2;

	ParseInt(param, "ID", Id);
	ParseInt(param, "refineryOp1", RefineryOp1);
	ParseInt(param, "refineryOp2", RefineryOp2);
	ParseInt(param, "ClassID", item.Id);
	ParseInt(param, "count", item.Count);
	ParseInt(param, "enchant", item.Enchant);
	ParseInt(param, "inputRefineryOp1", item.RefineryOp1);
	ParseInt(param, "inputRefineryOp2", item.RefineryOp2);
	ParseString(param, "AdditionalName", item.AdditionalName);
	if(item.Id == -100)
	{
		item.Name = GetSystemString(1277);
		item.IconName = "icon.etc_i.etc_pccafe_point_i00";
		item.Enchant = 0;
		item.ItemType = -1;
		item.Id = 0;        
	}
	else
	{
		if(item.Id == -200)
		{
			item.Name = GetSystemString(1311);
			item.IconName = "icon.etc_i.etc_bloodpledge_point_i00";
			item.Enchant = 0;
			item.ItemType = -1;
			item.Id = 0;            
		}
		else
		{
			item.Name = Class'UIDATA_ITEM'.static.GetItemName(item.Id);
			item.IconName = Class'UIDATA_ITEM'.static.GetItemTextureName(item.Id);
			item.AdditionalName = Class'UIDATA_ITEM'.static.GetItemAdditionalName(item.Id);
		}
	}
	i = m_MultiSellInfoList.Length - 1;
	J0x29B:
	if(i >= 0)
	{
		if(((m_MultiSellInfoList[i].OutputItemInfoList[0].Reserved == Id) && m_MultiSellInfoList[i].OutputItemInfoList[0].RefineryOp1 == RefineryOp1) && m_MultiSellInfoList[i].OutputItemInfoList[0].RefineryOp2 == RefineryOp2)
		{
			Info = m_MultiSellInfoList[i].OutputItemInfoList[0];
			Index = m_MultiSellInfoList[i].InputItemInfoList.Length;
			m_MultiSellInfoList[i].InputItemInfoList.Length = Index + 1;
			item.ItemType = Class'UIDATA_ITEM'.static.GetItemDataType(item.Id);
			item.CrystalType = Class'UIDATA_ITEM'.static.GetItemCrystalType(item.Id);
			m_MultiSellInfoList[i].InputItemInfoList[Index] = item;
			if(!compareWithInven(item, Info))
			{
				m_MultiSellInfoList[i].OutputItemInfoList[0].ForeTexture = "";                
			}
			else
			{
				m_MultiSellInfoList[i].OutputItemInfoList[0].ForeTexture = "L2UI_CH3.MultiSellWnd.SellablePanel";
			}
			goto J0x436;
		}
		--i;
		goto J0x29B;
	}
	J0x436:
	return;
}

function bool compareWithInven(NeededItem item, ItemInfo Info)
{
	local ItemInfo InvenItemInfo;

	if(lastFalseItem == Info.ClassID)
	{
		return false;
	}
	if(item.Id > 0)
	{
		GetItemInvInfo(item.Id, InvenItemInfo);
		if(item.Count > 0)
		{
			if(InvenItemInfo.ItemNum >= item.Count)
			{
				return true;
			}
		}
	}
	lastFalseItem = Info.ClassID;
	return false;
}

function HandleItemListEnd(string param)
{
	local WindowHandle m_inventoryWnd;

	m_inventoryWnd = GetHandle("InventoryWnd");
	if(m_inventoryWnd.IsShowWindow())
	{
		m_inventoryWnd.HideWindow();
	}
	ShowWindow("MultiSellWnd");
	Class'UIAPI_WINDOW'.static.SetFocus("MultiSellWnd");
	ShowItemList();
}

function ShowItemList()
{
	local ItemInfo Info;
	local int i;

	TreeClear("MultiSellWnd.MultisellTabTotalWnd.MultisellTabTotalWnd_ListCtrl");
	TreeClear("MultiSellWnd.MultisellTabEnableWnd.MultisellTabEnableWnd_ListCtrl");
	TreeInsertRootNode("MultiSellWnd.MultisellTabTotalWnd.MultisellTabTotalWnd_ListCtrl", "root", "", 0, 4);
	TreeInsertRootNode("MultiSellWnd.MultisellTabEnableWnd.MultisellTabEnableWnd_ListCtrl", "enableroot", "", 0, 4);
	i = 0;
	J0x143:
	if(i < m_MultiSellInfoList.Length)
	{
		Info = m_MultiSellInfoList[i].OutputItemInfoList[0];
		MultisellTabTotalWnd_ItemWindow.AddItem(Info);
		addTreeNode(MultisellTabTotalWnd_ItemWindow.GetItemNum(), Info, "MultiSellWnd.MultisellTabTotalWnd.MultisellTabTotalWnd_ListCtrl");
		if(Info.ForeTexture == "L2UI_CH3.MultiSellWnd.SellablePanel")
		{
			MultisellTabEnableWnd_ItemWindow.AddItem(Info);
			addTreeNode(MultisellTabEnableWnd_ItemWindow.GetItemNum(), Info, "MultiSellWnd.MultisellTabEnableWnd.MultisellTabEnableWnd_ListCtrl");
		}
		++i;
		goto J0x143;
	}
}

function fildAndShowItemList(string searchStr)
{
	local ItemInfo Info;
	local int i;
	local string fullNameString;

	TreeClear("MultiSellWnd.ItemListInfo");
	MultisellTabTotalWnd_ItemWindow.Clear();
	MultisellTabEnableWnd_ItemWindow.Clear();
	iniListWithItemWindow();
	i = 0;
	J0x4C:
	if(i < m_MultiSellInfoList.Length)
	{
		Info = m_MultiSellInfoList[i].OutputItemInfoList[0];
		fullNameString = GetItemNameAll(Info);
		if((findMatchString(fullNameString, searchStr)) != -1)
		{
			MultisellTabTotalWnd_ItemWindow.AddItem(Info);
			addTreeNode(MultisellTabTotalWnd_ItemWindow.GetItemNum(), Info, "MultiSellWnd.MultisellTabTotalWnd.MultisellTabTotalWnd_ListCtrl");
			if(Info.ForeTexture == "L2UI_CH3.MultiSellWnd.SellablePanel")
			{
				MultisellTabEnableWnd_ItemWindow.AddItem(Info);
				addTreeNode(MultisellTabEnableWnd_ItemWindow.GetItemNum(), Info, "MultiSellWnd.MultisellTabEnableWnd.MultisellTabEnableWnd_ListCtrl");
			}
		}
		++i;
		goto J0x4C;
	}
}

function iniListWithItemWindow()
{
	ItemCount_EditBox.SetString("1");
	TreeClear("MultiSellWnd.MultisellTabTotalWnd.MultisellTabTotalWnd_ListCtrl");
	TreeClear("MultiSellWnd.MultisellTabEnableWnd.MultisellTabEnableWnd_ListCtrl");
	TreeClear("MultiSellWnd.NeedItem");
	TreeClear("MultiSellWnd.ItemListInfo");
	TreeInsertRootNode("MultiSellWnd.MultisellTabTotalWnd.MultisellTabTotalWnd_ListCtrl", "root", "", 0, 4);
	TreeInsertRootNode("MultiSellWnd.MultisellTabEnableWnd.MultisellTabEnableWnd_ListCtrl", "enableroot", "", 0, 4);
	TreeInsertRootNode("MultiSellWnd.NeedItem", "rootNeed", "", 0, 4);
}

function OnChangeEditBox(string strID)
{
	local int SelectedIndex;

	switch(strID)
	{
		case "ItemCount_EditBox":
			SelectedIndex = selectedGlobal;
			if(SelectedIndex >= 0)
			{
				if(int(ItemCount_EditBox.GetString()) > 9999)
				{
					ItemCount_EditBox.SetString(string(9999));
				}
				GlobalItemCount = int(ItemCount_EditBox.GetString());
				pre_itemList = SelectedIndex;
				setTreeNeedItemInfo();
			}
		break;
			
		default:
		break;
	}
}

function HandleOKButton()
{
	local int SelectedIndex, ItemNum;

	SelectedIndex = selectedGlobal;
	ItemNum = int(ItemCount_EditBox.GetString());
	if(SelectedIndex >= 0)
	{
		DialogSetReservedInt(SelectedIndex);
		DialogSetReservedInt2(ItemNum);
		DialogSetID(1122);
		DialogShow(DIALOG_WARNING, GetSystemMessage(1383));
		pre_itemList = SelectedIndex;
	}
}

function HandleDialogOK()
{
	local string param;
	local int SelectedIndex, Id, inputNum;

	if(DialogIsMine())
	{
		Id = DialogGetID();
		if(Id == 1123)
		{
			inputNum = int(DialogGetString());
			if(inputNum <= 0)
			{
				inputNum = 1;
			}
			if(inputNum > 9999)
			{
				inputNum = 9999;
			}
			ItemCount_EditBox.SetString(string(inputNum));
			setTreeNeedItemInfo();            
		}
		else
		{
			SelectedIndex = DialogGetReservedInt();
			ParamAdd(param, "ShopID", string(m_shopID));
			ParamAdd(param, "ItemID", string(m_MultiSellInfoList[SelectedIndex].OutputItemInfoList[0].Reserved));
			ParamAdd(param, "RefineryOp1", string(m_MultiSellInfoList[SelectedIndex].OutputItemInfoList[0].RefineryOp1));
			ParamAdd(param, "RefineryOp2", string(m_MultiSellInfoList[SelectedIndex].OutputItemInfoList[0].RefineryOp2));
			ParamAdd(param, "ItemCount", string(DialogGetReservedInt2()));
			RequestMultiSellChoose(param);
		}
	}
}

function GetItemInvInfo(int Id, out ItemInfo Info)
{
	local int Index;
	local ItemInfo item;
	local ItemWindowHandle InvWnd;

	InvWnd = ItemWindowHandle(GetHandle("InventoryWnd.InventoryItem"));
	Index = InvWnd.FindItemWithClassID(Id);
	InvWnd.GetItem(Index, item);
	if(Index > -1)
	{
		Info = item;        
	}
	else
	{
		Info.ItemNum = 0;
	}
}

function CustomTooltip SetSimpleItemTooltip(ItemInfo item)
{
	local int i;
	local CustomTooltip ToolTip;
	local array<int> arrID;
	local EItemType EItemType;

	EItemType = EItemType(item.ItemType);
	Class'UIDATA_ITEM'.static.GetSetItemIDList(item.ClassID, 0, arrID);
	i = 0;
	ToolTip.DrawList.Length = 5;
	if(item.Enchanted > 0)
	{
		ToolTip.DrawList[i] = xxDrawText("+" $ string(item.Enchanted), xxgetInstanceL2Util().ColorEnchant, true, false, 3, 0);
		i++;
	}
	ToolTip.DrawList[i] = xxDrawText(setTooltipNameItem(item.Name), GetAColor(255, 255, 255, 255), true, false, 3, 0);
	i++;
	if(item.AdditionalName != "")
	{
		ToolTip.DrawList[i] = xxDrawText(item.AdditionalName, xxgetInstanceL2Util().Yellow03, true, false, 3, 0);
		i++;
	}
	if(item.CrystalType > 0)
	{
		if((item.CrystalType == 6) || item.CrystalType == 7)
		{
			ToolTip.DrawList[i] = DrawTex(GetItemGradeTextureName(item.CrystalType), 32, 16, 32, 16, 2, 0, false, false);            
		}
		else
		{
			ToolTip.DrawList[i] = DrawTex(GetItemGradeTextureName(item.CrystalType), 16, 16, 16, 16, 2, 0, false, false);
		}
		i++;
	}
	MileniumGearScore(GetScript("MileniumGearScore")).AppendItemScoreTooltip(ToolTip, item, true);
    return ToolTip;
}

function CustomTooltip SetTooltip(ItemInfo item)
{
	local int i, tmpStatus, armorSetCount, setIdx;
	local string tmpDescription, strValue;
	local CustomTooltip ToolTip;
	local array<int> arrID;
	local EItemType EItemType;
	local ItemWindowHandle hItemWnd;
	local ItemInfo ItemSlot;
	local int ItemValue, ItemCompareValue, currentWidth;

	EItemType = EItemType(item.ItemType);
	Class'UIDATA_ITEM'.static.GetSetItemIDList(item.ClassID, 0, arrID);
	i = 0;
	ToolTip.DrawList.Length = 10;
	ToolTip.MinimumWidth = 250;
	currentWidth = GetItemNameSize(item);
	if(currentWidth < 250)
	{
		currentWidth = 250;
	}
	switch(EItemType)
	{
		case ITEM_ARMOR:
		case ITEM_WEAPON:
		case ITEM_ACCESSARY:
			strValue = setItemTier(item.Description, "Tier:");
		break;
			
		default:
		break;
	}
	if(strValue == "1")
	{
		ToolTip.DrawList[i] = DrawTex("InterfaceText.ToolTip.bgRare", currentWidth, 39, 256, 39, 0, -2, false, false);
		i++;
		ToolTip.DrawList[i] = xxDrawText(GetSystemString(1568), xxgetInstanceL2Util().Blue, true, false, -(GetTextWidth(GetSystemString(1568))) + 8, 20);
		i++;
		ToolTip.DrawList[i] = DrawTex("InterfaceText.ToolTip.SlotBox_Default", 35, 35, 35, 35, -currentWidth + 9, -39, false, false);
		i++;
		ToolTip.DrawList[i] = DrawTex(item.IconName, 32, 32, 32, 32, -33, 1, false, false);
		i++;        
	}
	else
	{
		if(strValue == "2")
		{
			ToolTip.DrawList[i] = DrawTex("InterfaceText.ToolTip.bgSupreme", currentWidth, 39, 256, 39, 0, -2, false, false);
			i++;
			ToolTip.DrawList[i] = xxDrawText(GetSystemString(1569), SetCustomColor("Red"), true, false, -(GetTextWidth(GetSystemString(1569))) + 8, 20);
			i++;
			ToolTip.DrawList[i] = DrawTex("InterfaceText.ToolTip.SlotBox_Default", 35, 35, 35, 35, -currentWidth + 9, -39, false, false);
			i++;
			ToolTip.DrawList[i] = DrawTex(item.IconName, 32, 32, 32, 32, -33, 1, false, false);
			i++;            
		}
		else
		{
			ToolTip.DrawList[i] = DrawTex("InterfaceText.ToolTip.SlotBox_Default", 35, 35, 35, 35, 0, 0, false, false);
			i++;
			ToolTip.DrawList[i] = DrawTex(item.IconName, 32, 32, 32, 32, -33, 1, false, false);
			i++;
		}
	}
	if(item.Enchanted > 0)
	{
		ToolTip.DrawList[i] = xxDrawText("+" $ string(item.Enchanted), xxgetInstanceL2Util().ColorEnchant, true, false, 5, 0);
		i++;
	}
	ToolTip.DrawList[i] = xxDrawText(setTooltipNameItem(item.Name), xxgetInstanceL2Util().getItemNameColor(setTooltipNameColor(item.Name)), true, false, 5, 0);
	i++;
	if(item.AdditionalName != "")
	{
		ToolTip.DrawList[i] = xxDrawText(item.AdditionalName, xxgetInstanceL2Util().Yellow03, true, false, 3, 0);
		i++;
	}
	if(item.CrystalType > 0)
	{
		if((item.CrystalType == 6) || item.CrystalType == 7)
		{
			ToolTip.DrawList[i] = DrawTex(GetItemGradeTextureName(item.CrystalType), 32, 16, 32, 16, 2, 0, false, false);            
		}
		else
		{
			ToolTip.DrawList[i] = DrawTex(GetItemGradeTextureName(item.CrystalType), 16, 16, 16, 16, 2, 0, false, false);
		}
		i++;
	}
	ToolTip.DrawList[i] = xxDrawText(getSlotTypeWithItemTypeString(item), GetAColor(176, 155, 121, 255), true, true, 40, -17);
	i++;
	if(getItemInveCompare(item.SlotBitType, hItemWnd))
	{
		hItemWnd.GetItem(0, ItemSlot);
		EItemType = EItemType(item.ItemType);
		if(ItemSlot.ClassID > 0)
		{
			if(!(item.SlotBitType != ItemSlot.SlotBitType) && hItemWnd.GetWindowName() != "EquipItem_RHand")
			{
				switch(EItemType)
				{
					case ITEM_WEAPON:
						ItemValue = EnchantCalculateWeapon(item);
						ItemCompareValue = EnchantCalculateWeapon(ItemSlot);
					break;
						
					case ITEM_ARMOR:
						ItemValue = EnchantCalculateArmor(item);
						ItemCompareValue = EnchantCalculateArmor(ItemSlot);
					break;
						
					case ITEM_ACCESSARY:
						ItemValue = EnchantCalculateJewel(item);
						ItemCompareValue = EnchantCalculateJewel(ItemSlot);
					break;
						
					default:
					break;
				}
				if((ItemValue > ItemCompareValue) && item.ShieldDefense <= 0)
				{
					ToolTip.DrawList[i] = DrawTex("InterfaceText.ToolTip.up_stats", 14, 8, 14, 8, 3, -13, true, false);
					i++;
					ToolTip.DrawList[i] = xxDrawText("+" $ string(ItemValue - ItemCompareValue), GetAColor(96, 182, 9, 255), true, false, 0, -17);
					i++;                    
				}
				else
				{
					if((ItemValue < ItemCompareValue) && item.ShieldDefense <= 0)
					{
						ToolTip.DrawList[i] = DrawTex("InterfaceText.ToolTip.down_stats", 14, 8, 14, 8, 3, -13, true, false);
						i++;
						ToolTip.DrawList[i] = xxDrawText("" $ string(ItemValue - ItemCompareValue), SetCustomColor("Red"), true, false, 0, -17);
						i++;
					}
				}
			}            
		}
		else
		{
			switch(EItemType)
			{
				case ITEM_WEAPON:
					ItemValue = EnchantCalculateWeapon(item);
				break;
					
				case ITEM_ARMOR:
					ItemValue = EnchantCalculateArmor(item);
				break;
					
				case ITEM_ACCESSARY:
					ItemValue = EnchantCalculateJewel(item);
				break;
					
				default:
				break;
			}
			if((ItemValue > 0) && item.ShieldDefense <= 0)
			{
				ToolTip.DrawList[i] = DrawTex("InterfaceText.ToolTip.up_stats", 14, 8, 14, 8, 3, -13, true, false);
				i++;
				ToolTip.DrawList[i] = xxDrawText("+" $ string(ItemValue - ItemCompareValue), GetAColor(96, 182, 9, 255), true, false, 0, -17);
				i++;
			}
		}
	}
	if(item.PhysicalDamage > 0)
	{
		ToolTip.DrawList[i] = xxDrawText(GetSystemString(94), xxgetInstanceL2Util().BrightWhite, false, true, 2, 2);
		i++;
		ToolTip.DrawList[i] = xxDrawText(": " $ string(item.PhysicalDamage), xxgetInstanceL2Util().ColorYellow, false, false, 2, 2);
		i++;
	}
	if(item.MagicalDamage > 0)
	{
		ToolTip.DrawList[i] = xxDrawText(GetSystemString(98), xxgetInstanceL2Util().BrightWhite, false, true, 2, 2);
		i++;
		ToolTip.DrawList[i] = xxDrawText(": " $ string(item.MagicalDamage), xxgetInstanceL2Util().ColorYellow, false, false, 2, 2);
		i++;
	}
	if((item.SlotBitType == 256) || item.SlotBitType == 128)
	{
		if(item.ShieldDefenseRate > 0)
		{
			ToolTip.DrawList[i] = xxDrawText(GetSystemString(317), xxgetInstanceL2Util().BrightWhite, false, true, 2, 2);
			i++;
			ToolTip.DrawList[i] = xxDrawText(": " $ string(item.ShieldDefenseRate), xxgetInstanceL2Util().ColorYellow, false, false, 2, 2);
			i++;
		}
		if(item.AvoidModify > 0)
		{
			ToolTip.DrawList[i] = xxDrawText(GetSystemString(97), xxgetInstanceL2Util().BrightWhite, false, true, 2, 2);
			i++;
			ToolTip.DrawList[i] = xxDrawText(": " $ string(item.AvoidModify), xxgetInstanceL2Util().ColorYellow, false, false, 2, 2);
			i++;
		}
	}
	if(item.PhysicalDefense > 0)
	{
		ToolTip.DrawList[i] = xxDrawText(GetSystemString(95), xxgetInstanceL2Util().BrightWhite, false, true, 2, 2);
		i++;
		ToolTip.DrawList[i] = xxDrawText(": " $ string(item.PhysicalDefense), xxgetInstanceL2Util().ColorYellow, false, false, 2, 2);
		i++;
	}
	if(item.MagicalDefense > 0)
	{
		ToolTip.DrawList[i] = xxDrawText(GetSystemString(99), xxgetInstanceL2Util().BrightWhite, false, true, 2, 2);
		i++;
		ToolTip.DrawList[i] = xxDrawText(": " $ string(item.MagicalDefense), xxgetInstanceL2Util().ColorYellow, false, false, 2, 2);
		i++;
	}
	if(EItemType == ITEM_WEAPON)
	{
		tmpStatus = 0;
		tmpStatus = int(setItemTier(item.Description, "Tier:"));
		if(tmpStatus > 0)
		{
			ToolTip.DrawList[i] = DrawTex("L2UI_CH3.AugBG", currentWidth, 25, -1, -1, 0, 6, false, true);
			i++;
			if(tmpStatus == 1)
			{
				ToolTip.DrawList[i] = DrawTex("L2UI_CH3.water", 18, 18, -1, -1, 0, -23, true, true);
				i++;
				ToolTip.DrawList[i] = xxDrawText("Tier " $ ": ", xxgetInstanceL2Util().ColorGold, true, false, 4, -22);
				i++;
				ToolTip.DrawList[i] = xxDrawText("Rare ", xxgetInstanceL2Util().ColorYellow, true, false, 4, -22);
				i++;                
			}
			else
			{
				if(tmpStatus == 2)
				{
					ToolTip.DrawList[i] = DrawTex("L2UI_CH3.fire", 18, 18, -1, -1, 0, -23, true, true);
					i++;
					ToolTip.DrawList[i] = xxDrawText("Tier " $ ": ", xxgetInstanceL2Util().ColorGold, true, false, 4, -22);
					i++;
					ToolTip.DrawList[i] = xxDrawText("Supreme ", xxgetInstanceL2Util().ColorYellow, true, false, 4, -22);
					i++;
				}
			}
		}
		if(InStr(item.Description, "<Soul Crystal Enhancement>") > -1)
		{
			ToolTip.DrawList[i] = DrawTex("L2UI_CH3.AugBG", currentWidth, 25, -1, -1, 0, 4, false, true);
			i++;
			ToolTip.DrawList[i] = DrawTex("L2UI_CH3.SaBG", 18, 18, -1, -1, 0, -23, true, true);
			i++;
			ToolTip.DrawList[i] = xxDrawText("Special Ability" $ ": ", xxgetInstanceL2Util().ColorGold, true, false, 4, -22);
			i++;
			ToolTip.DrawList[i] = xxDrawText(item.AdditionalName, xxgetInstanceL2Util().ColorYellow, true, false, 4, -22);
			i++;
			tmpDescription = item.Description;
			if(InStr(item.Description, "<Soul Crystal Enhancement>\\n ") > -1)
			{
				tmpDescription =  ReplaceText(item.Description, "<Soul Crystal Enhancement>\\n ", "");                
			}
			else
			{
				tmpDescription =  ReplaceText(item.Description, "<Soul Crystal Enhancement>\\n", "");
			}
			bTooltipItem(tmpDescription);
			ToolTip.DrawList[i] = xxDrawText(setItemDecWidth(tmpDescription, currentWidth), GetAColor(110, 140, 160, 255), false, true, 4, 0);
			i++;            
		}
		else
		{
			tmpDescription = item.Description;
			bTooltipItem(tmpDescription);
			if(tmpDescription != "")
			{
				ToolTip.DrawList[i] = xxDrawText(setItemDecWidth(tmpDescription, currentWidth), xxgetInstanceL2Util().ColorDesc, false, true, 2, 2);
				i++;
			}
		}        
	}
	else
	{
		if(EItemType == ITEM_ARMOR)
		{
			if(arrID.Length > 0)
			{
				ToolTip.DrawList[i] = DrawTex("L2UI_CH3.AugBG", currentWidth, 25, -1, -1, 0, 6, false, true);
				i++;
				ToolTip.DrawList[i] = DrawTex("L2UI_CH3.setBG", 18, 18, -1, -1, 0, -23, true, true);
				i++;
				ToolTip.DrawList[i] = xxDrawText("Armor Set ", xxgetInstanceL2Util().ColorGold, true, false, 4, -22);
				i++;
				setIdx = 0;
				J0x127A:
				if(setIdx < 3)
				{
					Class'UIDATA_ITEM'.static.GetSetItemIDList(item.ClassID, setIdx, arrID);
					armorSetCount = 0;
					J0x12B0:
					if(armorSetCount < arrID.Length)
					{
						if(arrID[armorSetCount] != item.ClassID)
						{
							if(setIdx != 0)
							{
								ToolTip.DrawList[i] = DrawTex("L2UI_CH3.tooltip_line", currentWidth, 1, -1, -1, 0, 6, true, true);
								i++;
							}
							ToolTip.DrawList[i] = DrawTex("InterfaceText.ToolTip.lifeBG", 18, 18, 18, 18, 3, 6, true, true);
							i++;
							ToolTip.DrawList[i] = DrawTex(Class'UIDATA_ITEM'.static.GetItemTextureName(arrID[armorSetCount]), 16, 16, 32, 32, -17, 7, true, false);
							i++;
							ToolTip.DrawList[i] = xxDrawText(setTooltipNameItem(Class'UIDATA_ITEM'.static.GetItemName(arrID[armorSetCount])), GetAColor(100, 100, 65, 255), true, false, 7, 8);
							i++;
						}
						armorSetCount++;
						goto J0x12B0;
					}
					setIdx++;
					goto J0x127A;
				}
				tmpStatus = 0;
				tmpStatus = int(setItemTier(item.Description, "Tier:"));
				if(tmpStatus > 0)
				{
					ToolTip.DrawList[i] = DrawTex("L2UI_CH3.AugBG", currentWidth, 25, -1, -1, 0, 6, false, true);
					i++;
					if(tmpStatus == 1)
					{
						ToolTip.DrawList[i] = DrawTex("L2UI_CH3.water", 18, 18, -1, -1, 0, -23, true, true);
						i++;
						ToolTip.DrawList[i] = xxDrawText("Tier " $ ": ", xxgetInstanceL2Util().ColorGold, true, false, 4, -22);
						i++;
						ToolTip.DrawList[i] = xxDrawText("Rare ", xxgetInstanceL2Util().ColorYellow, true, false, 4, -22);
						i++;                        
					}
					else
					{
						if(tmpStatus == 2)
						{
							ToolTip.DrawList[i] = DrawTex("L2UI_CH3.fire", 18, 18, -1, -1, 0, -23, true, true);
							i++;
							ToolTip.DrawList[i] = xxDrawText("Tier " $ ": ", xxgetInstanceL2Util().ColorGold, true, false, 4, -22);
							i++;
							ToolTip.DrawList[i] = xxDrawText("Supreme ", xxgetInstanceL2Util().ColorYellow, true, false, 4, -22);
							i++;
						}
					}
				}
				tmpDescription = "";
				tmpStatus = 0;
				tmpDescription = Class'UIDATA_ITEM'.static.GetSetItemEffectDescription(item.ClassID, 0);
				bTooltipItem(tmpDescription);
				if(tmpDescription != "")
				{
					ToolTip.DrawList[i] = xxDrawText(setItemDecWidth(tmpDescription, currentWidth), GetAColor(100, 70, 0, 255), false, true, 4, 4);
					i++;
				}
			}            
		}
		else
		{
			if(item.Description != "")
			{
				tmpStatus = 0;
				tmpStatus = int(setItemTier(item.Description, "Tier:"));
				if(tmpStatus > 0)
				{
					ToolTip.DrawList[i] = DrawTex("L2UI_CH3.AugBG", currentWidth, 25, -1, -1, 0, 6, false, true);
					i++;
					if(tmpStatus == 1)
					{
						ToolTip.DrawList[i] = DrawTex("L2UI_CH3.water", 18, 18, -1, -1, 0, -23, true, true);
						i++;
						ToolTip.DrawList[i] = xxDrawText("Tier " $ ": ", xxgetInstanceL2Util().ColorGold, true, false, 4, -22);
						i++;
						ToolTip.DrawList[i] = xxDrawText("Rare ", xxgetInstanceL2Util().ColorYellow, true, false, 4, -22);
						i++;                        
					}
					else
					{
						if(tmpStatus == 2)
						{
							ToolTip.DrawList[i] = DrawTex("L2UI_CH3.fire", 18, 18, -1, -1, 0, -23, true, true);
							i++;
							ToolTip.DrawList[i] = xxDrawText("Tier " $ ": ", xxgetInstanceL2Util().ColorGold, true, false, 4, -22);
							i++;
							ToolTip.DrawList[i] = xxDrawText("Supreme ", xxgetInstanceL2Util().ColorYellow, true, false, 4, -22);
							i++;
						}
					}
				}
				tmpDescription = item.Description;
				bTooltipItem(tmpDescription);
				if(tmpStatus <= 0)
				{
					ToolTip.DrawList[i] = DrawTex("L2UI_CH3.tooltip_line", currentWidth, 1, -1, -1, 0, 6, true, true);
					i++;
				}
				ToolTip.DrawList[i] = xxDrawText(setItemDecWidth(tmpDescription, currentWidth), xxgetInstanceL2Util().ColorDesc, false, true, 2, 2);
				i++;
			}
		}
	}
	tmpStatus = 0;
	tmpStatus = setAcquireItem("Acquire:{", item.Description);
	if(tmpStatus > 0)
	{
		tmpDescription = Mid(item.Description, tmpStatus, InStr(item.Description, "}") - 9);
		ToolTip.DrawList[i] = DrawTex("L2UI_CH3.tooltip_line", currentWidth, 1, -1, -1, 0, 6, true, true);
		i++;
		ToolTip.DrawList[i] = xxDrawText(setItemDecWidth(tmpDescription, currentWidth), xxgetInstanceL2Util().ColorGold, false, true, 2, 4);
		i++;
	}
	MileniumGearScore(GetScript("MileniumGearScore")).AppendItemScoreTooltip(ToolTip, item, true);
    return ToolTip;
}

function int GetItemNameSize(ItemInfo item)
{
	local int Width;

	Width = 60;
	if(item.Enchanted > 0)
	{
		Width += (GetTextWidth("+" $ string(item.Enchanted)));
	}
	Width += (GetTextWidth(item.Name));
	if(item.AdditionalName != "")
	{
		Width += (GetTextWidth(item.AdditionalName));
	}
	if(item.ItemNum > 1)
	{
		Width += (GetTextWidth(("(" $ string(item.ItemNum)) $ ")"));
	}
	return Width;
}

function string getSlotTypeWithItemTypeString(ItemInfo item)
{
	local string SlotString, strTmp;
	local EItemType EItemType;

	EItemType = EItemType(item.ItemType);
	SlotString = GetSlotTypeString(item.ItemType, item.SlotBitType, item.ArmorType);
	if(EItemType == ITEM_WEAPON)
	{
		strTmp = GetWeaponTypeString(item.WeaponType);
		if(Len(strTmp) > 0)
		{
			SlotString = (strTmp $ " / ") $ SlotString;
		}
	}
	return SlotString;
}

function addTreeNode(int nodeLine, ItemInfo Info, string Tree)
{
	local string strRetName;
	local XMLTreeNodeInfo infNode;
	local string fullNameString;
	local int itemColor;
	local Color i_Color;

	itemColor = 0;
	i_Color = xxgetInstanceL2Util().getItemNameColor(setTooltipNameColor(Info.Name));
	fullNameString = GetItemNameAll(Info);
	infNode.strName = string(nodeLine);
	infNode.bFollowCursor = false;
	infNode.ToolTip = SetSimpleItemTooltip(Info);
	infNode.nOffSetX = 2;
	infNode.nOffSetY = 0;
	infNode.bShowButton = 0;
	infNode.nTexExpandedHeight = 36;
	infNode.nTexExpandedRightWidth = 5;
	infNode.nTexExpandedLeftUWidth = 30;
	infNode.nTexExpandedLeftUHeight = 34;
	infNode.strTexExpandedLeft = "L2UI_CH3.etc.IconSelect2";
	if(Tree == "MultiSellWnd.MultisellTabTotalWnd.MultisellTabTotalWnd_ListCtrl")
	{
		strRetName = Class'UIAPI_TREECTRL'.static.InsertNode(Tree, "root", infNode);        
	}
	else
	{
		strRetName = Class'UIAPI_TREECTRL'.static.InsertNode(Tree, "enableroot", infNode);
	}
	if(int(float(nodeLine) % float(2)) == 0)
	{
		TreeInsertTextureNode(Tree, strRetName, "L2UI_CH3.etc.GroupBox_df_LineBack", 295, 36);        
	}
	else
	{
		TreeInsertTextureNode(Tree, strRetName, "L2UI_CH3.Null", 295, 36);
	}
	TreeInsertTextureNode(Tree, strRetName, "L2UI_CH3.InventoryWnd.ItemWindow_DF_Slotbox_2x2", 36, 36, -286, 4 - 3);
	TreeInsertTextureNode(Tree, strRetName, Info.IconName, 32, 32, -34, 4 - 2);
	if(Info.ForeTexture == "L2UI_CH3.MultiSellWnd.SellablePanel")
	{
		TreeInsertTextureNode(Tree, strRetName, "L2UI_CH3.MultiSellWnd.SellablePanel", 32, 32, -32, 4 - 2);
	}
	if((Info.Enchanted <= 50) && Info.Enchanted > 0)
	{
		TreeInsertTextureNode(Tree, strRetName, "L2UI_CH3.ItemEnchant.enchant" $ string(Info.Enchanted), 32, 32, -32, 4 - 2);
	}
	if(IsStackableItem(Info.ConsumeType))
	{
		fullNameString = makeShortStringByPixel(fullNameString, 212, "..");
		if(Info.ItemNum > 0)
		{
			fullNameString = ((fullNameString $ " (") $ string(Info.ItemNum)) $ ")";            
		}
		else
		{
			fullNameString = fullNameString $ " (1)";
		}        
	}
	else
	{
		fullNameString = makeShortStringByPixel(fullNameString, 230, "..");
	}
	TreeInsertNodeItemColor(Tree, strRetName, fullNameString, 5, 11, i_Color, true);
	if(Info.CrystalType > 0)
	{
		if((Info.CrystalType == 6) || Info.CrystalType == 7)
		{
			TreeInsertTextureNode(Tree, strRetName, GetItemGradeTextureName(Info.CrystalType), 32, 16, 2, 11);            
		}
		else
		{
			TreeInsertTextureNode(Tree, strRetName, GetItemGradeTextureName(Info.CrystalType), 16, 16, 2, 11);
		}
	}
}

function OnSearch_ButtonClick()
{
	local string searchStr;

	searchStr = Search_EditBox.GetString();
	fildAndShowItemList(searchStr);
}

function OnRefresh_ButtonClick()
{
	ItemCount_EditBox.SetString("1");
	Search_EditBox.SetString("");
	fildAndShowItemList("");
}

function OnClear_ButtonClick()
{
	ItemCount_EditBox.SetString("1");
	setTreeNeedItemInfo();
}

function OnMultiSell_Up_ButtonClick()
{
	local string numStr;
	local int Count;

	numStr = ItemCount_EditBox.GetString();
	Count = int(numStr);
	if(Count < GlobalAvailable)
	{
		Count++;
		if(Count > 9999)
		{
			Count = 9999;
		}
		ItemCount_EditBox.SetString(string(Count));
		setTreeNeedItemInfo();
	}
}

function OnMultiSell_Down_ButtonClick()
{
	local string numStr;
	local int Count;

	numStr = ItemCount_EditBox.GetString();
	Count = int(numStr);
	if(Count > 1)
	{
		Count--;
		ItemCount_EditBox.SetString(string(Count));
		setTreeNeedItemInfo();
	}
}

function OnPriceEditBtnHandler()
{
	local ItemInfo Info;

	DialogHide();
	DialogSetID(1123);
	DialogSetReservedInt(Info.ServerID);
	DialogSetParamInt(GlobalAvailable);
	DialogShow(DIALOG_NUMBERPAD, "Indicate the number of items for exchange.");
}

function OnKeyUp(EInputKey nKey)
{
	if(Search_EditBox.IsFocused())
	{
		if(nKey == 13)
		{
			OnSearch_ButtonClick();
		}
	}
}

function itemCountTextEditEnable(bool bEnable)
{
	if(bEnable)
	{
		MultiSell_Input_Button.EnableWindow();
		ItemCount_EditBox.EnableWindow();
		MultiSell_Up_Button.EnableWindow();
		MultiSell_Down_Button.EnableWindow();
		MultiSell_Input_Button.EnableWindow();        
	}
	else
	{
		MultiSell_Input_Button.DisableWindow();
		ItemCount_EditBox.DisableWindow();
		MultiSell_Up_Button.DisableWindow();
		MultiSell_Down_Button.DisableWindow();
		MultiSell_Input_Button.DisableWindow();
	}
}

function bool getCurrentSelectedItemInfo(out ItemInfo rItemInfo)
{
	local bool bFlag;

	if(MultisellTab.GetTopIndex() == 0)
	{
		bFlag = MultisellTabTotalWnd_ItemWindow.GetItem(indexGlobal, rItemInfo);        
	}
	else
	{
		bFlag = MultisellTabEnableWnd_ItemWindow.GetItem(indexGlobal, rItemInfo);
	}
	return bFlag;
}
