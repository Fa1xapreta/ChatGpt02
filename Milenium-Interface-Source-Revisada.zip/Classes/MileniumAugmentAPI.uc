class MileniumAugmentAPI extends UICommonAPI;

var Color BrightWhite;
var Color BrightYellow;
var Color Blue;
var Color Red;
var array<Color> RefineryColor;

function MileniumAugmentAPI getInstanceL2Util()
{
    return self;
}

static final operator(30) string ? (bool A, string B) { if (A) return B; return ""; }
static final operator(30) string ~ (string A, string B) { if (A != "") return A; return B; }

function bool xxFindInventoryItem( int zz_ItemID, out ItemInfo zz_item )
{
	local int zz_i, zz_itemPosition;
	local ItemWindowHandle zz_ItemList;
	local InventoryWnd zz_InventoryScript;

	zz_ItemList = xxGetItemWindowHandle( "InventoryWnd.InventoryItem" );

	zz_itemPosition = xxFindItemPositionByID( zz_ItemList, zz_ItemID );

	if(zz_itemPosition <= -1)
	{
		zz_ItemList = xxGetItemWindowHandle( "InventoryWnd.QuestItem" );

		zz_itemPosition = xxFindItemPositionByID( zz_ItemList, zz_ItemID );
	
		if(zz_itemPosition <= -1)
		{
			zz_InventoryScript = InventoryWnd( GetScript( "InventoryWnd" ) );

			for (zz_i = 0; zz_i < 15; zz_i++) 
			{			
				zz_itemPosition = xxFindItemPositionByID( zz_InventoryScript.zzm_equipItem[ zz_i ], zz_ItemID );
				if(zz_itemPosition >= 0)
				{
					zz_ItemList = zz_InventoryScript.zzm_equipItem[ zz_i ];
					break;
				}
			}
		}
	}
	
	if( zz_ItemList.GetItem( zz_itemPosition, zz_item ) )
		return true;
	
	return false;
}

function int xxFindItemPositionByID( ItemWindowHandle zzhandle, int zzItemID )
{
	local int zzItemPosition;

	if(zzItemID < 100000000)// Identifica se Ã© ID server ou class
		zzItemPosition = zzhandle.FindItemWithClassID( zzItemID );
	else
		zzItemPosition = zzhandle.FindItemWithServerID( zzItemID );

	return zzItemPosition;
}

function string xxReplace(string zz_Text, string zz_Replace, coerce string zz_With)
{
	local int zz_i;
	local string zz_Input;
		
	zz_Input = zz_Text;
	zz_Text = "";
	zz_i = InStr(zz_Input, zz_Replace);
	while(zz_i != -1)
	{	
		zz_Text = zz_Text $ Left(zz_Input, zz_i) $ zz_With;
		zz_Input = Mid(zz_Input, zz_i + Len(zz_Replace));	
		zz_i = InStr(zz_Input, zz_Replace);
	}
	return zz_Text $ zz_Input;
}

function array<string> xxSplitString(string zz_InString, string zz_Separator)
{
    local string zz_RemainingString;
    local array<string> zz_Substrings;
    local int zz_FoundIndex;

    zz_RemainingString = zz_InString;
    while (zz_RemainingString != "")
    {
        zz_FoundIndex = InStr(zz_RemainingString, zz_Separator);
        if (zz_FoundIndex == -1)
        {
            zz_Substrings[zz_Substrings.Length] = zz_RemainingString;
            zz_RemainingString = "";
        }
        else
        {
            zz_Substrings[zz_Substrings.Length] = Left(zz_RemainingString, zz_FoundIndex);
            zz_RemainingString = Mid(zz_RemainingString, zz_FoundIndex + Len(zz_Separator));
        }
    }
    return zz_Substrings;
}

defaultproperties
{
    BrightWhite=(B=255,G=255,R=255,A=255)
    BrightYellow=(B=190,G=217,R=230,A=255)
    Blue=(B=253,G=150,R=102,A=255)
    Red=(B=0,G=50,R=250,A=255)
    RefineryColor(0)=(B=138,G=181,R=187,A=255)
    RefineryColor(1)=(B=138,G=181,R=187,A=255)
    RefineryColor(2)=(B=216,G=174,R=132,A=255)
    RefineryColor(3)=(B=202,G=112,R=193,A=255)
    RefineryColor(4)=(B=109,G=109,R=225,A=255)
}
