class PlayerSkillGauge extends UICommonAPI;

const SKILL_DISPLAY_RANGE = 600;
const CAST_CLEANUP_TIMER = 12999;

var WindowHandle _obf2836;
var UIEventManager.UserInfo _obf2216;
var bool bShow;
var int _obfCasterID;

static function DebugLog(string Msg)
{
    local Color Col;

    Col.R = 0;
    Col.G = 220;
    Col.B = 255;
    Col.A = 255;

    class'NWindow.UIAPI_TEXTLISTBOX'.static.AddString(
        "ChatWnd.NormalChat",
        "[Tema] " $ Msg,
        Col
    );
}

function OnLoad()
{
    _obf2836 = GetHandle("PlayerSkillGauge");

    RegisterEvent(EV_Die);
    RegisterEvent(EV_TargetUpdate);
    RegisterEvent(EV_ReceiveMagicSkillUse);
    RegisterEvent(EV_TargetHideWindow);

    _obf2216.nID = -1;
    _obfCasterID = 0;
    bShow = false;

    _obf2836.HideWindow();
}

function OnEnterState(name _obf3505)
{
    _obf2216.nID = -1;
    _obf413();
}

function OnTimer(int _obf3662)
{
    if (_obf3662 == CAST_CLEANUP_TIMER)
    {
        _obf413();
    }
}

function OnEvent(int _obf2786, string _obf3648)
{
    local int TargetID;

    switch (_obf2786)
    {
        case 980:
            TargetID =
                class'NWindow.UIDATA_TARGET'.static.GetTargetID();

            if (_obf2216.nID != TargetID)
            {
                _obf2216.nID = TargetID;
                _obf413();
            }
            break;

        case 290:
            if (GetOptionBool("Lotus_Custom", "EnemySkill"))
            {
                _obf636(_obf3648);
            }
            else
            {
                _obf413();
            }
            break;

        case 50:
        case 990:
            _obf413();
            break;
    }
}

// Consulta o personagem que realmente utilizou a habilidade.
function bool GetCasterInRange(
    int CasterID,
    out UIEventManager.UserInfo CasterInfo)
{
    if (CasterID <= 0)
    {
        return false;
    }

    if (!GetUserInfo(CasterID, CasterInfo))
    {
        return false;
    }

    if (CasterInfo.nID != CasterID)
    {
        return false;
    }

    if (CasterInfo.bNpc || CasterInfo.bPet)
    {
        return false;
    }

    if (VSize(CasterInfo.Loc - GetPlayerPosition())
        > float(SKILL_DISPLAY_RANGE))
    {
        return false;
    }

    return true;
}

function bool IsIgnoredSkill(int SkillID)
{
    return SkillID == 7038
        || SkillID == 2036
        || SkillID == 92008
        || SkillID == 2213
        || SkillID == 2099
        || SkillID == 92015;
}

function _obf636(string _obf3648)
{
    local int SkillID;
    local int SkillLevel;
    local int CasterID;
    local int CastTime;
    local int CastingSpeed;
    local float EstimatedTime;

    local UIEventManager.SkillInfo SkillInfo;
    local UIEventManager.UserInfo CasterInfo;

    ParseInt(_obf3648, "AttackerID", CasterID);
    ParseInt(_obf3648, "SkillID", SkillID);

    if (CasterID <= 0 || SkillID <= 0)
    {
        return;
    }

    // Uma habilidade de fora do alcance nao substitui a atual.
    if (!GetCasterInRange(CasterID, CasterInfo))
    {
        if (bShow && CasterID == _obfCasterID)
        {
            _obf413();
        }

        return;
    }

    if (IsIgnoredSkill(SkillID))
    {
        if (bShow && CasterID == _obfCasterID)
        {
            _obf413();
        }

        return;
    }

    SkillLevel = 1;
    ParseInt(_obf3648, "SkillLevel", SkillLevel);

    if (SkillLevel <= 0)
    {
        SkillLevel = 1;
    }

    if (!GetSkillInfo(SkillID, SkillLevel, SkillInfo))
    {
        if (SkillLevel == 1)
        {
            return;
        }

        if (!GetSkillInfo(SkillID, 1, SkillInfo))
        {
            return;
        }
    }

    // Uma nova acao instantanea do mesmo personagem
    // encerra a exibicao anterior.
    if (SkillInfo.HitTime <= 0.0)
    {
        if (bShow && CasterID == _obfCasterID)
        {
            _obf413();
        }

        return;
    }

    if (SkillInfo.IsMagic == 1)
    {
        CastingSpeed = CasterInfo.nMagicCastingSpeed;
    }
    else
    {
        CastingSpeed = CasterInfo.nPhysicalAttackSpeed + 300;
    }

    // Evita divisao por zero quando os atributos nao estao disponiveis.
    if (CastingSpeed <= 0)
    {
        CastingSpeed = 234;
    }

    EstimatedTime =
        SkillInfo.HitTime * 1000.0 * 234.0
        / float(CastingSpeed);

    CastTime = int(EstimatedTime + 117.0);

    if (CastTime < 100)
    {
        CastTime = 100;
    }

    // Limite de seguranca contra tempos incorretos.
    if (CastTime > 60000)
    {
        CastTime = 60000;
    }

    // Limpa a exibicao anterior somente depois de validar a nova.
    _obf413();

    _obfCasterID = CasterID;

        if (SkillInfo.TexName == ""
        || SkillInfo.TexName ~= "None")
    {
        class'NWindow.UIAPI_TEXTURECTRL'.static.SetTexture(
            "PlayerSkillGauge.texCastIcon",
            "Icon.etc_alphabet_m_i00"
        );
    }
    else
    {
        class'NWindow.UIAPI_TEXTURECTRL'.static.SetTexture(
            "PlayerSkillGauge.texCastIcon",
            SkillInfo.TexName
        );
    }

    class'NWindow.UIAPI_PROGRESSCTRL'.static.SetProgressTime(
        "PlayerSkillGauge.progressCast",
        CastTime
    );

    class'NWindow.UIAPI_PROGRESSCTRL'.static.SetPos(
        "PlayerSkillGauge.progressCast",
        CastTime
    );

    class'NWindow.UIAPI_PROGRESSCTRL'.static.Reset(
        "PlayerSkillGauge.progressCast"
    );

    bShow = true;

    // Remove mesmo se o evento de termino da barra nao chegar.
    _obf2836.SetTimer(
        CAST_CLEANUP_TIMER,
        CastTime + 250
    );

    _obf1092();

    class'NWindow.UIAPI_PROGRESSCTRL'.static.Start(
        "PlayerSkillGauge.progressCast"
    );
}

function _obf413()
{
    _obf2836.KillTimer(CAST_CLEANUP_TIMER);

    bShow = false;
    _obfCasterID = 0;

    _obf1091();
}

function OnProgressTimeUp(string _obf3484)
{
    if (_obf3484 == "progressCast" && bShow)
    {
        _obf413();
    }
}

function _obf1092()
{
    if (!bShow)
    {
        return;
    }

    GotoState('_obf1090');

    _obf2836.ShowWindow();
    _obf378(_obf2836, true);
}

function _obf1091()
{
    GotoState('None');
    _obf2836.HideWindow();
}

// Mantem o calculo e os deslocamentos originais.
function _obf378(WindowHandle Handle, bool bPlayer)
{
    local float PosX;
    local float PosY;

    PosX = -10000.0;
    PosY = -10000.0;

    if (bPlayer)
    {
        xxheaderhpplayerByID(
            _obfCasterID,
            PosX,
            PosY
        );
    }
    else
    {
        xxheaderhp(PosX, PosY);
    }

    Handle.MoveTo(
        int(PosX - 47.0),
        int(PosY - 100.0)
    );
}

state _obf1090
{
    event OnTick()
    {
        local UIEventManager.UserInfo CasterInfo;

        if (!bShow)
        {
            return;
        }

        if (!GetOptionBool("Lotus_Custom", "EnemySkill"))
        {
            _obf413();
            return;
        }

        // Confere o alcance enquanto o personagem se movimenta.
        if (!GetCasterInRange(_obfCasterID, CasterInfo))
        {
            _obf413();
            return;
        }

        if (_obf2836.IsShowWindow())
        {
            _obf378(_obf2836, true);
        }
        else
        {
            _obf413();
        }
    }
}