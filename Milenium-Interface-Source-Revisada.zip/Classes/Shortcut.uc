//================================================================================
// Shortcut.
//================================================================================

class Shortcut extends UICommonAPI;

const CHAT_WINDOW_SYSTEM= 5;
const CHAT_WINDOW_COUNT= 5;
const CHAT_WINDOW_ALLY= 4;
const CHAT_WINDOW_CLAN= 3;
const CHAT_WINDOW_PARTY= 2;
const CHAT_WINDOW_TRADE= 1;
const CHAT_WINDOW_NORMAL= 0;
//var NPHRN_KeyWnd script;
var bool m_chatstateok;
var bool Deobfuscated4146;
var bool Deobfuscated4147;
var bool Deobfuscated4148;
var int Deobfuscated4149;
var int Deobfuscated4150;
var int Deobfuscated4151;
var NewMenu Script1;
/*var Some Some;
var RadarContainerWnd RadarContainerWnd;*/

function OnLoad ()
{
  RegisterEvent(90);
  Deobfuscated527();
//  script = NPHRN_KeyWnd(GetScript("NPHRN_KeyWnd"));
  Script1 = NewMenu(GetScript("NewMenu"));
  /*Some = Some(GetScript("Some"));
  RadarContainerWnd = RadarContainerWnd(GetScript("RadarContainerWnd"));*/
  if (  !Deobfuscated4146 &&  !Deobfuscated4147 &&  !Deobfuscated4148 )
  {
    SetOptionBool("Key","UseFPad",True);
    SetOptionBool("Key","UseNumpad",True);
    SetOptionBool("Key","UseQwerty",True);
    SetOptionInt("Key","Panel1",1);
    SetOptionInt("Key","Panel2",1);
    SetOptionInt("Key","Panel3",1);
 //   script.ComboPanel1.SetSelectedNum(Deobfuscated4149 - 1);
 //   script.ComboPanel2.SetSelectedNum(Deobfuscated4150 - 1);
//    script.ComboPanel3.SetSelectedNum(Deobfuscated4151 - 1);
    Deobfuscated527();
  }
}

function Deobfuscated527 ()
{
  Deobfuscated4146 = GetOptionBool("Key","UseNumpad");
  Deobfuscated4147 = GetOptionBool("Key","UseFPad");
  Deobfuscated4148 = GetOptionBool("Key","UseQwerty");
  Deobfuscated4149 = GetOptionInt("Key","Panel1");
  Deobfuscated4150 = GetOptionInt("Key","Panel2");
  Deobfuscated4151 = GetOptionInt("Key","Panel3");
  GetOptionBool("Game","EnterChatting");
  if ( Deobfuscated4149 <= 0 )
  {
    Deobfuscated4149 = 1;
  }
  if ( Deobfuscated4150 <= 0 )
  {
    Deobfuscated4150 = 1;
  }
  if ( Deobfuscated4151 <= 0 )
  {
    Deobfuscated4151 = 1;
  }
}

function OnEvent (int Deobfuscated4156, string param)
{
  switch (Deobfuscated4156)
  {
    case 90:
    HandleShortcutCommand(param);
    break;
    default:
  }
}

function OnExitState (name a_NextStateName)
{
  if ( a_NextStateName == 'GamingState' )
  {
    m_chatstateok = True;
  } else {
    m_chatstateok = False;
  }
}

function HandleShortcutCommand (string param)
{
  local string Deobfuscated1909;
  

  if ( ParseString(param,"Command",Deobfuscated1909) )
  {
    switch (Deobfuscated1909)
    {
            case "Dismount":
      MountBtnWnd(
          GetScript("MountBtnWnd")
      ).HandleMountDismount();
      break;
      case "CloseAllWindow":
      HandleCloseAllWindow();
      break;
      case "ShowChatWindow":
      HandleShowChatWindow();
      break;
      case "SetPrevChatType":
      HandleSetPrevChatType();
      break;
      case "SetNextChatType":
      HandleSetNextChatType();
      break;
      case "ShowDetailStatusWnd":
      Script1.xxToggleOpenCharInfoWnd();
      break;
      case "ShowActionWnd":
      Script1.xxToggleOpenActionWnd();
      break;
      case "ShowMagicSkillWnd":
      Script1.xxToggleOpenMagicSkillWnd();
      break;
      case "ShowQuestTreeWnd":
      Script1.xxToggleOpenQuestWnd();
      break;
      case "ShowClanWnd":
      Script1.xxToggleOpenClanWnd();
      break;
      case "SwitchSupport":
     // Some.OnBotEnableClick();
      break;
      case "SwitchAssist":
   //   RadarContainerWnd.HandleAssistButtonsState();
      break;
      case "ForceExit":
      RequestExit();
      break;
      case "Test":
      AddSystemMessage("Test!",getColor("YELLOW"));
      break;
	        case "Teleport2k2Wnd":
      if ( IsShowWindow("NewMenu.BtnTeleportMap") )
      {
        HandleHideShowWnd(Deobfuscated1909);
      }
	  break;
      default:
    }
    if ( Left(Deobfuscated1909,11) == "UserShorcut" )
    {
      Deobfuscated1120(Deobfuscated1909);
    }
  }
}


function HandleHideShowWnd (string WndName)
{
  local WindowHandle Handle;

  Handle = GetHandle(WndName);
  if ( Handle.IsShowWindow() )
  {
    Handle.HideWindow();
  } else {
    Handle.ShowWindow();
  }
}




function Deobfuscated1120 (string Name)
{
  switch (Name)
  {
    case "UserShorcutKey_1":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4149) $ " 1");
    }
    break;
    case "UserShorcutKey_2":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4149) $ " 2");
    }
    break;
    case "UserShorcutKey_3":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4149) $ " 3");
    }
    break;
    case "UserShorcutKey_4":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4149) $ " 4");
    }
    break;
    case "UserShorcutKey_5":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4149) $ " 5");
    }
    break;
    case "UserShorcutKey_6":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4149) $ " 6");
    }
    break;
    case "UserShorcutKey_7":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4149) $ " 7");
    }
    break;
    case "UserShorcutKey_8":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4149) $ " 8");
    }
    break;
    case "UserShorcutKey_9":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4149) $ " 9");
    }
    break;
    case "UserShorcutKey_10":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4149) $ " 10");
    }
    break;
    case "UserShorcutKey_11":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4149) $ " 11");
    }
    break;
    case "UserShorcutKey_12":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4149) $ " 12");
    }
    break;
    case "UserShorcutKey_Q":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4150) $ " 1");
    }
    break;
    case "UserShorcutKey_W":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4150) $ " 2");
    }
    break;
    case "UserShorcutKey_E":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4150) $ " 3");
    }
    break;
    case "UserShorcutKey_R":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4150) $ " 4");
    }
    break;
    case "UserShorcutKey_T":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4150) $ " 5");
    }
    break;
    case "UserShorcutKey_Y":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4150) $ " 6");
    }
    break;
    case "UserShorcutKey_U":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4150) $ " 7");
    }
    break;
    case "UserShorcutKey_I":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4150) $ " 8");
    }
    break;
    case "UserShorcutKey_O":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4150) $ " 9");
    }
    break;
    case "UserShorcutKey_P":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4150) $ " 10");
    }
    break;
    case "UserShorcutKey_[":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4150) $ " 11");
    }
    break;
    case "UserShorcutKey_]":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4150) $ " 12");
    }
    break;
    case "UserShorcutKey_F1":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4151) $ " 1");
    }
    break;
    case "UserShorcutKey_F2":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4151) $ " 2");
    }
    break;
    case "UserShorcutKey_F3":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4151) $ " 3");
    }
    break;
    case "UserShorcutKey_F4":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4151) $ " 4");
    }
    break;
    case "UserShorcutKey_F5":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4151) $ " 5");
    }
    break;
    case "UserShorcutKey_F6":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4151) $ " 6");
    }
    break;
    case "UserShorcutKey_F7":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4151) $ " 7");
    }
    break;
    case "UserShorcutKey_F8":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4151) $ " 8");
    }
    break;
    case "UserShorcutKey_F9":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4151) $ " 9");
    }
    break;
    case "UserShorcutKey_F10":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4151) $ " 10");
    }
    break;
    case "UserShorcutKey_F11":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4151) $ " 11");
    }
    break;
    case "UserShorcutKey_F12":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcut " $ string(Deobfuscated4151) $ " 12");
    }
    break;
    case "UserShorcutKeyForce_1":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4149) $ " 1");
    }
    break;
    case "UserShorcutKeyForce_2":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4149) $ " 2");
    }
    break;
    case "UserShorcutKeyForce_3":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4149) $ " 3");
    }
    break;
    case "UserShorcutKeyForce_4":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4149) $ " 4");
    }
    break;
    case "UserShorcutKeyForce_5":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4149) $ " 5");
    }
    break;
    case "UserShorcutKeyForce_6":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4149) $ " 6");
    }
    break;
    case "UserShorcutKeyForce_7":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4149) $ " 7");
    }
    break;
    case "UserShorcutKeyForce_8":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4149) $ " 8");
    }
    break;
    case "UserShorcutKeyForce_9":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4149) $ " 9");
    }
    break;
    case "UserShorcutKeyForce_10":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4149) $ " 10");
    }
    break;
    case "UserShorcutKeyForce_11":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4149) $ " 11");
    }
    break;
    case "UserShorcutKeyForce_12":
    if ( Deobfuscated4146 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4149) $ " 12");
    }
    break;
    case "UserShorcutKeyForce_Q":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4150) $ " 1");
    }
    break;
    case "UserShorcutKeyForce_W":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4150) $ " 2");
    }
    break;
    case "UserShorcutKeyForce_E":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4150) $ " 3");
    }
    break;
    case "UserShorcutKeyForce_R":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4150) $ " 4");
    }
    break;
    case "UserShorcutKeyForce_T":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4150) $ " 5");
    }
    break;
    case "UserShorcutKeyForce_Y":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4150) $ " 6");
    }
    break;
    case "UserShorcutKeyForce_U":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4150) $ " 7");
    }
    break;
    case "UserShorcutKeyForce_I":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4150) $ " 8");
    }
    break;
    case "UserShorcutKeyForce_O":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4150) $ " 9");
    }
    break;
    case "UserShorcutKeyForce_P":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4150) $ " 10");
    }
    break;
    case "UserShorcutKeyForce_[":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4150) $ " 11");
    }
    break;
    case "UserShorcutKeyForce_]":
    if ( Deobfuscated4147 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4150) $ " 12");
    }
    break;
    case "UserShorcutKeyForce_F1":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4151) $ " 1");
    }
    break;
    case "UserShorcutKeyForce_F2":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4151) $ " 2");
    }
    break;
    case "UserShorcutKeyForce_F3":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4151) $ " 3");
    }
    break;
    case "UserShorcutKeyForce_F4":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4151) $ " 4");
    }
    break;
    case "UserShorcutKeyForce_F5":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4151) $ " 5");
    }
    break;
    case "UserShorcutKeyForce_F6":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4151) $ " 6");
    }
    break;
    case "UserShorcutKeyForce_F7":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4151) $ " 7");
    }
    break;
    case "UserShorcutKeyForce_F8":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4151) $ " 8");
    }
    break;
    case "UserShorcutKeyForce_F9":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4151) $ " 9");
    }
    break;
    case "UserShorcutKeyForce_F10":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4151) $ " 10");
    }
    break;
    case "UserShorcutKeyForce_F11":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4151) $ " 11");
    }
    break;
    case "UserShorcutKeyForce_F12":
    if ( Deobfuscated4148 )
    {
      ExecuteCommand("/useshortcutforce " $ string(Deobfuscated4151) $ " 12");
    }
    break;
    default:
  }
}

function HandleShowChatWindow ()
{
  local WindowHandle Deobfuscated1881;

  Deobfuscated1881 = GetHandle("ChatWnd");
  if ( Deobfuscated1881.IsShowWindow() )
  {
    Deobfuscated1881.HideWindow();
    if ( GetOptionBool("Game","SystemMsgWnd") )
    {
      Class'UIAPI_WINDOW'.static.HideWindow("SystemMsgWnd");
    }
  } else {
    Deobfuscated1881.ShowWindow();
    if ( GetOptionBool("Game","SystemMsgWnd") )
    {
      Class'UIAPI_WINDOW'.static.ShowWindow("SystemMsgWnd");
    }
  }
}

function HandleSetPrevChatType ()
{
  local ChatWnd chatWndScript;

  chatWndScript = ChatWnd(GetScript("ChatWnd"));
  switch (chatWndScript.m_chatType)
  {
    case 0:
    chatWndScript.ChatTabCtrl.MergeTab(1);
    chatWndScript.ChatTabCtrl.MergeTab(2);
    chatWndScript.ChatTabCtrl.MergeTab(3);
    chatWndScript.ChatTabCtrl.MergeTab(4);
    chatWndScript.ChatTabCtrl.SetTopOrder(4,True);
    chatWndScript.HandleTabClick("ChatTabCtrl4");
    break;
    case 1:
    chatWndScript.ChatTabCtrl.MergeTab(0);
    chatWndScript.ChatTabCtrl.MergeTab(2);
    chatWndScript.ChatTabCtrl.MergeTab(3);
    chatWndScript.ChatTabCtrl.MergeTab(4);
    chatWndScript.ChatTabCtrl.SetTopOrder(0,True);
    chatWndScript.HandleTabClick("ChatTabCtrl0");
    break;
    case 2:
    chatWndScript.ChatTabCtrl.MergeTab(0);
    chatWndScript.ChatTabCtrl.MergeTab(1);
    chatWndScript.ChatTabCtrl.MergeTab(3);
    chatWndScript.ChatTabCtrl.MergeTab(4);
    chatWndScript.ChatTabCtrl.SetTopOrder(1,True);
    chatWndScript.HandleTabClick("ChatTabCtrl1");
    break;
    case 3:
    chatWndScript.ChatTabCtrl.MergeTab(0);
    chatWndScript.ChatTabCtrl.MergeTab(1);
    chatWndScript.ChatTabCtrl.MergeTab(2);
    chatWndScript.ChatTabCtrl.MergeTab(3);
    chatWndScript.ChatTabCtrl.SetTopOrder(2,True);
    chatWndScript.HandleTabClick("ChatTabCtrl2");
    break;
    case 4:
    chatWndScript.ChatTabCtrl.MergeTab(0);
    chatWndScript.ChatTabCtrl.MergeTab(1);
    chatWndScript.ChatTabCtrl.MergeTab(2);
    chatWndScript.ChatTabCtrl.MergeTab(3);
    chatWndScript.ChatTabCtrl.SetTopOrder(3,True);
    chatWndScript.HandleTabClick("ChatTabCtrl3");
    break;
    default:
  }
}

function HandleSetNextChatType ()
{
  local ChatWnd chatWndScript;

  chatWndScript = ChatWnd(GetScript("ChatWnd"));
  switch (chatWndScript.m_chatType)
  {
    case 0:
    chatWndScript.ChatTabCtrl.MergeTab(0);
    chatWndScript.ChatTabCtrl.MergeTab(2);
    chatWndScript.ChatTabCtrl.MergeTab(3);
    chatWndScript.ChatTabCtrl.MergeTab(4);
    chatWndScript.ChatTabCtrl.SetTopOrder(1,True);
    chatWndScript.HandleTabClick("ChatTabCtrl1");
    break;
    case 1:
    chatWndScript.ChatTabCtrl.MergeTab(0);
    chatWndScript.ChatTabCtrl.MergeTab(1);
    chatWndScript.ChatTabCtrl.MergeTab(3);
    chatWndScript.ChatTabCtrl.MergeTab(4);
    chatWndScript.ChatTabCtrl.SetTopOrder(2,True);
    chatWndScript.HandleTabClick("ChatTabCtrl2");
    break;
    case 2:
    chatWndScript.ChatTabCtrl.MergeTab(0);
    chatWndScript.ChatTabCtrl.MergeTab(1);
    chatWndScript.ChatTabCtrl.MergeTab(2);
    chatWndScript.ChatTabCtrl.MergeTab(4);
    chatWndScript.ChatTabCtrl.SetTopOrder(3,True);
    chatWndScript.HandleTabClick("ChatTabCtrl3");
    break;
    case 3:
    chatWndScript.ChatTabCtrl.MergeTab(0);
    chatWndScript.ChatTabCtrl.MergeTab(1);
    chatWndScript.ChatTabCtrl.MergeTab(2);
    chatWndScript.ChatTabCtrl.MergeTab(3);
    chatWndScript.ChatTabCtrl.SetTopOrder(4,True);
    chatWndScript.HandleTabClick("ChatTabCtrl4");
    break;
    case 4:
    chatWndScript.ChatTabCtrl.MergeTab(1);
    chatWndScript.ChatTabCtrl.MergeTab(2);
    chatWndScript.ChatTabCtrl.MergeTab(3);
    chatWndScript.ChatTabCtrl.MergeTab(4);
    chatWndScript.ChatTabCtrl.SetTopOrder(0,True);
    chatWndScript.HandleTabClick("ChatTabCtrl0");
    break;
    default:
  }
}

function HandleCloseAllWindow ()
{
  Class'UIAPI_WINDOW'.static.HideWindow("SystemMenuWnd");
}
defaultproperties
{
}
