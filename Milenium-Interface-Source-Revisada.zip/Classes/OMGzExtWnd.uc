class OMGzExtWnd extends Object;

static function Init(Object Receiver)
{
    class'interface.OMGzExt'.static.Init(Receiver);
}

static function DebugLog(string Msg)
{
}