class AuthExtWnd extends UICommonAPI;

const MAX_ACCOUNTS = 10;

var private WindowHandle zzme;
var ButtonHandle zzshowautologin;
var ButtonHandle zzBtnAccdel;
var ButtonHandle zzBtnclose;
var ButtonHandle zzBtnlogin;
var ButtonHandle zzBtnexit;
var ButtonHandle zzinfouser;
var ButtonHandle zzinfopass;
var bool bIsPasswordMode;  
var WindowHandle zzlistacount;
var ListCtrlHandle zzlistcontrol;
var EditBoxHandle zzuser;
var EditBoxHandle zzpass;
var string zzcheckza;
var bool zzboleano;

function OnLoad()
{
    zzme = GetHandle("AuthExtWnd");
   zzlistacount  = GetHandle("AuthExtWnd.accListWnd");
   GetINIString("LastAccount", "AutoLogin",zzcheckza, "AutoLogin.ini");
   zzshowautologin  = xxGetButtonHandle("AuthExtWnd.AuthOMGzWnd.btn_accList");
   zzBtnAccdel  = xxGetButtonHandle("AuthExtWnd.accListWnd.btn_accDel");
   zzBtnclose  = xxGetButtonHandle("AuthExtWnd.accListWnd.btn_Close");
      zzinfouser  = xxGetButtonHandle("AuthExtWnd.AuthOMGzWnd.InfoUser");
   zzinfopass  = xxGetButtonHandle("AuthExtWnd.AuthOMGzWnd.InfoPass");
   zzBtnlogin  = xxGetButtonHandle("AuthExtWnd.AuthOMGzWnd.btn_Login");
   zzBtnexit  = xxGetButtonHandle("AuthExtWnd.AuthOMGzWnd.btn_Exit");
   zzlistcontrol  = ListCtrlHandle(GetHandle("AuthExtWnd.accListWnd.accList"));
   zzuser  = xxGetEditBoxHandle("AuthExtWnd.AuthOMGzWnd.AccUser");
   zzpass  = xxGetEditBoxHandle("AuthExtWnd.AuthOMGzWnd.AccPassword");
   
   zzinfouser.SetTooltipCustomType(xxMakeTooltipSimpleText("User"));
   zzinfopass.SetTooltipCustomType(xxMakeTooltipSimpleText("Password"));
   zzshowautologin.SetTooltipCustomType(xxMakeTooltipSimpleText("Open/Close AutoLogin"));
   
   bIsPasswordMode = false;
   
    zzboleano = true;
	
	xxstx();
	if(zzcheckza == "True")
	{
	
	Class'NWindow.UIAPI_CHECKBOX'.static.SetCheck("AuthExtWnd.AuthOMGzWnd.cb_SaveLastLogin", true);
	
	}
	else
	{
	Class'NWindow.UIAPI_CHECKBOX'.static.SetCheck("AuthExtWnd.AuthOMGzWnd.cb_SaveLastLogin", false);
	}
	
    Class'NWindow.UIAPI_WINDOW'.static.SetTabOrder("AuthExtWnd.AuthOMGzWnd.AccUser", "AuthExtWnd.AuthOMGzWnd.AccPassword", "AuthExtWnd.AuthOMGzWnd.AccPassword");
    Class'NWindow.UIAPI_WINDOW'.static.SetTabOrder("AuthExtWnd.AuthOMGzWnd.AccPassword", "AuthExtWnd.AuthOMGzWnd.AccUser", "AuthExtWnd.AuthOMGzWnd.AccUser");
   

   return;
}

function OnShow()
{
 //   local string zzusuario, zzpassword;
    local string zzusuario, zzpassword,zzautologin;
    GetHandle("AuthWnd").SetAlpha(0);
    GetHandle("AuthWnd").SetAnchor("", "TopLeft", "TopLeft", 0, 0);
    // End:0x119
    if(GetINIString("LastAccount", "User",zzusuario, "AutoLogin.ini") && zzusuario != "")
    {
        GetINIString("LastAccount", "Password",zzpassword, "AutoLogin.ini");
		GetINIString("LastAccount", "AutoLogin",zzautologin, "AutoLogin.ini");
        zzuser.SetString(zzusuario);
        zzpass.SetString(zzpassword);
		

		
   
    }
    zzme.SetFocus();
	zzlistacount.ShowWindow();

    return;
}


function OnClickCheckBox(string strID)
{
    if(strID == "cb_SaveLastLogin")
    {
        if(Class'UIAPI_CHECKBOX'.static.IsChecked("AuthExtWnd.AuthOMGzWnd.cb_SaveLastLogin"))
        {
            SetINIString("LastAccount", "AutoLogin", "True", "AutoLogin.ini");
			RefreshINI("AutoLogin.ini");
        }
        else
        {
            SetINIString("LastAccount", "AutoLogin", "False", "AutoLogin.ini");
			RefreshINI("AutoLogin.ini");
        }
    }
    return;
}

function OnHide()
{
    // End:0x21
    if(zzlistacount.IsShowWindow())
    {
        zzlistacount.HideWindow();
    }
    // End:0x80
    if(!Class'NWindow.UIAPI_CHECKBOX'.static.IsChecked("AuthExtWnd.AuthOMGzWnd.cb_SaveLastLogin"))
    {
        zzuser.SetString("");
        zzpass.SetString("");
    }
    return;
}

function OnClickButtonWithHandle(ButtonHandle zzbtn)
{
    switch(zzbtn)
    {
        // End:0x18
        case zzshowautologin:
            xxussi();
            // End:0x68
            break;
        // End:0x29
        case zzBtnAccdel:
            xxbelsi();
            // End:0x68
            break;
        // End:0x43
        case zzBtnclose:
            zzlistacount.HideWindow();
            // End:0x68
            break;
        // End:0x54
        case zzBtnexit:
            RequestExit();
            // End:0x68
            break;
        // End:0x65
        case zzBtnlogin:
            xxlogin();
            // End:0x68
            break;
			
		        // End:0x65
        case zzinfopass:
          if (zzpass != None)
    {
        if (bIsPasswordMode) 
        {
            zzpass.SetEditType("NORMAL");
            bIsPasswordMode = false;
        }
        else 
        {
            zzpass.SetEditType("PASSWORD");
            bIsPasswordMode = true;
        }
    }
            // End:0x68
            break;	
			
        // End:0xFFFF
        default:
            break;
    }
    return;
}

function xxussi()
{
    // End:0x24
    if(zzlistacount.IsShowWindow())
    {
        zzlistacount.HideWindow();        
    }
    else
    {
        zzlistacount.ShowWindow();
    //    xxstx();
    }
    return;
}




function xxbelsi()
{
    local private int zzidaa;
    local LVDataRecord Record;

    zzidaa = zzlistcontrol.GetSelectedIndex();
    
    // Verifica si se seleccionó un índice válido
    if(zzidaa < 0)
    {
        return;
    }

    // Limpia la información de usuario y contraseña en el archivo INI
    SetINIString("Account_" $ string(zzidaa), "User", "", "AutoLogin.ini");
    SetINIString("Account_" $ string(zzidaa), "Password", "", "AutoLogin.ini");

    // Modifica el registro en el ListCtrl para reflejar que está vacío
    Record.LVDataList.Length = 2;
    Record.LVDataList[0].szData = string(zzidaa + 1);  // Número del slot
    Record.LVDataList[1].szData = "";                  // Usuario vacío en el slot
    Record.LVDataList[1].szReserved = "";              // Contraseña vacía en el slot
    zzlistcontrol.ModifyRecord(zzidaa, Record);

    return;
}








function xxsoeot()
{
    local private int zzipa;
    local private string zzuserstring, zzpassstring;

   zzipa  = zzlistcontrol.GetSelectedIndex();
    // End:0x22
    if(zzipa < 0)
    {
        return;
    }
    zzuserstring = zzuser.GetString();
    zzpassstring = zzpass.GetString();
    SetINIString("Account_" $ string(zzipa), "User",zzuserstring, "AutoLogin.ini");
    SetINIString("Account_" $ string(zzipa), "Password",zzpassstring, "AutoLogin.ini");
    xxstx();
    return;
}

function xxstx()
{
    local private int zzikala;
    local LVDataRecord Record;
    local string zzuserSlot, zzpassSlot;

    zzlistcontrol.DeleteAllItem();

    // Carga las cuentas desde AutoLogin.ini
    for (zzikala = 0; zzikala < MAX_ACCOUNTS; ++zzikala)
    {
        GetINIString("Account_" $ string(zzikala), "User", zzuserSlot, "AutoLogin.ini");
        GetINIString("Account_" $ string(zzikala), "Password", zzpassSlot, "AutoLogin.ini");

        Record.LVDataList.Length = 2;
        Record.LVDataList[0].szData = string(zzikala + 1);  // Número del slot
        Record.LVDataList[1].szData = zzuserSlot;           // Usuario en el slot
        Record.LVDataList[1].szReserved = zzpassSlot;       // Contraseña en el slot

        Class'NWindow.UIAPI_LISTCTRL'.static.InsertRecord("AuthExtWnd.accListWnd.accList", Record);
    }

    xxgssi();  // Llama a xxgssi si necesitas sincronizar
    return;
}

function xxgssi()
{
    local private int zzolka;
    local private LVDataRecord zzrekaa;

    // Recorre todos los slots y guarda los datos en el archivo INI
    for (zzolka = 0; zzolka < MAX_ACCOUNTS; ++zzolka)
    {
        zzrekaa = zzlistcontrol.GetRecord(zzolka);  // Obtiene el registro del índice actual

        if (zzrekaa.LVDataList.Length > 0 && zzrekaa.LVDataList[1].szData != "")
        {
            // Guarda usuario y contraseña si hay datos en LVDataList
            SetINIString("Account_" $ string(zzolka), "User", zzrekaa.LVDataList[1].szData, "AutoLogin.ini");
            SetINIString("Account_" $ string(zzolka), "Password", zzrekaa.LVDataList[1].szReserved, "AutoLogin.ini");
        }
        else
        {
            // Limpia usuario y contraseña si no hay datos en LVDataList
            SetINIString("Account_" $ string(zzolka), "User", "", "AutoLogin.ini");
            SetINIString("Account_" $ string(zzolka), "Password", "", "AutoLogin.ini");
        }
    }
    
    // Refresca el archivo INI después del bucle
    RefreshINI("AutoLogin.ini");
    return;
}








function OnClickListCtrlRecord(string strID)
{
    local private int zzikuakl;
    local private LVDataRecord zzrecorda;

    // End:0x15
    if(strID != "accList")
    {
        return;
    }
    zzikuakl = zzlistcontrol.GetSelectedIndex();
    zzrecorda = zzlistcontrol.GetRecord(zzikuakl);
    zzuser.SetString(zzrecorda.LVDataList[1].szData);
    zzpass.SetString(zzrecorda.LVDataList[1].szReserved);
//    Class'NWindow.UIAPI_CHECKBOX'.static.SetCheck("AuthExtWnd.AuthOMGzWnd.cb_SaveLastLogin", true);
    return;
}

function OnDBClickListCtrlRecord(string strID)
{
    xxlogin();
    return;
}

function OnCompleteEditBox(string strID)
{
    xxlogin();
    return;
}

function xxlogin() 
{
    local private string zzuserparametro, zzpassparametro, zzuserSlot;
    local LVDataRecord Record;
    local int slotToUse, i;
    local bool isDuplicate;
    isDuplicate = false;
    
    zzuserparametro = zzuser.GetString();
    zzpassparametro = zzpass.GetString();

    if (Class'NWindow.UIAPI_CHECKBOX'.static.IsChecked("AuthExtWnd.AuthOMGzWnd.cb_SaveLastLogin"))
    {
        // Verifica si el usuario ya existe en algún slot
        for (i = 0; i < MAX_ACCOUNTS; i++)
        {
            GetINIString("Account_" $ string(i), "User", zzuserSlot, "AutoLogin.ini");
            if (zzuserSlot == zzuserparametro)
            {
                isDuplicate = true;
                break;
            }
        }

        // Si el usuario no es duplicado, se procede a guardar en un slot vacío
        if (!isDuplicate)
        {
            // Busca un slot vacío para guardar el nuevo usuario
            slotToUse = -1;
            for (i = 0; i < MAX_ACCOUNTS; i++)
            {
                GetINIString("Account_" $ string(i), "User", zzuserSlot, "AutoLogin.ini");
                if (zzuserSlot == "") 
                {
                    slotToUse = i;  // Encuentra el primer slot vacío
                    break;
                }
            }

            // Si todos los slots están ocupados, usa el primer slot (slot 0) para sobrescribir
            if (slotToUse == -1) 
            {
                slotToUse = 0;
            }

            // Guarda la cuenta en el slot seleccionado
            SetINIString("Account_" $ string(slotToUse), "User", zzuserparametro, "AutoLogin.ini");
            SetINIString("Account_" $ string(slotToUse), "Password", zzpassparametro, "AutoLogin.ini");

            // Actualiza la visualización en el ListCtrl
            Record.LVDataList.Length = 2;
            Record.LVDataList[0].szData = string(slotToUse + 1);  // Número del slot
            Record.LVDataList[1].szData = zzuserparametro;        // Usuario en el slot
            Record.LVDataList[1].szReserved = zzpassparametro;    // Contraseña en el slot
            zzlistcontrol.ModifyRecord(slotToUse, Record);
        }

        // Guarda la última cuenta en LastAccount, sin importar si es duplicada o no
        SetINIString("LastAccount", "User", zzuserparametro, "AutoLogin.ini");
        SetINIString("LastAccount", "Password", zzpassparametro, "AutoLogin.ini");

        // Refresca el archivo INI para asegurarse de que se guarden los cambios
        RefreshINI("AutoLogin.ini");
    }
    else
    {
        // Limpia la información si no está marcado el checkbox
        SetINIString("LastAccount", "User", "", "AutoLogin.ini");
        SetINIString("LastAccount", "Password", "", "AutoLogin.ini");
        RefreshINI("AutoLogin.ini");
    }

    // Ejecuta la autenticación
    AuthLoginPad(zzuserparametro $ "," $ zzpassparametro);

    return;
}


native(1252) final function string AuthLoginUI(); // Solo muestra el estado
function AuthLoginPad(string loginpassword)
{
loginpassword = AuthLoginUI();

}


