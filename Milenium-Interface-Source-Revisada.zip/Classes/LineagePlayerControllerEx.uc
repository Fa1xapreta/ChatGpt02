class LineagePlayerControllerEx extends LineagePlayerController
    config(user);

var Viewport vPort;

static function Viewport GetActorViewport()
{
    return default.vPort;
}

static function Actor GetMyActor()
{
    return default.vPort.Actor;    
}

event PostBeginPlay()
{
    super.PostBeginPlay();
    default.vPort = GetViewport();   	
    return;
}

simulated event LostChild(Actor aSelfActor)
{
    super.LostChild(aSelfActor);    
}

simulated event ClearL2Game()
{
    super.ClearL2Game();
}