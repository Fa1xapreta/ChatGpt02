class OnScreenMessageWnd extends UIScript;

const MAX_CHAR = 35;

var string currentwnd;
var bool onshowstat1;
var bool onshowstat2;
var int globalAlphavalue1;
var int globalAlphavalue2;
var int globalDuration;
var int droprate;
var int m_TimerCount;
var int m_TickCount; // Contador interno para garantir que a mensagem suma mesmo se o UITimer falhar

function OnLoad ()
{
    RegisterEvent(140);
    RegisterEvent(580);
    ResetAllMessage();
    globalAlphavalue1 = 0;
    globalAlphavalue2 = 255;
    m_TimerCount = 0;
    m_TickCount = 0;
}

function OnTick ()
{
    if ( onshowstat1 == True ) 
    {
        FadeIn(currentwnd);
    }
    
    if ( onshowstat2 == True ) 
    {
        FadeOut(currentwnd);
    }
    
    // Controle de tempo interno por ticks (garante que a mensagem saia mesmo se o timer falhar)
    if ( globalDuration > 0 && onshowstat1 == False && onshowstat2 == False )
    {
        m_TickCount++;
        // Cada segundo equivale aproximadamente a 10 a 30 ticks dependendo do FPS, 
        // aqui usamos globalDuration que já vem em milissegundos ou segundos ajustados.
        if ( m_TickCount >= (globalDuration / 30) ) 
        {
            m_TickCount = 0;
            onshowstat2 = True;
        }
    }
}

function OnTimer (int TimerID)
{
    if ( TimerID == 999 )
    {
        onshowstat2 = True;
        Class'UIAPI_WINDOW'.static.KillUITimer("OnScreenMessageWnd2", 999);
    }
}

function ResetAllMessage ()
{
    local int i;
    
    globalAlphavalue1 = 0;
    globalAlphavalue2 = 255;
    currentwnd = "";
    onshowstat1 = False;
    onshowstat2 = False;
    m_TickCount = 0;
    
    Class'UIAPI_WINDOW'.static.HideWindow("OnScreenMessageWnd1");
    Class'UIAPI_WINDOW'.static.HideWindow("OnScreenMessageWnd2");
    
    for(i = 1; i <= MAX_CHAR; ++i)
    {
        Class'UIAPI_WINDOW'.static.SetWindowSize("OnScreenMessageWnd2.Message1Wnd.TextTex" $ string(i), 0, 0);
    }
    
    Class'UIAPI_WINDOW'.static.SetWindowSize("OnScreenMessageWnd2.TexBGMessage", 0, 0);
}

function ShowMsg (string TextValue, int Duration, int Animation, int msgcolor)
{
    // TRAVA DE SEGURANÇA: Se não tiver texto, esconde a janela e aborta!
    if (TextValue == "" || Len(TextValue) <= 0)
    {
        ResetAllMessage();
        return;
    }

    ResetAllMessage();
    currentwnd = "OnScreenMessageWnd2";
    
    SetTextTexColor(msgcolor);
    TextToTex(TextValue);
    
    Class'UIAPI_WINDOW'.static.ShowWindow(currentwnd);
    Class'UIAPI_WINDOW'.static.ShowWindow("OnScreenMessageWnd2.Message1Wnd");
    Class'UIAPI_WINDOW'.static.ShowWindow("OnScreenMessageWnd2.TexBGMessage");

    Class'UIAPI_WINDOW'.static.SetAlpha(currentwnd, 0);
    Class'UIAPI_WINDOW'.static.SetAlpha("OnScreenMessageWnd2.Message1Wnd", 0);
    Class'UIAPI_WINDOW'.static.SetAlpha("OnScreenMessageWnd2.TexBGMessage", 0);

    onshowstat1 = True;
    onshowstat2 = False;
    
    if (Duration <= 0) 
        globalDuration = 3000;
    else 
        globalDuration = Duration;
        
    m_TickCount = 0;
    
    switch (Animation)
    {
        case 0:  droprate = 255; break;
        case 1:  droprate = 25;  break;
        case 11: droprate = 15;  break;
        case 12: droprate = 25;  break;
        case 13: droprate = 35;  break;
        default: droprate = 25;  break;
    }
}

function FadeIn (string WndName)
{
    globalAlphavalue1 = globalAlphavalue1 + droprate;
    if ( globalAlphavalue1 < 255 )
    {
        Class'UIAPI_WINDOW'.static.SetAlpha(WndName, globalAlphavalue1);
        Class'UIAPI_WINDOW'.static.SetAlpha("OnScreenMessageWnd2.Message1Wnd", globalAlphavalue1);
        Class'UIAPI_WINDOW'.static.SetAlpha("OnScreenMessageWnd2.TexBGMessage", globalAlphavalue1);
    } 
    else 
    {
        Class'UIAPI_WINDOW'.static.SetAlpha(WndName, 255);
        Class'UIAPI_WINDOW'.static.SetAlpha("OnScreenMessageWnd2.Message1Wnd", 255);
        Class'UIAPI_WINDOW'.static.SetAlpha("OnScreenMessageWnd2.TexBGMessage", 255);
        
        globalAlphavalue1 = 0;
        onshowstat1 = False;
        Class'UIAPI_WINDOW'.static.SetUITimer("OnScreenMessageWnd2", 999, globalDuration);
    }
}

function FadeOut (string WndName)
{
    globalAlphavalue2 = globalAlphavalue2 - droprate;
    if ( globalAlphavalue2 > 15 )
    {
        Class'UIAPI_WINDOW'.static.SetAlpha(WndName, globalAlphavalue2);
        Class'UIAPI_WINDOW'.static.SetAlpha("OnScreenMessageWnd2.Message1Wnd", globalAlphavalue2);
        Class'UIAPI_WINDOW'.static.SetAlpha("OnScreenMessageWnd2.TexBGMessage", globalAlphavalue2);
    } 
    else 
    {
        Class'UIAPI_WINDOW'.static.SetAlpha(WndName, 0);
        Class'UIAPI_WINDOW'.static.SetAlpha("OnScreenMessageWnd2.Message1Wnd", 0);
        Class'UIAPI_WINDOW'.static.SetAlpha("OnScreenMessageWnd2.TexBGMessage", 0);
        
        globalAlphavalue2 = 255;
        onshowstat2 = False;
        ResetAllMessage();
    }
}

function OnEvent (int a_EventID, string a_Param)
{
    local int MsgType, msgNo, WindowType, FontSize, FontType, MsgColor;
    local int shadowtype, BackgroundType, Lifetime, AnimationType, SystemMsgIndex;
    local string msgtext, ParamString1, ParamString2;

    if ( a_EventID == 140 )
    {
        ParseInt(a_Param, "MsgType", MsgType);
        ParseInt(a_Param, "MsgNo", msgNo);
        ParseInt(a_Param, "WindowType", WindowType);
        ParseInt(a_Param, "FontSize", FontSize);
        ParseInt(a_Param, "FontType", FontType);
        ParseInt(a_Param, "MsgColor", MsgColor);
        ParseInt(a_Param, "ShadowType", shadowtype);
        ParseInt(a_Param, "BackgroundType", BackgroundType);
        ParseInt(a_Param, "LifeTime", Lifetime);
        ParseInt(a_Param, "AnimationType", AnimationType);
        ParseString(a_Param, "Msg", msgtext);
        
        if (InStr(msgtext, "CustomEvent=") != -1) return;
        
        if (MsgType == 0)
        {
            msgtext = GetSystemMessage(msgNo);
        }
        
        // A CORREÇÃO ESTÁ AQUI:
        // Só chama a textura e o texto se o WindowType for diferente de 0 (chat normal)
        if (WindowType != 0) 
        {
            ShowMsg(msgtext, Lifetime, AnimationType, MsgColor);
        }
    }
    
    if ( a_EventID == 580 )
    {
        ParseInt(a_Param, "Index", SystemMsgIndex);
        ParseString(a_Param, "Param1", ParamString1);
        ParseString(a_Param, "Param2", ParamString2);
        
        if ( (SystemMsgIndex == 35) && !Class'UIAPI_CHECKBOX'.static.IsChecked("OptionWnd.CB_ShowDamage") ) return;
        ValidateSystemMsg(SystemMsgIndex, ParamString1, ParamString2);
    }
}

function ValidateSystemMsg (int index, string StringTxt1, string StringTxt2)
{
    local SystemMsgData SystemMsgCurrent;
    local int Lifetime, AnimationType, FontColorType;
    local string msgtext;

    GetSystemMsgInfo(index, SystemMsgCurrent);
    
    if ( SystemMsgCurrent.WindowType != 0 )
    {
        msgtext = SystemMsgCurrent.OnScrMsg;
        
        // TRAVA 2: Se a mensagem de tela nativa não existir (ex: logs de dano), nem continua.
        if (msgtext == "")
        {
            return;
        }

        msgtext = MakeFullSystemMsg(msgtext, StringTxt1, StringTxt2);
        Lifetime = SystemMsgCurrent.Lifetime * 1000;
        AnimationType = SystemMsgCurrent.AnimationType;
        FontColorType = 1; 
        
        ShowMsg(msgtext, Lifetime, AnimationType, FontColorType);
    }
}

// =========================================================================
// LÓGICA DAS TEXTURAS DA FONTE E TAMANHO DO FUNDO
// =========================================================================

function TextToTex(string TextValue)
{
    local int i, Length, RealSize, RealAllSize;
    local string S, RealChar, Param1;

    Length = Len(TextValue);
    Param1 = TextValue;
    
    if(Length > MAX_CHAR)
    {
        Param1 = Left(Param1, MAX_CHAR);
    }

    Length = Len(Param1);
    i = 1;

    while(i <= MAX_CHAR)
    {
        Class'UIAPI_WINDOW'.static.ClearAnchor("OnScreenMessageWnd2.Message1Wnd.TextTex" $ string(i));
        Class'UIAPI_TEXTURECTRL'.static.SetUV("OnScreenMessageWnd2.Message1Wnd.TextTex" $ string(i), 0, 0);
        Class'UIAPI_WINDOW'.static.SetWindowSize("OnScreenMessageWnd2.Message1Wnd.TextTex" $ string(i), 0, 0);
        ++i;
    }

    RealAllSize = 0;
    i = 1;
    
    while(i <= Length)
    {
        S = Right(Left(Param1, i), 1);
        RealChar = GetRealChr(Asc(S));

        RealSize = GetVSize(RealChar);
        Class'UIAPI_WINDOW'.static.SetWindowSize("OnScreenMessageWnd2.Message1Wnd.TextTex" $ string(i), RealSize, 24);
        Class'UIAPI_TEXTURECTRL'.static.SetUV("OnScreenMessageWnd2.Message1Wnd.TextTex" $ string(i), GetUTex(RealChar), GetVTex(RealChar));
        RealAllSize = RealAllSize + (RealSize - 1);
        
        if(i > 1)
        {
            Class'UIAPI_WINDOW'.static.SetAnchor("OnScreenMessageWnd2.Message1Wnd.TextTex" $ string(i), "OnScreenMessageWnd2.Message1Wnd.TextTex" $ string(i - 1), "TopRight", "TopLeft", -1, 0);
        }
        ++i;
    }

// Centraliza o texto perfeitamente no meio da imagem (Horizontal e Vertical)
    // O último valor (32) controla a altura/vertical: aumente se quiser descer, diminua se quiser subir
    Class'UIAPI_WINDOW'.static.SetAnchor("OnScreenMessageWnd2.Message1Wnd.TextTex1", "OnScreenMessageWnd2.Message1Wnd", "TopCenter", "TopCenter", -RealAllSize / 2, 32);
    
    // Mantém a altura da janela pai em 90 (para esconder o ícone de baixo sem achatar a imagem)
    Class'UIAPI_WINDOW'.static.SetWindowSize("OnScreenMessageWnd2", 1024, 90);
    
    // Força o tamanho original da textura de fundo
    Class'UIAPI_WINDOW'.static.SetWindowSize("OnScreenMessageWnd2.TexBGMessage", 1024, 128);
    Class'UIAPI_WINDOW'.static.ClearAnchor("OnScreenMessageWnd2.TexBGMessage");
    
    // Alinha a imagem dentro da janela pai
    Class'UIAPI_WINDOW'.static.SetAnchor("OnScreenMessageWnd2.TexBGMessage", "OnScreenMessageWnd2", "TopCenter", "TopCenter", 0, -3);
}

function SetTextTexColor(int FontColor)
{
    local int i;
    local string Color;

    if(FontColor == 2)
        Color = "L2UI_CH3.OnScreenMsgWnd.largefontomgR";        
    else if(FontColor == 3)
        Color = "L2UI_CH3.OnScreenMsgWnd.largefontomgG";            
    else if(FontColor == 4)
        Color = "L2UI_CH3.OnScreenMsgWnd.largefontomgB";                
    else
        Color = "L2UI_CH3.OnScreenMsgWnd.largefontomg";

    for(i = 1; i <= MAX_CHAR; ++i)
    {
        Class'UIAPI_TEXTURECTRL'.static.SetTexture("OnScreenMessageWnd2.Message1Wnd.TextTex" $ string(i), Color);
    }
}

function int GetVSize(string Chr)
{
    local int tmp;
    tmp = InStr("OÓÒÔÕÖQWwMm@%", Chr);
    if(tmp > -1) return 15;
    
    tmp = InStr("gACDGHNRTUVXYZÁÀÂÃÄÉÈÊËÚÙÛÜÇ#&/", Chr);
    if(tmp > -1) return 13;
    
    tmp = InStr("eéèêëSBEFLdq0123456789_=+<>", Chr);
    if(tmp > -1) return 12;
    
    tmp = InStr("abchovxyáàâãäçóòôõöúùûünuzsK1?$*){}[]P", Chr);
    if(tmp > -1) return 11;
    
    tmp = InStr("ftjkÍÌÎÏIJ(-p", Chr);
    if(tmp > -1) return 9;
    
    tmp = InStr("ríìîï'!.,:; ", Chr);
    if(tmp > -1) return 7;
    
    tmp = InStr("il", Chr);
    if(tmp > -1) return 5;
    
    return 0;
}

function int GetUTex(string Chr)
{
    local int tmp;
    tmp = InStr("ABCDEFGHIJKLMNOPQRSTUVWXYZ ", Chr);
    if(tmp > -1) return tmp * 15;
    
    tmp = InStr("abcdefghijklmnopqrstuvwxyz", Chr);
    if(tmp > -1) return tmp * 15;
    
    tmp = InStr("0123456789", Chr);
    if(tmp > -1) return tmp * 15;
    
    tmp = InStr("'!?@#$%&*-_=+(){}[]<>.,:;/", Chr);
    if(tmp > -1) return tmp * 15;
    
    tmp = InStr("ÁÀÂÃÄÉÈÊËÍÌÎÏÓÒÔÕÖÚÙÛÜÇ", Chr);
    if(tmp > -1) return (tmp / 2) * 15;
    
    tmp = InStr("áàâãäéèêëíìîïóòôõöúùûüç", Chr);
    if(tmp > -1) return (tmp / 2) * 15;
    
    return 460;
}

function int GetVTex(string Chr)
{
    local int tmp;
    tmp = InStr("ABCDEFGHIJKLMNOPQRSTUVWXYZ ", Chr);
    if(tmp > -1) return 0;
    
    tmp = InStr("abcdefghijklmnopqrstuvwxyz", Chr);
    if(tmp > -1) return 24;
    
    tmp = InStr("0123456789", Chr);
    if(tmp > -1) return 48;
    
    tmp = InStr("'!?@#$%&*-_=+(){}[]<>.,:;/", Chr);
    if(tmp > -1) return 72;
    
    tmp = InStr("ÁÀÂÃÄÉÈÊËÍÌÎÏÓÒÔÕÖÚÙÛÜÇ", Chr);
    if(tmp > -1) return 96;
    
    tmp = InStr("áàâãäéèêëíìîïóòôõöúùûüç", Chr);
    if(tmp > -1) return 120;
    
    return 0;
}

function string GetRealChr(int Chr)
{
    switch(Chr)
    {
        case 32: return " ";
        case 33: return "!";
        case 34: return "'";
        case 35: return "#";
        case 36: return "$";
        case 37: return "%";
        case 38: return "&";
        case 39: return "'";
        case 40: return "(";
        case 41: return ")";
        case 42: return "'";
        case 43: return "+";
        case 44: return ",";
        case 45: return "-";
        case 46: return ".";
        case 47: return "/";
        case 48: return "0";
        case 49: return "1";
        case 50: return "2";
        case 51: return "3";
        case 52: return "4";
        case 53: return "5";
        case 54: return "6";
        case 55: return "7";
        case 56: return "8";
        case 57: return "9";
        case 58: return ":";
        case 59: return ";";
        case 60: return "<";
        case 61: return "=";
        case 62: return ">";
        case 63: return "?";
        case 64: return "@";
        case 65: return "A";
        case 66: return "B";
        case 67: return "C";
        case 68: return "D";
        case 69: return "E";
        case 70: return "F";
        case 71: return "G";
        case 72: return "H";
        case 73: return "I";
        case 74: return "J";
        case 75: return "K";
        case 76: return "L";
        case 77: return "M";
        case 78: return "N";
        case 79: return "O";
        case 80: return "P";
        case 81: return "Q";
        case 82: return "R";
        case 83: return "S";
        case 84: return "T";
        case 85: return "U";
        case 86: return "V";
        case 87: return "W";
        case 88: return "X";
        case 89: return "Y";
        case 90: return "Z";
        case 91: return "[";
        case 92: return "/";
        case 93: return "]";
        case 94: return "^";
        case 95: return "_";
        case 96: return "`";
        case 97: return "a";
        case 98: return "b";
        case 99: return "c";
        case 100: return "d";
        case 101: return "e";
        case 102: return "f";
        case 103: return "g";
        case 104: return "h";
        case 105: return "i";
        case 106: return "j";
        case 107: return "k";
        case 108: return "l";
        case 109: return "m";
        case 110: return "n";
        case 111: return "o";
        case 112: return "p";
        case 113: return "q";
        case 114: return "r";
        case 115: return "s";
        case 116: return "t";
        case 117: return "u";
        case 118: return "v";
        case 119: return "w";
        case 120: return "x";
        case 121: return "y";
        case 122: return "z";
        case 123: return "{";
        case 124: return "|";
        case 125: return "}";
        case 126: return "~";
        case 127: return " ";
        case 128: return "€";
        case 129: return " ";
        case 130: return "‚";
        case 131: return "ƒ";
        case 132: return "„";
        case 133: return "…";
        case 134: return "†";
        case 135: return "‡";
        case 136: return "ˆ";
        case 137: return "‰";
        case 138: return "Š";
        case 139: return "‹";
        case 140: return "Œ";
        case 141: return " ";
        case 142: return "Ž";
        case 143: return "ž";
        case 144: return "Ž";
        case 145: return "‘";
        case 146: return "’";
        case 147: return "“";
        case 148: return "”";
        case 149: return "•";
        case 150: return "–";
        case 151: return "—";
        case 152: return "˜";
        case 153: return "™";
        case 154: return "š";
        case 155: return "›";
        case 156: return "œ";
        case 157: return " ";
        case 158: return "ž";
        case 159: return "Ÿ";
        case 160: return " ";
        case 161: return "¡";
        case 162: return "¢";
        case 163: return "£";
        case 164: return "¤";
        case 165: return "¥";
        case 166: return "¦";
        case 167: return "§";
        case 168: return "¨";
        case 169: return "©";
        case 170: return "ª";
        case 171: return "«";
        case 172: return "¬";
        case 173: return "­";
        case 174: return "®";
        case 175: return "¯";
        case 176: return "°";
        case 177: return "±";
        case 178: return "²";
        case 179: return "³";
        case 180: return "´";
        case 181: return "µ";
        case 182: return "¶";
        case 183: return "·";
        case 184: return "¸";
        case 185: return "¹";
        case 186: return "º";
        case 187: return "»";
        case 188: return "¼";
        case 189: return "½";
        case 190: return "¾";
        case 191: return "¿";
        case 192: return "À";
        case 193: return "Á";
        case 194: return "Â";
        case 195: return "Ã";
        case 196: return "Ä";
        case 197: return "Å";
        case 198: return "Æ";
        case 199: return "Ç";
        case 200: return "È";
        case 201: return "É";
        case 202: return "Ê";
        case 203: return "Ë";
        case 204: return "Ì";
        case 205: return "Í";
        case 206: return "Î";
        case 207: return "Ï";
        case 208: return "Ð";
        case 209: return "Ñ";
        case 210: return "Ò";
        case 211: return "Ó";
        case 212: return "Ô";
        case 213: return "Õ";
        case 214: return "Ö";
        case 215: return "×";
        case 216: return "Ø";
        case 217: return "Ù";
        case 218: return "Ú";
        case 219: return "Û";
        case 220: return "Ü";
        case 221: return "Ý";
        case 222: return "Þ";
        case 223: return "ß";
        case 224: return "à";
        case 225: return "á";
        case 226: return "â";
        case 227: return "ã";
        case 228: return "ä";
        case 229: return "å";
        case 230: return "æ";
        case 231: return "ç";
        case 232: return "è";
        case 233: return "é";
        case 234: return "ê";
        case 235: return "ë";
        case 236: return "ì";
        case 237: return "í";
        case 238: return "î";
        case 239: return "ï";
        case 240: return "ð";
        case 241: return "ñ";
        case 242: return "ò";
        case 243: return "ó";
        case 244: return "ô";
        case 245: return "õ";
        case 246: return "ö";
        case 247: return "÷";
        case 248: return "ø";
        case 249: return "ù";
        case 250: return "ú";
        case 251: return "û";
        case 252: return "ü";
        case 253: return "ý";
        case 254: return "þ";
        case 255: return "ÿ";
        default: break;
    }
}

defaultproperties
{
}