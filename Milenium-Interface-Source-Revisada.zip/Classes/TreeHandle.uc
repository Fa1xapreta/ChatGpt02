class TreeHandle extends UIScript;

const NODE_NAME = "tree_btn_";

var string HandleName;
var string ParentName;
var int NodeCount;

var int nodeWidth;
var int nodeHeight;

var array<int> TablesPosition;

static function TreeHandle Inst()
{
	return new class'TreeHandle';
}

function Init(string name, string parent, int nodeBtnWidth, int nodeBtnHeight, array<int> tables)
{
    local XMLTreeNodeInfo infNodeItem;

    HandleName = name;
    ParentName = parent;
	nodeWidth = nodeBtnWidth;
	nodeHeight = nodeBtnHeight;
	TablesPosition = tables;
    NodeCount = 0;

    infNodeItem.strName = ParentName;

    class'UIAPI_TREECTRL'.static.InsertNode(HandleName, "", infNodeItem);
}

function Clear()
{
    class'UIAPI_TREECTRL'.static.Clear( HandleName );
}

function Reset()
{
    self.Clear();
    self.Init(HandleName, ParentName, nodeWidth, nodeHeight, TablesPosition);
}

function ShowScrollBar(bool bShow) {
	class'UIAPI_TREECTRL'.static.ShowScrollBar(HandleName, bShow);
}

function SetExpandedNode(bool bExpanded)
{
    class'UIAPI_TREECTRL'.static.SetExpandedNode( self.HandleName, self.ParentName, bExpanded );
}

function string InsertNode(optional string Reserved, optional bool FollowCursor, optional CustomTooltip TooltipInfo, optional int OffSetX, optional int OffSetY, optional int ShowButton, optional bool IsExpanded)
{
    local XMLTreeNodeInfo infNodeItem;

	if(Reserved != "") {
    	infNodeItem.strName = NODE_NAME $ Reserved;
	}else {
    	infNodeItem.strName = NODE_NAME $ NodeCount;
	}

	infNodeItem.bFollowCursor = FollowCursor;
    infNodeItem.Tooltip = TooltipInfo;
    infNodeItem.nOffSetX = OffSetX;
    infNodeItem.nOffSetY = OffSetY;
	infNodeItem.bShowButton = ShowButton;

	if(IsExpanded) {
		infNodeItem.nTexExpandedHeight = 38;
		infNodeItem.nTexExpandedRightWidth = 5;	
		infNodeItem.nTexExpandedLeftUWidth = 30;
		infNodeItem.nTexExpandedLeftUHeight = 38;
		infNodeItem.strTexExpandedLeft = "MUI_AUGM.etc.IconSelect2";
	}

    NodeCount++;

    return class'UIAPI_TREECTRL'.static.InsertNode(self.HandleName, self.ParentName, infNodeItem);
}

function string InsertExpandButtonNode(string Reserved, int ButtonWidth, int ButtonHeight, string ExpandTexture, string ExpandTextureOver, string CollapseTexture, string CollapseTextureOver)
{
    local XMLTreeNodeInfo infNode;
	local XMLTreeNodeItemInfo infNodeItem;
	local string NodeName;

	infNode.strName = NODE_NAME $ Reserved;
	
	infNode.bShowButton = 1;
	infNode.nTexBtnWidth = ButtonWidth;
	infNode.nTexBtnHeight = ButtonHeight;
	// infNode.nTexBtnOffSetX = 0;
	// infNode.nTexBtnOffSetY = 0;
	infNode.strTexBtnExpand = ExpandTexture;
	infNode.strTexBtnExpand_Over = ExpandTextureOver;
	infNode.strTexBtnCollapse = CollapseTexture;
	infNode.strTexBtnCollapse_Over = CollapseTextureOver;

    NodeName = class'UIAPI_TREECTRL'.static.InsertNode(self.HandleName, self.ParentName, infNode);

	infNodeItem.eType = XTNITEM_TEXTURE;
	infNodeItem.u_nTextureWidth = ButtonWidth;
	infNodeItem.u_nTextureHeight = ButtonHeight;
	// infNodeItem.u_strTexture = ButtonTexture;
	
    infNodeItem.nOffSetX = -ButtonWidth;
    // infNodeItem.nOffSetY = OffSetY;

	class'UIAPI_TREECTRL'.static.InsertNodeItem(self.HandleName, NodeName, infNodeItem );

	return NodeName;
}

function string InsertParentNode(string ParentName, coerce string NodeName, optional bool FollowCursor, optional CustomTooltip TooltipInfo, optional int OffSetX, optional int OffSetY, optional int ShowButton)
{
    local XMLTreeNodeInfo infNodeItem;

	infNodeItem.strName = NodeName;
	infNodeItem.bFollowCursor = FollowCursor;
    infNodeItem.Tooltip = TooltipInfo;
    infNodeItem.nOffSetX = OffSetX;
    infNodeItem.nOffSetY = OffSetY;
	infNodeItem.bShowButton = ShowButton;

	// infNodeItem.nTexExpandedHeight = 38;
	// infNodeItem.nTexExpandedRightWidth = 5;	
	// infNodeItem.nTexExpandedLeftUWidth = 30;
	// infNodeItem.nTexExpandedLeftUHeight = 38;
	// infNodeItem.strTexExpandedLeft = "MUI_AUGM.etc.IconSelect2";

    return class'UIAPI_TREECTRL'.static.InsertNode(self.HandleName, ParentName, infNodeItem);
}

function InsertTexture(string NodeName, string TextureName, string TextureMouseOn, int TextureWidth, int TextureHeight, int TablePoint, string NodePoint, string TexturePoint, optional int offSetX, optional int offSetY, 
optional bool OneLine, optional bool bLineBreak, optional int TextureUWidth, optional int TextureUHeight, optional bool bStopMouseFocus)
{
	local XMLTreeNodeItemInfo infNodeItem;
	local int NodePositionX, NodePositionY;
	local int TexPositionX, TexPositionY;

	GetNodePoint(NodePoint, TablePoint, NodePositionX, NodePositionY);

	GetTexturePoint(TexturePoint, TextureWidth, TextureHeight, TexPositionX, TexPositionY);

    if(TextureName == "")
        TextureName = "MUI_AUGM.null";

	infNodeItem.eType = XTNITEM_TEXTURE;
	infNodeItem.t_bDrawOneLine = OneLine;
	infNodeItem.bLineBreak = bLineBreak;
	infNodeItem.nOffSetX = (NodePositionX - TexPositionX) + offSetX;
	infNodeItem.nOffSetY = (NodePositionY - TexPositionY) + offSetY;
	infNodeItem.u_nTextureWidth = TextureWidth;
	infNodeItem.u_nTextureHeight = TextureHeight;
	infNodeItem.u_nTextureUWidth = TextureUWidth;
	infNodeItem.u_nTextureUHeight = TextureUHeight;
	infNodeItem.u_strTexture = TextureName;
	infNodeItem.bStopMouseFocus = bStopMouseFocus;
    infNodeItem.u_strTextureMouseOn = TextureMouseOn;

    class'UIAPI_TREECTRL'.static.InsertNodeItem(self.HandleName, NodeName, infNodeItem );
}

function InsertSimpleTexture(string NodeName, string TextureName, string TextureMouseOn, int TextureWidth, int TextureHeight, optional int offSetX, optional int offSetY, 
optional bool OneLine, optional bool bLineBreak, optional int TextureUWidth, optional int TextureUHeight, optional bool bStopMouseFocus)
{
	local XMLTreeNodeItemInfo infNodeItem;

	infNodeItem.eType = XTNITEM_TEXTURE;
	infNodeItem.t_bDrawOneLine = OneLine;
	infNodeItem.bLineBreak = bLineBreak;
	infNodeItem.nOffSetX = offSetX;
	infNodeItem.nOffSetY = offSetY;
	infNodeItem.u_nTextureWidth = TextureWidth;
	infNodeItem.u_nTextureHeight = TextureHeight;
	infNodeItem.u_nTextureUWidth = TextureUWidth;
	infNodeItem.u_nTextureUHeight = TextureUHeight;
	infNodeItem.u_strTexture = TextureName;
	infNodeItem.bStopMouseFocus = bStopMouseFocus;
    infNodeItem.u_strTextureMouseOn = TextureMouseOn;

    class'UIAPI_TREECTRL'.static.InsertNodeItem(self.HandleName, NodeName, infNodeItem );
}

function InsertText(string NodeName, coerce string Text, int TablePoint, string NodePoint, string TextPoint, int offSetX, int offSetY, optional Color Color, 
optional bool bDrawOneLine, optional bool bLineBreak)
{
	local XMLTreeNodeItemInfo infNodeItem;
	local int NodePositionX, NodePositionY;
	local int TextPositionX, TextPositionY;
	local int TextWidth, TextHeight;

	GetTextSize(Text, TextWidth, TextHeight);

	GetNodePoint(NodePoint, TablePoint, NodePositionX, NodePositionY);
	GetTexturePoint(TextPoint, TextWidth, TextHeight, TextPositionX, TextPositionY);

	infNodeItem.eType = XTNITEM_TEXT;
	infNodeItem.t_strText = Text;
	infNodeItem.t_bDrawOneLine = bDrawOneLine;
	infNodeItem.bLineBreak = bLineBreak;
	infNodeItem.nOffSetX = (NodePositionX - TextPositionX) + offSetX;
	infNodeItem.nOffSetY = (NodePositionY - TextPositionY) + offSetY;

	infNodeItem.t_color = Color;

	class'UIAPI_TREECTRL'.static.InsertNodeItem(self.HandleName, NodeName, infNodeItem );
}

function InsertSimpleText(string NodeName, coerce string Text, int offSetX, int offSetY, optional Color Color, 
optional bool bDrawOneLine, optional bool bLineBreak)
{
	local XMLTreeNodeItemInfo infNodeItem;

	infNodeItem.eType = XTNITEM_TEXT;
	infNodeItem.t_strText = Text;
	infNodeItem.t_bDrawOneLine = bDrawOneLine;
	infNodeItem.bLineBreak = bLineBreak;
	infNodeItem.nOffSetX = offSetX;
	infNodeItem.nOffSetY = offSetY;

	infNodeItem.t_color = Color;

	class'UIAPI_TREECTRL'.static.InsertNodeItem(self.HandleName, NodeName, infNodeItem );
}

function InsertSimpleButton(string NodeName, optional string ButtonTexture, optional string ButtonTextureOver, optional int customNodeWidth, optional int customNodeHeight, optional int customNodeUWidth, optional int customNodeUHeight)
{
	local XMLTreeNodeItemInfo infNodeItem;
	local int buttonWidth, buttonHeight, buttonUWidth, buttonUHeight;

	// if( ButtonTexture == "" && (NodeCount % 2 == 0) ) {
	// 	ButtonTexture = "MUI_AUGM.etc.GroupBox_df_LineBack";
	// }

	if( customNodeWidth > 0 ) {
		buttonWidth = customNodeWidth;
		buttonUWidth = customNodeUWidth;
	}else {
		buttonWidth = nodeWidth;
		buttonUWidth = 15;
	}

	if( customNodeHeight > 0 ) {
		buttonHeight = customNodeHeight;
		buttonUHeight = customNodeUHeight;
	}else {
		buttonHeight = nodeHeight;
		buttonUHeight = 15;
	}

	infNodeItem.eType = XTNITEM_TEXTURE;
	infNodeItem.u_nTextureWidth = buttonWidth;
	infNodeItem.u_nTextureHeight = buttonHeight;
	infNodeItem.u_nTextureUWidth = buttonUWidth;
	infNodeItem.u_nTextureUHeight = buttonUHeight;
	infNodeItem.u_strTexture = ButtonTexture;

	if( ButtonTextureOver != "" )
    	infNodeItem.u_strTextureMouseOn = ButtonTextureOver;

    class'UIAPI_TREECTRL'.static.InsertNodeItem(self.HandleName, NodeName, infNodeItem );
}

function InsertColoredByIndexButton(string NodeName, int Index, optional string ButtonTextureOver, optional int customNodeWidth, optional int customNodeHeight, optional int customNodeUWidth, optional int customNodeUHeight) {
	local string ButtonTexture;

	if( Index % 2 == 0 ) {
		ButtonTexture = "MUI_AUGM.etc.GroupBox_df_LineBack";
	}else {
		ButtonTexture = "MUI_AUGM.null";
	}

	self.InsertSimpleButton( NodeName, ButtonTexture, ButtonTextureOver, customNodeWidth, customNodeHeight, customNodeUWidth, customNodeUHeight );
}

function GetNodePoint(string NodePoint, int TablePoint, out int NodePositionX, out int NodePositionY)
{
	switch( NodePoint )
	{
		case "TopLeft":
			NodePositionX = TablesPosition[TablePoint];
			NodePositionY = -nodeHeight;
			break;
		case "CenterLeft":
			NodePositionX = TablesPosition[TablePoint];
			NodePositionY = -nodeHeight + (nodeHeight / 2);
			break;
		case "BottomLeft":
			NodePositionX = TablesPosition[TablePoint];
			NodePositionY = 0;
			break;
		case "TopCenter":
			NodePositionX = TablesPosition[TablePoint] + ((TablesPosition[TablePoint + 1] - TablesPosition[TablePoint]) / 2) - 2;
			NodePositionY = -nodeHeight;
			break;
		case "Center":
			NodePositionX = TablesPosition[TablePoint] + ((TablesPosition[TablePoint + 1] - TablesPosition[TablePoint]) / 2) - 2;
			NodePositionY = -nodeHeight + (nodeHeight / 2);
			break;
		case "BottomCenter":
			NodePositionX = TablesPosition[TablePoint] + ((TablesPosition[TablePoint + 1] - TablesPosition[TablePoint]) / 2) - 2;
			NodePositionY = 0;
			break;
		case "TopRight":
			NodePositionX = TablesPosition[TablePoint + 1] - 2;
			NodePositionY = -nodeHeight;
			break;
		case "CenterRight":
			NodePositionX = TablesPosition[TablePoint + 1] - 2;
			NodePositionY = -nodeHeight + (nodeHeight / 2);
			break;
		case "BottomRight":
			NodePositionX = TablesPosition[TablePoint + 1] - 2;
			NodePositionY = 0;
			break;
		default:
			NodePositionX = TablesPosition[TablePoint];
			NodePositionY = -nodeHeight;
			break;
	}
}


function GetTexturePoint(string TexturePoint, int TextureWidth, int TextureHeight, out int TexPositionX, out int TexPositionY)
{
	switch( TexturePoint )
	{
		case "TopLeft":
			TexPositionY = 0;
			TexPositionX = 0;
			break;
		case "CenterLeft":
			TexPositionY = TextureHeight / 2;
			TexPositionX = 0;
			break;
		case "BottomLeft":
			TexPositionY = TextureHeight;
			TexPositionX = 0;
			break;
		case "TopCenter":
			TexPositionY = 0;
			TexPositionX = TextureWidth / 2;
			break;
		case "Center":
			TexPositionY = TextureHeight / 2;
			TexPositionX = TextureWidth / 2;
			break;
		case "BottomCenter":
			TexPositionY = TextureHeight;
			TexPositionX = TextureWidth / 2;
			break;
		case "TopRight":
			TexPositionY = 0;
			TexPositionX = TextureWidth;
			break;
		case "CenterRight":
			TexPositionY = TextureHeight / 2;
			TexPositionX = TextureWidth;
			break;
		case "BottomRight":
			TexPositionY = TextureHeight;
			TexPositionX = TextureWidth;
			break;
		default:
			TexPositionY = 0;
			TexPositionX = 0;
			break;
	}
}

defaultproperties
{
    TablesPosition(0)=0
}
