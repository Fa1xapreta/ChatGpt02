class OMGzExt extends Object
    native;

native static function Init(Object Receiver);