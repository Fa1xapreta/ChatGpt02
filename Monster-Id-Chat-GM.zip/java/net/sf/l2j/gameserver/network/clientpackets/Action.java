/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.network.clientpackets;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.model.L2Object;
import net.sf.l2j.gameserver.model.L2World;
import net.sf.l2j.gameserver.model.actor.L2Npc;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.actor.instance.L2MonsterInstance;
import net.sf.l2j.gameserver.custom.MileniumMonsterData;
import net.sf.l2j.gameserver.network.SystemMessageId;
import net.sf.l2j.gameserver.network.serverpackets.ActionFailed;
import net.sf.l2j.gameserver.network.serverpackets.MyTargetSelected;
import net.sf.l2j.gameserver.network.serverpackets.StatusUpdate;

public final class Action extends L2GameClientPacket
{
	// cddddc
	private int _objectId;
	@SuppressWarnings("unused")
	private int _originX, _originY, _originZ;
	private int _actionId;
	
	@Override
	protected void readImpl()
	{
		_objectId = readD(); // Target object Identifier
		_originX = readD();
		_originY = readD();
		_originZ = readD();
		_actionId = readC(); // Action identifier : 0-Simple click, 1-Shift click
	}
	
	@Override
	protected void runImpl()
	{
		if (Config.DEBUG)
			_log.fine("Action: " + _actionId + ", objectId: " + _objectId);
		
		// Get the current L2PcInstance of the player
		final L2PcInstance activeChar = getClient().getActiveChar();
		if (activeChar == null)
			return;
	     
		if (activeChar.inObserverMode())
		{
			activeChar.sendPacket(SystemMessageId.OBSERVERS_CANNOT_PARTICIPATE);
			activeChar.sendPacket(ActionFailed.STATIC_PACKET);
			return;
		}
		
		// If the player is the requester of a transaction
		if (activeChar.getActiveRequester() != null)
		{
			activeChar.sendPacket(ActionFailed.STATIC_PACKET);
			return;
		}
		
		// If requested object doesn't exist
		final L2Object obj = (activeChar.getTargetId() == _objectId) ? activeChar.getTarget() : L2World.getInstance().findObject(_objectId);
		if (obj == null)
		{
			activeChar.sendPacket(ActionFailed.STATIC_PACKET);
			return;
		}
		
		if (!obj.isTargetable())
		{
			activeChar.sendPacket(ActionFailed.STATIC_PACKET);
			return;
		}
		
		if (obj.getInstanceId() != activeChar.getInstanceId())
		{
			activeChar.sendPacket(ActionFailed.STATIC_PACKET);
			return;
		}
				
		if (!activeChar.isGM() && activeChar.isOutOfControl())
		{
			activeChar.sendPacket(ActionFailed.STATIC_PACKET);
			return;
		}
		
		// Only GMs can directly interact with invisible characters
		if (obj instanceof L2PcInstance)
		{
			L2PcInstance player = (L2PcInstance)obj;
			if (player.getAppearance().getInvisible() && !activeChar.isGM() || player.isInArenaEvent() && !activeChar.isInArenaEvent() || !player.isInArenaEvent() && activeChar.isInArenaEvent())
			{
				getClient().sendPacket(ActionFailed.STATIC_PACKET);
				return;
			}
		}
	
		switch (_actionId)
		{
			case 0:
				obj.onAction(activeChar);
				break;
			
			case 1:
				if (activeChar.isGM() && obj instanceof L2Npc)
				{
					final L2Npc npc = (L2Npc) obj;
					activeChar.sendChatMessage(0, Say2.PARTY, "", "Monster Id: " + npc.getNpcId());
				}

                // Replace monster inspection only, after the original action validations.
                if (obj instanceof L2MonsterInstance && (activeChar.isGM() || Config.ENABLE_SHIFT_CLICK_TO_NPCS))
                {
                    final L2MonsterInstance monster = (L2MonsterInstance) obj;
                    if (activeChar.getTarget() != monster)
                    {
                        activeChar.setTarget(monster);
                        activeChar.sendPacket(new MyTargetSelected(monster.getObjectId(), activeChar.getLevel() - monster.getLevel()));
                        if (monster.isAutoAttackable(activeChar))
                        {
                            final StatusUpdate status = new StatusUpdate(monster);
                            status.addAttribute(StatusUpdate.CUR_HP, (int) monster.getCurrentHp());
                            status.addAttribute(StatusUpdate.MAX_HP, monster.getMaxHp());
                            activeChar.sendPacket(status);
                        }
                    }
                    MileniumMonsterData.open(activeChar);
                    activeChar.sendPacket(ActionFailed.STATIC_PACKET);
                    break;
                }
				obj.onActionShift(activeChar);
				break;
			
			default:
				// Invalid action detected (probably client cheating), log this
				_log.warning(activeChar.getName() + " requested invalid action: " + _actionId);
				activeChar.sendPacket(ActionFailed.STATIC_PACKET);
				break;
		}
	}
	
	@Override
	protected boolean triggersOnActionRequest()
	{
		return false;
	}
}