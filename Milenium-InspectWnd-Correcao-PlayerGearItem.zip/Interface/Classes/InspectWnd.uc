class InspectWnd extends MileniumGearScore;

var WindowHandle zz_Me;

var TextBoxHandle zz_Nickname;
var TextBoxHandle zz_ClassName;
var TextBoxHandle zz_GearScore;

var TextureHandle zz_ClassTex;

var ItemWindowHandle zz_InspectItens[15];

var string zz_PlayerNickname;
var int zz_PlayerClassID;
var int zz_PlayerGearScore;
var array<PlayerGearItem> zz_InspectItensList;

function OnLoad() {
    local int i;

    zz_Me = xxGetWindowHandle("InspectWnd");

    zz_Nickname = xxGetTextBoxHandle("InspectWnd.player_name");
    zz_ClassName = xxGetTextBoxHandle("InspectWnd.player_class_name");
    zz_GearScore = xxGetTextBoxHandle("InspectWnd.player_gear_score");

    zz_ClassTex = xxGetTextureHandle("InspectWnd.player_class_tex");

    for( i = 0; i < 15; i++ )
    {
        zz_InspectItens[i] = xxGetItemWindowHandle("InspectWnd.inspect_itens.item_" $ i);
        zz_InspectItens[i].SetDisableTex( "L2UI.InventoryWnd.Icon_dualcap" );
    }
}
function OnClickButton(string strButton) {
    switch( strButton ) {
        case "btnClose":
            zz_Me.HideWindow();
            break;
    }
}


function OnPlayerGearItensListAdd(string PlayerName, int PlayerClassID, int PlayerGearScore, array<PlayerGearItem> ItensList) {
    zz_PlayerNickname = PlayerName;
    zz_PlayerClassID = PlayerClassID;
    zz_PlayerGearScore = PlayerGearScore;
    zz_InspectItensList = ItensList;

    GoToState('UpdateInspectItens');
}

function xxClearAllBox()
{
    local int i;

    for( i = 0; i < 15; i++ ) {
        zz_InspectItens[i].Clear();
        zz_InspectItens[i].DisableWindow();
    }
}


function xxSetInspectItens() {
    local int i;
    local ItemInfo info;

    xxClearAllBox();

    zz_Nickname.SetText(zz_PlayerNickname);
    zz_ClassName.SetText(GetClassType(zz_PlayerClassID));
    zz_GearScore.SetInt(zz_PlayerGearScore);
    zz_ClassTex.SetTexture(xxGetDetailedClassIconName(zz_PlayerClassID, 2 ));

    for( i = 0; i < zz_InspectItensList.Length; i++ ) {
        if(zz_InspectItensList[i].ItemID <= 0)
            continue;

        if(zz_InspectItensList[i].SlotBitType != -1) {
            if(!xxGetItemInfo(  zz_InspectItensList[i].ItemID, info  ))
                continue;

            info.ServerID = zz_InspectItensList[i].ServerID;
            info.Enchanted = zz_InspectItensList[i].Enchant;
            info.SlotBitType = zz_InspectItensList[i].SlotBitType;

            if( zz_InspectItensList[i].RefineryOp1 > 0)
                info.RefineryOp1 = zz_InspectItensList[i].RefineryOp1;

            if( zz_InspectItensList[i].RefineryOp2 > 0)
                info.RefineryOp2 = zz_InspectItensList[i].RefineryOp2;

            if ((info.Enchanted <=50) && (info.Enchanted >0)) 
		        info.ForeTexture = "MUI_GEAR.ItemEnchant.enchant" $ String(info.Enchanted);
        }else {
            continue;
        }

        info.Blessed = zz_InspectItensList[i].GearScore;

        xxAddItemBySlot(info);
    }

    zz_Me.ShowWindow();
}

state UpdateInspectItens {
	function OnTick() {
        xxSetInspectItens();

        zz_Me.ShowWindow();

        GoToState('');
	}
}

function xxAddItemBySlot(ItemInfo zz_Info) {
	local ItemWindowHandle zz_ItemHande, zz_ItemHandeEx;
    local ItemInfo zz_InfoEx;
    local int i;

    switch( zz_Info.SlotBitType )
	{
        case 0:		// HENNA
            for(i = 15; i <= 17; i++) {
                if(zz_InspectItens[i].GetItemNum() <= 0) {
                    zz_ItemHande = zz_InspectItens[i]; // 15 a 17
                    break;
                }
            }
            break;
        case 1:		// SBT_UNDERWEAR
            zz_ItemHande = zz_InspectItens[11];
            break;
        case 2:		// SBT_REAR
        case 4:		// SBT_LEAR
        case 6:		// SBT_RLEAR
            for(i = 9; i <= 10; i++) {
                if(zz_InspectItens[i].GetItemNum() <= 0) {
                    zz_ItemHande = zz_InspectItens[i]; // 9 e 10
                    break;
                }
            }
            break;
        case 8:		// SBT_NECK
            zz_ItemHande = zz_InspectItens[14];
            break;
        case 16:	// SBT_RFINGER
        case 32:	// SBT_LFINGER
        case 48:	// SBT_RLFINGER
            for(i = 12; i <= 13; i++) {
                if(zz_InspectItens[i].GetItemNum() <= 0) {
                    zz_ItemHande = zz_InspectItens[i]; // 12 e 13
                    break;
                }
            }
            break;
        case 64:	// SBT_HEAD
            zz_ItemHande = zz_InspectItens[1];
            break;
        case 128:	// SBT_RHAND
            zz_ItemHande = zz_InspectItens[6];
            break;
        case 256:	// SBT_LHAND
            zz_ItemHande = zz_InspectItens[8];
            break;
        case 512:	// SBT_GLOVES
            zz_ItemHande = zz_InspectItens[3];
            break;
        case 1024:	// SBT_CHEST
            zz_ItemHande = zz_InspectItens[4];
            break;
        case 2048:	// SBT_LEGS
            zz_ItemHande = zz_InspectItens[7];
            break;
        case 4096:	// SBT_FEET
            zz_ItemHande = zz_InspectItens[5];
            break;
        case 8192:	// SBT_BACK
            zz_ItemHande = zz_InspectItens[11];
            break;
        case 16384:	// SBT_RLHAND
            zz_ItemHande = zz_InspectItens[6];
            zz_ItemHandeEx = zz_InspectItens[8];

            zz_InfoEx = zz_Info;
            break;
        case 32768:	// SBT_ONEPIECE
            zz_ItemHande = zz_InspectItens[4];
            zz_ItemHandeEx = zz_InspectItens[7];

            zz_InfoEx = zz_Info;
            break;
        case 65536:	// SBT_HAIR
            zz_ItemHande = zz_InspectItens[0];
            break;
        case 131072:	// SBT_ALLDRESS
            zz_ItemHande = zz_InspectItens[4];
            break;
        case 262144:	// SBT_HAIR2
            zz_ItemHande = zz_InspectItens[2];
            break;
        case 524288:	// SBT_HAIRALL
            zz_ItemHande = zz_InspectItens[0];
            break;
	}

    if(zz_ItemHande != none) {
        zz_ItemHande.AddItem(zz_Info);
        zz_ItemHande.EnableWindow();
    }

        

    if(zz_ItemHandeEx != none)
        zz_ItemHandeEx.AddItem(zz_InfoEx);
}
