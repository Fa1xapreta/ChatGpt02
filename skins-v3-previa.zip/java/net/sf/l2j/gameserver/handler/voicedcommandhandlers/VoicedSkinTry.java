/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.handler.voicedcommandhandlers;

import net.sf.l2j.gameserver.datatables.custom.SkinTable;
import net.sf.l2j.gameserver.handler.IVoicedCommandHandler;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;

public class VoicedSkinTry implements IVoicedCommandHandler
{
	private static final String[] COMMANDS = { "skintry", "skinpreview" };

	@Override
	public boolean useVoicedCommand(String command, L2PcInstance player, String target)
	{
		final String[] arguments = command.split(" +");
		if (arguments[0].equals("skintry"))
		{
			showSkinMenu(player, 3);
			return true;
		}

		if (arguments.length > 3)
			return false;

		try
		{
			final int page = arguments.length > 1 ? Integer.parseInt(arguments[1]) : 0;
			if (page < 0 || page > 17)
				return false;

			if (arguments.length == 3 && page != 0)
			{
				if (player.isAlikeDead() || player.isInOlympiadMode())
				{
					player.sendMessage("Skin preview is unavailable while dead or in Olympiad.");
					return true;
				}

				final int itemId = Integer.parseInt(arguments[2]);
				final boolean weapon = page == 1 || page == 2 || page == 4;
				final SkinTable skins = SkinTable.getInstance();
				if (weapon)
				{
					if (skins.isModelWeaponVisual(itemId))
					{
						player.previewSkin(itemId, true);
						player.sendMessage("Weapon skin preview active for 5 seconds.");
					}
					else if (skins.isPendingModelWeaponVisual(itemId))
						player.sendMessage("This skin is waiting for its client WeaponGrp entry.");
				}
				else if (skins.isModelArmorItem(itemId))
				{
					if (skins.getSkinId(itemId))
					{
						player.previewSkin(itemId, false);
						player.sendMessage("Armor skin preview active for 5 seconds.");
					}
					else
						player.sendMessage("This skin is waiting for its client visuals.");
				}
			}

			showSkinMenu(player, page);
			return true;
		}
		catch (NumberFormatException e)
		{
			return false;
		}
	}

	public static void showSkinMenu(L2PcInstance player, int page)
	{
		if (page < 0 || page > 17)
			return;

		final NpcHtmlMessage html = new NpcHtmlMessage(0);
		html.setFile("data/html/mods/skinpreview/193" + (page == 0 ? "" : "-" + page) + ".htm");
		player.sendPacket(html);
	}

	@Override
	public String[] getVoicedCommandList()
	{
		return COMMANDS;
	}
}
