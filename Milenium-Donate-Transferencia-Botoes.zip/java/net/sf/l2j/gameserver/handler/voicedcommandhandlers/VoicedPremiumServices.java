package net.sf.l2j.gameserver.handler.voicedcommandhandlers;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.datatables.SkillTable;
import net.sf.l2j.gameserver.datatables.SkillTreeTable;
import net.sf.l2j.gameserver.handler.IVoicedCommandHandler;
import net.sf.l2j.gameserver.model.L2Augmentation;
import net.sf.l2j.gameserver.model.L2EnchantSkillLearn;
import net.sf.l2j.gameserver.model.L2ShortCut;
import net.sf.l2j.gameserver.model.L2Skill;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.base.ClassId;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.model.item.kind.Item;
import net.sf.l2j.gameserver.network.serverpackets.InventoryUpdate;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;
import net.sf.l2j.gameserver.network.serverpackets.ShortCutRegister;
import net.sf.l2j.gameserver.network.serverpackets.UserInfo;

public class VoicedPremiumServices implements IVoicedCommandHandler
{
	private static final int SERVICE_ITEMS_PER_PAGE = 10;

	private static final String[] VOICED_COMMANDS =
	{
		"services", "transfer"
	};

	@Override
	public boolean useVoicedCommand(String command, L2PcInstance activeChar, String target)
	{
		if (activeChar == null)
			return false;

		if (!Config.PREMIUM_SERVICES_ENABLED)
		{
			activeChar.sendMessage("Services are disabled.");
			return true;
		}

		StringTokenizer st = new StringTokenizer(command, " ");
		st.nextToken();

		if (!st.hasMoreTokens())
		{
			showMain(activeChar);
			return true;
		}

		String action = st.nextToken();
		if (action.equals("enchant_1"))
			action = "enchsrc";
		else if (action.equals("augment_1"))
			action = "augsrc";
		if (action.equalsIgnoreCase("subdominator"))
			buySubDominator(activeChar);
		else if (action.equalsIgnoreCase("augsrc"))
			showAugSources(activeChar, st.hasMoreTokens() ? parseInt(st.nextToken(), 1) : 1);
		else if (action.equalsIgnoreCase("augdst") && st.hasMoreTokens())
		{
			int sourceObjId = parseInt(st.nextToken(), 0);
			showAugTargets(activeChar, sourceObjId, st.hasMoreTokens() ? parseInt(st.nextToken(), 1) : 1);
		}
		else if (action.equalsIgnoreCase("augmove") && st.countTokens() >= 2)
			transferAugment(activeChar, parseInt(st.nextToken(), 0), parseInt(st.nextToken(), 0));
		else if (action.equalsIgnoreCase("enchsrc"))
			showEnchantSources(activeChar, st.hasMoreTokens() ? parseInt(st.nextToken(), 1) : 1);
		else if (action.equalsIgnoreCase("enchdst") && st.hasMoreTokens())
		{
			int sourceObjId = parseInt(st.nextToken(), 0);
			showEnchantTargets(activeChar, sourceObjId, st.hasMoreTokens() ? parseInt(st.nextToken(), 1) : 1);
		}
		else if (action.equalsIgnoreCase("enchmove") && st.countTokens() >= 2)
			transferEnchant(activeChar, parseInt(st.nextToken(), 0), parseInt(st.nextToken(), 0));
		else if ((action.equals("enchconfirm") || action.equals("augconfirm")) && st.countTokens() >= 2)
			showTransferConfirm(activeChar, action.equals("enchconfirm"), parseInt(st.nextToken(), 0), parseInt(st.nextToken(), 0));
		else if (action.equalsIgnoreCase("skills"))
			showSkills(activeChar);
		else if (action.equalsIgnoreCase("skill") && st.hasMoreTokens())
			enchantSkill(activeChar, parseInt(st.nextToken(), 0));
		else
			showMain(activeChar);

		return true;
	}

	private static void showMain(L2PcInstance player)
	{
		NpcHtmlMessage msg = new NpcHtmlMessage(0);
		msg.setFile("data/html/mods/services/Services.htm");
		msg.replace("%sub_price%", priceText(Config.PREMIUM_SUB_DOMINATOR_ITEM_ID, Config.PREMIUM_SUB_DOMINATOR_ITEM_COUNT));
		msg.replace("%aug_price%", priceText(Config.PREMIUM_AUGMENT_TRANSFER_ITEM_ID, Config.PREMIUM_AUGMENT_TRANSFER_ITEM_COUNT));
		msg.replace("%enchant_price%", priceText(Config.PREMIUM_ENCHANT_TRANSFER_ITEM_ID, Config.PREMIUM_ENCHANT_TRANSFER_ITEM_COUNT));
		msg.replace("%skill_price%", priceText(Config.PREMIUM_SKILL_ENCHANT_ITEM_ID, Config.PREMIUM_SKILL_ENCHANT_ITEM_COUNT));
		msg.replace("%skill_price_mode%", Config.PREMIUM_SKILL_ENCHANT_PRICE_PER_LEVEL ? "per enchant" : "once");
		player.sendPacket(msg);
	}

	private static void buySubDominator(L2PcInstance player)
	{
		if (!Config.PREMIUM_SUB_DOMINATOR_ENABLED)
		{
			player.sendMessage("Dominator subclass service is disabled.");
			return;
		}

		if (!canUseServices(player))
			return;

		int classId = Config.PREMIUM_SUB_DOMINATOR_CLASS_ID;
		if (classId <= 0 || classId >= ClassId.values().length)
		{
			player.sendMessage("Invalid Dominator class id in config.");
			return;
		}

		if (player.getBaseClass() == classId || hasSubClass(player, classId))
		{
			player.sendMessage("You already have this class.");
			return;
		}

		int classIndex = getFreeSubClassIndex(player);
		if (classIndex == 0)
		{
			player.sendMessage("You do not have a free subclass slot.");
			return;
		}

		if (!takePrice(player, Config.PREMIUM_SUB_DOMINATOR_ITEM_ID, Config.PREMIUM_SUB_DOMINATOR_ITEM_COUNT, "SubDominator"))
			return;

		if (!player.addSubClass(classId, classIndex))
		{
			player.sendMessage("Could not add subclass. Contact an admin.");
			return;
		}

		player.sendMessage("Dominator subclass added successfully.");
		showMain(player);
	}

	private static void showAugSources(L2PcInstance player, int page)
	{
		List<ItemInstance> items = new ArrayList<>();
		for (ItemInstance item : player.getInventory().getItems())
		{
			if (isWeapon(item) && item.isAugmented())
				items.add(item);
		}

		StringBuilder sb = new StringBuilder();
		appendServicePage(sb, items, page, "bypass -h voiced_services augdst %obj%", "bypass -h voiced_services augsrc %page%");
		if (items.isEmpty())
			sb.append("No augmented weapon found.<br>");
		sendTransferList(player, "Escolha a arma de ORIGEM:", sb.toString(), "bypass -h voiced_donate");
	}

	private static void showAugTargets(L2PcInstance player, int sourceObjId, int page)
	{
		ItemInstance source = player.getInventory().getItemByObjectId(sourceObjId);
		if (!isWeapon(source) || !source.isAugmented())
		{
			player.sendMessage("Invalid source weapon.");
			showAugSources(player, 1);
			return;
		}

		List<ItemInstance> items = new ArrayList<>();
		for (ItemInstance item : player.getInventory().getItems())
		{
			if (isWeapon(item) && !item.isAugmented() && item.getObjectId() != sourceObjId)
				items.add(item);
		}

		StringBuilder sb = new StringBuilder();
		appendServicePage(sb, items, page, "bypass -h voiced_services augconfirm " + sourceObjId + " %obj%", "bypass -h voiced_services augdst " + sourceObjId + " %page%");
		if (items.isEmpty())
			sb.append("No target weapon without augment found.<br>");
		sendTransferList(player, "Escolha o DESTINO:", sb.toString(), "bypass -h voiced_services augsrc");
	}

	private static void appendServicePage(StringBuilder sb, List<ItemInstance> items, int page, String itemBypass, String pageBypass)
	{
		int totalPages = Math.max(1, (items.size() + SERVICE_ITEMS_PER_PAGE - 1) / SERVICE_ITEMS_PER_PAGE);
		page = Math.max(1, Math.min(page, totalPages));

		int start = (page - 1) * SERVICE_ITEMS_PER_PAGE;
		int end = Math.min(start + SERVICE_ITEMS_PER_PAGE, items.size());
		sb.append("<table width=270>");
		for (int i = start; i < end; i++)
		{
			ItemInstance item = items.get(i);
			String icon = item.getItem().getIcon();
			if (icon == null || icon.isEmpty())
				icon = "icon.NOIMAGE";
			sb.append("<tr><td width=35><img src=\"").append(escape(icon))
				.append("\" width=32 height=32></td><td width=235>")
				.append(transferButton(item.getItemName() + " (+" + item.getEnchantLevel() + ")",
					itemBypass.replace("%obj%", String.valueOf(item.getObjectId())), false))
				.append("</td></tr>");
		}

		sb.append("</table>");

		if (items.size() > SERVICE_ITEMS_PER_PAGE)
		{
			sb.append("Page ").append(page).append("/").append(totalPages).append("<br>");
			if (page > 1)
				sb.append(link("Previous", pageBypass.replace("%page%", String.valueOf(page - 1))));
			if (page < totalPages)
				sb.append(link("Next", pageBypass.replace("%page%", String.valueOf(page + 1))));
		}
	}
	private static void transferAugment(L2PcInstance player, int sourceObjId, int targetObjId)
	{
		if (!Config.PREMIUM_AUGMENT_TRANSFER_ENABLED)
		{
			player.sendMessage("Augment transfer service is disabled.");
			return;
		}

		if (!canUseServices(player))
			return;

		ItemInstance source = player.getInventory().getItemByObjectId(sourceObjId);
		ItemInstance target = player.getInventory().getItemByObjectId(targetObjId);
		if (!isWeapon(source) || !isWeapon(target) || !source.isAugmented() || target.isAugmented() || source == target)
		{
			player.sendMessage("Invalid weapons selected.");
			return;
		}
		if (source.isEquipped() || target.isEquipped())
		{
			player.sendMessage("Unequip both weapons first.");
			return;
		}

		if (!takePrice(player, Config.PREMIUM_AUGMENT_TRANSFER_ITEM_ID, Config.PREMIUM_AUGMENT_TRANSFER_ITEM_COUNT, "AugmentTransfer"))
			return;

		L2Augmentation aug = new L2Augmentation(source.getAugmentation().getAugmentationId(), source.getAugmentation().getSkill());
		source.removeAugmentation();
		target.setAugmentation(aug);
		source.updateDatabase();
		target.updateDatabase();

		InventoryUpdate iu = new InventoryUpdate();
		iu.addModifiedItem(source);
		iu.addModifiedItem(target);
		player.sendPacket(iu);
		player.sendPacket(new UserInfo(player));
		player.sendMessage("Augment transferred successfully.");
		showMain(player);
	}

	private static void showEnchantSources(L2PcInstance player, int page)
	{
		List<ItemInstance> items = new ArrayList<>();
		for (ItemInstance item : player.getInventory().getItems())
		{
			if (isEnchantTransferItem(item) && item.getEnchantLevel() > 0)
				items.add(item);
		}

		StringBuilder sb = new StringBuilder();
		appendServicePage(sb, items, page, "bypass -h voiced_services enchdst %obj%", "bypass -h voiced_services enchsrc %page%");
		if (items.isEmpty())
			sb.append("No enchanted item found.<br>");
		sendTransferList(player, "Escolha o item de ORIGEM:", sb.toString(), "bypass -h voiced_donate");
	}

	private static void showEnchantTargets(L2PcInstance player, int sourceObjId, int page)
	{
		ItemInstance source = player.getInventory().getItemByObjectId(sourceObjId);
		if (!isEnchantTransferItem(source) || source.getEnchantLevel() <= 0)
		{
			player.sendMessage("Invalid source item.");
			showEnchantSources(player, 1);
			return;
		}

		List<ItemInstance> items = new ArrayList<>();
		for (ItemInstance item : player.getInventory().getItems())
		{
			if (isValidEnchantTarget(source, item))
				items.add(item);
		}

		StringBuilder sb = new StringBuilder();
		appendServicePage(sb, items, page, "bypass -h voiced_services enchconfirm " + sourceObjId + " %obj%", "bypass -h voiced_services enchdst " + sourceObjId + " %page%");
		if (items.isEmpty())
			sb.append("No valid target item found.<br>");
		sendTransferList(player, "Escolha o DESTINO:", sb.toString(), "bypass -h voiced_services enchsrc");
	}

	private static void transferEnchant(L2PcInstance player, int sourceObjId, int targetObjId)
	{
		if (!Config.PREMIUM_ENCHANT_TRANSFER_ENABLED)
		{
			player.sendMessage("Enchant transfer service is disabled.");
			return;
		}

		if (!canUseServices(player))
			return;

		ItemInstance source = player.getInventory().getItemByObjectId(sourceObjId);
		ItemInstance target = player.getInventory().getItemByObjectId(targetObjId);
		if (!isEnchantTransferItem(source) || !isValidEnchantTarget(source, target))
		{
			player.sendMessage("Invalid items selected.");
			return;
		}
		if (source.isEquipped() || target.isEquipped())
		{
			player.sendMessage("Unequip both items first.");
			return;
		}

		if (!takePrice(player, Config.PREMIUM_ENCHANT_TRANSFER_ITEM_ID, Config.PREMIUM_ENCHANT_TRANSFER_ITEM_COUNT, "EnchantTransfer"))
			return;

		int enchant = source.getEnchantLevel();
		source.setEnchantLevel(0);
		target.setEnchantLevel(enchant);
		source.updateDatabase();
		target.updateDatabase();

		InventoryUpdate iu = new InventoryUpdate();
		iu.addModifiedItem(source);
		iu.addModifiedItem(target);
		player.sendPacket(iu);
		player.sendPacket(new UserInfo(player));
		player.sendMessage("Enchant transferred successfully.");
		showMain(player);
	}
	private static void showSkills(L2PcInstance player)
	{
		StringBuilder sb = new StringBuilder();

		Set<Integer> listed = new HashSet<>();
		int count = 0;
		for (L2EnchantSkillLearn esl : SkillTreeTable.getInstance().getAvailableEnchantSkills(player))
		{
			if (esl == null || !listed.add(esl.getId()))
				continue;

			L2Skill skill = SkillTable.getInstance().getInfo(esl.getId(), esl.getLevel());
			if (skill == null || getEnchantPower(esl.getLevel()) > Config.PREMIUM_SKILL_ENCHANT_MAX)
				continue;

			sb.append(link(skill.getName() + " +" + getEnchantPower(esl.getLevel()), "bypass -h voiced_services skill " + esl.getId()));
			count++;
		}

		if (count == 0)
			sb.append("No skill available up to +" + Config.PREMIUM_SKILL_ENCHANT_MAX + ".<br>");
		sendServicePage(player, "SKILL ENCHANT", "Choose skill up to +" + Config.PREMIUM_SKILL_ENCHANT_MAX, priceText(Config.PREMIUM_SKILL_ENCHANT_ITEM_ID, Config.PREMIUM_SKILL_ENCHANT_ITEM_COUNT) + " " + (Config.PREMIUM_SKILL_ENCHANT_PRICE_PER_LEVEL ? "per enchant" : "once"), sb.toString(), "bypass -h voiced_services");
	}

	private static void enchantSkill(L2PcInstance player, int skillId)
	{
		if (!Config.PREMIUM_SKILL_ENCHANT_ENABLED)
		{
			player.sendMessage("Skill enchant service is disabled.");
			return;
		}

		if (!canUseServices(player))
			return;

		if (player.getClassId().level() < 3 || player.getLevel() < Config.PREMIUM_SKILL_ENCHANT_MIN_LEVEL)
		{
			player.sendMessage("You do not meet the level/class requirements.");
			return;
		}

		int currentPower = getEnchantPower(player.getSkillLevel(skillId));
		if (currentPower >= Config.PREMIUM_SKILL_ENCHANT_MAX)
		{
			player.sendMessage("This skill is already at the configured limit.");
			return;
		}

		if (!Config.PREMIUM_SKILL_ENCHANT_PRICE_PER_LEVEL && !takePrice(player, Config.PREMIUM_SKILL_ENCHANT_ITEM_ID, Config.PREMIUM_SKILL_ENCHANT_ITEM_COUNT, "SkillEnchantService"))
			return;

		int applied = 0;
		while (getEnchantPower(player.getSkillLevel(skillId)) < Config.PREMIUM_SKILL_ENCHANT_MAX)
		{
			L2EnchantSkillLearn next = getNextEnchant(player, skillId);
			if (next == null || getEnchantPower(next.getLevel()) > Config.PREMIUM_SKILL_ENCHANT_MAX)
				break;

			L2Skill skill = SkillTable.getInstance().getInfo(next.getId(), next.getLevel());
			if (skill == null)
				break;

			if (Config.PREMIUM_SKILL_ENCHANT_PRICE_PER_LEVEL && !takePrice(player, Config.PREMIUM_SKILL_ENCHANT_ITEM_ID, Config.PREMIUM_SKILL_ENCHANT_ITEM_COUNT, "SkillEnchantService"))
				break;

			player.addSkill(skill, true);
			updateShortcut(player, skill);
			applied++;
		}

		if (applied == 0)
		{
			player.sendMessage("This skill cannot be enchanted by this service now.");
			return;
		}

		player.sendSkillList();
		player.sendPacket(new UserInfo(player));
		player.sendMessage("Skill enchanted successfully up to +" + getEnchantPower(player.getSkillLevel(skillId)) + ".");
		showSkills(player);
	}

	private static L2EnchantSkillLearn getNextEnchant(L2PcInstance player, int skillId)
	{
		for (L2EnchantSkillLearn esl : SkillTreeTable.getInstance().getAvailableEnchantSkills(player))
		{
			if (esl != null && esl.getId() == skillId)
				return esl;
		}
		return null;
	}

	private static void updateShortcut(L2PcInstance player, L2Skill skill)
	{
		for (L2ShortCut sc : player.getAllShortCuts())
		{
			if (sc.getId() == skill.getId() && sc.getType() == L2ShortCut.TYPE_SKILL)
			{
				L2ShortCut newsc = new L2ShortCut(sc.getSlot(), sc.getPage(), L2ShortCut.TYPE_SKILL, skill.getId(), skill.getLevel(), 1);
				player.sendPacket(new ShortCutRegister(newsc));
				player.registerShortCut(newsc);
			}
		}
	}

	private static int getEnchantPower(int level)
	{
		return level > 100 ? level % 100 : 0;
	}

	private static int getFreeSubClassIndex(L2PcInstance player)
	{
		for (int i = 1; i <= Config.PREMIUM_SUB_DOMINATOR_MAX_SUBS; i++)
		{
			if (!player.getSubClasses().containsKey(i))
				return i;
		}
		return 0;
	}

	private static boolean hasSubClass(L2PcInstance player, int classId)
	{
		for (net.sf.l2j.gameserver.model.base.SubClass subClass : player.getSubClasses().values())
		{
			if (subClass.getClassId() == classId)
				return true;
		}
		return false;
	}

	private static boolean isWeapon(ItemInstance item)
	{
		return item != null && item.getItem() != null && item.getItem().getType2() == Item.TYPE2_WEAPON;
	}

	private static boolean isEnchantTransferItem(ItemInstance item)
	{
		if (item == null || item.getItem() == null || !item.isEquipable())
			return false;

		int type2 = item.getItem().getType2();
		if (type2 == Item.TYPE2_WEAPON)
			return Config.PREMIUM_ENCHANT_TRANSFER_ALLOW_WEAPONS;
		if (type2 == Item.TYPE2_SHIELD_ARMOR)
			return Config.PREMIUM_ENCHANT_TRANSFER_ALLOW_ARMORS;
		if (type2 == Item.TYPE2_ACCESSORY)
			return Config.PREMIUM_ENCHANT_TRANSFER_ALLOW_JEWELS;

		return false;
	}

	private static boolean isValidEnchantTarget(ItemInstance source, ItemInstance target)
	{
		if (!isEnchantTransferItem(source) || !isEnchantTransferItem(target) || source == target || source.getEnchantLevel() <= 0)
			return false;
		if (Config.PREMIUM_ENCHANT_TRANSFER_TARGET_MUST_BE_ZERO && target.getEnchantLevel() > 0)
			return false;
		if (Config.PREMIUM_ENCHANT_TRANSFER_REQUIRE_SAME_TYPE && source.getItem().getType2() != target.getItem().getType2())
			return false;
		if (Config.PREMIUM_ENCHANT_TRANSFER_REQUIRE_SAME_SLOT && source.getItem().getBodyPart() != target.getItem().getBodyPart())
			return false;

		return true;
	}
	private static boolean canUseServices(L2PcInstance player)
	{
		if (player.isDead() || player.isAlikeDead() || player.isParalyzed() || player.isInStoreMode() || player.isProcessingTransaction())
		{
			player.sendMessage("You cannot use this service now.");
			return false;
		}
		return true;
	}

	private static boolean takePrice(L2PcInstance player, int itemId, int count, String process)
	{
		if (itemId <= 0 || count <= 0)
			return true;

		if (!player.destroyItemByItemId(process, itemId, count, null, true))
		{
			player.sendMessage("You do not have the required payment item.");
			return false;
		}
		return true;
	}

	private static String priceText(int itemId, int count)
	{
		if (itemId <= 0 || count <= 0)
			return "Free";
		Item item = ItemTable.getInstance().getTemplate(itemId);
		return count + " " + (item != null ? item.getName() : "item " + itemId);
	}

	private static String link(String text, String bypass)
	{
		return "<a action=\"" + bypass + "\"><font color=\"80BFFF\">" + escape(text) + "</font></a><br>";
	}

	private static String escape(String text)
	{
		return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
	}

	private static void sendServicePage(L2PcInstance player, String title, String subtitle, String price, String content, String backAction)
	{
		NpcHtmlMessage msg = new NpcHtmlMessage(0);
		msg.setFile("data/html/mods/services/List.htm");
		msg.replace("%title%", title);
		msg.replace("%subtitle%", subtitle);
		msg.replace("%price%", price);
		msg.replace("%content%", content);
		msg.replace("%back_action%", backAction);
		player.sendPacket(msg);
	}

	private static String transferButton(String text, String action, boolean backButton)
	{
		String style = backButton
			? "width=90 height=18 back=\"custom_textures.button90x18\" fore=\"custom_textures.button90x18\""
			: "width=184 height=35 back=\"L2DeathBtns.Expedition.btn_Trade_over\" fore=\"L2DeathBtns.Expedition.btn_Trade\"";
		return "<button value=\"" + escape(text) + "\" action=\"" + action + "\" " + style + ">";
	}

	private static void sendTransferList(L2PcInstance player, String heading, String items, String back)
	{
		NpcHtmlMessage msg = new NpcHtmlMessage(0);
		msg.setFile("data/html/transfer/list.htm");
		msg.replace("%heading%", heading);
		msg.replace("%list%", items.replace("\\", "&#92;"));
		msg.replace("%back%", transferButton("Voltar", back, true));
		player.sendPacket(msg);
	}

	private static void showTransferConfirm(L2PcInstance player, boolean enchant, int sourceId, int targetId)
	{
		ItemInstance source = player.getInventory().getItemByObjectId(sourceId);
		ItemInstance target = player.getInventory().getItemByObjectId(targetId);
		boolean valid = enchant ? isValidEnchantTarget(source, target)
			: isWeapon(source) && isWeapon(target) && source != target && source.isAugmented() && !target.isAugmented();
		if (!valid)
		{
			player.sendMessage("Invalid items selected.");
			return;
		}
		if (source.isEquipped() || target.isEquipped())
		{
			player.sendMessage("Unequip both items first.");
			return;
		}

		int itemId = enchant ? Config.PREMIUM_ENCHANT_TRANSFER_ITEM_ID : Config.PREMIUM_AUGMENT_TRANSFER_ITEM_ID;
		int count = enchant ? Config.PREMIUM_ENCHANT_TRANSFER_ITEM_COUNT : Config.PREMIUM_AUGMENT_TRANSFER_ITEM_COUNT;
		String action = enchant ? "ench" : "aug";
		NpcHtmlMessage msg = new NpcHtmlMessage(0);
		msg.setFile("data/html/transfer/confirm.htm");
		msg.replace("%type%", enchant ? "ENCHANT" : "AUGMENT");
		msg.replace("%source%", escape(source.getItemName()).replace("\\", "&#92;"));
		msg.replace("%target%", escape(target.getItemName()).replace("\\", "&#92;"));
		msg.replace("%cost%", escape(priceText(itemId, count)).replace("\\", "&#92;"));
		msg.replace("%confirm%", transferButton("Concluir", "bypass -h voiced_services " + action + "move " + sourceId + " " + targetId, false));
		msg.replace("%back%", transferButton("Voltar", "bypass -h voiced_services " + action + "dst " + sourceId, true));
		player.sendPacket(msg);
	}

	private static int parseInt(String value, int defaultValue)
	{
		try
		{
			return Integer.parseInt(value);
		}
		catch (Exception e)
		{
			return defaultValue;
		}
	}

	@Override
	public String[] getVoicedCommandList()
	{
		return VOICED_COMMANDS;
	}
}




