//================================================================================

class PvpRankWnd extends UICommonAPI;

const MAX_SLOTS = 5;
const EVENT_PVP_RANK = 88554;
const TIMER_TICK = 88555;
const SEARCH_RADIUS = 3000.0;


const RANK_HEIGHT_BONUS_SELECTED = 19.0;
const RANK_HEIGHT_BONUS_UNSELECTED = 4.0;
const MOUNTED_HEAD_Z = 25.0;

const ICON_W = 128;
const ICON_H = 32;
const CONTENT_CX = 32;
const CONTENT_CY = 16;
const MAX_RANK = 10;


const EXTRA_UP_PX = 5;

var WindowHandle Me;
var WindowHandle SlotWnd[5];
var TextureHandle SlotTex[5];
var int SlotCreatureId[5];
var int SlotRank[5];
var int SlotFound[5];
var bool bTicking;


var PvpRankWnd Instance;

function OnLoad()
{
	local int i;
	local string root;

	RegisterEvent(40);
	RegisterEvent(50);
	RegisterEvent(EVENT_PVP_RANK);

	default.Instance = Self;

	Me = GetHandle("PvpRankWnd");
	for (i = 0; i < MAX_SLOTS; i++)
	{
		root = "PvpRankIcon" $ i;
		SlotWnd[i] = GetHandle(root);
		SlotTex[i] = TextureHandle(GetHandle(root $ ".Icon"));
		SlotCreatureId[i] = 0;
		SlotRank[i] = 0;
		SlotFound[i] = 0;
		if (SlotWnd[i] != none)
		{
			SlotWnd[i].MoveTo(-300, -300);
			SlotWnd[i].HideWindow();
		}
	}
	if (Me != none)
	{
		Me.MoveTo(-80, -80);
		Me.HideWindow();
	}
	bTicking = False;
}

function OnEvent(int Event_ID, string param)
{
	if (Event_ID == 40 || Event_ID == 50)
	{
		ClearAll();
		return;
	}
	if (Event_ID == EVENT_PVP_RANK)
		HandleRankEvent(param);
}

function HandleSync(string param)
{
	ClearAll();
}

function OnTimer(int TimerID)
{
	if (TimerID == TIMER_TICK)
		UpdateAll();
}

function HandleRankEvent(string param)
{
	local int id, rank, i, slotIdx;

	ParseInt(param, "Id", id);
	ParseInt(param, "Rank", rank);
	if (id <= 0)
		return;
	if (rank > MAX_RANK)
		return;


	for (i = 0; i < MAX_SLOTS; i++)
	{
		if (SlotCreatureId[i] == id)
		{
			if (rank <= 0)
				FreeSlot(i);
			else if (SlotRank[i] != rank)
				ApplyRank(i, rank);
			return;
		}
	}

	if (rank <= 0)
		return;

	slotIdx = -1;
	for (i = 0; i < MAX_SLOTS; i++)
	{
		if (SlotCreatureId[i] == 0)
		{
			slotIdx = i;
			break;
		}
	}
	if (slotIdx == -1)
		return; 

	SlotCreatureId[slotIdx] = id;
	ApplyRank(slotIdx, rank);
	StartTicking();
}

function ApplyRank(int i, int rank)
{
	SlotRank[i] = rank;
	if (SlotTex[i] != none)
		SlotTex[i].SetTexture("L2UI_CH3.HeaderRanking.head_rank_" $ string(rank));
}

function FreeSlot(int i)
{
	SlotCreatureId[i] = 0;
	SlotRank[i] = 0;
	SlotFound[i] = 0;
	if (SlotWnd[i] != none)
	{
		SlotWnd[i].MoveTo(-300, -300);
		SlotWnd[i].HideWindow();
	}
}

function ClearAll()
{
	local int i;

	for (i = 0; i < MAX_SLOTS; i++)
		FreeSlot(i);
	StopTicking();
}

function StartTicking()
{
	if (Me == none || bTicking)
		return;

	Me.SetTimer(TIMER_TICK, 33);
	bTicking = True;
}

function StopTicking()
{
	bTicking = False;
	if (Me != none)
		Me.KillTimer(TIMER_TICK);
}


function UpdateAll()
{
    local int i;
    local int CurrentTargetId;
    local int RankX;
    local int RankY;
    local int HighestAllowedY;

    local float sx, sy;
    local bool anyActive;
    local bool bCheckPlayerBars;

    local WindowHandle PlayerHeader;
    local WindowHandle PlayerBars;
    local Rect BarsRect;

    anyActive = False;

    for (i = 0; i < MAX_SLOTS; i++)
    {
        if (SlotCreatureId[i] != 0)
            anyActive = True;
    }

    if (!anyActive)
    {
        StopTicking();
        return;
    }

    CurrentTargetId =
        class'NWindow.UIDATA_TARGET'.static.GetTargetID();

    PlayerHeader = GetHandle("TargetHeaderPlayer");

    PlayerBars = GetHandle(
        "TargetHeaderPlayer.BarraHud"
    );

    bCheckPlayerBars = False;

    if (CurrentTargetId > 0
        && PlayerHeader != None
        && PlayerBars != None)
    {
        if (PlayerHeader.IsShowWindow())
        {
            BarsRect = PlayerBars.GetRect();
            bCheckPlayerBars = True;
        }
    }

    for (i = 0; i < MAX_SLOTS; i++)
    {
        if (SlotCreatureId[i] == 0 || SlotWnd[i] == None)
            continue;

        if (!ProjectRankHead(SlotCreatureId[i], sx, sy))
        {
            SlotWnd[i].MoveTo(-300, -300);
            SlotWnd[i].HideWindow();
            continue;
        }

        // Mantem a posicao original do ranking.
        RankX = int(sx) - CONTENT_CX;

        RankY =
            int(sy)
            - CONTENT_CY
            - ICON_H
            - EXTRA_UP_PX;

        // Evita sobrepor as barras do mesmo personagem.
        if (bCheckPlayerBars
            && SlotCreatureId[i] == CurrentTargetId)
        {
            // A parte inferior do ranking fica pelo menos
            // 8 pixels acima do inicio das barras.
            HighestAllowedY = BarsRect.nY - ICON_H - 8;

            if (RankY > HighestAllowedY)
                RankY = HighestAllowedY;
        }

        SlotWnd[i].SetWindowSize(ICON_W, ICON_H);
        SlotWnd[i].MoveTo(RankX, RankY);
        SlotWnd[i].ShowWindow();
    }
}

function bool ProjectRankHead(int creatureId, out float outX, out float outY)
{
	local Vector camLoc, camDir, camRight, camUp, head;
	local Rotator camRot;
	local int sw, sh;
	local float fsw, fsh, aspect, fov, nearZ, farZ, frameMul, calibrate, pctX, pctY, screenX, screenY;
	local Matrix projMat, viewMat, mvp;
	local Plane homog, clip;
	local Actor selfActor;
	local Pawn target;
	local LineagePlayerController ctrl;
	local UserInfo info, tInfo;
	local int bFound;
	local float bonus;

	outX = -100;
	outY = -100;

	if (creatureId <= 0)
		return False;
	if (!GetPlayerActor(selfActor))
		return False;
	if (!GetPlayerController(ctrl))
		return False;

	bonus = RANK_HEIGHT_BONUS_UNSELECTED;
	if (GetTargetInfo(tInfo) && tInfo.nID == creatureId)
		bonus = RANK_HEIGHT_BONUS_SELECTED;

	bFound = 0;
	foreach selfActor.CollidingActors(Class'Engine.Pawn', target, 1500.0, selfActor.Location)
	{
		if (target == none || target.CreatureID != creatureId)
			continue;

		head = target.Location;
		if (target.bRide)
			head.Z = head.Z + MOUNTED_HEAD_Z;
		else
			head.Z = head.Z + target.CollisionHeight + bonus;
		bFound = 1;
		break;
	}
	if (bFound == 0 && GetUserInfo(creatureId, info))
	{
		head = info.Loc;
		head.Z = head.Z + 48.0 + bonus;
		bFound = 1;
	}
	if (bFound == 0)
		return False;

	ctrl.PlayerCalcView(selfActor, camLoc, camRot);
	GetCurrentResolution(sw, sh);
	fsw = float(sw);
	fsh = float(sh);
	GetAxes(camRot, camDir, camRight, camUp);

	fov = 50.0;
	nearZ = 0.1;
	farZ = 1000.0;
	frameMul = 1000.0;
	aspect = fsw / fsh;

	projMat = xxfaaxa(fov, nearZ, farZ, aspect);
	viewMat = xxbgdfaa(camLoc, camDir, camRight, camUp);
	mvp = xxeraaxac(projMat, viewMat);
	homog = xxplanekaa(head.X, head.Y, head.Z, 1.0);
	clip = xxmujjkkasd(mvp, homog);
	if (clip.W == 0.0)
		return False;

	clip.X = clip.X / (clip.W / frameMul);
	clip.Y = clip.Y / (clip.W / frameMul);
	clip.Z = clip.Z / (clip.W / frameMul);

	calibrate = (0.5729 * aspect) / frameMul;
	if (calibrate == 0.0)
		return False;

	pctX = ((((clip.X * 0.5) * fsw) + (fsw / calibrate)) / ((fsw / calibrate) * 2.0)) * 100.0;
	pctY = ((((clip.Y * 0.5) * fsh) + (fsh / calibrate)) / ((fsh / calibrate) * 2.0)) * 100.0;
	screenX = ((100.0 - pctX) * fsw) / 100.0;
	screenY = (pctY * fsh) / 100.0;

	if (((head - camLoc) Dot camDir) < 0.0)
		return False;
	if (screenX < -100.0 || screenX > fsw + 100.0)
		return False;
	if (screenY < -100.0 || screenY > fsh + 100.0)
		return False;

	outX = screenX;
	outY = screenY;
	return True;
}

