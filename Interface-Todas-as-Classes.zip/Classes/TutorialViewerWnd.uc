class TutorialViewerWnd extends UICommonAPI;

function OnLoad()
{
    RegisterEvent(EV_TutorialViewerWndShow);
    RegisterEvent(EV_TutorialViewerWndHide);
}

function OnClickButton(string strID)
{
    if (
        Caps(strID) == "BTNCLOSE" ||
        Caps(strID) == "CLOSE" ||
        Caps(strID) == "CLOSEBUTTON"
    )
    {
        HideWindow("TutorialViewerWnd");
    }
}

function OnEvent(int Event_ID, string param)
{
    local string HtmlString;

    switch (Event_ID)
    {
        case EV_TutorialViewerWndShow:
            ParseString(param, "HtmlString", HtmlString);

            if (HtmlString == "")
                return;

            // Milenium Monster Data: keep the existing tutorial/reward routes.
            if (Left(HtmlString, 9) == "MOB_INFO|")
            {
                MobInformerWnd(GetScript("MobInformerWnd")).ApplyPacket(HtmlString);
                return;
            }
            if (Left(HtmlString, 12) == "MOB_CATALOG|")
            {
                MobInformerWnd(GetScript("MobInformerWnd")).ApplyCatalogPacket(HtmlString);
                return;
            }

            // DailyRewardWnd recebe e trata este evento diretamente.
            // Nao encaminha novamente nem abre o tutorial.
            if (InStr(HtmlString, "<!--DAILY_REWARD_NATIVE_V1-->") == 0)
            {
                return;
            }

            ShowServerTutorial(HtmlString);
            break;

        case EV_TutorialViewerWndHide:
            HideWindow("TutorialViewerWnd");
            break;
    }
}

static function DebugLog(string Msg)
{
    local Color Col;

    Col.R = 0;
    Col.G = 220;
    Col.B = 255;
    Col.A = 255;

    class'NWindow.UIAPI_TEXTLISTBOX'.static.AddString(
        "ChatWnd.NormalChat",
        "[DailyDebug] " $ Msg,
        Col
    );
}

function ShowServerTutorial(string HtmlString)
{
    local int WindowWidth;
    local int WindowHeight;
    local int HtmlWidth;
    local int HtmlHeight;
    local int MaxHtmlHeight;
    local int screenW;
    local int screenH;

    WindowWidth = 330;
    HtmlWidth = WindowWidth - 16;

    GetCurrentResolution(screenW, screenH);

    MaxHtmlHeight = screenH - 100;

    if (MaxHtmlHeight > 620)
        MaxHtmlHeight = 620;

    if (MaxHtmlHeight < 220)
        MaxHtmlHeight = 220;

    // Define a largura antes de carregar e medir o HTML.
    class'UIAPI_WINDOW'.static.SetWindowSize(
        "TutorialViewerWnd",
        WindowWidth,
        302
    );

    class'UIAPI_WINDOW'.static.SetAnchor(
        "TutorialViewerWnd.HtmlTutorialViewer",
        "TutorialViewerWnd",
        "TopLeft",
        "TopLeft",
        8,
        30
    );

    class'UIAPI_WINDOW'.static.SetWindowSize(
        "TutorialViewerWnd.HtmlTutorialViewer",
        HtmlWidth,
        260
    );

    class'UIAPI_HTMLCTRL'.static.LoadHtmlFromString(
        "TutorialViewerWnd.HtmlTutorialViewer",
        HtmlString
    );

    HtmlHeight = class'UIAPI_HTMLCTRL'.static.GetFrameMaxHeight(
        "TutorialViewerWnd.HtmlTutorialViewer"
    );

    HtmlHeight = HtmlHeight + 8;

    if (HtmlHeight < 220)
        HtmlHeight = 220;

    if (HtmlHeight > MaxHtmlHeight)
        HtmlHeight = MaxHtmlHeight;

    WindowHeight = HtmlHeight + 42;

    class'UIAPI_WINDOW'.static.SetWindowSize(
        "TutorialViewerWnd",
        WindowWidth,
        WindowHeight
    );

    class'UIAPI_WINDOW'.static.SetWindowSize(
        "TutorialViewerWnd.HtmlTutorialViewer",
        HtmlWidth,
        HtmlHeight
    );

    GetHandle("TutorialViewerWnd").MoveTo(
        (screenW - WindowWidth) / 2,
        (screenH - WindowHeight) / 2
    );

    ShowWindowWithFocus("TutorialViewerWnd");
}

