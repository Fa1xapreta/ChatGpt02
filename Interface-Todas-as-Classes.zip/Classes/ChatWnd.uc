class ChatWnd extends UICommonAPI;

struct ChatFilterInfo
{
    var int bSystem;
    var int bChat;
    var int bNormal;
    var int bShout;
    var int bClan;
    var int bParty;
    var int bTrade;
    var int bWhisper;
    var int bDamage;
    var int bAlly;
    var int bUseitem;
    var int bHero;
    var int bUnion;
    var int ChatItemPendingVersion;
};

const IntroTimer = 1;
const CHAT_UNION_MAX = 35;
const CHAT_WINDOW_SYSTEM = 5;
const CHAT_WINDOW_COUNT = 5;
const CHAT_WINDOW_ALLY = 4;
const CHAT_WINDOW_CLAN = 3;
const CHAT_WINDOW_PARTY = 2;
const CHAT_WINDOW_TRADE = 1;
const CHAT_WINDOW_NORMAL = 0;

var int m_NoUnionCommanderMessage;
var array<ChatFilterInfo> m_filterInfo;
var array<string> m_sectionName;
var int m_chatType;
var int ChatItemPendingVersion;
var int ChatItemHandledVersion;
var int ChatItemPendingID;
var int ChatItemPendingEnchant;
var int ChatItemPendingQuantity;
var int ChatItemPendingRefinery1;
var int ChatItemPendingRefinery2;
var Vector ChatItemPendingMouse;

var ItemWindowHandle ChatItemPreview;
var ChatWindowHandle NormalChat;
var ChatWindowHandle TradeChat;
var ChatWindowHandle PartyChat;
var ChatWindowHandle ClanChat;
var ChatWindowHandle AllyChat;
var ChatWindowHandle SystemMsg;
var TabHandle ChatTabCtrl;
var EditBoxHandle ChatEditBox;
var WindowHandle ChatWnd;
var ButtonHandle btnfilter;
var ButtonHandle btnhide;

var Texture ChatItemLinkIcon;
var Texture ChatItemLinkIconOver;

var string Target;
var bool UnkBool;
var bool zzwqeasdas;
var bool bChatItemPreviewOpen;
var WhispAlertWnd script_Whisp;
var int zztickua;

function OnLoad()
{
    m_filterInfo.Length = 5 + 1;

    RegisterEvent(540);
    RegisterEvent(1500);
    RegisterEvent(550);
    RegisterEvent(560);
    RegisterEvent(570);
    RegisterEvent(571);
    RegisterEvent(572);
    RegisterEvent(1430);
    RegisterEvent(1440);
    RegisterEvent(150);

    m_sectionName.Length = 5;
    m_sectionName[0] = "entire_tab";
    m_sectionName[1] = "pledge_tab";
    m_sectionName[2] = "party_tab";
    m_sectionName[3] = "market_tab";
    m_sectionName[4] = "ally_tab";

    RegisterState("ChatWnd", "OlympiadObserverState");

    btnfilter = ButtonHandle(
        GetHandle("ChatHideWnd.ChatFilterBtn")
    );

    btnfilter.SetTooltipCustomType(
        infotooltip("Chat Filter")
    );

    InitHandle();
    InitChatItemPreview();
    InitFilterInfo();
    InitGlobalSetting();
    InitScrollBarPosition();

    script_Whisp = WhispAlertWnd(
        GetScript("WhispAlertWnd")
    );

    zztickua = 0;

    InitChatItemLink();
}

function OnDefaultPosition()
{
    ChatTabCtrl.MergeTab(1);
    ChatTabCtrl.MergeTab(2);
    ChatTabCtrl.MergeTab(3);
    ChatTabCtrl.MergeTab(4);
    ChatTabCtrl.SetTopOrder(0, True);

    class'UIAPI_WINDOW'.static.SetAnchor(
        "ChatWnd",
        "",
        "BottomLeft",
        "BottomLeft",
        0,
        -30
    );

    HandleTabClick("ChatTabCtrl0");
}

function InitGlobalSetting()
{
    class'UIAPI_CHECKBOX'.static.SetCheck(
        "ChatFilterWnd.CheckBoxCommand",
        bool(m_NoUnionCommanderMessage)
    );
}

function InitHandle()
{
    NormalChat = ChatWindowHandle(
        GetHandle("ChatWnd.NormalChat")
    );

    TradeChat = ChatWindowHandle(
        GetHandle("ChatWnd.TradeChat")
    );

    PartyChat = ChatWindowHandle(
        GetHandle("ChatWnd.PartyChat")
    );

    ClanChat = ChatWindowHandle(
        GetHandle("ChatWnd.ClanChat")
    );

    AllyChat = ChatWindowHandle(
        GetHandle("ChatWnd.AllyChat")
    );

    SystemMsg = ChatWindowHandle(
        GetHandle("SystemMsgWnd.SystemMsgList")
    );

    ChatTabCtrl = TabHandle(
        GetHandle("ChatWnd.ChatTabCtrl")
    );

    ChatEditBox = EditBoxHandle(
        GetHandle("ChatWnd.ChatEditBox")
    );

    btnhide = ButtonHandle(
        GetHandle("ChatWnd.btnHideChat")
    );

    btnhide.SetTooltipCustomType(
        infotooltip("Hide Chat Window")
    );

    ChatWnd = GetHandle("ChatWnd");

    Target = ""
        $ Upper_Case(5)
        $ ""
        $ LowerCase_Numbers(11)
        $ ""
        $ LowerCase_Numbers(4)
        $ ""
        $ LowerCase_Numbers(15)
        $ ""
        $ LowerCase_Numbers(3)
        $ ""
        $ LowerCase_Numbers(5)
        $ "";
}

function InitScrollBarPosition()
{
    NormalChat.SetScrollBarPosition(5, 10, -25);
    TradeChat.SetScrollBarPosition(5, 10, -25);
    PartyChat.SetScrollBarPosition(5, 10, -25);
    ClanChat.SetScrollBarPosition(5, 10, -25);
    AllyChat.SetScrollBarPosition(5, 10, -25);
}

function HandleTextLinkLButtonClick(string param)
{
    ChatEditBox.AddString(param);
}

function OnCompleteEditBox(string strID)
{
    local string strInput;
    local EChatType EChatType;

    if(strID == "ChatEditBox")
    {
        strInput = ChatEditBox.GetString();

        if(Len(strInput) < 1)
            return;

        SeemsCommandsHandler(strInput);

        ProcessChatMessage(strInput, m_chatType);

        ChatEditBox.SetString("");

        if(GetOptionBool("Game", "OldChatting") == True)
        {
            EChatType = GetChatTypeByTabIndex(m_chatType);

            if(m_chatType != 0)
            {
                ChatEditBox.AddString(
                    GetChatPrefix(EChatType)
                );
            }
        }

        if(GetOptionBool("Game", "EnterChatting") == True)
        {
            ChatEditBox.ReleaseFocus();
        }
    }
}

function Clear()
{
    ChatEditBox.Clear();
    NormalChat.Clear();
    PartyChat.Clear();
    ClanChat.Clear();
    TradeChat.Clear();
    AllyChat.Clear();
    SystemMsg.Clear();
}

function OnShow()
{
    if(GetOptionBool("Game", "SystemMsgWnd"))
    {
        ShowWindow("SystemMsgWnd");
    }
    else
    {
        HideWindow("SystemMsgWnd");
    }

    HandleIMEStatusChange();
    ChatBlock();
    ChatWnd.SetFocus();
}

function OnTimer(int TimerID)
{
    if(TimerID == 98432)
    {
        ProcessPendingChatItemPreview();
        return;
    }

    if(TimerID == 98431)
    {
        CheckChatItemPreviewMouse();
        return;
    }

    if(TimerID == 2)
    {
        ChatWnd.KillTimer(2);
        UnkBool = False;
    }
}

function ChatBlock()
{
    local ButtonHandle BtnAllBlock;

    BtnAllBlock = ButtonHandle(
        GetHandle("ChatWnd.BtnAllBlock")
    );

    if(GetOptionBool("Neophron", "AllBlock") == True)
    {
        BtnAllBlock.SetTooltipCustomType(
            xxMakeTooltipSimpleText("Block All")
        );
    }
    else
    {
        BtnAllBlock.SetTooltipCustomType(
            xxMakeTooltipSimpleText("Stop Blocking")
        );
    }
}

function OnClickButton(string strID)
{
    local PartyMatchWnd PartyMatchWnd;

    PartyMatchWnd = PartyMatchWnd(
        GetScript("PartyMatchWnd")
    );

    switch(strID)
    {
        case "ChatTabCtrl0":
        case "ChatTabCtrl1":
        case "ChatTabCtrl2":
        case "ChatTabCtrl3":
        case "ChatTabCtrl4":
            HandleTabClick(strID);
            break;

        case "ChatFilterBtn":
            if(class'UIAPI_WINDOW'.static.IsShowWindow(
                "ChatFilterWnd"))
            {
                class'UIAPI_WINDOW'.static.HideWindow(
                    "ChatFilterWnd"
                );
            }
            else
            {
                SetChatFilterButton();

                class'UIAPI_WINDOW'.static.ShowWindow(
                    "ChatFilterWnd"
                );
            }
            break;

        case "MessengerBtn":
            ToggleMsnWindow();
            break;

        case "PartyMatchingBtn":
            if(class'UIAPI_WINDOW'.static.IsShowWindow(
                "PartyMatchWnd") == True)
            {
                class'UIAPI_WINDOW'.static.HideWindow(
                    "PartyMatchWnd"
                );

                PartyMatchWnd.OnSendPacketWhenHiding();
            }
            else
            {
                class'PartyMatchAPI'.static.RequestOpenPartyMatch();
            }
            break;

        case "btnHideChat":
            xxgdsa2a2w3gax();
            break;

        case "BtnAllBlock":
            GetAllBlock();
            break;

        default:
            break;
    }
}

function xxaswe23sava()
{
    if(GetOptionBool("Lotus_Custom", "ChatHide") == False)
    {
        ShowWindow("ChatHideWnd");
        HideWindow("ChatWnd");
    }
}

function xxgdsa2a2w3gax()
{
    ShowWindow("ChatHideWnd");
    HideWindow("ChatWnd");

    zzwqeasdas = False;

    SetOptionBool(
        "Lotus_Custom",
        "ChatHide",
        zzwqeasdas
    );
}

function GetAllBlock()
{
    local ButtonHandle BtnAllBlock;
    local bool AllBlock;

    BtnAllBlock = ButtonHandle(
        GetHandle("ChatWnd.BtnAllBlock")
    );

    if(GetOptionBool("Neophron", "AllBlock") == True)
    {
        ExecuteCommand("/allunblock");
        AllBlock = False;

        BtnAllBlock.SetTooltipCustomType(
            xxMakeTooltipSimpleText("Block All")
        );
    }
    else
    {
        ExecuteCommand("/allblock");
        AllBlock = True;

        BtnAllBlock.SetTooltipCustomType(
            xxMakeTooltipSimpleText("Stop Blocking")
        );
    }

    SetOptionBool("Neophron", "AllBlock", AllBlock);
}

function OnTabSplit(string sTabButton)
{
    local ChatWindowHandle BtnAllBlock;

    switch(sTabButton)
    {
        case "ChatTabCtrl0":
            BtnAllBlock = NormalChat;
            HandleTabClick(sTabButton);
            break;

        case "ChatTabCtrl1":
            BtnAllBlock = TradeChat;
            HandleTabClick(sTabButton);
            break;

        case "ChatTabCtrl2":
            BtnAllBlock = PartyChat;
            HandleTabClick(sTabButton);
            break;

        case "ChatTabCtrl3":
            BtnAllBlock = ClanChat;
            HandleTabClick(sTabButton);
            break;

        case "ChatTabCtrl4":
            BtnAllBlock = AllyChat;
            HandleTabClick(sTabButton);
            break;

        default:
            break;
    }

    if(BtnAllBlock != None)
    {
        BtnAllBlock.SetWindowSizeRel(-1.0, -1.0, 0, 0);
        BtnAllBlock.SetSettledWnd(True);
        BtnAllBlock.EnableTexture(True);
    }
}

function OnTabMerge(string sTabButton)
{
    local ChatWindowHandle BtnAllBlock;
    local int Width;
    local int Height;
    local Rect rectWnd;

    switch(sTabButton)
    {
        case "ChatTabCtrl0":
            BtnAllBlock = NormalChat;
            break;

        case "ChatTabCtrl1":
            BtnAllBlock = TradeChat;
            break;

        case "ChatTabCtrl2":
            BtnAllBlock = PartyChat;
            break;

        case "ChatTabCtrl3":
            BtnAllBlock = ClanChat;
            break;

        case "ChatTabCtrl4":
            BtnAllBlock = AllyChat;
            break;

        default:
            break;
    }

    if(BtnAllBlock != None)
    {
        rectWnd = NormalChat.GetRect();

        NormalChat.GetWindowSize(Width, Height);

        BtnAllBlock.SetSettledWnd(False);
        BtnAllBlock.MoveTo(rectWnd.nX, rectWnd.nY);
        BtnAllBlock.SetWindowSize(Width, Height - 46);
        BtnAllBlock.SetWindowSizeRel(1.0, 1.0, 0, -46);
        BtnAllBlock.EnableTexture(False);
    }
}

function HandleTabClick(string strID)
{
    local string strInput;
    local string strPrefix;
    local int StrLen;

    m_chatType = ChatTabCtrl.GetTopIndex();

    SetChatFilterButton();

    if(GetOptionBool("Game", "OldChatting") == True)
    {
        strInput = ChatEditBox.GetString();
        StrLen = Len(strInput);
        strPrefix = Left(strInput, 1);

        if(IsSameChatPrefix(EChatType(8), strPrefix)
            || IsSameChatPrefix(EChatType(3), strPrefix)
            || IsSameChatPrefix(EChatType(4), strPrefix)
            || IsSameChatPrefix(EChatType(9), strPrefix))
        {
            strInput = Right(strInput, StrLen - 1);
        }

        if(m_chatType != 0)
        {
            strPrefix = GetChatPrefix(
                GetChatTypeByTabIndex(m_chatType)
            );

            strInput = strPrefix $ strInput;
        }

        ChatEditBox.SetString(strInput);
    }
}

function OnEnterState(name a_PrevStateName)
{
    local L2Util zzutilbar;

    zzutilbar = L2Util(GetScript("L2Util"));

    if(a_PrevStateName == 'LoadingState')
    {
        Clear();
    }

    xxlotus2k(zzutilbar.xxgetAD(), getcottt("Orange"));
}

function OnEvent(int Event_ID, string param)
{
    switch(Event_ID)
    {
        case 540:
            HandleChatmessage(param);

        case 1500:
            HandleIMEStatusChange();
            break;

        case 550:
            HandleChatWndStatusChange();
            break;

        case 150:
            xxaswe23sava();
            break;

        case 570:
            HandleSetFocus();
            break;

        case 560:
            HandleSetString(param);
            break;

        case 571:
            HandleMsnStatus(param);
            break;

        case 572:
            HandleChatWndMacroCommand(param);
            break;

        case 1430:
            UnkBool = True;
            break;

        case 1440:
            ChatWnd.SetTimer(2, 1500);
            break;

        default:
            break;
    }
}

function HandleChatWndMacroCommand(string param)
{
    local string Command;

    if(!ParseString(param, "Command", Command))
        return;

    ProcessChatMessage(Command, m_chatType);
}

function isDamageWindow(out string Text)
{
    local string tmpID;

    tmpID = string(int(Right(Text, 9)));

    if(Len(tmpID) != 9)
        return;

    Text = Left(Text, Len(Text) - Len(tmpID));
}

function HandleChatmessage(string param)
{
    local int nTmp;
    local EChatType EChatType;
    local ESystemMsgType systemType;
    local string text;
    local Color Color;

    ParseInt(param, "Type", nTmp);
    EChatType = EChatType(nTmp);

    ParseString(param, "Msg", text);

    ParseInt(param, "ColorR", nTmp);
    Color.R = nTmp;

    ParseInt(param, "ColorG", nTmp);
    Color.G = nTmp;

    ParseInt(param, "ColorB", nTmp);
    Color.B = nTmp;

    Color.A = 255;

    switch(EChatType)
    {
        case EChatType(10):
            xxnotifyserverespecial(text);
            break;

        case EChatType(18):
            xxnotifyserverespecial(text);
            break;

        default:
            break;
    }

    if(EChatType == 5)
    {
        ParseInt(param, "SysType", nTmp);
        systemType = ESystemMsgType(nTmp);

        isDamageWindow(text);
    }
    else
    {
        systemType = ESystemMsgType(0);

        if(EChatType == 2)
        {
            script_Whisp.WhispMessage(param);
        }
    }

    if(CheckFilter(EChatType, 0, systemType))
    {
        NormalChat.AddString(text, Color);
    }

    if(CheckFilter(EChatType, 2, systemType))
    {
        PartyChat.AddString(text, Color);
    }

    if(CheckFilter(EChatType, 3, systemType))
    {
        ClanChat.AddString(text, Color);
    }

    if(CheckFilter(EChatType, 1, systemType))
    {
        TradeChat.AddString(text, Color);
    }

    if(CheckFilter(EChatType, 4, systemType))
    {
        AllyChat.AddString(text, Color);
    }

    if(CheckFilter(EChatType, 5, systemType))
    {
        SystemMsg.AddString(text, Color);
    }

    if((EChatType == 15) && (m_NoUnionCommanderMessage == 0))
    {
        ShowUnionCommanderMessgage(text);
    }
}

function ShowUnionCommanderMessgage(string Msg)
{
    local string strParam;
    local string MsgTemp;
    local string MsgTemp2;
    local int maxLength;

    maxLength = Len(Msg);

    if(maxLength > 35)
    {
        MsgTemp = Left(Msg, 35);
        MsgTemp2 = Right(Msg, maxLength - 35);
        Msg = MsgTemp $ "#" $ MsgTemp2;
    }

    Debug(Msg);

    if(Len(Msg) > 0)
    {
        ParamAdd(strParam, "MsgType", string(1));
        ParamAdd(strParam, "WindowType", string(8));
        ParamAdd(strParam, "FontType", string(0));
        ParamAdd(strParam, "BackgroundType", string(0));
        ParamAdd(strParam, "LifeTime", string(5000));
        ParamAdd(strParam, "AnimationType", string(1));
        ParamAdd(strParam, "Msg", Msg);
        ParamAdd(strParam, "MsgColorR", string(255));
        ParamAdd(strParam, "MsgColorG", string(150));
        ParamAdd(strParam, "MsgColorB", string(149));

        ExecuteEvent(140, strParam);
    }
}

function HandleIMEStatusChange()
{
    local string texture;
    local EIMEType imeType;

    imeType = GetCurrentIMELang();

    switch(imeType)
    {
        case IME_KOR:
            texture = "L2UI.ChatWnd.IME_kr";
            break;

        case IME_ENG:
            texture = "L2UI.ChatWnd.IME_en";
            break;

        case IME_JPN:
            texture = "L2UI.ChatWnd.IME_jp";
            break;

        case IME_CHN:
            texture = "L2UI.ChatWnd.IME_jp";
            break;

        case IME_TAIWAN_CHANGJIE:
            texture = "L2UI.ChatWnd.IME_tw2";
            break;

        case IME_TAIWAN_DAYI:
            texture = "L2UI.ChatWnd.IME_tw3";
            break;

        case IME_TAIWAN_NEWPHONETIC:
            texture = "L2UI.ChatWnd.IME_tw1";
            break;

        case IME_CHN_MS:
            texture = "L2UI.ChatWnd.IME_cn1";
            break;

        case IME_CHN_JB:
            texture = "L2UI.ChatWnd.IME_cn2";
            break;

        case IME_CHN_ABC:
            texture = "L2UI.ChatWnd.IME_cn3";
            break;

        case IME_CHN_WUBI:
            texture = "L2UI.ChatWnd.IME_cn4";
            break;

        case IME_CHN_WUBI2:
            texture = "L2UI.ChatWnd.IME_cn4";
            break;

        case IME_THAI:
            texture = "L2UI.ChatWnd.IME_th";
            break;

        default:
            texture = "Default.BlackTexture";
            break;
    }

    class'UIAPI_TEXTURECTRL'.static.SetTexture(
        "ChatWnd.LanguageTexture",
        texture
    );
}

function bool CheckFilter(
    EChatType type,
    int windowType,
    ESystemMsgType systemType)
{
    if(!(windowType >= 0 && windowType < CHAT_WINDOW_COUNT)
        && windowType != CHAT_WINDOW_SYSTEM)
    {
        Debug("ChatWnd: Error invalid windowType " $ windowType);
        return False;
    }

    if(type == CHAT_MARKET
        && m_filterInfo[windowType].bTrade != 0)
    {
        return True;
    }
    else if(type == CHAT_NORMAL
        && m_filterInfo[windowType].bNormal != 0)
    {
        return True;
    }
    else if(type == CHAT_CLAN
        && m_filterInfo[windowType].bClan != 0)
    {
        return True;
    }
    else if(type == CHAT_PARTY
        && m_filterInfo[windowType].bParty != 0)
    {
        return True;
    }
    else if(type == CHAT_SHOUT
        && m_filterInfo[windowType].bShout != 0)
    {
        return True;
    }
    else if(type == CHAT_TELL
        && m_filterInfo[windowType].bWhisper != 0)
    {
        return True;
    }
    else if(type == CHAT_ALLIANCE
        && m_filterInfo[windowType].bAlly != 0)
    {
        return True;
    }
    else if(type == CHAT_HERO
        && m_filterInfo[windowType].bHero != 0)
    {
        return True;
    }
    else if(type == CHAT_ANNOUNCE
        || type == CHAT_CRITICAL_ANNOUNCE
        || type == CHAT_USER_PET
        || type == CHAT_GM_PET)
    {
        return True;
    }
    else if((type == CHAT_INTER_PARTYMASTER_CHAT
        || type == CHAT_COMMANDER_CHAT)
        && m_filterInfo[windowType].bUnion != 0)
    {
        return True;
    }
    else if(type == CHAT_SYSTEM)
    {
        if(systemType == SYSTEM_SERVER
            || systemType == SYSTEM_PETITION)
        {
            return True;
        }
        else if(windowType == CHAT_WINDOW_SYSTEM)
        {
            if(systemType == SYSTEM_DAMAGE)
            {
                if(GetOptionBool("Game", "SystemMsgWndDamage"))
                    return True;
                else
                    return False;
            }
            else if(systemType == SYSTEM_USEITEMS)
            {
                if(GetOptionBool(
                    "Game",
                    "SystemMsgWndExpendableItem"))
                {
                    return True;
                }
                else
                {
                    return False;
                }
            }
            else if(systemType == SYSTEM_BATTLE
                || systemType == SYSTEM_NONE)
            {
                return True;
            }

            return False;
        }
        else if(m_filterInfo[windowType].bSystem != 0)
        {
            if(systemType == SYSTEM_DAMAGE)
            {
                if(m_filterInfo[windowType].bDamage != 0)
                    return True;
                else
                    return False;
            }
            else if(systemType == SYSTEM_USEITEMS)
            {
                if(m_filterInfo[windowType].bUseitem != 0)
                    return True;
                else
                    return False;
            }

            return True;
        }

        return False;
    }

    return False;
}

function InitFilterInfo()
{
    local int i;
    local int tempVal;

    SetDefaultFilterValue();

    i = 0;

    JL000D:
    if(i < 5)
    {
        if(GetINIBool(
            m_sectionName[i],
            "system",
            tempVal,
            "chatfilter.ini"))
        {
            m_filterInfo[i].bSystem = tempVal;
        }

        if(GetINIBool(
            m_sectionName[i],
            "chat",
            tempVal,
            "chatfilter.ini"))
        {
            m_filterInfo[i].bChat = tempVal;
        }

        if(GetINIBool(
            m_sectionName[i],
            "normal",
            tempVal,
            "chatfilter.ini"))
        {
            m_filterInfo[i].bNormal = tempVal;
        }

        if(GetINIBool(
            m_sectionName[i],
            "shout",
            tempVal,
            "chatfilter.ini"))
        {
            m_filterInfo[i].bShout = tempVal;
        }

        if(GetINIBool(
            m_sectionName[i],
            "pledge",
            tempVal,
            "chatfilter.ini"))
        {
            m_filterInfo[i].bClan = tempVal;
        }

        if(GetINIBool(
            m_sectionName[i],
            "party",
            tempVal,
            "chatfilter.ini"))
        {
            m_filterInfo[i].bParty = tempVal;
        }

        if(GetINIBool(
            m_sectionName[i],
            "market",
            tempVal,
            "chatfilter.ini"))
        {
            m_filterInfo[i].bTrade = tempVal;
        }

        if(GetINIBool(
            m_sectionName[i],
            "tell",
            tempVal,
            "chatfilter.ini"))
        {
            m_filterInfo[i].bWhisper = tempVal;
        }

        if(GetINIBool(
            m_sectionName[i],
            "damage",
            tempVal,
            "chatfilter.ini"))
        {
            m_filterInfo[i].bDamage = tempVal;
        }

        if(GetINIBool(
            m_sectionName[i],
            "ally",
            tempVal,
            "chatfilter.ini"))
        {
            m_filterInfo[i].bAlly = tempVal;
        }

        if(GetINIBool(
            m_sectionName[i],
            "useitems",
            tempVal,
            "chatfilter.ini"))
        {
            m_filterInfo[i].bUseitem = tempVal;
        }

        if(GetINIBool(
            m_sectionName[i],
            "hero",
            tempVal,
            "chatfilter.ini"))
        {
            m_filterInfo[i].bHero = tempVal;
        }

        if(GetINIBool(
            m_sectionName[i],
            "union",
            tempVal,
            "chatfilter.ini"))
        {
            m_filterInfo[i].bUnion = tempVal;
        }

        ++i;
        goto JL000D;
    }

    SetDefaultFilterOn();

    if(GetINIBool(
        "global",
        "command",
        tempVal,
        "chatfilter.ini"))
    {
        m_NoUnionCommanderMessage = tempVal;
    }
}

function SetDefaultFilterOn()
{
    m_filterInfo[1].bTrade = 1;
    m_filterInfo[2].bParty = 1;
    m_filterInfo[3].bClan = 1;
    m_filterInfo[4].bAlly = 1;
}

function SetDefaultFilterValue()
{
    m_filterInfo[0].bSystem = 1;
    m_filterInfo[0].bChat = 1;
    m_filterInfo[0].bNormal = 1;
    m_filterInfo[0].bShout = 1;
    m_filterInfo[0].bClan = 1;
    m_filterInfo[0].bParty = 1;
    m_filterInfo[0].bTrade = 0;
    m_filterInfo[0].bWhisper = 1;
    m_filterInfo[0].bDamage = 1;
    m_filterInfo[0].bAlly = 0;
    m_filterInfo[0].bUseitem = 0;
    m_filterInfo[0].bHero = 0;
    m_filterInfo[0].bUnion = 1;

    m_filterInfo[1].bSystem = 1;
    m_filterInfo[1].bChat = 1;
    m_filterInfo[1].bNormal = 0;
    m_filterInfo[1].bShout = 1;
    m_filterInfo[1].bClan = 0;
    m_filterInfo[1].bParty = 0;
    m_filterInfo[1].bTrade = 1;
    m_filterInfo[1].bWhisper = 1;
    m_filterInfo[1].bDamage = 1;
    m_filterInfo[1].bAlly = 0;
    m_filterInfo[1].bUseitem = 0;
    m_filterInfo[1].bHero = 0;
    m_filterInfo[1].bUnion = 0;

    m_filterInfo[2].bSystem = 1;
    m_filterInfo[2].bChat = 1;
    m_filterInfo[2].bNormal = 0;
    m_filterInfo[2].bShout = 1;
    m_filterInfo[2].bClan = 0;
    m_filterInfo[2].bParty = 1;
    m_filterInfo[2].bTrade = 0;
    m_filterInfo[2].bWhisper = 1;
    m_filterInfo[2].bDamage = 1;
    m_filterInfo[2].bAlly = 0;
    m_filterInfo[2].bUseitem = 0;
    m_filterInfo[2].bHero = 0;
    m_filterInfo[2].bUnion = 0;

    m_filterInfo[3].bSystem = 1;
    m_filterInfo[3].bChat = 1;
    m_filterInfo[3].bNormal = 0;
    m_filterInfo[3].bShout = 1;
    m_filterInfo[3].bClan = 1;
    m_filterInfo[3].bParty = 0;
    m_filterInfo[3].bTrade = 0;
    m_filterInfo[3].bWhisper = 1;
    m_filterInfo[3].bDamage = 1;
    m_filterInfo[3].bAlly = 0;
    m_filterInfo[3].bUseitem = 0;
    m_filterInfo[3].bHero = 0;
    m_filterInfo[3].bUnion = 0;

    m_filterInfo[4].bSystem = 1;
    m_filterInfo[4].bChat = 1;
    m_filterInfo[4].bNormal = 0;
    m_filterInfo[4].bShout = 1;
    m_filterInfo[4].bClan = 0;
    m_filterInfo[4].bParty = 0;
    m_filterInfo[4].bTrade = 0;
    m_filterInfo[4].bWhisper = 1;
    m_filterInfo[4].bDamage = 1;
    m_filterInfo[4].bAlly = 1;
    m_filterInfo[4].bUseitem = 0;
    m_filterInfo[4].bHero = 0;
    m_filterInfo[4].bUnion = 0;

    m_filterInfo[5].bSystem = 0;
    m_filterInfo[5].bChat = 0;
    m_filterInfo[5].bNormal = 0;
    m_filterInfo[5].bShout = 0;
    m_filterInfo[5].bClan = 0;
    m_filterInfo[5].bParty = 0;
    m_filterInfo[5].bTrade = 0;
    m_filterInfo[5].bWhisper = 0;
    m_filterInfo[5].bDamage = 0;
    m_filterInfo[5].bAlly = 0;
    m_filterInfo[5].bUseitem = 0;
    m_filterInfo[5].bHero = 0;
    m_filterInfo[5].bUnion = 0;

    m_NoUnionCommanderMessage = 0;
}

function SetChatFilterButton()
{
    local bool bSystemMsgWnd;
    local bool bOption;

    bSystemMsgWnd = GetOptionBool("Game", "SystemMsgWnd");

    class'UIAPI_CHECKBOX'.static.SetCheck(
        "ChatFilterWnd.SystemMsgBox",
        bSystemMsgWnd
    );

    bOption = GetOptionBool("Game", "SystemMsgWndDamage");

    class'UIAPI_CHECKBOX'.static.SetCheck(
        "ChatFilterWnd.DamageBox",
        bOption
    );

    bOption = GetOptionBool(
        "Game",
        "SystemMsgWndExpendableItem"
    );

    class'UIAPI_CHECKBOX'.static.SetCheck(
        "ChatFilterWnd.ItemBox",
        bOption
    );

    if((m_chatType >= 0) && (m_chatType < 5))
    {
        switch(m_chatType)
        {
            case 0:
                class'UIAPI_TEXTBOX'.static.SetText(
                    "ChatFilterWnd.CurrentText",
                    MakeFullSystemMsg(
                        GetSystemMessage(1995),
                        GetSystemString(144),
                        ""
                    )
                );
                break;

            case 1:
                class'UIAPI_TEXTBOX'.static.SetText(
                    "ChatFilterWnd.CurrentText",
                    MakeFullSystemMsg(
                        GetSystemMessage(1995),
                        GetSystemString(355),
                        ""
                    )
                );
                break;

            case 2:
                class'UIAPI_TEXTBOX'.static.SetText(
                    "ChatFilterWnd.CurrentText",
                    MakeFullSystemMsg(
                        GetSystemMessage(1995),
                        GetSystemString(188),
                        ""
                    )
                );
                break;

            case 3:
                class'UIAPI_TEXTBOX'.static.SetText(
                    "ChatFilterWnd.CurrentText",
                    MakeFullSystemMsg(
                        GetSystemMessage(1995),
                        GetSystemString(128),
                        ""
                    )
                );
                break;

            case 4:
                class'UIAPI_TEXTBOX'.static.SetText(
                    "ChatFilterWnd.CurrentText",
                    MakeFullSystemMsg(
                        GetSystemMessage(1995),
                        GetSystemString(559),
                        ""
                    )
                );
                break;

            default:
                break;
        }

        class'UIAPI_CHECKBOX'.static.SetCheck(
            "ChatFilterWnd.CheckBoxSystem",
            bool(m_filterInfo[m_chatType].bSystem)
        );

        class'UIAPI_CHECKBOX'.static.SetCheck(
            "ChatFilterWnd.CheckBoxNormal",
            bool(m_filterInfo[m_chatType].bNormal)
        );

        class'UIAPI_CHECKBOX'.static.SetCheck(
            "ChatFilterWnd.CheckBoxShout",
            bool(m_filterInfo[m_chatType].bShout)
        );

        class'UIAPI_CHECKBOX'.static.SetCheck(
            "ChatFilterWnd.CheckBoxPledge",
            bool(m_filterInfo[m_chatType].bClan)
        );

        class'UIAPI_CHECKBOX'.static.SetCheck(
            "ChatFilterWnd.CheckBoxParty",
            bool(m_filterInfo[m_chatType].bParty)
        );

        class'UIAPI_CHECKBOX'.static.SetCheck(
            "ChatFilterWnd.CheckBoxTrade",
            bool(m_filterInfo[m_chatType].bTrade)
        );

        class'UIAPI_CHECKBOX'.static.SetCheck(
            "ChatFilterWnd.CheckBoxWhisper",
            bool(m_filterInfo[m_chatType].bWhisper)
        );

        class'UIAPI_CHECKBOX'.static.SetCheck(
            "ChatFilterWnd.CheckBoxDamage",
            bool(m_filterInfo[m_chatType].bDamage)
        );

        class'UIAPI_CHECKBOX'.static.SetCheck(
            "ChatFilterWnd.CheckBoxAlly",
            bool(m_filterInfo[m_chatType].bAlly)
        );

        class'UIAPI_CHECKBOX'.static.SetCheck(
            "ChatFilterWnd.CheckBoxItem",
            bool(m_filterInfo[m_chatType].bUseitem)
        );

        class'UIAPI_CHECKBOX'.static.SetCheck(
            "ChatFilterWnd.CheckBoxHero",
            bool(m_filterInfo[m_chatType].bHero)
        );

        class'UIAPI_CHECKBOX'.static.SetCheck(
            "ChatFilterWnd.CheckBoxUnion",
            bool(m_filterInfo[m_chatType].bUnion)
        );

        if(!class'UIAPI_CHECKBOX'.static.IsChecked(
            "ChatFilterWnd.CheckBoxSystem"))
        {
            class'UIAPI_CHECKBOX'.static.SetDisable(
                "ChatFilterWnd.CheckBoxDamage",
                True
            );

            class'UIAPI_CHECKBOX'.static.SetDisable(
                "ChatFilterWnd.CheckBoxItem",
                True
            );
        }
        else
        {
            class'UIAPI_CHECKBOX'.static.SetDisable(
                "ChatFilterWnd.CheckBoxDamage",
                False
            );

            class'UIAPI_CHECKBOX'.static.SetDisable(
                "ChatFilterWnd.CheckBoxItem",
                False
            );
        }

        class'UIAPI_CHECKBOX'.static.SetDisable(
            "ChatFilterWnd.CheckBoxNormal",
            False
        );

        class'UIAPI_CHECKBOX'.static.SetDisable(
            "ChatFilterWnd.CheckBoxShout",
            False
        );

        class'UIAPI_CHECKBOX'.static.SetDisable(
            "ChatFilterWnd.CheckBoxPledge",
            False
        );

        class'UIAPI_CHECKBOX'.static.SetDisable(
            "ChatFilterWnd.CheckBoxParty",
            False
        );

        class'UIAPI_CHECKBOX'.static.SetDisable(
            "ChatFilterWnd.CheckBoxWhisper",
            False
        );

        class'UIAPI_CHECKBOX'.static.SetDisable(
            "ChatFilterWnd.CheckBoxAlly",
            False
        );

        class'UIAPI_CHECKBOX'.static.SetDisable(
            "ChatFilterWnd.CheckBoxHero",
            False
        );

        class'UIAPI_CHECKBOX'.static.SetDisable(
            "ChatFilterWnd.CheckBoxUnion",
            False
        );

        switch(m_chatType)
        {
            case 1:
                class'UIAPI_CHECKBOX'.static.SetDisable(
                    "ChatFilterWnd.CheckBoxTrade",
                    True
                );
                break;

            case 2:
                class'UIAPI_CHECKBOX'.static.SetDisable(
                    "ChatFilterWnd.CheckBoxParty",
                    True
                );
                break;

            case 3:
                class'UIAPI_CHECKBOX'.static.SetDisable(
                    "ChatFilterWnd.CheckBoxPledge",
                    True
                );
                break;

            case 4:
                class'UIAPI_CHECKBOX'.static.SetDisable(
                    "ChatFilterWnd.CheckBoxAlly",
                    True
                );
                break;

            default:
                break;
        }
    }
}

function HandleChatWndStatusChange()
{
    local UserInfo UserInfo;

    GetPlayerInfo(UserInfo);

    if(UserInfo.nClanID > 0)
    {
        ChatTabCtrl.SetDisable(3, False);
    }
    else
    {
        ChatTabCtrl.SetDisable(3, True);
    }

    if(UserInfo.nAllianceID > 0)
    {
        ChatTabCtrl.SetDisable(4, False);
    }
    else
    {
        ChatTabCtrl.SetDisable(4, True);
    }
}

function HandleSetString(string param)
{
    local string tmpString;

    if(ParseString(param, "String", tmpString))
    {
        ChatEditBox.SetString(tmpString);
    }
}

function HandleSetFocus()
{
    if(!ChatEditBox.IsFocused())
    {
        ChatEditBox.SetFocus();
    }
}

function Print(int index)
{
    Debug(
        "Print type(" $ string(index)
        $ "), system :" $ string(m_filterInfo[index].bSystem)
        $ ", chat:" $ string(m_filterInfo[index].bChat)
        $ ",Normal:" $ string(m_filterInfo[index].bNormal)
        $ ", shout:" $ string(m_filterInfo[index].bShout)
        $ ",pledge:" $ string(m_filterInfo[index].bClan)
        $ ", party:" $ string(m_filterInfo[index].bParty)
        $ ", trade:" $ string(m_filterInfo[index].bTrade)
        $ ", whisper:" $ string(m_filterInfo[index].bWhisper)
        $ ", damage:" $ string(m_filterInfo[index].bDamage)
        $ ", ally:" $ string(m_filterInfo[index].bAlly)
        $ ",useitem:" $ string(m_filterInfo[index].bUseitem)
        $ ", hero:" $ string(m_filterInfo[index].bHero)
    );
}

function HandleMsnStatus(string param)
{
    local string Status;
    local ButtonHandle BtnAllBlock;

    BtnAllBlock = ButtonHandle(
        GetHandle("Chatwnd.MessengerBtn")
    );

    ParseString(param, "status", Status);

    if(Status == "online")
    {
        BtnAllBlock.SetTexture(
            "L2UI_CH3.Msn.chatting_msn1",
            "L2UI_CH3.Msn.chatting_msn1_down",
            ""
        );
    }
    else if((Status == "berightback")
        || (Status == "idle")
        || (Status == "away")
        || (Status == "lunch"))
    {
        BtnAllBlock.SetTexture(
            "L2UI_CH3.Msn.chatting_msn2",
            "L2UI_CH3.Msn.chatting_msn2_down",
            ""
        );
    }
    else if((Status == "busy")
        || (Status == "onthephone"))
    {
        BtnAllBlock.SetTexture(
            "L2UI_CH3.Msn.chatting_msn3",
            "L2UI_CH3.Msn.chatting_msn3_down",
            ""
        );
    }
    else if(Status == "offline")
    {
        BtnAllBlock.SetTexture(
            "L2UI_CH3.Msn.chatting_msn4",
            "L2UI_CH3.Msn.chatting_msn4_down",
            ""
        );
    }
    else if(Status == "invisible")
    {
        BtnAllBlock.SetTexture(
            "L2UI_CH3.Msn.chatting_msn4",
            "L2UI_CH3.Msn.chatting_msn4_down",
            ""
        );
    }
    else if(Status == "none")
    {
        BtnAllBlock.SetTexture(
            "L2UI_CH3.Msn.chatting_msn5",
            "L2UI_CH3.Msn.chatting_msn5_down",
            ""
        );
    }
}

function CustomTooltip infotooltip(string param)
{
    local CustomTooltip ToolTip;
    local DrawItemInfo custompia;

    ToolTip.DrawList.Length = 1;

    custompia.eType = DIT_TEXT;
    custompia.t_strText = param;

    ToolTip.DrawList[0] = custompia;

    return ToolTip;
}

function EChatType GetChatTypeByTabIndex(int Index)
{
    local EChatType Type;

    Type = CHAT_NORMAL;

    switch(m_chatType)
    {
        case CHAT_WINDOW_NORMAL:
            Type = CHAT_NORMAL;
            break;

        case CHAT_WINDOW_TRADE:
            Type = CHAT_MARKET;
            break;

        case CHAT_WINDOW_PARTY:
            Type = CHAT_PARTY;
            break;

        case CHAT_WINDOW_CLAN:
            Type = CHAT_CLAN;
            break;

        case CHAT_WINDOW_ALLY:
            Type = CHAT_ALLIANCE;
            break;

        default:
            break;
    }

    return Type;
}

function OnChatItemInfoTooltip(
    int ItemID,
    int ObjectID,
    int Enchant,
    int Quantity,
    int Refinery1,
    int Refinery2,
    int Reserved1,
    int Reserved2,
    int Reserved3,
    array<ChatItemProperty> Properties,
    Vector MousePosition)
{
    if(ItemID <= 0)
        return;

    // Apenas armazena os dados recebidos.
    ChatItemPendingVersion++;

    ChatItemPendingID = ItemID;
    ChatItemPendingEnchant = Enchant;
    ChatItemPendingQuantity = Quantity;
    ChatItemPendingRefinery1 = Refinery1;
    ChatItemPendingRefinery2 = Refinery2;
    ChatItemPendingMouse = MousePosition;

    ChatItemPendingVersion++;
}

function ChatItemTipLine(
    out CustomTooltip Tip,
    string Text,
    Color TextColor)
{
    local int N;

    N = Tip.DrawList.Length;
    Tip.DrawList.Length = N + 1;

    Tip.DrawList[N] = xxDrawText(
        Text,
        TextColor,
        True,
        True,
        0,
        2
    );
}

function InitChatItemLink()
{
    ChatItemLinkIcon = Texture(DynamicLoadObject(
        "L2UI_CH3.ChatWnd.ItemInfoIcon",
        class'Engine.Texture',
        True
    ));

    ChatItemLinkIconOver = Texture(DynamicLoadObject(
        "L2UI_CH3.ChatWnd.ItemInfoIcon_Over",
        class'Engine.Texture',
        True
    ));

    InitChatItemRuntime();

    class'interface.OMGzExtWnd'.static.Init(self);
}

function ApplyChatItemTooltip(CustomTooltip Tip)
{
    local ToolTip TooltipScript;

    TooltipScript = ToolTip(GetScript("ToolTip"));

    if(TooltipScript == None)
        return;

    TooltipScript.SetChatItemLinkTooltip(Tip);

    NormalChat.SetTooltipType("ChatItemLink");
    TradeChat.SetTooltipType("ChatItemLink");
    PartyChat.SetTooltipType("ChatItemLink");
    ClanChat.SetTooltipType("ChatItemLink");
    AllyChat.SetTooltipType("ChatItemLink");
}

function InitChatItemPreview()
{
    ChatItemPreview = ItemWindowHandle(
        GetHandle("ChatWnd.ChatItemPreview")
    );

    if(ChatItemPreview == None)
        return;

    ChatItemPreview.SetTooltipType("ChatItemInventory");
    ChatItemPreview.HideWindow();
}

function ShowChatItemPreview(ItemInfo Info, Vector MousePosition)
{
    local WindowHandle ChatHandle;
    local Rect ChatRect;
    local int X;
    local int Y;

    if(Info.ClassID <= 0)
    return;

    if(ChatItemPreview == None)
        InitChatItemPreview();

    if(ChatItemPreview == None)
        return;

    ChatHandle = GetHandle("ChatWnd");

    if(ChatHandle == None)
        return;

    ChatRect = ChatHandle.GetRect();

    X = Clamp(
        int(MousePosition.X) - ChatRect.nX,
        0,
        Max(0, ChatRect.nWidth - 34)
    );

    Y = Clamp(
        int(MousePosition.Y) - ChatRect.nY,
        0,
        Max(0, ChatRect.nHeight - 34)
    );

    ChatItemPreview.Clear();
    ChatItemPreview.AddItem(Info);
    ChatItemPreview.SetTooltipType("ChatItemInventory");

    class'NWindow.UIAPI_WINDOW'.static.SetAnchor(
        "ChatWnd.ChatItemPreview",
        "ChatWnd",
        "TopLeft",
        "TopLeft",
        X,
        Y
    );

    class'NWindow.UIAPI_WINDOW'.static.SetAlpha(
        "ChatWnd.ChatItemPreview",
        0
    );

    bChatItemPreviewOpen = True;
    ChatItemPreview.ShowWindow();

    class'NWindow.UIAPI_WINDOW'.static.SetUITimer(
        "ChatWnd",
        98431,
        50
    );
}

function OnRClickItemWithHandle(
    ItemWindowHandle Handle,
    int Index)
{
    if(Handle == ChatItemPreview)
    {
        CloseChatItemPreview();
    }
}

function CloseChatItemPreview()
{
    class'NWindow.UIAPI_WINDOW'.static.KillUITimer(
        "ChatWnd",
        98431
    );

    bChatItemPreviewOpen = False;

    if(ChatItemPreview != None)
    {
        ChatItemPreview.HideWindow();
        ChatItemPreview.SetTooltipType("undefined");
        ChatItemPreview.Clear();
    }
}

function CheckChatItemPreviewMouse()
{
    local LineagePlayerController Controller;
    local Rect PreviewRect;
    local int MouseX;
    local int MouseY;

    if(!bChatItemPreviewOpen)
    {
        CloseChatItemPreview();
        return;
    }

    if(ChatItemPreview == None)
    {
        CloseChatItemPreview();
        return;
    }

    if(!ChatItemPreview.IsShowWindow())
    {
        CloseChatItemPreview();
        return;
    }

    if(!GetPlayerController(Controller))
    {
        CloseChatItemPreview();
        return;
    }

    if(Controller == None)
    {
        CloseChatItemPreview();
        return;
    }

    if(Controller.Player == None)
    {
        CloseChatItemPreview();
        return;
    }

    PreviewRect = ChatItemPreview.GetRect();

    MouseX = int(Controller.Player.WindowsMouseX);
    MouseY = int(Controller.Player.WindowsMouseY);

    if(MouseX < PreviewRect.nX
        || MouseX >= PreviewRect.nX + PreviewRect.nWidth
        || MouseY < PreviewRect.nY
        || MouseY >= PreviewRect.nY + PreviewRect.nHeight)
    {
        CloseChatItemPreview();
    }
}

function InitChatItemRuntime()
{
    local array<ChatItemProperty> EmptyProperties;
    local ItemInfo EmptyInfo;

    ChatItemPendingVersion = 0;
    ChatItemHandledVersion = 0;

    // Carrega as funcoes durante a inicializacao da interface.
    OnChatItemInfoTooltip(
        0, 0, 0, 0, 0, 0, 0, 0, 0,
        EmptyProperties,
        vect(0, 0, 0)
    );

    EmptyInfo.ClassID = 0;
    ShowChatItemPreview(EmptyInfo, vect(0, 0, 0));

    ProcessPendingChatItemPreview();

    class'NWindow.UIAPI_WINDOW'.static.SetUITimer(
        "ChatWnd",
        98432,
        50
    );
}

function ProcessPendingChatItemPreview()
{
    local ItemInfo Info;
    local int Version;
    local int ItemID;
    local int Enchant;
    local int Quantity;
    local int Refinery1;
    local int Refinery2;
    local Vector MousePosition;

    Version = ChatItemPendingVersion;

    if(Version == ChatItemHandledVersion
        || (Version & 1) != 0)
    {
        return;
    }

    ItemID = ChatItemPendingID;
    Enchant = ChatItemPendingEnchant;
    Quantity = ChatItemPendingQuantity;
    Refinery1 = ChatItemPendingRefinery1;
    Refinery2 = ChatItemPendingRefinery2;
    MousePosition = ChatItemPendingMouse;

    // Se os dados mudaram durante a leitura, tenta no proximo timer.
    if(Version != ChatItemPendingVersion)
        return;

    ChatItemHandledVersion = Version;

    if(ItemID <= 0 || Quantity <= 0)
        return;

    if(!class'UIDATA_ITEM'.static.GetItemInfo(ItemID, Info))
        return;

    if(Len(Info.IconName) == 0)
        return;

    Info.ClassID = ItemID;
    Info.ServerID = 0;
    Info.bEquipped = False;
    Info.Enchanted = Enchant;
    Info.ItemNum = Quantity;
    Info.RefineryOp1 = Refinery1;
    Info.RefineryOp2 = Refinery2;

    ShowChatItemPreview(Info, MousePosition);
}

