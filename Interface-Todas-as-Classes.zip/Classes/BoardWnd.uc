class BoardWnd extends UIScript;

var WindowHandle Me;
var bool m_bShow;

var AnimTextureHandle DailyGlow;
var TextureHandle DailyGlowFrame;
var int m_GlowDay;

const FRAME_X = 18;
const FRAME_Y = 104;
const FRAME_STEP_X = 64;
const FRAME_STEP_Y = 88;

function OnLoad()
{
    local int Day;
    local int Index;
    local string Path;
    local TextureHandle Frame;

    Me = GetHandle("BoardWnd");
    m_bShow = false;

    if (Me != None)
        Me.SetWindowTitle("Daily Rewards");

    for (Day = 1; Day <= 28; Day++)
    {
        Path = "BoardWnd.ClaimedDay" $ string(Day);
        Frame = TextureHandle(GetHandle(Path));

        if (Frame != None)
        {
            Index = Day - 1;

            Frame.SetTexture("iconfox-v3.AttendTodayEffect_checked");

            Frame.ClearAnchor();
            Frame.SetWindowSize(64, 128);
            Frame.SetAnchor("BoardWnd","TopLeft","TopLeft",FRAME_X + (Index % 7) * FRAME_STEP_X,FRAME_Y + (Index / 7) * FRAME_STEP_Y);
            Frame.SetAlpha(255);
            Frame.HideWindow();
        }
    }

    SetupSpecialDays();
    SetupDailyDecorations();

    RegisterEvent(1200);
    RegisterEvent(70);
}

function OnShow()
{
    m_bShow = true;
}

function OnHide()
{
    m_bShow = false;

    HideClaimedFrames();
    StopDailyGlow();
}

function OnEvent(int Event_ID, string Param)
{
    switch (Event_ID)
    {
        case 1200:
            HandleShowBoardPacket(Param);
            break;

        case 70:
            CloseDailyReward();
            break;
    }
}

function HandleShowBoardPacket(string Param)
{
    local int OK;
    local int LastDay;
    local int GlowDay;

    local string Address;
    local string Command;
    local string GlowCommand;

    ParseInt(Param, "OK", OK);

    if (OK < 1)
    {
        CloseDailyReward();
        return;
    }

    ParseString(Param, "Address", Address);

    class'UIAPI_HTMLCTRL'.static.SetHtmlBuffData(
        "BoardWnd.HtmlViewer",
        Address
    );

    if (!m_bShow)
        PlaySound("InterfaceSound.system_open_01");

    class'UIAPI_WINDOW'.static.ShowWindow("BoardWnd");
    class'UIAPI_WINDOW'.static.SetFocus("BoardWnd");

    ParseString(Param, "Command1", Command);

    if (Left(Command, 14) == "daily_claimed ")
    {
        LastDay = int(Mid(Command, 14));
        UpdateClaimedFrames(LastDay);
    }
    else
    {
        HideClaimedFrames();
    }

    ParseString(Param, "Command2", GlowCommand);

    if (Left(GlowCommand, 11) == "daily_glow ")
    {
        GlowDay = int(Mid(GlowCommand, 11));
        UpdateDailyGlow(GlowDay);
    }
    else
    {
        StopDailyGlow();
    }

    ShowDailyLogo();

    class'UIAPI_WINDOW'.static.SetFocus(
        "BoardWnd.HtmlViewer"
    );
}

function UpdateClaimedFrames(int LastDay)
{
    local int Day;
    local WindowHandle Frame;

    if (LastDay < 0)
        LastDay = 0;

    if (LastDay > 28)
        LastDay = 28;

    for (Day = 1; Day <= 28; Day++)
    {
        Frame = GetHandle(
            "BoardWnd.ClaimedDay" $ string(Day)
        );

        if (Frame != None)
        {
            if (Day <= LastDay)
                Frame.ShowWindow();
            else
                Frame.HideWindow();
        }
    }
}

function HideClaimedFrames()
{
    local int Day;
    local WindowHandle Frame;

    for (Day = 1; Day <= 28; Day++)
    {
        Frame = GetHandle(
            "BoardWnd.ClaimedDay" $ string(Day)
        );

        if (Frame != None)
            Frame.HideWindow();
    }
}

function OnClickButton(string strID)
{
    switch (Caps(strID))
    {
        case "BTNCLOSE":
        case "CLOSE":
        case "CLOSEBUTTON":
            CloseDailyReward();
            break;
    }
}

function CloseDailyReward()
{
    HideClaimedFrames();
    StopDailyGlow();

    class'UIAPI_WINDOW'.static.HideWindow(
        "BoardWnd"
    );

    class'UIAPI_HTMLCTRL'.static.Clear(
        "BoardWnd.HtmlViewer"
    );

    m_bShow = false;
}

function SetupDailyDecorations()
{
    // Same native animation mechanism used by the model DailyRewardWnd.
    // DailyGlow must be an animated texture control in Interface.xdat.
    DailyGlow = AnimTextureHandle(GetHandle("BoardWnd.DailyGlow"));
    DailyGlowFrame = TextureHandle(GetHandle("BoardWnd.DailyGlowFrame"));

    if (DailyGlowFrame != None)
    {
        DailyGlowFrame.SetTexture("L2UI_CT1.AttendCheckWnd.CheckEffect_BG");
        DailyGlowFrame.SetWindowSize(64, 128);
        DailyGlowFrame.SetAlpha(255);
    }

    if (DailyGlow != None)
    {
        DailyGlow.SetWindowSize(64, 84);
        DailyGlow.SetAlpha(255);
        DailyGlow.SetLoopCount(-1);
    }

    StopDailyGlow();
}

function ShowDailyLogo()
{
    local TextureHandle Logo;

    Logo = TextureHandle(
        GetHandle("BoardWnd.DailyLogo")
    );

    if (Logo == None)
    {
        DebugLog("DailyLogo: handle indisponivel.");
        return;
    }

    Logo.SetTexture("L2UI_CH3.LoginWnd.Logo_Classic-e");
    Logo.ClearAnchor();
    Logo.SetWindowSize(400, 96);
    Logo.SetAnchor("BoardWnd","TopCenter","TopCenter",0,8);
    Logo.SetAlpha(255);
    Logo.ShowWindow();
}

function SetupSpecialDays()
{
    local int Day;
    local int Index;
    local string Path;
    local TextureHandle Frame;

    for (Day = 7; Day <= 28; Day = Day + 7)
    {
        Path = "BoardWnd.SpecialDay" $ string(Day);
        Frame = TextureHandle(GetHandle(Path));

        if (Frame != None)
        {
            Index = Day - 1;

            Frame.SetTexture("iconfox-v3.SpecialSlot");
            Frame.ClearAnchor();
            Frame.SetWindowSize(64, 128);
            Frame.SetAnchor("BoardWnd","TopLeft","TopLeft",FRAME_X + (Index % 7) * FRAME_STEP_X,FRAME_Y + (Index / 7) * FRAME_STEP_Y);
            Frame.SetAlpha(255);
            Frame.ShowWindow();
        }
    }
}

function UpdateDailyGlow(int Day)
{
    local int Index;
    local int X;
    local int Y;

    if (Day < 1 || Day > 28)
    {
        StopDailyGlow();
        return;
    }

    if (Me == None || DailyGlow == None || DailyGlowFrame == None)
        return;

    // Keep the animation phase while the same claim day remains selected.
    if (m_GlowDay == Day)
        return;

    StopDailyGlow();

    Index = Day - 1;
    X = FRAME_X + (Index % 7) * FRAME_STEP_X;
    Y = FRAME_Y + (Index / 7) * FRAME_STEP_Y;

    DailyGlowFrame.ClearAnchor();
    DailyGlowFrame.SetWindowSize(64, 128);
    DailyGlowFrame.SetAnchor("BoardWnd", "TopLeft", "TopLeft", X, Y);
    DailyGlowFrame.SetAlpha(255);

    // Model DRLight is 6 pixels above/left of DRCheck, with size 64x84.
    DailyGlow.ClearAnchor();
    DailyGlow.SetWindowSize(64, 84);
    DailyGlow.SetAnchor("BoardWnd", "TopLeft", "TopLeft", X - 6, Y - 6);
    DailyGlow.SetAlpha(255);

    m_GlowDay = Day;
    DailyGlowFrame.ShowWindow();
    DailyGlow.ShowWindow();
    DailyGlow.SetLoopCount(-1);
    DailyGlow.Play();
}



function StopDailyGlow()
{
    if (DailyGlow != None)
    {
        DailyGlow.Stop();
        DailyGlow.HideWindow();
    }

    if (DailyGlowFrame != None)
        DailyGlowFrame.HideWindow();

    m_GlowDay = 0;
}

static function DebugLog(string Msg)
{
    local Color Col;

    Col.R = 0;
    Col.G = 220;
    Col.B = 255;
    Col.A = 255;

    class'NWindow.UIAPI_TEXTLISTBOX'.static.AddString(
        "ChatWnd.NormalChat",
        "[Tema] " $ Msg,
        Col
    );
}

