class MountBtnWnd extends UICommonAPI;

var WindowHandle Me;
var WindowHandle Selector;
var WindowHandle MountBox;

var ItemWindowHandle MountItem;
var ItemWindowHandle MountList;

var array<int> MountIDs;

var int SelectedID;
var int AutoMountAttempts;
var int AutoMountPetID;

var string CharacterName;

var bool bMount;
var bool bAutoMountPending;


// INICIALIZACAO

function InitHandles()
{
    Me = GetHandle("MountBtnWnd");

    Selector = xxGetWindowHandle(
        "MountBtnWnd.SetMountWnd"
    );

    MountBox = xxGetWindowHandle(
        "MountBtnWnd.box_itemMount"
    );

    MountItem = xxGetItemWindowHandle(
        "MountBtnWnd.itemMount"
    );

    MountList = xxGetItemWindowHandle(
        "MountBtnWnd.listMount"
    );
}

function OnLoad()
{
    InitHandles();
    InitMountIDs();

    RegisterEvent(99982);

    if(Selector != None)
        Selector.HideWindow();

    if(Me != None)
    {
        Me.KillTimer(80901);
        Me.SetTimer(80901, 500);
    }
}

function OnEnterState(name PreviousState)
{
    CharacterName = "";
    SelectedID = 4422;
    bMount = false;

    InitHandles();

    CancelAutoMount(
        "OnEnterState: " $ string(PreviousState)
    );

    if(Selector != None)
        Selector.HideWindow();

    if(Me != None)
    {
        Me.KillTimer(80901);
        Me.SetTimer(80901, 500);
    }

    AnchorMountBtn();
}

function OnExitState(name NextState)
{
    CancelAutoMount(
        "OnExitState: " $ string(NextState)
    );

    if(Me != None)
    {
        Me.KillTimer(80901);
        Me.HideWindow();
    }

    if(Selector != None)
        Selector.HideWindow();

    CharacterName = "";
    bMount = false;
}

function OnEvent(int EventID, string param)
{
    local int MountState;

    if(EventID != 99982)
        return;

    if(!ParseInt(param, "mount", MountState))
        return;

    bMount = MountState == 1;

    if(Selector != None)
        Selector.HideWindow();

    RefreshButton();
}


// MONTAGEM AUTOMATICA

function CancelAutoMount(optional string Reason)
{
    bAutoMountPending = false;

    if(Me != None)
    {
        Me.KillTimer(80902);
        Me.KillTimer(80903);
    }

    AutoMountAttempts = 0;
    AutoMountPetID = 0;
}

function OnTimer(int TimerID)
{
    local PetInfo Pet;
    local UserInfo Info;
    local LineagePlayerController PC;

    if(Me == None)
        return;

    // Timer de espera pela invocacao do pet.
    if(TimerID == 80902)
    {
        Me.KillTimer(80902);

        if(!bAutoMountPending)
            return;

        if(!GetPlayerInfo(Info))
        {
            CancelAutoMount(
                "Jogador indisponivel no timer 80902"
            );

            return;
        }

        AutoMountAttempts++;

        if(GetPetInfo(Pet))
        {
            if(Pet.nID > 0)
            {
                AutoMountPetID = Pet.nID;

                RequestAction(Pet.nID, Info.Loc);

                Me.SetTimer(80903, 700);
                return;
            }
        }

        if(AutoMountAttempts < 5)
        {
            Me.SetTimer(80902, 1000);
        }
        else
        {
            CancelAutoMount(
                "Pet nao encontrado apos 5 tentativas"
            );
        }

        return;
    }

    // Timer de espera entre selecionar e montar.
    if(TimerID == 80903)
    {
        Me.KillTimer(80903);

        if(!bAutoMountPending)
            return;

        if(!GetPlayerInfo(Info))
        {
            CancelAutoMount(
                "Jogador indisponivel no timer 80903"
            );

            return;
        }

        if(!GetPetInfo(Pet))
        {
            CancelAutoMount(
                "Pet indisponivel no timer 80903"
            );

            return;
        }

        if(AutoMountPetID <= 0 ||
            Pet.nID != AutoMountPetID)
        {
            CancelAutoMount(
                "ID do pet mudou antes de montar"
            );

            return;
        }

        if(GetPlayerController(PC))
        {
            if(PC.Pawn != None)
            {
                if(PC.Pawn.bRide ||
                    PC.Pawn.RidePawn != None)
                {
                    CancelAutoMount(
                        "Personagem detectado como montado"
                    );

                    return;
                }
            }
        }

        ExecuteCommand("/mount");

        CancelAutoMount("Comando enviado");
        return;
    }

    // Timer normal de atualizacao do icone.
    if(TimerID != 80901)
        return;

    if(!GetPlayerInfo(Info))
    {
        CancelAutoMount(
            "Jogador indisponivel na atualizacao 80901"
        );

        if(Selector != None)
            Selector.HideWindow();

        Me.HideWindow();
        return;
    }

    if(CharacterName != Info.Name)
    {
        CharacterName = Info.Name;
        SelectedID = 4422;

        if(Selector != None)
            Selector.HideWindow();

        AnchorMountBtn();
    }

    if(GetPlayerController(PC))
    {
        if(PC.Pawn != None)
        {
            bMount = PC.Pawn.bRide ||
                PC.Pawn.RidePawn != None;
        }
    }

    RefreshButton();
}


// ITENS DE MONTARIA

function InitMountIDs()
{
    local int ItemID;
    local int Position;

    MountIDs.Length = 36;

    Position = 0;
    MountIDs[Position] = 4422;
    Position++;

    for(ItemID = 10133; ItemID <= 10142; ItemID++)
    {
        MountIDs[Position] = ItemID;
        Position++;
    }

    for(ItemID = 29000; ItemID <= 29009; ItemID++)
    {
        MountIDs[Position] = ItemID;
        Position++;
    }

    for(ItemID = 31830; ItemID <= 31844; ItemID++)
    {
        MountIDs[Position] = ItemID;
        Position++;
    }

    SelectedID = 4422;
}

function bool FindMount(int ClassID, out ItemInfo Info)
{
    local ItemWindowHandle Inventory;
    local ItemInfo Candidate;
    local int i;

    if(ClassID <= 0)
        return false;

    Inventory = xxGetItemWindowHandle(
        "InventoryWnd.InventoryItem"
    );

    if(Inventory == None)
        return false;

    for(i = 0; i < Inventory.GetItemNum(); i++)
    {
        if(Inventory.GetItem(i, Candidate))
        {
            if(Candidate.ClassID == ClassID)
            {
                Info = Candidate;
                return true;
            }
        }
    }

    return false;
}

function ItemInfo GetStriderDisplayItem()
{
    local ItemInfo Info;

    FindMount(4422, Info);

    Info.ClassID = 4422;
    Info.Name = "Strider";
    Info.IconName = "icon.etc_bugle_i00";

    return Info;
}


// EXIBICAO

function SetSelectorTitle()
{
    local TextBoxHandle Title;

    Title = xxGetTextBoxHandle(
        "MountBtnWnd.SetMountWnd.headerMount"
    );

    if(Title != None)
        Title.SetText("Selecione a montaria");
}

function RefreshButton()
{
    local ItemInfo Info;

    if(Me == None
        || MountBox == None
        || MountItem == None)
    {
        return;
    }

    if(bMount)
    {
        Info.ClassID = 38;
        Info.ItemSubType = 3;
        Info.Name = "Desmontar";
        Info.IconName = "icon.action036";
    }
    else
    {
        if(FindSelectedMount(Info))
        {
            if(SelectedID == 4422)
                Info = GetStriderDisplayItem();
        }
        else
        {
            // Mantem o botao visivel mesmo sem possuir montaria.
            Info = GetStriderDisplayItem();
        }
    }

    if(MountItem.GetItemNum() == 0)
        MountItem.AddItem(Info);
    else
        MountItem.SetItem(0, Info);

    MountBox.SetTooltipCustomType(MakeMountTooltip());

    SetSelectorTitle();

    Me.ShowWindow();
    MountBox.ShowWindow();
    MountItem.ShowWindow();

    UpdateCompactToolbar();
}

function OnHide()
{
    if(Selector != None)
        Selector.HideWindow();
}

function OnShow()
{
    UpdateCompactToolbar();
}


// ACOES

function HandleMountDismount()
{
    if(bMount)
        HandleDismount();
    else
        HandleMount();
}

function HandleMount()
{
    local ItemInfo Info;

    if(Me == None || bAutoMountPending)
        return;

    if(!FindSelectedMount(Info))
        return;

    CancelAutoMount("Nova tentativa solicitada");

    if(Selector != None)
        Selector.HideWindow();

    // Montarias personalizadas: o servidor monta diretamente.
    if(SelectedID != 4422)
    {
        RequestUseItem(Info.ServerID);
        return;
    }

    // Strider: preserva a invocacao do pet e o comando /mount.
    bAutoMountPending = true;

    RequestUseItem(Info.ServerID);

    if(!bAutoMountPending)
        return;

    Me.SetTimer(80902, 3000);
}

function HandleDismount()
{
    CancelAutoMount("Acao de desmontar solicitada");

    DoAction(38);

    if(Selector != None)
        Selector.HideWindow();

    HideWindowTutorial("BtnMount");
}

function OnClickItem(string ID, int Index)
{
    if(Index < 0)
        return;

    if(ID == "itemMount")
        HandleMountDismount();

    if(ID == "listMount")
        SelectMount(Index);
}

function OnRClickItem(string ID, int Index)
{
    if(ID == "listMount")
    {
        SelectMount(Index);
        return;
    }

    if(ID != "itemMount")
        return;

    if(Selector == None || MountList == None)
        return;

    if(Selector.IsShowWindow())
    {
        Selector.HideWindow();
        return;
    }

    PopulateMountList();

    if(MountList.GetItemNum() == 0)
        return;

    SetSelectorTitle();

    Selector.ShowWindow();
    MountList.ShowWindow();

    xxGetWindowHandle(
        "MountBtnWnd.SetMountWnd.headerMount"
    ).ShowWindow();
}

function SelectMount(int Index)
{
    local ItemInfo Info;

    if(MountList == None || Index < 0)
        return;

    if(!MountList.GetItem(Index, Info))
        return;

    if(!IsSupportedMount(Info.ClassID))
        return;

    SelectedID = Info.ClassID;

    if(Selector != None)
        Selector.HideWindow();

    RefreshButton();
}


// INTEGRACAO COM A BARRA

function UpdateCompactToolbar()
{
    local CompactToolbarWnd Toolbar;

    Toolbar = CompactToolbarWnd(
        GetScript("CompactToolbarWnd")
    );

    if(Toolbar != None)
        Toolbar.ApplyLayout();
}

function AnchorMountBtn()
{
    local AutoPotionsWnd Potions;
    local bool Vertical;

    if(Me == None ||
        MountBox == None ||
        MountItem == None ||
        Selector == None)
        return;

    Potions = AutoPotionsWnd(
        GetScript("AutoPotionsWnd")
    );

    if(Potions == None)
        return;

    Vertical = Potions.IsVertical();

    MountBox.ClearAnchor();
    MountItem.ClearAnchor();
    Selector.ClearAnchor();

    if(Vertical)
    {
        Me.SetWindowSize(32, 80);

        MountBox.SetAnchor(
            "MountBtnWnd",
            "TopLeft", "TopLeft",
            0, 39
        );

        Selector.SetAnchor(
            "MountBtnWnd.box_itemMount",
            "TopLeft", "TopRight",
            0, -4
        );
    }
    else
    {
        Me.SetWindowSize(80, 40);

        MountBox.SetAnchor(
            "MountBtnWnd",
            "TopLeft", "TopLeft",
            39, 0
        );

        Selector.SetAnchor(
            "MountBtnWnd.box_itemMount",
            "TopLeft", "BottomLeft",
            -4, 0
        );
    }

    MountBox.SetWindowSize(32, 32);

    MountItem.SetAnchor(
        "MountBtnWnd.box_itemMount",
        "TopLeft", "TopLeft",
        0, 0
    );

    MountItem.SetWindowSize(32, 32);

    UpdateCompactToolbar();
}

function bool IsSupportedMount(int ClassID)
{
    local int i;

    for(i = 0; i < MountIDs.Length; i++)
    {
        if(MountIDs[i] == ClassID)
            return true;
    }

    return false;
}

function bool FindSelectedMount(out ItemInfo Info)
{
    local int i;

    // Mantem a selecao enquanto o jogador possuir o item.
    if(IsSupportedMount(SelectedID))
    {
        if(FindMount(SelectedID, Info))
            return true;
    }

    // Se a selecao nao estiver disponivel, procura outra.
    for(i = 0; i < MountIDs.Length; i++)
    {
        if(FindMount(MountIDs[i], Info))
        {
            SelectedID = MountIDs[i];
            return true;
        }
    }

    return false;
}

function PopulateMountList()
{
    local ItemInfo Info;
    local int i;

    if(MountList == None)
        return;

    MountList.Clear();

    for(i = 0; i < MountIDs.Length; i++)
    {
        if(FindMount(MountIDs[i], Info))
        {
            if(MountIDs[i] == 4422)
                Info = GetStriderDisplayItem();

            MountList.AddItem(Info);
        }
    }
}

// TOOLTIP DO BOTAO PRINCIPAL

function CustomTooltip MakeMountTooltip()
{
    local CustomTooltip Tooltip;
    local string Title;

    if(bMount)
        Title = "Desmontar";
    else
        Title = "Montar";

    Tooltip.DrawList.Length = 3;

    Tooltip.DrawList[0] = xxDrawText(
        Title,
        getAColor(255, 255, 255, 255),
        true, true, 2, 2
    );

    Tooltip.DrawList[1] = DrawTex(
        "L2UI_CH3.tooltip_line",
        175, 1,
        -1, -1,
        0, 3,
        true, true
    );

    Tooltip.DrawList[2] = xxDrawText(
        "Botao direito seleciona montaria",
        getAColor(255, 200, 0, 255),
        true, true, 2, 2
    );

    return Tooltip;
}


// COMPATIBILIDADE COM CHAMADAS ANTIGAS

function ShowMountTest()
{
    AnchorMountBtn();
    RefreshButton();
}


static function DebugLog(string Msg)
{
}
