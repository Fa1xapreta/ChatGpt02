class L2PassWnd extends UICommonAPI;

const _obf3518 = 28632;
const _obf3519 = 28633;
const _obf3520 = 28634;
const _obf3521 = 28635;
const _obf3522 = 28636;
const HUNTPASS_REFRESH_TIMER_ID = 2863601;
const HUNTPASS_REFRESH_DELAY = 2000;

var TextureHandle VipSayhasIcon_Texture;
var TextureHandle VipSayhasBG_Texture;
var TextureHandle TextFechaExpiracionBg_Texture;
var WindowHandle _obf2486;
var ButtonHandle _obf3523[10];
var ItemWindowHandle _obf3524[10];
var TextBoxHandle _obf3525[10];
var TextureHandle _obf3526[10];
var TextureHandle _obf3527[10];
var TextureHandle _obf3528[10];
var AnimTextureHandle _obf3529[10];
var ButtonHandle _obf3530[10];
var ItemWindowHandle _obf3531[10];
var TextBoxHandle _obf3532[10];
var TextureHandle _obf3533[10];
var TextureHandle _obf3534[10];
var TextureHandle _obf3535[10];
var AnimTextureHandle _obf3536[10];
var ButtonHandle _obf3537;
var ButtonHandle _obf3538;
var ButtonHandle _obf3539;
var ButtonHandle _obf3540;
var ButtonHandle _obf3541;
var ButtonHandle _obf3542;
var ButtonHandle _obf3543;
var int _obf3544;
var int _obf3545;
var int _obf3546;
var int _obf3547;
var int _obf3548;
var int _obf3549;
var int _obf3550;
var int zzDialogIdResetPass;
var bool zzHuntPassEnabled;
var bool zzHuntPassMenuOpen;
var ButtonHandle zzHuntPassMenuBtn;
var WindowHandle zzHuntPassMenuWnd;
var ButtonHandle zzHuntPassMenuClaimBtn;
var ButtonHandle zzHuntPassMenuResetBtn;
var ButtonHandle zzHuntPassMenuRefreshBtn;
var ButtonHandle zzHuntPassMenuClaimHitBtn;
var ButtonHandle zzHuntPassMenuResetHitBtn;
var ButtonHandle zzHuntPassMenuRefreshHitBtn;
var TextureHandle zzVipSayhasIconTexture;
var TextureHandle zzVipSayhasTextBgTexture;
var AnimTextureHandle zzVipSayhasLampBgAni;
var TextBoxHandle zzVipActivedText;
var TextBoxHandle zzNonVipText;

function bool IsHuntPassEnabled()
{
	return zzHuntPassEnabled;
}

function int zzGetSafeCurrentPage()
{
	// End:0x0D
	if((_obf3548 < 1))
	{
		return 1;
	}
	// End:0x2F
	if(((_obf3547 > 0) && (_obf3548 > _obf3547)))
	{
		return _obf3547;
	}
	return _obf3548;
}

function zzInitHuntPassExtensionHandles()
{
	zzHuntPassMenuBtn = _obf29("L2PassWnd.HuntPassMenu_BTN");
	zzHuntPassMenuWnd = GetHandle("L2PassWnd.HuntPassMenu_Wnd");
	zzHuntPassMenuClaimBtn = _obf29("L2PassWnd.HuntPassMenuClaim_BTN");
	zzHuntPassMenuResetBtn = _obf29("L2PassWnd.HuntPassMenuReset_BTN");
	zzHuntPassMenuRefreshBtn = _obf29("L2PassWnd.HuntPassMenuRefresh_BTN");
	zzHuntPassMenuClaimHitBtn = _obf29("L2PassWnd.HuntPassMenuClaim_Hit_BTN");
	zzHuntPassMenuResetHitBtn = _obf29("L2PassWnd.HuntPassMenuReset_Hit_BTN");
	zzHuntPassMenuRefreshHitBtn = _obf29("L2PassWnd.HuntPassMenuRefresh_Hit_BTN");
	TextFechaExpiracionBg_Texture = _obf46("L2PassWnd.texHuntPass_Groupbox1.TextFechaExpiracionBg_Texture");

	zzVipSayhasLampBgAni = _obf65("L2PassWnd.VipSayhasLampBg_AniTexture");

    zzVipSayhasIconTexture = _obf46("L2PassWnd.VipSayhasIcon_Texture");

    zzVipSayhasTextBgTexture = _obf46("L2PassWnd.VipSayhasBG_Texture");

    zzVipActivedText = _obf58("L2PassWnd.texHuntPass_Groupbox1.PassInfo_wnd.VipSayhasText");

    zzNonVipText = _obf58("L2PassWnd.NonVip_Text");
	return;

}

function zzCloseHuntPassMenu()
{
	zzHuntPassMenuOpen = false;
	zzHuntPassMenuWnd.HideWindow();
	return;
}

function zzToggleHuntPassMenu()
{
	// End:0x12
	if(zzHuntPassMenuOpen)
	{
		zzCloseHuntPassMenu();		
	}
	else
	{
		zzHuntPassMenuOpen = true;
		zzHuntPassMenuWnd.ShowWindow();
	}
	return;
}

function zzPlayVipLampAnim()
{

	zzStopVipLampAnim();
	return;
}

function zzStopVipLampAnim()
{
	zzVipSayhasLampBgAni.Stop();
	zzVipSayhasLampBgAni.HideWindow();
	return;
}

function zzHideVipActiveBadge()
{
    // Para a animação
    zzStopVipLampAnim();

    // Ícone VIP
    if(zzVipSayhasIconTexture != None)
        zzVipSayhasIconTexture.HideWindow();

    // Fundo/textura VIP
    if(zzVipSayhasTextBgTexture != None)
        zzVipSayhasTextBgTexture.HideWindow();

    // Texto "Vip Actived"
    if(zzVipActivedText != None)
        zzVipActivedText.HideWindow();

    // Texto Non Vip também fica oculto
    if(zzNonVipText != None)
        zzNonVipText.HideWindow();

    return;
}

function zzUpdateVipActiveBadge(bool bActive)
{
    if(bActive)
    {
        if(zzVipSayhasIconTexture != None)
            zzVipSayhasIconTexture.ShowWindow();

        if(zzVipSayhasTextBgTexture != None)
            zzVipSayhasTextBgTexture.ShowWindow();

        if(zzVipActivedText != None)
        {
            zzVipActivedText.SetText("Vip Actived");
            zzVipActivedText.SetTextColor(_obf33(255, 215, 80, 255));
            zzVipActivedText.ShowWindow();
        }

        if(zzNonVipText != None)
            zzNonVipText.HideWindow();

        zzPlayVipLampAnim();
    }
    else
    {
        // ESCONDE TUDO relacionado ao VIP
        if(zzVipSayhasIconTexture != None)
            zzVipSayhasIconTexture.HideWindow();

        if(zzVipSayhasTextBgTexture != None)
            zzVipSayhasTextBgTexture.HideWindow();

        if(zzVipActivedText != None)
            zzVipActivedText.HideWindow();

        if(zzNonVipText != None)
            zzNonVipText.HideWindow();

        zzStopVipLampAnim();
    }

    return;
}

function zzSetPremiumPriceVisibility(bool bVisible)
{
	// End:0x97
	if(bVisible)
	{
		ShowWindow("L2PassWnd.textvalpremium");
		ShowWindow("L2PassWnd.textvalpremiumcoin");
		ShowWindow("L2PassWnd.textvalpremiumnome");
		ShowWindow("L2PassWnd.texturevalpremium");		
	}
	else
	{
		HideWindow("L2PassWnd.textvalpremium");
		HideWindow("L2PassWnd.textvalpremiumcoin");
		HideWindow("L2PassWnd.textvalpremiumnome");
		HideWindow("L2PassWnd.texturevalpremium");
	}
	return;
}

function zzHideHuntPass()
{
	zzHideVipActiveBadge();
	zzCloseHuntPassMenu();
	_obf2486.HideWindow();
	return;
}

function OnLoad()
{
	local int _obf5804;

	RegisterEvent(28632);
	RegisterEvent(28633);
	RegisterEvent(28634);
	RegisterEvent(28635);
	RegisterEvent(28636);
	RegisterEvent(1710);
	RegisterEvent(1720);
	_obf2486 = GetHandle("L2PassWnd");
	_obf3548 = 1;
	_obf3544 = 9901;
	zzDialogIdResetPass = 9902;
	zzHuntPassEnabled = true;
	zzInitHuntPassExtensionHandles();
	_obf3537 = _obf29("L2PassWnd.HuntPassTab_Wnd.ControlNaviHunt_PrevBtn");
	_obf3538 = _obf29("L2PassWnd.HuntPassTab_Wnd.ControlNaviHunt_NextBtn");
	_obf3539 = _obf29("L2PassWnd.PageNaviControl.ControlNavi_PrevBtn");
	_obf3540 = _obf29("L2PassWnd.PageNaviControl.ControlNavi_NextBtn");
	_obf3541 = _obf29("L2PassWnd.PremiumActive_BTN");
	_obf3542 = _obf29("L2PassWnd.GetReward_Btn");
	_obf3543 = _obf29("L2PassWnd.texHuntPass_Groupbox1.PassInfo_wnd.Help_btn");

	if (_obf3542 != None)
		_obf3542.SetButtonName(1127);
	if (_obf3541 != None)
		_obf3541.SetButtonName(1964);
	_obf5804 = 0;
	J0x21B:

	// End:0x707 [Loop If]
	if((_obf5804 < 10))
	{
		_obf3523[_obf5804] = _obf29((("L2PassWnd.HuntPassTab_Wnd.Section0" $ string(_obf5804)) $ ".RewardBase_Btn"));
		_obf3524[_obf5804] = _obf27((("L2PassWnd.HuntPassTab_Wnd.Section0" $ string(_obf5804)) $ ".Reward_ItemWnd"));
		_obf3525[_obf5804] = _obf58((("L2PassWnd.HuntPassTab_Wnd.Section0" $ string(_obf5804)) $ ".RewardItemNem_Text"));
		_obf3526[_obf5804] = _obf46((("L2PassWnd.HuntPassTab_Wnd.Section0" $ string(_obf5804)) $ ".P_ActiveBG_texture"));
		_obf3527[_obf5804] = _obf46((("L2PassWnd.HuntPassTab_Wnd.Section0" $ string(_obf5804)) $ ".CountStateBGSet_texture"));
		_obf3528[_obf5804] = _obf46((("L2PassWnd.HuntPassTab_Wnd.Section0" $ string(_obf5804)) $ ".RewardStateIcon_texture"));
		_obf3529[_obf5804] = _obf65((("L2PassWnd.HuntPassTab_Wnd.Section0" $ string(_obf5804)) $ ".RewardCountStateBG_animTex"));
		_obf3530[_obf5804] = _obf29((("L2PassWnd.HuntPassTab_Wnd.P_Section0" $ string(_obf5804)) $ ".RewardBase_Btn"));
		_obf3531[_obf5804] = _obf27((("L2PassWnd.HuntPassTab_Wnd.P_Section0" $ string(_obf5804)) $ ".Reward_ItemWnd"));
		_obf3532[_obf5804] = _obf58((("L2PassWnd.HuntPassTab_Wnd.P_Section0" $ string(_obf5804)) $ ".RewardItemNem_Text"));
		_obf3533[_obf5804] = _obf46((("L2PassWnd.HuntPassTab_Wnd.P_Section0" $ string(_obf5804)) $ ".P_ActiveBG_texture"));
		_obf3534[_obf5804] = _obf46((("L2PassWnd.HuntPassTab_Wnd.P_Section0" $ string(_obf5804)) $ ".CountStateBGSet_texture"));
		_obf3535[_obf5804] = _obf46((("L2PassWnd.HuntPassTab_Wnd.P_Section0" $ string(_obf5804)) $ ".RewardStateIcon_texture"));
		_obf3536[_obf5804] = _obf65((("L2PassWnd.HuntPassTab_Wnd.P_Section0" $ string(_obf5804)) $ ".RewardCountStateBG_animTex"));
		_obf5804++;
		// [Loop Continue]
		goto J0x21B;
	}
	zzHideHuntPass();
	return;
}

function UpdateVipActiveStatus(bool bIsVipActive)
{
    if (bIsVipActive)
    {
        // Se for VIP / Premium ativado: mostra os dois elementos
        VipSayhasIcon_Texture.ShowWindow();
        VipSayhasBG_Texture.ShowWindow();
    }
    else
    {
        // Se NÃO for VIP / Premium: esconde os dois elementos
        VipSayhasIcon_Texture.HideWindow();
        VipSayhasBG_Texture.HideWindow();
    }
}

function OnShow()
{
    if(!zzHuntPassEnabled)
    {
        zzHideHuntPass();
        return;
    }

    zzCloseHuntPassMenu();

    // LIMPA completamente o estado visual anterior
    zzHideVipActiveBadge();

    zzHidePageNaviButtons();

    if(_obf3542 != None)
        _obf3542.SetButtonName(1127);

    if(_obf3541 != None)
        _obf3541.SetButtonName(1964);

    // Busca o estado REAL do personagem atual
    RequestBypassToServer(("lucdevbp RefreshPassInfo " $ string(zzGetSafeCurrentPage())));

    zzStartHuntPassAutoRefresh();

    return;
}

function OnHide()
{
	zzStopHuntPassAutoRefresh();
	zzStopVipLampAnim();
	zzCloseHuntPassMenu();
}

function zzHidePageNaviButtons()
{
	
	if(_obf3539 != None)
		_obf3539.HideWindow();
	if(_obf3540 != None)
		_obf3540.HideWindow();
}

function zzStartHuntPassAutoRefresh()
{
	
	if(_obf2486 == None)
		return;
	_obf2486.KillTimer(HUNTPASS_REFRESH_TIMER_ID);
	_obf2486.SetTimer(HUNTPASS_REFRESH_TIMER_ID, HUNTPASS_REFRESH_DELAY);
}

function zzStopHuntPassAutoRefresh()
{
	if(_obf2486 != None)
		_obf2486.KillTimer(HUNTPASS_REFRESH_TIMER_ID);
}

function OnTimer(int TimerID)
{
	if(TimerID != HUNTPASS_REFRESH_TIMER_ID)
		return;
	if(!zzHuntPassEnabled)
	{
		zzStopHuntPassAutoRefresh();
		return;
	}
	if(_obf2486 == None || !_obf2486.IsShowWindow())
	{
		zzStopHuntPassAutoRefresh();
		return;
	}
	RequestBypassToServer(("lucdevbp RefreshPassInfo " $ string(zzGetSafeCurrentPage())));

}

function OnEvent(int _obf5449, string _obf3273)
{
	// End:0x13
	if(!zzHuntPassEnabled)
	{
		zzHideHuntPass();
		return;
	}
	switch(_obf5449)
	{
		// End:0x34
		case 28632:
			
			if(_obf2486 != None && !_obf2486.IsShowWindow())
				_obf2486.ShowWindow();
			// End:0x19A
			break;
		// End:0x4E
		case 28633:
			_obf2486.HideWindow();
			// End:0x19A
			break;
		// End:0x64
		case 28634:
			_obf1229(_obf3273);
			// End:0x19A
			break;
		// End:0x7A
		case 28635:
			_obf1231(_obf3273);
			// End:0x19A
			break;
		// End:0x90
		case 28636:
			_obf1232(_obf3273);
			// End:0x19A
			break;
		// End:0x15A
		case 1710:
			if(DialogIsMine() && (DialogGetID() == _obf3544))
			{
				RequestBypassToServer("lucdevbp BuyPreInterface " $ string(zzGetSafeCurrentPage()));
				return;
			}
			if(DialogIsMine() && (DialogGetID() == zzDialogIdResetPass))
			{
				RequestBypassToServer("lucdevbp ResetPassInterface " $ string(zzGetSafeCurrentPage()));
				return;
			}
			break;
		case 1720:
			if(DialogIsMine() && ((DialogGetID() == _obf3544) || (DialogGetID() == zzDialogIdResetPass)))
			{
				return;
			}
			break;
		// End:0xFFFF
		default:
			// End:0x19A
			break;
			break;
	}
	return;
}

function _obf1232(string _obf3273)
{
	local int _obf3552, _obf3553, zzVipStatus, zzVipStatusSysString;
	local string _obf3554, _obf5755;
	local int _obf3555, _obf3556, _obf2770;
	local array<string> _obf3557;
	local int _obf5804;

	ParseString(_obf3273, "expiration_date", _obf3554);
	_obf3554 = _obf333(_obf3554);
	ParseString(_obf3273, "premium_item_name", _obf5755);
	_obf75(_obf5755, "_", _obf3557);
	_obf5804 = 0;
	J0x6F:

	// End:0xC0 [Loop If]
	if((_obf5804 < _obf3557.Length))
	{
		// End:0x9E
		if((_obf5804 == 0))
		{
			_obf5755 = _obf3557[_obf5804];
			// [Explicit Continue]
			goto J0xB6;
		}
		_obf5755 = (_obf5755 @ _obf3557[_obf5804]);
		J0xB6:

		_obf5804++;
		// [Loop Continue]
		goto J0x6F;
	}
	ParseInt(_obf3273, "is_premium", _obf3553);
	// End:0x108
	if((!ParseInt(_obf3273, "vip_status", zzVipStatus)))
	{
		zzVipStatus = _obf3553;
	}
	ParseInt(_obf3273, "vip_status_sysstring", zzVipStatusSysString);
	_obf3545 = zzVipStatus;
	ParseInt(_obf3273, "page", _obf3548);
	ParseInt(_obf3273, "onlyplayerpoint", _obf3555);
	ParseInt(_obf3273, "maxhuntpasspoint", _obf3556);
	ParseInt(_obf3273, "maxpage", _obf3547);
	ParseInt(_obf3273, "current_level", _obf3552);
	ParseInt(_obf3273, "premium_item_qty", _obf2770);
	ParseInt(_obf3273, "premium_price", _obf3549);
	ParseInt(_obf3273, "premium_price_id", _obf3550);
	// End:0x28A
	if(((_obf3548 >= 1) && (_obf3548 <= _obf3547)))
	{
		_obf332("L2PassWnd.PageNaviControl.ControlNavi_CurrPageText", string(_obf3548));
	}
	_obf332("L2PassWnd.PageNaviControl.ControlNavi_NextPageText", string(_obf3547));
	zzHidePageNaviButtons();
	_obf332("L2PassWnd.texHuntPass_Groupbox1.PassInfo_wnd.MyPassNum_text", MakeCostString(string(_obf3555)));
	_obf332("L2PassWnd.texHuntPass_Groupbox1.PassInfo_wnd.AllPassNum_text", MakeCostString(string(_obf3556)));
	_obf332("L2PassWnd.texHuntPass_Groupbox1.TextfechaExpiracion", ("Reset Hunt Pass: " $ _obf3554));
	_obf332("L2PassWnd.textvalpremiumnome", _obf5755);
	_obf332("L2PassWnd.textvalpremiumcoin", string(_obf2770));
	TextFechaExpiracionBg_Texture.ShowWindow();
	
	if ((_obf3550 > 0))
	{
		_obf46("L2PassWnd.texturevalpremium").SetTexture(Class'NWindow.UIDATA_ITEM'.static.GetItemTextureName(_obf3550));
	}
	// End:0x462
	if((zzVipStatusSysString > 0))
	{
		// End:0x448
		if((zzVipStatus > 0))
		{
			zzVipActivedText.SetText(GetSystemString(zzVipStatusSysString));			
		}
		else
		{
			zzNonVipText.SetText(GetSystemString(zzVipStatusSysString));
		}
	}
	// End:0x4D9
	if((zzVipStatus == 0))
	{
		_obf3541.EnableWindow();
		zzSetPremiumPriceVisibility(true);
		zzUpdateVipActiveBadge(false);
		_obf3543.SetTooltipCustomType(_obf23(((("Hunt Pass Enable\\n" $ "Status: Free\\n") $ "Lv: ") $ string(_obf3552))));		
	}
	else
	{
		_obf3541.DisableWindow();
		zzSetPremiumPriceVisibility(false);
		zzUpdateVipActiveBadge(true);
		_obf3543.SetTooltipCustomType(_obf23(((("Hunt Pass Enable\\n" $ "Status: Premium\\n") $ "Lv: ") $ string(_obf3552))));
	}
	return;
}

function _obf1231(string _obf3273)
{
	local int _obf5804, _obf3559, _obf3560, _obf3561, _obf3562, _obf3563,
		_obf3564;

	local float _obf3565;
	local CustomTooltip ToolTip;

	ParseInt(_obf3273, "onlyplayerpoint", _obf3546);
	_obf5804 = 0;
	J0x28:

	// End:0x747 [Loop If]
	if((_obf5804 < 10))
	{
		ParseInt(_obf3273, ("n_p_" $ string(_obf5804)), _obf3559);
		ParseInt(_obf3273, ("n_cm_" $ string(_obf5804)), _obf3562);
		ParseInt(_obf3273, ("p_cm_" $ string(_obf5804)), _obf3563);
		// End:0x11D
		if((_obf3545 == 0))
		{
			_obf3536[_obf5804].HideWindow();
			_obf3534[_obf5804].SetTexture(_obf148("Prem_LockBasic"));
			_obf3535[_obf5804].SetTexture(_obf148("Prem_LockIcon"));
			_obf3535[_obf5804].ShowWindow();
		}
		_obf1230((("L2PassWnd.HuntPassTab_Wnd.Gauge_Section0" $ string(_obf5804)) $ ".ItemPointNum_StatusBar.MPGauge_"), _obf3546, _obf3560, _obf3559);
		_obf3560 = _obf3559;
		// End:0x23E
		if((_obf3546 >= _obf3559))
		{
			_obf3561 = _obf3559;
			_obf3528[_obf5804].HideWindow();
			_obf782(_obf3529[_obf5804], "Free_GaugeComplete_Ani");
			// End:0x23B
			if((_obf3545 > 0))
			{
				_obf3535[_obf5804].HideWindow();
				_obf782(_obf3536[_obf5804], "Prem_ActiveGaugeComplete_Ani");
			}			
		}
		else
		{
			_obf3528[_obf5804].ShowWindow();
			_obf3535[_obf5804].ShowWindow();
			_obf3529[_obf5804].HideWindow();
			_obf3536[_obf5804].HideWindow();
			_obf3561 = _obf3546;
		}
		// End:0x333
		if((_obf3562 > 0))
		{
			_obf3529[_obf5804].HideWindow();
			_obf3527[_obf5804].SetTexture(_obf148("Free_RewardComplet"));
			_obf3528[_obf5804].SetTexture(_obf148("RewardCompleteICON"));
			_obf3528[_obf5804].ShowWindow();			
		}
		else
		{
			_obf3527[_obf5804].SetTexture(_obf148("Free_Basic"));
			_obf3528[_obf5804].SetTexture(_obf148("Prem_LockIcon"));
		}
		// End:0x420
		if((_obf3563 > 0))
		{
			_obf3536[_obf5804].HideWindow();
			_obf3534[_obf5804].SetTexture(_obf148("Prem_ActiveRewardComplet"));
			_obf3535[_obf5804].SetTexture(_obf148("RewardCompleteICON"));
			_obf3535[_obf5804].ShowWindow();			
		}
		else
		{
			_obf3534[_obf5804].SetTexture(_obf148("Prem_ActiveBaisc"));
			_obf3535[_obf5804].SetTexture(_obf148("Prem_LockIcon"));
		}
		// End:0x4A1
		if((_obf3559 > 0))
		{
			_obf3565 = ((float(_obf3561) / float(_obf3559)) * float(100));			
		}
		else
		{
			_obf3565 = 0.0000000;
		}
		_obf3564 = (_obf3559 - _obf3561);
		// End:0x4D0
		if((_obf3564 < 0))
		{
			_obf3564 = 0;
		}
		ToolTip.DrawList.Length = 0;
		ToolTip.DrawList[ToolTip.DrawList.Length] = DrawTex("L2UI_CH3.Null", 180, 0, 0, 0, 0, 0, false, true);
		ToolTip.DrawList[ToolTip.DrawList.Length] = _obf37((("Slot " $ string((_obf781(_obf5804) + 1))) $ " Progress"), _obf22().Gold, false, true, 0, 0);
		ToolTip.DrawList[ToolTip.DrawList.Length] = _obf37(((("Current: " $ string(_obf3561)) $ " / ") $ string(_obf3559)), _obf33(163, 163, 163, 255), false, true, 0, 0);
		ToolTip.DrawList[ToolTip.DrawList.Length] = _obf37((("Progress: " $ string(int(_obf3565))) $ "%"), _obf33(163, 163, 163, 255), true, true, 0, 0);
		// End:0x69C
		if((_obf3564 > 0))
		{
			ToolTip.DrawList[ToolTip.DrawList.Length] = _obf37("Needed: ", _obf33(163, 163, 163, 255), false, true, 0, 0);
			ToolTip.DrawList[ToolTip.DrawList.Length] = _obf37((string(_obf3564) $ " points to next level"), _obf33(163, 163, 163, 255), false, false, 0, 0);			
		}
		else
		{
			ToolTip.DrawList[ToolTip.DrawList.Length] = _obf37("Completed", _obf101("LightGreen"), false, true, 0, 0);
		}
		_obf28((("L2PassWnd.HuntPassTab_Wnd.Gauge_Section0" $ string(_obf5804)) $ ".ItemPointNum_StatusBar")).SetTooltipCustomType(ToolTip);
		_obf5804++;
		// [Loop Continue]
		goto J0x28;
	}
	return;
}

function _obf1230(string _obf3273, int _obf3555, int _obf5419, int _obf3567)
{
	local float _obf5969;
	local int _obf3568;

	// End:0x4C
	if((_obf3555 > _obf5419))
	{
		_obf3568 = (_obf3555 - _obf5419);
		// End:0x49
		if((_obf3568 > (_obf3567 - _obf5419)))
		{
			_obf3568 = (_obf3567 - _obf5419);
		}		
	}
	else
	{
		_obf3568 = 0;
	}
	// End:0x85
	if(((_obf3567 - _obf5419) > 0))
	{
		_obf5969 = (float(_obf3568) / float((_obf3567 - _obf5419)));		
	}
	else
	{
		_obf5969 = 0.0000000;
	}
	_obf46((_obf3273 $ "C")).SetWindowSizeRel(_obf5969, 0.0000000, -8, 26);
	// End:0xDD
	if((_obf5969 <= 0.0000000))
	{
		HideWindow((_obf3273 $ "L"));		
	}
	else
	{
		ShowWindow((_obf3273 $ "L"));
	}
	HideWindow((_obf3273 $ "Trail"));
	return;
}

function _obf1229(string _obf3273)
{
	local int _obf3570, _obf3571, _obf3572;
	local ItemInfo _obf3573;
	local int _obf5804;

	_obf5804 = 0;
	J0x07:

	// End:0x19E [Loop If]
	if((_obf5804 < 10))
	{
		// End:0x3B
		if((!ParseInt(_obf3273, ("n_id_" $ string(_obf5804)), _obf3570)))
		{
			// [Explicit Break]
			goto J0x19E;
		}
		ParseInt(_obf3273, ("n_co_" $ string(_obf5804)), _obf3571);
		ParseInt(_obf3273, ("normal_level_" $ string(_obf5804)), _obf3572);
		_obf3524[_obf5804].Clear();
		Class'NWindow.UIDATA_ITEM'.static.GetItemInfo(_obf3570, _obf3573);
		_obf3573.ForeTexture = "";
		_obf3573.ItemNum = _obf3571;
		// End:0x153
		if((_obf3573.ItemNum > 1))
		{
			// End:0x11D
			if((_obf3573.ItemNum > 99))
			{
				_obf3573.ForeTexture = "L2UI_CH3.ItemCount.texCount99+";				
			}
			else
			{
				_obf3573.ForeTexture = ("L2UI_CH3.ItemCount.texCount" $ string(_obf3573.ItemNum));
			}
		}
		_obf3524[_obf5804].AddItem(_obf3573);
		_obf3525[_obf5804].SetText(("x" $ MakeCostString(string(_obf3571))));
		_obf5804++;
		// [Loop Continue]
		goto J0x07;
	}
	J0x19E:

	_obf5804 = 0;
	J0x1A5:

	// End:0x33D [Loop If]
	if((_obf5804 < 10))
	{
		// End:0x1D9
		if((!ParseInt(_obf3273, ("p_id_" $ string(_obf5804)), _obf3570)))
		{
			// [Explicit Break]
			goto J0x33D;
		}
		ParseInt(_obf3273, ("p_co_" $ string(_obf5804)), _obf3571);
		ParseInt(_obf3273, ("premium_level_" $ string(_obf5804)), _obf3572);
		_obf3531[_obf5804].Clear();
		Class'NWindow.UIDATA_ITEM'.static.GetItemInfo(_obf3570, _obf3573);
		_obf3573.ForeTexture = "";
		_obf3573.ItemNum = _obf3571;
		// End:0x2F2
		if((_obf3573.ItemNum > 1))
		{
			// End:0x2BC
			if((_obf3573.ItemNum > 99))
			{
				_obf3573.ForeTexture = "L2UI_CH3.ItemCount.texCount99+";				
			}
			else
			{
				_obf3573.ForeTexture = ("L2UI_CH3.ItemCount.texCount" $ string(_obf3573.ItemNum));
			}
		}
		_obf3531[_obf5804].AddItem(_obf3573);
		_obf3532[_obf5804].SetText(("x" $ MakeCostString(string(_obf3571))));
		_obf5804++;
		// [Loop Continue]
		goto J0x1A5;
	}
	J0x33D:

	return;
}

function string _obf148(string Name)
{
	return ("Base.L2passWnd." $ Name);
}

function _obf332(string _obf3576, string _obf5312)
{
	local TextBoxHandle _obf5769;
	local string _obf5435;

	_obf5769 = _obf58(_obf3576);
	_obf5435 = _obf5769.GetText();
	// End:0x49
	if((_obf5435 != _obf5312))
	{
		_obf5769.SetText(_obf5312);
	}
	return;
}

function int _obf781(int _obf3578)
{
	return (_obf3578 + ((_obf3548 - 1) * 10));
}

function _obf384(int _obf3578, bool _obf3580)
{
	local int _obf3581;

	_obf3581 = _obf781(_obf3578);
	// End:0x6B
	if(_obf3580)
	{
		RequestBypassToServer(((("lucdevbp Slot " $ string((_obf3581 + 1))) $ " Premium ") $ string(_obf3548)));		
	}
	else
	{
		RequestBypassToServer(((("lucdevbp Slot " $ string((_obf3581 + 1))) $ " normal ") $ string(_obf3548)));
	}
	return;
}

function _obf366(int _obf5342)
{
	// End:0x5C
	if((_obf5342 < 0))
	{
		// End:0x59
		if((_obf3548 > 1))
		{
			RequestBypassToServer(("lucdevbp RefreshPassInfo " $ string((_obf3548 - 1))));
		}		
	}
	else
	{
		// End:0xB9
		if((_obf5342 > 0))
		{
			// End:0xB9
			if((_obf3548 < _obf3547))
			{
				RequestBypassToServer(("lucdevbp RefreshPassInfo " $ string((_obf3548 + 1))));
			}
		}
	}
	return;
}

function _obf782(AnimTextureHandle _obf5769, string TexName)
{
	_obf5769.SetTexture(_obf148(TexName));
	_obf5769.Stop();
	_obf5769.SetLoopCount(-1);
	_obf5769.Play();
	_obf5769.ShowWindow();
	return;
}

function bool _obf1880()
{
	return _obf3545 > 0;
}

function OnDBClickItemWithHandle(ItemWindowHandle _obf5416, int _obf2229)
{
	local int _obf5804;

	if(!zzHuntPassEnabled)
		return;

	for(_obf5804 = 0; _obf5804 < 10; _obf5804++)
	{
		if(_obf5416 == _obf3524[_obf5804])
		{
			_obf384(_obf5804, false);
			return;
		}
		if(_obf5416 == _obf3531[_obf5804])
		{
			_obf384(_obf5804, true);
			return;
		}
	}
}

function OnClickButtonWithHandle(ButtonHandle _obf3585)
{
	local int _obf5804;

	if(!zzHuntPassEnabled)
		return;

	if(_obf3585 == zzHuntPassMenuBtn)
	{
		zzToggleHuntPassMenu();
		return;
	}
	if((_obf3585 == zzHuntPassMenuClaimBtn) || (_obf3585 == zzHuntPassMenuClaimHitBtn))
	{
		zzCloseHuntPassMenu();
		RequestBypassToServer("lucdevbp rewardinterface " $ string(zzGetSafeCurrentPage()));
		return;
	}
	if((_obf3585 == zzHuntPassMenuResetBtn) || (_obf3585 == zzHuntPassMenuResetHitBtn))
	{
		zzCloseHuntPassMenu();
		DialogSetID(zzDialogIdResetPass);
		DialogShow(DIALOG_OKCancel, "Do you want to reset your Hunt Pass?");
		return;
	}
	if((_obf3585 == zzHuntPassMenuRefreshBtn) || (_obf3585 == zzHuntPassMenuRefreshHitBtn))
	{
		zzCloseHuntPassMenu();
		RequestBypassToServer("lucdevbp RefreshPassInfo " $ string(zzGetSafeCurrentPage()));
		return;
	}
	if((_obf3585 == _obf3537) || (_obf3585 == _obf3539))
	{
		_obf366(-1);
		return;
	}
	if((_obf3585 == _obf3538) || (_obf3585 == _obf3540))
	{
		_obf366(1);
		return;
	}
	if(_obf3585 == _obf3541)
	{
		zzCloseHuntPassMenu();
		DialogSetID(_obf3544);
		DialogShow(DIALOG_OKCancel, "Do you want to enable the battle pass?\\nPrice: " $ MakeCostString(string(_obf3549)) $ " " $ Class'NWindow.UIDATA_ITEM'.static.GetItemName(_obf3550));
		return;
	}
	if(_obf3585 == _obf3542)
	{
		zzCloseHuntPassMenu();
		RequestBypassToServer("lucdevbp rewardinterface " $ string(zzGetSafeCurrentPage()));
		return;
	}

	for(_obf5804 = 0; _obf5804 < 10; _obf5804++)
	{
		if(_obf3585 == _obf3523[_obf5804])
		{
			_obf384(_obf5804, false);
			return;
		}
		if(_obf3585 == _obf3530[_obf5804])
		{
			_obf384(_obf5804, true);
			return;
		}
	}
}

function WindowHandle _obf28(string Path)
{
	return GetHandle(Path);
}

function ButtonHandle _obf29(string Path)
{
	return ButtonHandle(GetHandle(Path));
}

function ItemWindowHandle _obf27(string Path)
{
	return ItemWindowHandle(GetHandle(Path));
}

function TextureHandle _obf46(string Path)
{
	return TextureHandle(GetHandle(Path));
}

function TextBoxHandle _obf58(string Path)
{
	return TextBoxHandle(GetHandle(Path));
}

function AnimTextureHandle _obf65(string Path)
{
	return AnimTextureHandle(GetHandle(Path));
}

function L2Util _obf22()
{
	return L2Util(GetScript("L2Util"));
}

function Color _obf33(int R, int G, int B, int A)
{
	local Color C;

	C.R = byte(R);
	C.G = byte(G);
	C.B = byte(B);
	C.A = byte(A);
	return C;
}

function string _obf333(string s)
{
	local int i;
	local string outStr, ch;

	outStr = "";
	for(i = 0; i < Len(s); i++)
	{
		ch = Mid(s, i, 1);
		if(ch == "_")
			outStr = outStr $ " ";
		else
			outStr = outStr $ ch;
	}
	return outStr;
}

function int _obf75(string strInput, string delim, out array<string> arrToken)
{
	return Split(strInput, delim, arrToken);
}

/*function CustomTooltip _obf23(string Text)
{
	return MakeTooltipSimpleText(Text);
}*/

function CustomTooltip _obf23(string Text)
{
    local CustomTooltip ToolTip;

    ToolTip.DrawList.Length = 0;
    ToolTip.DrawList[ToolTip.DrawList.Length] = xxDrawText(Text, _obf22().Gold,false,true,0,0);

    return ToolTip;
}

function DrawItemInfo _obf37(string Text, Color c_Color, bool bDrawOneLine, bool bLineBreak, int nOffSetX, int nOffSetY)
{
	return xxDrawText(Text, c_Color, bDrawOneLine, bLineBreak, nOffSetX, nOffSetY);
}

function Color _obf101(string val)
{
	local Color colit;

	colit.A = 255;
	if(val == "LightGreen")
	{
		colit.R = 144;
		colit.G = 238;
		colit.B = 144;
		return colit;
	}
	colit.R = 255;
	colit.G = 255;
	colit.B = 255;
	return colit;
}
