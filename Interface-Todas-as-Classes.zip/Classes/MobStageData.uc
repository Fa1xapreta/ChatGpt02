class MobStageData extends Object;
// Generated from the current GS NPC XML and actual class inheritance.
// 0=NPC, 1=Monster, 2=RaidBoss, 3=Epic, -1=unknown. No server changes.
var array<int> IDs;
var array<int> Categories;
static function int Category(int npcID)
{
    local int low,high,mid,value;
    low=0;high=default.IDs.Length-1;
    while(low<=high){
        mid=(low+high)/2;value=default.IDs[mid];
        if(value==npcID)return default.Categories[mid];
        if(value<npcID)low=mid+1;else high=mid-1;
    }
    return -1;
}
