class TeleportWnd extends UICommonAPI;

const MAX_BUTTON_ON_MAP = 30;
const TELEPORT_BYPASS = "GkGo _";
const RAID_ICON = "L2_GF.MinimapWnd.Boss_Off";

struct RaidStatusData
{
    var int DestinationId;
    var string StatusCode;
    var string Respawn;
};

struct zonesData
{
    var int catId;
    var string catName;
    var int id;
    var string name;
    var int price;
    var bool noble;
    var string x;
    var string y;
};

var array<RaidStatusData> RaidStatuses;

var bool m_bShow;
var bool bVipTeleportOpenPermit;
var int PendingTeleportId;
var string m_WindowName;

var WindowHandle MainZoneListTree;
var WindowHandle SubMainZoneListTree;
var WindowHandle HuntZoneListTree;
var WindowHandle SubHuntZoneListTree;

var EditBoxHandle Search_EditBox;
var TextBoxHandle TitleTxt;
var TextBoxHandle MainZoneText;
var TextBoxHandle HuntZoneText;
var TextureHandle MainZoneHeaderTex;
var TextureHandle HuntZoneHeaderTex;

var array<zonesData> zones;
var array<zonesData> resZones;
var array<zonesData> cleanZones;

var string myZoneTxt;
var int myZoneID;


// ============================================================
// INICIALIZACAO
// ============================================================

function OnLoad()
{
    RegisterEvent(140);
    RegisterEvent(EV_BeginShowZoneTitleWnd);
    RegisterEvent(EV_DialogOK);
    RegisterEvent(EV_DialogCancel);

    TitleTxt = TextBoxHandle(
        GetHandle(m_WindowName$".TitleInterface")
    );

    Search_EditBox = EditBoxHandle(
        GetHandle(m_WindowName$".Search_EditBox")
    );

    MainZoneText = TextBoxHandle(
        GetHandle(m_WindowName$".TeleportTabMainWnd.MainZoneTxt")
    );

    HuntZoneText = TextBoxHandle(
        GetHandle(m_WindowName$".TeleportTabHuntWnd.HuntZoneTxt")
    );

    MainZoneHeaderTex = TextureHandle(
        GetHandle(m_WindowName$".TeleportTabMainWnd.MainZoneHeaderTex")
    );

    HuntZoneHeaderTex = TextureHandle(
        GetHandle(m_WindowName$".TeleportTabHuntWnd.HuntZoneHeaderTex")
    );

    MainZoneListTree = GetHandle(
        TreeCtrlPath("MainZoneList")
    );

    SubMainZoneListTree = GetHandle(
        TreeCtrlPath("SubMainZoneList")
    );

    HuntZoneListTree = GetHandle(
        TreeCtrlPath("HuntZoneList")
    );

    SubHuntZoneListTree = GetHandle(
        TreeCtrlPath("SubHuntZoneList")
    );

    m_bShow = False;
    PendingTeleportId = 0;

    LoadZonesData();
}

function string TreeCtrlPath(string ListName)
{
    if (
        ListName == "MainZoneList" ||
        ListName == "SubMainZoneList"
    )
    {
        return m_WindowName$
            ".TeleportTabMainWnd."$
            ListName$"Tree";
    }

    return m_WindowName$
        ".TeleportTabHuntWnd."$
        ListName$"Tree";
}


// ============================================================
// FUNCOES AUXILIARES DAS ARVORES
// ============================================================

function ClearXMLNode(string strID)
{
    class'UIAPI_TREECTRL'.Static.Clear(strID);
}

function InsertXMLNodeRoot(
    string TreeName,
    string NodeName,
    string ParentName,
    optional int offsetX,
    optional int offsetY
)
{
    local XMLTreeNodeInfo infNode;

    infNode.strName = NodeName;
    infNode.nOffSetX = offsetX;
    infNode.nOffSetY = offsetY;

    class'UIAPI_TREECTRL'.Static.InsertNode(
        TreeName,
        ParentName,
        infNode
    );
}

function InsertXMLNodeTexture(
    string TreeName,
    string NodeName,
    string TextureName,
    string TextureExpandedName,
    int TextureWidth,
    int TextureHeight,
    optional int offsetX,
    optional int offsetY,
    optional bool OneLine,
    optional bool bLineBreak,
    optional bool StopMouseFocus,
    optional int TextureUWidth,
    optional int TextureUHeight
)
{
    local XMLTreeNodeItemInfo infNodeItem;

    infNodeItem.eType = XTNITEM_TEXTURE;
    infNodeItem.bStopMouseFocus = StopMouseFocus;
    infNodeItem.t_bDrawOneLine = OneLine;
    infNodeItem.bLineBreak = bLineBreak;
    infNodeItem.nOffSetX = offsetX;
    infNodeItem.nOffSetY = offsetY;

    infNodeItem.u_nTextureWidth = TextureWidth;
    infNodeItem.u_nTextureHeight = TextureHeight;
    infNodeItem.u_nTextureUWidth = TextureUWidth;
    infNodeItem.u_nTextureUHeight = TextureUHeight;
    infNodeItem.u_strTexture = TextureName;

    if (TextureExpandedName != "")
        infNodeItem.u_strTextureExpanded = TextureExpandedName;

    class'UIAPI_TREECTRL'.Static.InsertNodeItem(
        TreeName,
        NodeName,
        infNodeItem
    );
}

function InsertXMLNodeText(
    string TreeName,
    string NodeName,
    string ItemName,
    optional int offsetX,
    optional int offsetY,
    optional Color color,
    optional bool OneLine,
    optional bool bLineBreak,
    optional bool StopMouseFocus,
    optional int TextID
)
{
    local XMLTreeNodeItemInfo infNodeItem;

    infNodeItem.eType = XTNITEM_TEXT;
    infNodeItem.bStopMouseFocus = StopMouseFocus;

    if (TextID > 0)
        infNodeItem.t_nTextID = TextID;

    infNodeItem.t_strText = ItemName;
    infNodeItem.t_bDrawOneLine = OneLine;
    infNodeItem.bLineBreak = bLineBreak;
    infNodeItem.nOffSetX = offsetX;
    infNodeItem.nOffSetY = offsetY;
    infNodeItem.t_color = color;

    if (color.A == 0)
        infNodeItem.t_color.A = 255;

    class'UIAPI_TREECTRL'.Static.InsertNodeItem(
        TreeName,
        NodeName,
        infNodeItem
    );
}

function Color MakeRGB(int r, int g, int b)
{
    local Color c;

    c.R = r;
    c.G = g;
    c.B = b;
    c.A = 255;

    return c;
}


// ============================================================
// ABERTURA E FECHAMENTO
// ============================================================

function OnShow()
{
    // Bloqueia aberturas diretas, inclusive pelos atalhos.
    if (!bVipTeleportOpenPermit)
    {
        class'UIAPI_WINDOW'.Static.SetAlpha(
            m_WindowName,
            0
        );

        HideWindow(m_WindowName);

        RequestBypassToServer("GkOpenTeleport");
        return;
    }

    // Cada autorizacao permite somente uma abertura.
    bVipTeleportOpenPermit = False;

    class'UIAPI_WINDOW'.Static.SetAlpha(
        m_WindowName,
        255
    );

    m_bShow = True;
    PendingTeleportId = 0;

    class'UIAPI_TABCTRL'.Static.SetTopOrder(
        m_WindowName$".TeleportTabCtrl",
        0,
        False
    );

    if (TitleTxt != None)
        TitleTxt.SetText("Teleport Premiun");

    CheckMyMapPos();
    CleanMapBtns();
    InitMainTrees();
    InitTreesContent();
    InitSubTrees();

    Search_EditBox.SetString("");

    MainZoneText.SetText("Global Teleport");
    MainZoneText.SetTextColor(
        MakeRGB(204, 179, 255)
    );

    HuntZoneText.SetText("Boss Teleport");
    HuntZoneText.SetTextColor(
        MakeRGB(230, 153, 77)
    );

    MainZoneHeaderTex.SetTexture(
        "L2UI_AS.TeleportWnd.light_HighLVList"
    );

    HuntZoneHeaderTex.SetTexture(
        "L2UI_AS.TeleportWnd.light_Bookmark"
    );

    SetCurrentLocation();

    resZones = cleanZones;

    GetSubTreeList("MainZoneList.main_0");

    class'UIAPI_TREECTRL'.Static.SetExpandedNode(
        TreeCtrlPath("MainZoneList"),
        "MainZoneList.main_0",
        True
    );

    RequestBossStatuses();
}
function OnHide()
{
    bVipTeleportOpenPermit = False;
    PendingTeleportId = 0;

    if (DialogIsMine() && DialogGetID() == 7717)
        DialogHide();

    resZones = cleanZones;

    CleanMapBtns();
    InitMainTrees();
    InitTreesContent();
    InitSubTrees();

    m_bShow = False;
}

// ============================================================
// EVENTOS E CONFIRMACAO
// ============================================================

function OnEvent(int a_EventID, string a_Param)
{
    switch (a_EventID)
    {
        case 140:
            if (!HandleVipTeleportAccess(a_Param))
                ReceiveBossStatusEvent(a_Param);
            break;

        case EV_BeginShowZoneTitleWnd:
            SetCurrentLocation();
            break;

        case EV_DialogOK:
            HandleDialogOK();
            break;

        case EV_DialogCancel:
            if (DialogIsMine() && DialogGetID() == 7717)
                PendingTeleportId = 0;
            break;
    }
}

function HandleDialogOK()
{
    local int DestinationId;
    local string Command;

    if (!DialogIsMine())
        return;

    if (DialogGetID() != 7717)
        return;

    DestinationId = DialogGetReservedInt();

    if (FindTeleportIndex(DestinationId) < 0)
        return;

    Command = TELEPORT_BYPASS$string(DestinationId);

    PendingTeleportId = 0;

    DialogHide();

    RequestBypassToServer(Command);

    HideWindow(m_WindowName);
}

function OnLButtonDblClick(int MouseX, int MouseY)
{
    local Rect ListRect;
    local string ListName;
    local string Category;
    local int ZoneIndex;

    if (!m_bShow)
        return;

    if (DialogIsMine())
        return;

    if (PendingTeleportId <= 0)
        return;

    if (GetTeleportTabIndex() == 0)
    {
        ListName = "SubMainZoneList";
        Category = "main";
    }
    else
    {
        ListName = "SubHuntZoneList";
        Category = "hunt";
    }

    ZoneIndex = FindTeleportIndex(PendingTeleportId);

    if (ZoneIndex < 0)
        return;

    if (zones[ZoneIndex].catName != Category)
        return;

    ListRect = class'UIAPI_WINDOW'.Static.GetRect(
        TreeCtrlPath(ListName)
    );

    // Duplo clique precisa ocorrer dentro da lista.
    // Desconsidera a faixa da barra de rolagem.
    if (
        MouseX < ListRect.nX ||
        MouseX >= ListRect.nX + ListRect.nWidth - 16 ||
        MouseY < ListRect.nY ||
        MouseY >= ListRect.nY + ListRect.nHeight
    )
        return;

    ShowTeleportConfirmation(PendingTeleportId);
}

function OnClickButton(string strID)
{
    local array<string> Parts;
    local ButtonHandle Marker;
    local string ParentName;
    local string IndexText;
    local int ParentIndex;
    local int MapIndex;
    local int DestinationId;

    switch (strID)
    {
        case "BtnClose":
            PendingTeleportId = 0;
            HideWindow(m_WindowName);
            return;

        case "Search_Button":
            PendingTeleportId = 0;
            OnSearch_ButtonClick();
            return;

        case "Refresh_Button":
            PendingTeleportId = 0;
            OnRefresh_ButtonClick();
            return;

        case "TeleportTabCtrl0":
            PendingTeleportId = 0;

            class'UIAPI_TABCTRL'.Static.SetTopOrder(
                m_WindowName$".TeleportTabCtrl",
                0,
                False
            );

            OnRefresh_ButtonClick();
            return;

        case "TeleportTabCtrl1":
            PendingTeleportId = 0;

            class'UIAPI_TABCTRL'.Static.SetTopOrder(
                m_WindowName$".TeleportTabCtrl",
                1,
                False
            );

            OnRefresh_ButtonClick();
            return;

        case "myZoneBtn":
            PendingTeleportId = 0;
            SetTeleportTabAndLine();
            return;

        case "btnTeleportIcon":
            Marker = ButtonHandle(
                GetHandle(
                    m_WindowName$
                    ".TeleportMapOverlayWnd.btnTeleportIcon"
                )
            );

            if (Marker == None)
                return;

            ParentName = Marker.GetParentWindowName();

            ParentIndex = InStr(
                ParentName,
                "TeleportMapIcon"
            );

            if (ParentIndex < 0)
                return;

            IndexText = Mid(
                ParentName,
                ParentIndex + Len("TeleportMapIcon")
            );

            if (IndexText == "")
                return;

            MapIndex = int(IndexText);

            if (string(MapIndex) != IndexText)
                return;

            if (
                MapIndex < 0 ||
                MapIndex >= MAX_BUTTON_ON_MAP ||
                MapIndex >= resZones.Length
            )
                return;

            // Mantem o comportamento dos marcadores do mapa.
            ShowTeleportConfirmation(
                resZones[MapIndex].id
            );
            return;
    }

    Split(strID, ".", Parts);

    if (Parts.Length != 2)
        return;

    if (
        Parts[0] == "MainZoneList" ||
        Parts[0] == "HuntZoneList"
    )
    {
        PendingTeleportId = 0;
        GetSubTreeList(strID);
        return;
    }

    if (
        (
            Parts[0] == "SubMainZoneList" ||
            Parts[0] == "SubHuntZoneList"
        ) &&
        Left(Parts[1], 9) == "Teleport_"
    )
    {
        DestinationId = int(Mid(Parts[1], 9));

        if (FindTeleportIndex(DestinationId) < 0)
            return;

        // Clique simples apenas seleciona.
        PendingTeleportId = DestinationId;
    }
}

function bool HandleVipTeleportAccess(string Params)
{
    local string Message;

    ParseString(Params, "Msg", Message);

    if (Message == "CustomEvent=TeleportAccessV1|OPEN")
    {
        if (IsShowWindow(m_WindowName))
        {
            class'UIAPI_WINDOW'.Static.SetFocus(
                m_WindowName
            );

            return True;
        }

        // Permissao recebida exclusivamente do servidor.
        bVipTeleportOpenPermit = True;

        ShowWindowWithFocus(m_WindowName);

        return True;
    }

    if (Message == "CustomEvent=TeleportAccessV1|DENIED")
    {
        bVipTeleportOpenPermit = False;

        class'UIAPI_WINDOW'.Static.SetAlpha(
            m_WindowName,
            0
        );

        HideWindow(m_WindowName);

        return True;
    }

    return False;
}

function OnSearch_ButtonClick()
{
    local string searchStr;

    searchStr = Search_EditBox.GetString();

    FindAndShowItemList(searchStr);
}

function OnRefresh_ButtonClick()
{
    Search_EditBox.SetString("");

    FindAndShowItemList("");

    if (GetTeleportTabIndex() == 0)
        GetSubTreeList("MainZoneList.main_0");
    else
        GetSubTreeList("HuntZoneList.hunt_0");

    RequestBossStatuses();
}


// ============================================================
// MAPA E LOCALIZACAO
// ============================================================

function CleanMapBtns()
{
    local int i;
    local ButtonHandle teleportBtn;

    for (i = 0; i < MAX_BUTTON_ON_MAP; i++)
    {
        class'UIAPI_WINDOW'.Static.HideWindow(
            m_WindowName$
            ".TeleportMapOverlayWnd.TeleportMapIcon"$i
        );

        class'UIAPI_WINDOW'.Static.SetAnchor(
            m_WindowName$
            ".TeleportMapOverlayWnd.TeleportMapIcon"$i,
            m_WindowName$".TeleportMapOverlayWnd",
            "TopLeft",
            "TopLeft",
            0,
            0
        );

        teleportBtn = ButtonHandle(
            GetHandle(
                m_WindowName$
                ".TeleportMapOverlayWnd.TeleportMapIcon"$
                i$".btnTeleportIcon"
            )
        );

        teleportBtn.SetTooltipCustomType(
            MakeTeleportTextTooltip("")
        );
    }
}

function CheckMyMapPos()
{
    local float x, y;
    local UserInfo info;
    local AnimTextureHandle m_TexMyMapAnim;

    m_TexMyMapAnim = AnimTextureHandle(
        GetHandle(
            m_WindowName$
            ".TeleportMapOverlayWnd.MyMapIcon.texMyMapPos"
        )
    );

    if (GetPlayerInfo(info))
    {
        x = (
            ((info.Loc.x - float(-229300)) / 133) * 0.11
        ) - 54 - 8;

        y = (
            ((info.Loc.y - float(-260600)) / 133) * 0.11
        ) - 8;

        class'UIAPI_WINDOW'.Static.ShowWindow(
            m_WindowName$".TeleportMapOverlayWnd.MyMapIcon"
        );

        m_TexMyMapAnim.SetLoopCount(-1);
        m_TexMyMapAnim.Play();

        class'UIAPI_WINDOW'.Static.ClearAnchor(
            m_WindowName$".TeleportMapOverlayWnd.MyMapIcon"
        );

        class'UIAPI_WINDOW'.Static.SetAnchor(
            m_WindowName$".TeleportMapOverlayWnd.MyMapIcon",
            m_WindowName$".TeleportMapOverlayWnd",
            "TopLeft",
            "TopLeft",
            x,
            y
        );
    }
    else
    {
        m_TexMyMapAnim.Stop();

        class'UIAPI_WINDOW'.Static.HideWindow(
            m_WindowName$".TeleportMapOverlayWnd.MyMapIcon"
        );

        class'UIAPI_WINDOW'.Static.ClearAnchor(
            m_WindowName$".TeleportMapOverlayWnd.MyMapIcon"
        );

        class'UIAPI_WINDOW'.Static.SetAnchor(
            m_WindowName$".TeleportMapOverlayWnd.MyMapIcon",
            m_WindowName$".TeleportMapOverlayWnd",
            "TopLeft",
            "TopLeft",
            0,
            0
        );
    }
}

function SetCurrentLocation()
{
    myZoneTxt = GetCurrentZoneName();
    myZoneID = GetHuntZoneCatId(myZoneTxt);

    class'UIAPI_TEXTBOX'.Static.SetText(
        m_WindowName$".myZoneTxt",
        myZoneTxt
    );

    if (IsShowWindow(m_WindowName))
        CheckMyMapPos();
}

function int GetHuntZoneCatId(string zonename)
{
    if (
        InStr(zonename, "Talking") != -1 ||
        InStr(zonename, "Einhov") != -1 ||
        InStr(zonename, "Cedric") != -1
    )
        return 0;

    if (
        zonename == "Elven Village" ||
        InStr(zonename, "Mother") != -1
    )
        return 1;

    if (
        InStr(zonename, "Dark") != -1 ||
        InStr(zonename, "Misty") != -1 ||
        InStr(zonename, "Shilen") != -1
    )
        return 2;

    if (
        zonename == "Orc Village" ||
        InStr(zonename, "Immortal") != -1 ||
        InStr(zonename, "Heroes") != -1 ||
        InStr(zonename, "Pa'agrio") != -1
    )
        return 3;

    if (
        zonename == "Dwarven Village" ||
        InStr(zonename, "Spine") != -1 ||
        InStr(zonename, "Mining") != -1 ||
        InStr(zonename, "Mine") != -1
    )
        return 4;

    if (InStr(zonename, "Gludin") != -1)
        return 5;

    if (
        InStr(zonename, "Gludio") != -1 ||
        InStr(zonename, "Ruined") != -1 ||
        InStr(zonename, "Maille") != -1 ||
        InStr(zonename, "Incubator") != -1
    )
        return 6;

    if (
        InStr(zonename, "Dion") != -1 ||
        InStr(zonename, "Cruma") != -1 ||
        InStr(zonename, "Partisan") != -1 ||
        InStr(zonename, "Floran") != -1 ||
        InStr(zonename, "Monster Race") != -1
    )
        return 7;

    if (
        InStr(zonename, "Giran") != -1 ||
        zonename == "Death Pass" ||
        InStr(zonename, "Pirate") != -1 ||
        InStr(zonename, "Anthar") != -1
    )
        return 8;

    if (
        InStr(zonename, "Heine") != -1 ||
        InStr(zonename, "Innadril") != -1
    )
        return 9;

    if (
        zonename == "Hunters Village" ||
        InStr(zonename, "Hardin") != -1 ||
        InStr(zonename, "Enchanted") != -1
    )
        return 10;

    if (
        InStr(zonename, "Oren") != -1 ||
        InStr(zonename, "Crater") != -1
    )
        return 11;

    if (
        InStr(zonename, "Insolence") != -1 ||
        InStr(zonename, "Giant's Cave") != -1 ||
        InStr(zonename, "Aden") != -1 ||
        InStr(zonename, "Cemetery") != -1 ||
        InStr(zonename, "Forbidden Gateway") != -1 ||
        InStr(zonename, "Coliseum") != -1 ||
        InStr(zonename, "Narsell") != -1
    )
        return 12;

    if (
        InStr(zonename, "Goddard") != -1 ||
        InStr(zonename, "Varka") != -1 ||
        InStr(zonename, "Ketra") != -1 ||
        InStr(zonename, "Monastery") != -1 ||
        InStr(zonename, "Rainbow") != -1 ||
        InStr(zonename, "Forge") != -1 ||
        InStr(zonename, "Imperial") != -1 ||
        InStr(zonename, "Flames") != -1 ||
        InStr(zonename, "Valak") != -1
    )
        return 13;

    if (
        InStr(zonename, "Rune") != -1 ||
        InStr(zonename, "Farm") != -1 ||
        InStr(zonename, "Primeval") != -1
    )
        return 14;

    if (
        InStr(zonename, "Schuttgart") != -1 ||
        InStr(zonename, "Railroad") != -1 ||
        InStr(zonename, "Brigand") != -1 ||
        InStr(zonename, "Labyrinth") != -1 ||
        InStr(zonename, "Caron's") != -1
    )
        return 15;

    return -1;
}


// ============================================================
// RAIZES DAS ARVORES
// ============================================================

function InitMainTrees()
{
    ClearXMLNode(TreeCtrlPath("MainZoneList"));

    InsertXMLNodeRoot(
        TreeCtrlPath("MainZoneList"),
        "MainZoneList",
        "",
        0,
        0
    );

    ClearXMLNode(TreeCtrlPath("HuntZoneList"));

    InsertXMLNodeRoot(
        TreeCtrlPath("HuntZoneList"),
        "HuntZoneList",
        "",
        0,
        0
    );
}

function InitSubTrees()
{
    ClearXMLNode(TreeCtrlPath("SubMainZoneList"));

    InsertXMLNodeRoot(
        TreeCtrlPath("SubMainZoneList"),
        "SubMainZoneList",
        "",
        0,
        0
    );

    ClearXMLNode(TreeCtrlPath("SubHuntZoneList"));

    InsertXMLNodeRoot(
        TreeCtrlPath("SubHuntZoneList"),
        "SubHuntZoneList",
        "",
        0,
        0
    );
}


// ============================================================
// CATEGORIAS
// ============================================================

function InitTreesContent()
{
    AddTeleportLine(0, "main", "Towns and Villages", "MainZoneList");
    AddTeleportLine(1, "main", "Level Destinations 40-85", "MainZoneList");
    AddTeleportLine(2, "main", "Intermed Drop Zone", "MainZoneList");
    AddTeleportLine(3, "main", "Extreme Drop Zone", "MainZoneList");

    // IDs iguais aos usados em LoadZonesData().
    AddTeleportLine(5, "main", "Instancias Spoil", "MainZoneList");
    AddTeleportLine(7, "main", "Areas PvP", "MainZoneList");

    AddTeleportLine(1, "hunt", "Raid Bosses Words", "HuntZoneList");
    AddTeleportLine(2, "hunt", "Epic Bosses Words", "HuntZoneList");

    MainZoneListTree.SetScrollPosition(0);
    HuntZoneListTree.SetScrollPosition(0);
}


// ============================================================
// DESTINOS DO SERVIDOR
//
// Parametros:
// aba, categoria, ID do destino, nome, preco, noble, X, Y.
//
// Z, efeito e validacoes continuam no servidor.
// ============================================================

function LoadZonesData()
{
    zones.Length = 0;

    // MAIN 0: Towns and Villages.
    AddServerTeleport("main", 0, 1, "Town of Giran", 2000, False, "83456", "148609");
    AddServerTeleport("main", 0, 2, "Town of Aden", 2000, False, "147464", "25949");
    AddServerTeleport("main", 0, 3, "Town of Schuttgart", 2000, False, "87393", "-143389");
    AddServerTeleport("main", 0, 4, "Town of Oren", 2000, False, "82795", "53366");
    AddServerTeleport("main", 0, 5, "Town of Gludio", 2000, False, "-12672", "122776");
    AddServerTeleport("main", 0, 6, "Heine", 2000, False, "111397", "219036");
    AddServerTeleport("main", 0, 7, "Town of Goddard", 2000, False, "147681", "-55451");
    AddServerTeleport("main", 0, 8, "Town of Dion", 2000, False, "15245", "143096");
    AddServerTeleport("main", 0, 9, "Rune Township", 2000, False, "43823", "-48148");
    AddServerTeleport("main", 0, 10, "Talking Island Village", 2000, False, "-84570", "244403");
    AddServerTeleport("main", 0, 11, "Elven Village", 2000, False, "47015", "51182");
    AddServerTeleport("main", 0, 12, "Dark Elven Village", 2000, False, "9841", "15578");
    AddServerTeleport("main", 0, 13, "Orc Village", 2000, False, "-45031", "-112669");
    AddServerTeleport("main", 0, 14, "Dwarven Village", 2000, False, "115376", "-178058");
    AddServerTeleport("main", 0, 15, "Hunter Village", 2000, False, "116716", "76502");
    AddServerTeleport("main", 0, 16, "Gludin Village", 2000, False, "-80877", "150183");
    AddServerTeleport("main", 0, 17, "Floran Village", 2000, False, "17811", "170219");

    // MAIN 1: Level Destinations.
    AddServerTeleport("main", 1, 601, "Cruma Tower: (Level 40 - 55)", 0, False, "17733", "108369");
    AddServerTeleport("main", 1, 602, "Devasted Castle: (Level 55 - 65)", 0, False, "168783", "-18775");
    AddServerTeleport("main", 1, 603, "Swamp of Screams: (Level 65 - 75)", 0, False, "69612", "-50136");
    AddServerTeleport("main", 1, 29, "Forge of the Gods: (Level 75 - 85)", 2000, False, "174455", "-115583");

    // MAIN 2: Intermed Drop Zone.
    AddServerTeleport("main", 2, 620, "Ketra Orc Outpost I", 0, False, "140610", "-76026");
    AddServerTeleport("main", 2, 621, "Ketra Orc Outpost II", 0, False, "145896", "-89480");
    AddServerTeleport("main", 2, 622, "Ketra Orc Outpost III", 0, False, "137376", "-76860");
    AddServerTeleport("main", 2, 623, "Fafurion's Nest I", 0, False, "168846", "234475");
    AddServerTeleport("main", 2, 624, "Fafurion's Nest II", 0, False, "185438", "235733");
    AddServerTeleport("main", 2, 625, "Fafurion's Nest III", 0, False, "173313", "246869");

    // MAIN 3: Extreme Drop Zone.
    AddServerTeleport("main", 3, 632, "Talking Island I", 0, False, "-84334", "244586");
    AddServerTeleport("main", 3, 633, "Talking Island Random II", 0, False, "-99194", "237757");

    // MAIN 5: Spoil.
    AddServerTeleport("main", 5, 673, "Instancias Spoil", 0, False, "46850", "-115842");

    // MAIN 7: PvP.
    AddServerTeleport("main", 7, 696, "Area PvP Event", 0, False, "115276", "191443");
    AddServerTeleport("main", 7, 697, "Giran Arena", 0, False, "73890", "142656");
    AddServerTeleport("main", 7, 698, "Gludin Arena", 0, False, "-88929", "142092");

    // MAIN 9: Monastery.
    AddServerTeleport("main", 9, 629, "Monastery I", 0, False, "120725", "-74854");
    AddServerTeleport("main", 9, 630, "Monastery II", 0, False, "115388", "-88857");
    AddServerTeleport("main", 9, 631, "Monastery III", 0, False, "117093", "-81185");

    // MAIN 10: Advanced Destinations.
    AddServerTeleport("main", 10, 30, "Advanced Destination 30", 2000, False, "10731", "-24387");
    AddServerTeleport("main", 10, 31, "Advanced Destination 31", 2000, False, "6998", "-9875");
    AddServerTeleport("main", 10, 32, "Advanced Destination 32", 2000, False, "13310", "-9116");
    AddServerTeleport("main", 10, 33, "Advanced Destination 33", 2000, False, "26792", "-20102");

    // HUNT 1: Raid Bosses Words.
    AddServerTeleport("hunt", 1, 641, "Flame of Splendor Barakiel", 0, False, "85624", "-85416");
    AddServerTeleport("hunt", 1, 647, "Ketra's Hero Hekaton ", 0, False, "147204", "-79381");
    AddServerTeleport("hunt", 1, 645, "Ketra's Commander Tayr", 0, False, "149896", "-81032");
    AddServerTeleport("hunt", 1, 643, "Ketra's Chief Brakki", 0, False, "149896", "-81064");
    AddServerTeleport("hunt", 1, 649, "Varka's Hero Shadith", 0, False, "114056", "-43112");
    AddServerTeleport("hunt", 1, 653, "Varka's Commander Mos", 0, False, "109960", "-41384");
    AddServerTeleport("hunt", 1, 651, "Varka's Chief Horus", 0, False, "110728", "-43736");
    AddServerTeleport("hunt", 1, 657, "Beast Lord Behemoth", 0, False, "125238", "-33112");
    AddServerTeleport("hunt", 1, 659, "Cherub Galaxias", 0, False, "126735", "-45272");

    // HUNT 2: Epic Bosses.
    AddServerTeleport("hunt", 2, 680, "Valakas", 0, False, "181980", "-117963");
    AddServerTeleport("hunt", 2, 678, "Antharas", 0, False, "154378", "121344");
    AddServerTeleport("hunt", 2, 674, "Baium", 0, False, "114012", "17463");
    AddServerTeleport("hunt", 2, 682, "Zaken", 0, False, "50282", "-94067");
    AddServerTeleport("hunt", 2, 676, "Queen Ant", 0, False, "-23992", "184008");
    AddServerTeleport("hunt", 2, 684, "Core", 0, False, "18646", "115416");
    AddServerTeleport("hunt", 2, 686, "Orfen", 0, False, "50264", "18568");
    AddServerTeleport("hunt", 2, 688, "Scarlet Van Halisha (Frintezza)", 0, False, "180216", "-78697");
    AddServerTeleport("hunt", 2, 690, "Sailren", 0, False, "22023", "-8706");
}


// ============================================================
// SELECIONAR CATEGORIA MAIS PROXIMA DO PERSONAGEM
// ============================================================

function SetTeleportTabAndLine()
{
    local UserInfo Info;
    local int i;
    local int BestIndex;
    local int TabIndex;
    local float DeltaX;
    local float DeltaY;
    local float Distance;
    local float BestDistance;
    local string RootName;

    if (!GetPlayerInfo(Info) || zones.Length == 0)
        return;

    BestIndex = -1;

    for (i = 0; i < zones.Length; i++)
    {
        DeltaX = float(zones[i].x) - Info.Loc.x;
        DeltaY = float(zones[i].y) - Info.Loc.y;

        Distance = DeltaX * DeltaX + DeltaY * DeltaY;

        if (BestIndex < 0 || Distance < BestDistance)
        {
            BestIndex = i;
            BestDistance = Distance;
        }
    }

    if (BestIndex < 0)
        return;

    RootName = "MainZoneList";
    TabIndex = 0;

    if (zones[BestIndex].catName == "hunt")
    {
        RootName = "HuntZoneList";
        TabIndex = 1;
    }

    class'UIAPI_TABCTRL'.Static.SetTopOrder(
        m_WindowName$".TeleportTabCtrl",
        TabIndex,
        False
    );

    Search_EditBox.SetString("");

    FindAndShowItemList("");

    class'UIAPI_TREECTRL'.Static.SetExpandedNode(
        TreeCtrlPath(RootName),
        RootName$"."$
        zones[BestIndex].catName$"_"$
        zones[BestIndex].catId,
        True
    );

    GetSubTreeList(
        RootName$"."$
        zones[BestIndex].catName$"_"$
        zones[BestIndex].catId
    );
}


// ============================================================
// PESQUISA
// ============================================================

function FindAndShowItemList(string searchStr)
{
    local int i, j;
    local ButtonHandle teleportBtn;
    local float x, y;
    local string type, listName;

    resZones = cleanZones;

    CleanMapBtns();
    InitMainTrees();
    InitSubTrees();

    if (searchStr == "")
    {
        InitTreesContent();

        MainZoneHeaderTex.SetTexture(
            "L2UI_AS.TeleportWnd.light_HighLVList"
        );

        MainZoneText.SetText("Global Teleport");
        MainZoneText.SetTextColor(
            MakeRGB(204, 179, 255)
        );

        HuntZoneHeaderTex.SetTexture(
            "L2UI_AS.TeleportWnd.light_Bookmark"
        );

        HuntZoneText.SetText("Boss Teleport");
        HuntZoneText.SetTextColor(
            MakeRGB(230, 153, 77)
        );

        return;
    }

    if (GetTeleportTabIndex() == 0)
    {
        type = "main";
        listName = "SubMainZoneList";

        MainZoneHeaderTex.SetTexture(
            "L2UI_AS.TeleportWnd.light_Searchresult"
        );

        MainZoneText.SetText("Search result");
        MainZoneText.SetTextColor(
            MakeRGB(128, 179, 128)
        );
    }
    else
    {
        type = "hunt";
        listName = "SubHuntZoneList";

        HuntZoneHeaderTex.SetTexture(
            "L2UI_AS.TeleportWnd.light_Searchresult"
        );

        HuntZoneText.SetText("Search result");
        HuntZoneText.SetTextColor(
            MakeRGB(128, 179, 128)
        );
    }

    j = 0;

    for (i = 0; i < zones.Length; i++)
    {
        if (
            zones[i].catName == type &&
            InStr(Caps(zones[i].name), Caps(searchStr)) != -1
        )
        {
            resZones[resZones.Length] = zones[i];

            AddTeleportLine(
                j,
                type,
                "subLine"$j,
                listName
            );

            if (j < MAX_BUTTON_ON_MAP)
            {
                teleportBtn = ButtonHandle(
                    GetHandle(
                        m_WindowName$
                        ".TeleportMapOverlayWnd.TeleportMapIcon"$
                        j$".btnTeleportIcon"
                    )
                );

                teleportBtn.SetTooltipCustomType(
                    TeleportLocTooltip(j)
                );

                if (
                    resZones[j].catName == "main" &&
                    (
                        resZones[j].catId == 4 ||
                        resZones[j].catId == 5
                    )
                )
                {
                    teleportBtn.SetTexture(
                        "L2UI_AS.TeleportWnd.TeleporMap_LVHuntingIcon",
                        "L2UI_AS.TeleportWnd.TeleporMap_LVHuntingIcon_Down",
                        "L2UI_AS.TeleportWnd.TeleporMap_LVHuntingIcon_Over"
                    );
                }
                else
                {
                    teleportBtn.SetTexture(
                        "L2UI_AS.TeleportWnd.TeleporMap_HuntingIcon",
                        "L2UI_AS.TeleportWnd.TeleporMap_HuntingIcon_Down",
                        "L2UI_AS.TeleportWnd.TeleporMap_HuntingIcon_Over"
                    );
                }

                class'UIAPI_WINDOW'.Static.SetWindowSize(
                    m_WindowName$
                    ".TeleportMapOverlayWnd.TeleportMapIcon"$j,
                    16,
                    16
                );

                x = (
                    ((float(resZones[j].x) - float(-229300)) / 133)
                    * 0.11
                ) - 54 - 5;

                y = (
                    ((float(resZones[j].y) - float(-260600)) / 133)
                    * 0.11
                ) - 5;

                class'UIAPI_WINDOW'.Static.ShowWindow(
                    m_WindowName$
                    ".TeleportMapOverlayWnd.TeleportMapIcon"$j
                );

                class'UIAPI_WINDOW'.Static.ClearAnchor(
                    m_WindowName$
                    ".TeleportMapOverlayWnd.TeleportMapIcon"$j
                );

                class'UIAPI_WINDOW'.Static.SetAnchor(
                    m_WindowName$
                    ".TeleportMapOverlayWnd.TeleportMapIcon"$j,
                    m_WindowName$".TeleportMapOverlayWnd",
                    "TopLeft",
                    "TopLeft",
                    x,
                    y
                );

                ApplyBossMapIcon(j);
            }

            j++;
        }
    }

    SubMainZoneListTree.SetScrollPosition(0);
    SubHuntZoneListTree.SetScrollPosition(0);
}


// ============================================================
// DESTINOS DA CATEGORIA SELECIONADA
// ============================================================

function GetSubTreeList(string strID)
{
    local int i, j;
    local string ListName;
    local array<string> strSplit;
    local array<string> strSubSplit;
    local float x, y;
    local ButtonHandle teleportBtn;

    Split(strID, ".", strSplit);

    if (strSplit.Length < 2)
        return;

    Split(strSplit[1], "_", strSubSplit);

    if (strSubSplit.Length != 2)
        return;

    if (
        strSplit[0] != "MainZoneList" &&
        strSplit[0] != "HuntZoneList"
    )
        return;

    resZones.Length = 0;

    CleanMapBtns();

    ListName = "Sub"$strSplit[0];

    ClearXMLNode(TreeCtrlPath(ListName));

    InsertXMLNodeRoot(
        TreeCtrlPath(ListName),
        ListName,
        "",
        0,
        0
    );

    j = 0;

    for (i = 0; i < zones.Length; i++)
    {
        if (
            zones[i].catName == strSubSplit[0] &&
            zones[i].catId == int(strSubSplit[1])
        )
        {
            resZones[resZones.Length] = zones[i];

            AddTeleportLine(
                j,
                strSplit[1],
                "subLine"$j,
                ListName
            );

            if (j < MAX_BUTTON_ON_MAP)
            {
                teleportBtn = ButtonHandle(
                    GetHandle(
                        m_WindowName$
                        ".TeleportMapOverlayWnd.TeleportMapIcon"$
                        j$".btnTeleportIcon"
                    )
                );

                teleportBtn.SetTooltipCustomType(
                    TeleportLocTooltip(j)
                );

                if (
                    resZones[j].catName == "main" &&
                    resZones[j].catId == 0
                )
                {
                    teleportBtn.SetTexture(
                        "L2UI_AS.TeleportWnd.TeleporMap_VillageIcon",
                        "L2UI_AS.TeleportWnd.TeleporMap_VillageIcon_Down",
                        "L2UI_AS.TeleportWnd.TeleporMap_VillageIcon_Over"
                    );

                    class'UIAPI_WINDOW'.Static.SetWindowSize(
                        m_WindowName$
                        ".TeleportMapOverlayWnd.TeleportMapIcon"$j,
                        32,
                        32
                    );

                    x = (
                        ((float(resZones[j].x) - float(-229300)) / 133)
                        * 0.11
                    ) - 54 - 16;

                    y = (
                        ((float(resZones[j].y) - float(-260600)) / 133)
                        * 0.11
                    ) - 16;
                }
                else
                {
                    if (
                        resZones[j].catName == "main" &&
                        (
                            resZones[j].catId == 4 ||
                            resZones[j].catId == 5
                        )
                    )
                    {
                        teleportBtn.SetTexture(
                            "L2UI_AS.TeleportWnd.TeleporMap_LVHuntingIcon",
                            "L2UI_AS.TeleportWnd.TeleporMap_LVHuntingIcon_Down",
                            "L2UI_AS.TeleportWnd.TeleporMap_LVHuntingIcon_Over"
                        );
                    }
                    else
                    {
                        teleportBtn.SetTexture(
                            "L2UI_AS.TeleportWnd.TeleporMap_HuntingIcon",
                            "L2UI_AS.TeleportWnd.TeleporMap_HuntingIcon_Down",
                            "L2UI_AS.TeleportWnd.TeleporMap_HuntingIcon_Over"
                        );
                    }

                    class'UIAPI_WINDOW'.Static.SetWindowSize(
                        m_WindowName$
                        ".TeleportMapOverlayWnd.TeleportMapIcon"$j,
                        16,
                        16
                    );

                    x = (
                        ((float(resZones[j].x) - float(-229300)) / 133)
                        * 0.11
                    ) - 54 - 6;

                    y = (
                        ((float(resZones[j].y) - float(-260600)) / 133)
                        * 0.11
                    ) - 6;
                }

                class'UIAPI_WINDOW'.Static.ShowWindow(
                    m_WindowName$
                    ".TeleportMapOverlayWnd.TeleportMapIcon"$j
                );

                class'UIAPI_WINDOW'.Static.ClearAnchor(
                    m_WindowName$
                    ".TeleportMapOverlayWnd.TeleportMapIcon"$j
                );

                class'UIAPI_WINDOW'.Static.SetAnchor(
                    m_WindowName$
                    ".TeleportMapOverlayWnd.TeleportMapIcon"$j,
                    m_WindowName$".TeleportMapOverlayWnd",
                    "TopLeft",
                    "TopLeft",
                    x,
                    y
                );

                ApplyBossMapIcon(j);
            }

            j++;
        }
    }

    SubMainZoneListTree.SetScrollPosition(0);
    SubHuntZoneListTree.SetScrollPosition(0);
}


// ============================================================
// CONSTRUCAO DAS LINHAS
// ============================================================
function AddTeleportLine(int strID, string type, string lineName, string ListName)
{
    local XMLTreeNodeInfo infNode;
    local XMLTreeNodeInfo infNodeClear;
    local string strRetName;
    local int lineWidth, offsetY, iconOffset, wHeight, squareSize;
    local int DisplayPrice, NameOffsetX;
    local string iconName, textName, idName, PriceText;
    local string BackgroundTexture;
    local Color colorName, PriceColor;
    local bool bSubLine;

    bSubLine = (Left(lineName, 7) == "subLine");

    if (bSubLine)
    {
        if (strID < 0 || strID >= resZones.Length)
            return;

        lineWidth = 292;
        iconName = "L2UI_AS.TeleportWnd.TeleporMap_HuntingIcon";
        colorName = MakeRGB(200, 200, 200);

        idName = "Teleport_"$resZones[strID].id;
        textName = resZones[strID].name;

        if (Len(textName) > 38)
            textName = Left(textName, 35)$"...";

        offsetY = 3;
        wHeight = 37;
        iconOffset = 11;
        squareSize = 11;

        DisplayPrice = GetTeleportPrice(resZones[strID].price);
        PriceText = MakeCostString(string(DisplayPrice));
        PriceColor = GetNumericColor(PriceText);
    }
    else
    {
        lineWidth = 186;
        iconName = "L2UI_AS.TeleportWnd.TeleporMap_VillageIcon";
        colorName = MakeRGB(130, 114, 93);

        idName = type$"_"$strID;
        textName = lineName;

        offsetY = 6;
        wHeight = 26;
        iconOffset = 0;
        squareSize = 24;
    }

    if (bSubLine)
    {
        if (resZones[strID].catName == "hunt")
        {
            iconName = GetBossStatusIcon(resZones[strID].id);

            // Nome sempre branco.
            colorName = MakeRGB(255, 255, 255);

            iconOffset = 2;
            squareSize = 32;
        }
    }
    else if (type == "hunt")
    {
        // Icone das categorias sempre cinza.
        iconName = RAID_ICON;
    }

    NameOffsetX = iconOffset + 2;

    if (!bSubLine && type == "hunt")
        NameOffsetX = 8;

    // Fundo alternado nas categorias e nos destinos.
    // Linha clara seguida de linha transparente/escura.
    if ((strID % 2) == 0)
        BackgroundTexture = "L2UI_AS.etc.lineback";
    else
        BackgroundTexture = "L2UI_CH3.Etc.Null";

    infNode = infNodeClear;
    infNode.strName = idName;
    infNode.bFollowCursor = True;
    infNode.bShowButton = 0;

    infNode.nTexExpandedOffSetX = 0;
    infNode.nTexExpandedOffSetY = 0;
    infNode.nTexExpandedHeight = wHeight;
    infNode.nTexExpandedRightWidth = 32;
    infNode.nTexExpandedLeftUWidth = 16;
    infNode.nTexExpandedLeftUHeight = wHeight;
    infNode.nTexExpandedRightUWidth = 32;
    infNode.nTexExpandedRightUHeight = wHeight;

    infNode.strTexExpandedLeft = "L2UI_AS.etc.iconselect1_over";
    infNode.strTexExpandedRight = "L2UI_AS.etc.iconselect2_over";

    if (bSubLine)
        infNode.ToolTip = TeleportLocTooltip(strID);

    strRetName = class'UIAPI_TREECTRL'.Static.InsertNode(
        TreeCtrlPath(ListName),
        ListName,
        infNode
    );

    if (Len(strRetName) < 1)
        return;

    // Fundo da linha.
    // A textura transparente mantem o mesmo posicionamento.
    InsertXMLNodeTexture(
        TreeCtrlPath(ListName),
        strRetName,
        BackgroundTexture,
        "",
        lineWidth,
        wHeight
    );

    // Icone.
    InsertXMLNodeTexture(
        TreeCtrlPath(ListName),
        strRetName,
        iconName,
        "",
        squareSize,
        squareSize,
        -lineWidth + iconOffset,
        iconOffset
    );

    // Primeira linha: nome.
    InsertXMLNodeText(
        TreeCtrlPath(ListName),
        strRetName,
        textName,
        NameOffsetX,
        offsetY,
        colorName,
        True
    );

    if (bSubLine)
    {
        // Bosses: segunda linha com status e respawn.
        if (resZones[strID].catName == "hunt")
        {
            InsertXMLNodeText(
                TreeCtrlPath(ListName),
                strRetName,
                GetBossStatusText(resZones[strID].id),
                40,
                -17,
                GetBossStatusColor(resZones[strID].id),
                True,
                True
            );

            return;
        }

        // Global Teleport: segunda linha com adena e preco.
        InsertXMLNodeTexture(
            TreeCtrlPath(ListName),
            strRetName,
            "L2UI_AS.Icon.Icon_Adena",
            "",
            14,
            11,
            40,
            -17,
            True,
            True
        );

        InsertXMLNodeText(
            TreeCtrlPath(ListName),
            strRetName,
            PriceText,
            3,
            -17,
            PriceColor,
            True
        );

        if (resZones[strID].noble)
        {
            InsertXMLNodeTexture(
                TreeCtrlPath(ListName),
                strRetName,
                "L2UI_AS.DetailStatusWnd.DetailStatus_IconNoble",
                "",
                12,
                12,
                15,
                -19,
                True,
                False
            );
        }
    }
}

function int GetTeleportTabIndex()
{
    return class'UIAPI_TABCTRL'.Static.GetTopIndex(
        m_WindowName$".TeleportTabCtrl"
    );
}


// ============================================================
// TOOLTIPS
// ============================================================

function CustomTooltip TeleportLocTooltip(int i)
{
    local CustomTooltip TooltipInfo;
    local Color whiteCol;

    if (resZones[i].catName == "hunt")
    {
        TooltipInfo.MinimumWidth = 160;
        TooltipInfo.DrawList.Length = 2;

        // Nome sempre branco.
        TooltipInfo.DrawList[0].eType = DIT_TEXT;
        TooltipInfo.DrawList[0].t_bDrawOneLine = True;
        TooltipInfo.DrawList[0].t_color = MakeRGB(255, 255, 255);
        TooltipInfo.DrawList[0].t_strText = resZones[i].name;

        // Apenas o status muda de cor.
        TooltipInfo.DrawList[1].eType = DIT_TEXT;
        TooltipInfo.DrawList[1].bLineBreak = True;
        TooltipInfo.DrawList[1].nOffSetY = 4;
        TooltipInfo.DrawList[1].t_bDrawOneLine = True;

        TooltipInfo.DrawList[1].t_color =
            GetBossStatusColor(resZones[i].id);

        TooltipInfo.DrawList[1].t_strText =
            GetBossStatusText(resZones[i].id);

        return TooltipInfo;
    }

    TooltipInfo.MinimumWidth = 110;
    TooltipInfo.DrawList.Length = 4;

    whiteCol.R = 255;
    whiteCol.G = 255;
    whiteCol.B = 255;
    whiteCol.A = 255;

    TooltipInfo.DrawList[0].eType = DIT_TEXT;
    TooltipInfo.DrawList[0].nOffSetX = 1;
    TooltipInfo.DrawList[0].t_bDrawOneLine = True;
    TooltipInfo.DrawList[0].t_color = whiteCol;
    TooltipInfo.DrawList[0].t_strText = resZones[i].name;

    TooltipInfo.DrawList[1].eType = DIT_TEXTURE;
    TooltipInfo.DrawList[1].nOffSetX = 0;
    TooltipInfo.DrawList[1].nOffSetY = 4;
    TooltipInfo.DrawList[1].u_nTextureWidth = 15;
    TooltipInfo.DrawList[1].u_nTextureHeight = 12;

    TooltipInfo.DrawList[1].u_strTexture =
        "L2UI_AS.Icon.Icon_Adena";

    TooltipInfo.DrawList[1].bLineBreak = True;

    TooltipInfo.DrawList[2].eType = DIT_TEXT;
    TooltipInfo.DrawList[2].nOffSetX = 3;
    TooltipInfo.DrawList[2].nOffSetY = 4;
    TooltipInfo.DrawList[2].t_bDrawOneLine = True;

    TooltipInfo.DrawList[2].t_color = GetNumericColor(
        MakeCostString(
            string(GetTeleportPrice(resZones[i].price))
        )
    );

    TooltipInfo.DrawList[2].t_strText = MakeCostString(
        string(GetTeleportPrice(resZones[i].price))
    );

    if (resZones[i].noble)
    {
        TooltipInfo.DrawList[3].eType = DIT_TEXTURE;
        TooltipInfo.DrawList[3].nOffSetX = 12;
        TooltipInfo.DrawList[3].nOffSetY = 2;
        TooltipInfo.DrawList[3].t_bDrawOneLine = True;
        TooltipInfo.DrawList[3].u_nTextureWidth = 14;
        TooltipInfo.DrawList[3].u_nTextureHeight = 14;

        TooltipInfo.DrawList[3].u_strTexture =
            "L2UI_AS.DetailStatusWnd.DetailStatus_IconNoble";
    }

    return TooltipInfo;
}

function CustomTooltip MakeTeleportTextTooltip(string TooltipText)
{
    local CustomTooltip TooltipInfo;
    local Color TextColor;

    TextColor.R = 255;
    TextColor.G = 255;
    TextColor.B = 255;
    TextColor.A = 255;

    TooltipInfo.MinimumWidth = 110;
    TooltipInfo.DrawList.Length = 1;

    TooltipInfo.DrawList[0].eType = DIT_TEXT;
    TooltipInfo.DrawList[0].nOffSetX = 1;
    TooltipInfo.DrawList[0].nOffSetY = 1;
    TooltipInfo.DrawList[0].t_bDrawOneLine = True;
    TooltipInfo.DrawList[0].t_color = TextColor;
    TooltipInfo.DrawList[0].t_strText = TooltipText;

    return TooltipInfo;
}


// ============================================================
// CADASTRO E CONFIRMACAO DOS DESTINOS
// ============================================================

function AddServerTeleport(
    string Category,
    int CategoryId,
    int DestinationId,
    string DestinationName,
    int Price,
    bool Noble,
    string MapX,
    string MapY
)
{
    local zonesData Zone;

    Zone.catName = Category;
    Zone.catId = CategoryId;
    Zone.id = DestinationId;
    Zone.name = DestinationName;
    Zone.price = Price;
    Zone.noble = Noble;
    Zone.x = MapX;
    Zone.y = MapY;

    zones[zones.Length] = Zone;
}

function int FindTeleportIndex(int DestinationId)
{
    local int i;

    for (i = 0; i < zones.Length; i++)
    {
        if (zones[i].id == DestinationId)
            return i;
    }

    return -1;
}

function ShowTeleportConfirmation(int DestinationId)
{
    local int ZoneIndex;

    ZoneIndex = FindTeleportIndex(DestinationId);

    if (ZoneIndex < 0)
        return;

    if (DialogIsMine())
        DialogHide();

    PendingTeleportId = DestinationId;

    DialogSetID(7717);
    DialogSetReservedInt(DestinationId);

    DialogShow(
        DIALOG_OKCancel,
        "Teleport to"@zones[ZoneIndex].name
    );
}

function int GetTeleportPrice(int BasePrice)
{
    local UserInfo Info;

    if (GetPlayerInfo(Info) && Info.nLevel < 40)
        return 0;

    return BasePrice;
}


// ============================================================
// ICONES DOS BOSSES NO MAPA
// ============================================================

function ApplyBossMapIcon(int MapIndex)
{
    local ButtonHandle Marker;
    local string IconPath;
    local float MapX, MapY;
    local string BossIcon;

    if (MapIndex < 0 || MapIndex >= MAX_BUTTON_ON_MAP)
        return;

    if (MapIndex >= resZones.Length)
        return;

    if (resZones[MapIndex].catName != "hunt")
        return;

    IconPath = m_WindowName$
        ".TeleportMapOverlayWnd.TeleportMapIcon"$MapIndex;

    Marker = ButtonHandle(
        GetHandle(IconPath$".btnTeleportIcon")
    );

    if (Marker == None)
        return;

    BossIcon = GetBossStatusIcon(
        resZones[MapIndex].id
    );

    Marker.SetTexture(
        BossIcon,
        BossIcon,
        BossIcon
    );

    Marker.SetTooltipCustomType(
        TeleportLocTooltip(MapIndex)
    );

    MapX = (
        ((float(resZones[MapIndex].x) - float(-229300)) / 133)
        * 0.11
    ) - 54 - 16;

    MapY = (
        ((float(resZones[MapIndex].y) - float(-260600)) / 133)
        * 0.11
    ) - 16;

    class'UIAPI_WINDOW'.Static.SetWindowSize(
        IconPath,
        32,
        32
    );

    class'UIAPI_WINDOW'.Static.ClearAnchor(IconPath);

    class'UIAPI_WINDOW'.Static.SetAnchor(
        IconPath,
        m_WindowName$".TeleportMapOverlayWnd",
        "TopLeft",
        "TopLeft",
        MapX,
        MapY
    );
}


// ============================================================
// CONSULTA E APRESENTACAO DOS STATUS
// ============================================================

function RequestBossStatuses()
{
    RaidStatuses.Length = 0;

    RedrawBossResults();

    RequestBypassToServer("GkRaidStatus");
}

function int FindBossStatus(int DestinationId)
{
    local int i;

    for (i = 0; i < RaidStatuses.Length; i++)
    {
        if (RaidStatuses[i].DestinationId == DestinationId)
            return i;
    }

    return -1;
}

function string GetBossStatusIcon(int DestinationId)
{
    local int i;

    i = FindBossStatus(DestinationId);

    if (i >= 0)
    {
        if (RaidStatuses[i].StatusCode == "A")
            return "L2_GF.MinimapWnd.Boss_On";

        if (RaidStatuses[i].StatusCode == "D")
            return "L2_GF.MinimapWnd.Boss_Red";
    }

    return RAID_ICON;
}

function Color GetBossStatusColor(int DestinationId)
{
    local int i;

    i = FindBossStatus(DestinationId);

    if (i >= 0)
    {
        if (RaidStatuses[i].StatusCode == "A")
            return MakeRGB(95, 215, 105);

        if (RaidStatuses[i].StatusCode == "D")
            return MakeRGB(235, 105, 95);
    }

    return MakeRGB(180, 180, 180);
}

function string GetBossStatusText(int DestinationId)
{
    local int i;

    i = FindBossStatus(DestinationId);

    if (i < 0)
        return "Aguardando dados...";

    if (RaidStatuses[i].StatusCode == "A")
        return "Alive";

    if (RaidStatuses[i].StatusCode == "D")
    {
        if (
            RaidStatuses[i].Respawn != "-" &&
            RaidStatuses[i].Respawn != ""
        )
        {
            return "Dead - "$RaidStatuses[i].Respawn;
        }

        return "Dead - horario indisponivel";
    }

    return "Sem informacao";
}


// ============================================================
// RECEBIMENTO DOS DADOS DO SERVIDOR
//
// Formato:
// CustomEvent=TeleportRaidV1|641,A,-;642,D,26/10_21:00
//
// A = vivo
// D = morto
// U = sem informacao
// ============================================================

function ReceiveBossStatusEvent(string Params)
{
    local string Message;
    local array<string> Sections;
    local array<string> Rows;
    local array<string> Fields;
    local array<RaidStatusData> NewStatuses;
    local int i, n, DestinationId, ZoneIndex;

    if (!m_bShow)
        return;

    ParseString(Params, "Msg", Message);

    Split(Message, "|", Sections);

    if (Sections.Length != 2)
        return;

    if (Sections[0] != "CustomEvent=TeleportRaidV1")
        return;

    Split(Sections[1], ";", Rows);

    for (i = 0; i < Rows.Length; i++)
    {
        Fields.Length = 0;

        Split(Rows[i], ",", Fields);

        if (Fields.Length != 3)
            return;

        if (
            Fields[1] != "A" &&
            Fields[1] != "D" &&
            Fields[1] != "U"
        )
            return;

        DestinationId = int(Fields[0]);

        ZoneIndex = FindTeleportIndex(DestinationId);

        // Ignora os destinos Respawn II removidos da interface.
        if (ZoneIndex < 0)
            continue;

        if (zones[ZoneIndex].catName != "hunt")
            return;

        n = NewStatuses.Length;

        NewStatuses.Length = n + 1;

        NewStatuses[n].DestinationId = DestinationId;
        NewStatuses[n].StatusCode = Fields[1];
        NewStatuses[n].Respawn = Fields[2];

        n = InStr(Fields[2], "_");

        if (n >= 0)
        {
            NewStatuses[NewStatuses.Length - 1].Respawn =
                Left(Fields[2], n)$" "$Mid(Fields[2], n + 1);
        }
    }

    RaidStatuses = NewStatuses;

    RedrawBossResults();
}


// ============================================================
// ATUALIZACAO DA LISTA ABERTA
// ============================================================

function RedrawBossResults()
{
    local int i;
    local string ListName;

    if (!m_bShow)
        return;

    if (GetTeleportTabIndex() != 1)
        return;

    if (resZones.Length == 0)
        return;

    if (resZones[0].catName != "hunt")
        return;

    ListName = "SubHuntZoneList";

    ClearXMLNode(TreeCtrlPath(ListName));

    InsertXMLNodeRoot(
        TreeCtrlPath(ListName),
        ListName,
        "",
        0,
        0
    );

    CleanMapBtns();

    for (i = 0; i < resZones.Length; i++)
    {
        AddTeleportLine(
            i,
            "hunt",
            "subLine"$i,
            ListName
        );

        if (i < MAX_BUTTON_ON_MAP)
        {
            ApplyBossMapIcon(i);

            class'UIAPI_WINDOW'.Static.ShowWindow(
                m_WindowName$
                ".TeleportMapOverlayWnd.TeleportMapIcon"$i
            );
        }
    }
}

