class ButtonPvPWnd extends UICommonAPI;

var WindowHandle Me;
var ButtonHandle btnPvP;
var ButtonHandle btnSmall1;
var ButtonHandle btnSmall2;

var bool m_bExpanded;
var bool m_waitingResponse;
var bool m_stateKnown;
var bool m_showTutorialAfterReply;

var int m_currentMode;
var int m_smallMode1;
var int m_smallMode2;
var int m_requestedMode;

function OnLoad()
{
    Me = GetHandle("ButtonPvPWnd");

    btnPvP = ButtonHandle(
        GetHandle("ButtonPvPWnd.btnPvP")
    );

    btnSmall1 = ButtonHandle(
        GetHandle("ButtonPvPWnd.btnSmall1")
    );

    btnSmall2 = ButtonHandle(
        GetHandle("ButtonPvPWnd.btnSmall2")
    );

    RegisterEvent(EV_UpdateUserInfo);
    RegisterEvent(28650);

    ResetInterfaceState();
    CheckLevelVisibility();
    TrySynchronizeMode();
}

event OnEnterState(name a_PreStateName)
{
    ResetInterfaceState();
    CheckLevelVisibility();
    TrySynchronizeMode();
}

function OnExitState(name a_NextStateName)
{
    Me.KillTimer(28651);

    m_waitingResponse = false;
    m_stateKnown = false;
    m_bExpanded = false;
    m_showTutorialAfterReply = false;

    Me.HideWindow();
}

function ResetInterfaceState()
{
    Me.KillTimer(28651);

    m_currentMode = 0;
    m_smallMode1 = 1;
    m_smallMode2 = 2;
    m_requestedMode = -1;

    m_bExpanded = false;
    m_waitingResponse = false;
    m_stateKnown = false;
    m_showTutorialAfterReply = false;

    UpdateVisuals();
}

function OnEvent(int Event_ID, string param)
{
    if(Event_ID == EV_UpdateUserInfo)
    {
        CheckLevelVisibility();
        TrySynchronizeMode();
    }
    else if(Event_ID == 28650)
    {
        HandleModeState(param);
    }
}

function CheckLevelVisibility()
{
    local UserInfo info;

    if(GetPlayerInfo(info))
    {
        if(info.nLevel >= 20)
        {
            Me.ShowWindow();
            return;
        }
    }

    m_bExpanded = false;

    btnSmall1.HideWindow();
    btnSmall2.HideWindow();

    Me.HideWindow();
}

function TrySynchronizeMode()
{
    local UserInfo info;

    if(m_stateKnown || m_waitingResponse)
    {
        return;
    }

    if(!GetPlayerInfo(info))
    {
        return;
    }

    if(info.nLevel < 20)
    {
        return;
    }

    m_requestedMode = -1;
    m_showTutorialAfterReply = false;
    m_waitingResponse = true;

    Me.SetTimer(28651, 5000);

    RequestBypassToServer("voiced_playerModeStatus");
}

function UIEventManager.CustomTooltip ModeTooltip(string Text)
{
    local UIEventManager.CustomTooltip tooltip;
    local UIEventManager.DrawItemInfo item;

    if(Text == "PvE")
    {
        tooltip.MinimumWidth = 20;
    }
    else
    {
        tooltip.MinimumWidth = 40;
    }

    tooltip.DrawList.Length = 1;

    item.eType = DIT_TEXT;
    item.nOffSetX = 2;
    item.t_bDrawOneLine = true;
    item.t_strText = Text;

    item.t_color.R = 255;
    item.t_color.G = 220;
    item.t_color.B = 150;
    item.t_color.A = 255;

    tooltip.DrawList[0] = item;

    return tooltip;
}

function string ModeName(int mode)
{
    if(mode == 1)
    {
        return "PvE";
    }

    if(mode == 2)
    {
        return "Hunter";
    }

    return "Normal";
}

function ApplyButtonTextures(
    ButtonHandle btn,
    int mode,
    bool isSmall)
{
    local string texture;

    if(btn == None)
    {
        return;
    }

    if(mode == 1)
    {
        texture = "L2UI_CH3.btn_pve_mode";
    }
    else if(mode == 2)
    {
        texture = "L2UI_CH3.btn_pvp_mode";
    }
    else
    {
        texture = "L2UI_CH3.btn_normal_mode";
    }

    if(isSmall)
    {
        texture = texture $ "_small";
    }

    btn.SetTexture(
        texture,
        texture $ "_over",
        texture $ "_over"
    );

    btn.SetTooltipCustomType(
        ModeTooltip(ModeName(mode))
    );
}

function UpdateVisuals()
{
    ApplyButtonTextures(btnPvP, m_currentMode, false);
    ApplyButtonTextures(btnSmall1, m_smallMode1, true);
    ApplyButtonTextures(btnSmall2, m_smallMode2, true);

    if(m_bExpanded && m_stateKnown && !m_waitingResponse)
    {
        btnSmall1.ShowWindow();
        btnSmall2.ShowWindow();
    }
    else
    {
        btnSmall1.HideWindow();
        btnSmall2.HideWindow();
    }
}

function HandleModeState(string param)
{
    local int mode;
    local int result;
    local int previousMode;
    local bool showTutorial;

    if(!ParseInt(param, "Mode", mode))
    {
        return;
    }

    if(mode < 0 || mode > 2)
    {
        return;
    }

    ParseInt(param, "Result", result);

    previousMode = m_currentMode;

    showTutorial = m_waitingResponse
        && m_showTutorialAfterReply
        && result == 1
        && mode == m_requestedMode
        && mode != previousMode;

    Me.KillTimer(28651);

    m_currentMode = mode;
    m_stateKnown = true;
    m_waitingResponse = false;
    m_showTutorialAfterReply = false;
    m_requestedMode = -1;
    m_bExpanded = false;

    if(mode == 0)
    {
        m_smallMode1 = 1;
        m_smallMode2 = 2;
    }
    else if(mode == 1)
    {
        m_smallMode1 = 0;
        m_smallMode2 = 2;
    }
    else
    {
        m_smallMode1 = 0;
        m_smallMode2 = 1;
    }

    UpdateVisuals();
    CheckLevelVisibility();

    if(showTutorial)
    {
        ShowModeTutorial(mode);
    }
}

function SelectMode(int clickedMode, int smallSlotIndex)
{
    local string command;

    if(m_waitingResponse || !m_stateKnown)
    {
        return;
    }

    if(clickedMode < 0
        || clickedMode > 2
        || clickedMode == m_currentMode)
    {
        return;
    }

    if(clickedMode == 1)
    {
        command = "voiced_playerModePve";
    }
    else if(clickedMode == 2)
    {
        command = "voiced_playerModeHunter";
    }
    else
    {
        command = "voiced_playerModeNormal";
    }

    m_requestedMode = clickedMode;
    m_showTutorialAfterReply = true;
    m_waitingResponse = true;
    m_bExpanded = false;

    UpdateVisuals();

    Me.SetTimer(28651, 5000);

    RequestBypassToServer(command);
}

function ShowModeTutorial(int mode)
{
    local string texture;
    local string htmlContent;

    if(mode == 1)
    {
        texture = "tutorial_window.pve_mode";
    }
    else if(mode == 2)
    {
        texture = "tutorial_window.pvp_mode";
    }
    else
    {
        texture = "tutorial_window.normal_mode_nohunting";
    }

    class'NWindow.UIAPI_HTMLCTRL'.static.SetPageLock(
        "TutorialViewerWnd.HtmlTutorialViewer",
        false
    );

    class'NWindow.UIAPI_HTMLCTRL'.static.Clear(
        "TutorialViewerWnd.HtmlTutorialViewer"
    );

    class'NWindow.UIAPI_WINDOW'.static.SetWindowSize(
        "TutorialViewerWnd",
        534,
        292
    );

    class'NWindow.UIAPI_WINDOW'.static.SetAnchor(
        "TutorialViewerWnd.HtmlTutorialViewer",
        "TutorialViewerWnd",
        "TopLeft",
        "TopLeft",
        8,
        30
    );

    class'NWindow.UIAPI_WINDOW'.static.SetWindowSize(
        "TutorialViewerWnd.HtmlTutorialViewer",
        512,
        250
    );

    // Reabre a janela e o controle HTML antes do carregamento.
    ShowWindowWithFocus("TutorialViewerWnd");

    class'NWindow.UIAPI_WINDOW'.static.ShowWindow(
        "TutorialViewerWnd.HtmlTutorialViewer"
    );

    htmlContent =
        "<html><body style=\"overflow: hidden;\"><center><img src=\""
        $ texture
        $ "\" width=512 height=250></center></body></html>";

    class'NWindow.UIAPI_HTMLCTRL'.static.LoadHtmlFromString(
        "TutorialViewerWnd.HtmlTutorialViewer",
        htmlContent
    );
}

function ToggleMenu()
{
    if(m_waitingResponse)
    {
        return;
    }

    if(!m_stateKnown)
    {
        TrySynchronizeMode();
        return;
    }

    m_bExpanded = !m_bExpanded;

    UpdateVisuals();
}

function OnClickButton(string strID)
{
    local int dot;

    dot = InStr(strID, ".");

    while(dot >= 0)
    {
        strID = Mid(strID, dot + 1);
        dot = InStr(strID, ".");
    }

    if(Caps(strID) == "BTNPVP")
    {
        ToggleMenu();
    }
    else if(Caps(strID) == "BTNSMALL1")
    {
        SelectMode(m_smallMode1, 1);
    }
    else if(Caps(strID) == "BTNSMALL2")
    {
        SelectMode(m_smallMode2, 2);
    }
}

function OnTimer(int timerId)
{
    local Color messageColor;

    if(timerId != 28651)
    {
        return;
    }

    Me.KillTimer(28651);

    if(!m_waitingResponse)
    {
        return;
    }

    m_waitingResponse = false;
    m_stateKnown = false;
    m_showTutorialAfterReply = false;
    m_requestedMode = -1;
    m_bExpanded = false;

    UpdateVisuals();

    messageColor.R = 255;
    messageColor.G = 180;
    messageColor.B = 80;
    messageColor.A = 255;

    AddSystemMessage("O servidor nao confirmou o modo. Clique no botao para sincronizar novamente.",messageColor);
}

