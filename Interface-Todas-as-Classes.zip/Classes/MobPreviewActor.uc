class MobPreviewActor extends Actor;
