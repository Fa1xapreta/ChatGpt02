class BuffWnd extends UICommonAPI;

const _obf2171 = 6;
const _obf2172 = 24;
const _obf2173 = 40;
const _obf2174 = 98700;
const _obf2175 = 1900;

var string _obf1929;

var WindowHandle _obf2486;
var WindowHandle _obf2176;
var WindowHandle _obf2177;
var WindowHandle _obf2178;
var WindowHandle _obf2179;

var ButtonHandle _obf2180[24];
var ButtonHandle _obf2181[6];
var ButtonHandle _obf2182[6];

var ButtonHandle _obf2183;
var ButtonHandle _obf2184;
var ButtonHandle _obf2185;
var ButtonHandle _obf2186;
var ButtonHandle _obf2187;
var ButtonHandle _obf2188;
var ButtonHandle _obf2189;
var ButtonHandle _obf2190;
var ButtonHandle _obf2191;
var ButtonHandle _obf2192;
var ButtonHandle _obf2193;
var ButtonHandle _obf2194;
var ButtonHandle _obf2195;
var ButtonHandle _obf2196;
var ButtonHandle btnPresetHit;

var array<UIEventManager.SkillInfo> _obf2197;
var array<UIEventManager.SkillInfo> _obf2198;
var array<UIEventManager.SkillInfo> _obf2199;
var array<UIEventManager.SkillInfo> _obf2200;
var array<UIEventManager.SkillInfo> _obf2201;
var array<UIEventManager.SkillInfo> _obf2202;

var StatusIconHandle _obf2203;
var StatusIconHandle _obf2204;

var int _obf2205;
var int _obf2206;

var array<int> _obf2207;
var array<int> _obf2208;

var bool bPet;
var bool bVipBuffOpenPermit;

function _obf399()
{
    RegisterEvent(140);
    RegisterEvent(EV_LanguageChanged);
    RegisterEvent(99978);
    RegisterEvent(99979);
    RegisterEvent(99980);
    RegisterEvent(99995);
    RegisterEvent(EV_SystemMessage);
}

function OnLoad()
{
    local int _obf5804;

    _obf399();
    _obf1027();

    _obf2486 = _obf28(_obf1929);
    _obf2176 = _obf28(_obf1929 $ ".Buffs");
    _obf2177 = _obf28(_obf1929 $ ".Scheme");
    _obf2178 = _obf28(_obf1929 $ ".Preset");
    _obf2179 = _obf28(_obf1929 $ ".Preset.presetConfirm");

    _obf2183 = _obf29(_obf1929 $ ".btnAddPreset");
    _obf2184 = _obf29(_obf1929 $ ".Scheme.btnClose");
    _obf2185 = _obf29(_obf1929 $ ".Buffs.btnBack");
    _obf2186 = _obf29(_obf1929 $ ".Preset.btnPresetClose");
    _obf2187 = _obf29(_obf1929 $ ".Preset.btnBuffMe");
    _obf2188 = _obf29(_obf1929 $ ".Preset.btnRefresh");
    _obf2190 = _obf29(_obf1929 $ ".Preset.presetConfirm.btnConfirm");
    _obf2191 = _obf29(_obf1929 $ ".Preset.presetConfirm.btnCancel");
    _obf2189 = _obf29(_obf1929 $ ".Scheme.btnDispelBuffs");
    _obf2192 = _obf29(_obf1929 $ ".Scheme.btnQuestion");
    _obf2193 = _obf29(_obf1929 $ ".Scheme.btnAutoBuff");
    _obf2194 = _obf29(_obf1929 $ ".Scheme.btnNoblesse");
    _obf2195 = _obf29(_obf1929 $ ".Scheme.btnHeal");
    _obf2196 = _obf29(_obf1929 $ ".Scheme.btnChange");

    btnPresetHit = _obf29(_obf1929 $ ".Preset.btnPresetHit");

    _obf2203 = _obf616(_obf1929 $ ".Preset.StatusIcon");
    _obf2204 = _obf616(_obf1929 $ ".Preset.DebuffIcon");

    for(_obf5804 = 0; _obf5804 < 24; _obf5804++)
    {
        _obf2180[_obf5804] = _obf29(
            _obf1929 $ ".Buffs.Buff" $ string(_obf5804)
        );
    }

    for(_obf5804 = 0; _obf5804 < 6; _obf5804++)
    {
        _obf2181[_obf5804] = _obf29(
            _obf1929 $ ".Scheme.DefaultScheme" $ string(_obf5804)
        );

        _obf2182[_obf5804] = _obf29(
            _obf1929 $ ".Scheme.UserScheme" $ string(_obf5804)
        );

        _obf2182[_obf5804].SetTooltipCustomType(
            _obf23("Lista " $ string(_obf5804 + 1))
        );
    }

    _obf2192.SetTooltipCustomType(
        _obf169(
            "Ajuda",
            "Esquerda: categorias. Direita: presets 1-6. Topo: Noblesse, Heal e Auto. Seta azul salva o preset; silhueta aplica."
        )
    );

    _obf2184.SetTooltipCustomType(_obf23("Fechar"));

    _obf2188.SetTooltipCustomType(
        _obf169(
            "Atualizar preset",
            "Salva seus buffs atuais neste preset."
        )
    );

    _obf2187.SetTooltipCustomType(
        _obf169(
            "Aplicar preset",
            "Usa os buffs salvos neste preset."
        )
    );

    _obf2193.SetTooltipCustomType(
        _obf169(
            "Auto Buff",
            "Aplica o pacote automatico de buffs."
        )
    );

    _obf2194.SetTooltipCustomType(_obf23("Noblesse"));
    _obf2195.SetTooltipCustomType(_obf23("Heal"));

    _obf2183.HideWindow();
    _obf2486.SetAlpha(0);
    AtualizarTooltipsBuffWnd();
    return;
}

function OnShow()
{
    // Bloqueia aberturas locais sem autorizacao.
    if (!bVipBuffOpenPermit)
    {
        _obf2486.SetAlpha(0);
        _obf2486.HideWindow();

        RequestBypassToServer("BuffWnd");
        return;
    }

    bVipBuffOpenPermit = False;

    bPet = false;
    _obf576();

    _obf2184 = _obf29(
        _obf1929$".Scheme.btnClose"
    );

    _obf2192 = _obf29(
        _obf1929$".Scheme.btnQuestion"
    );

    _obf577();

    HideWindow(_obf1929$".TitleInterface");

    _obf2486.SetAlpha(255, 0.5);

    _obf2184.ShowWindow();
    _obf2184.EnableWindow();

    _obf2184.SetTooltipCustomType(
        _obf23("Fechar")
    );

    _obf2192.ShowWindow();
    _obf2192.EnableWindow();

    _obf2192.SetTooltipCustomType(
        _obf169(
            "Ajuda",
            "Esquerda: categorias. Direita: presets 1-6. Topo: Noblesse, Heal e Auto. Seta azul salva o preset; silhueta aplica."
        )
    );

    AtualizarTooltipsBuffWnd();

    if (IsShowWindow("TeleportWnd"))
        HideWindow("TeleportWnd");
}

function HandleHide()
{
    _obf245();
    return;
}

function _obf245()
{
    _obf161("Hide");
    _obf2486.KillTimer(98700);

    if(_obf2178.IsShowWindow())
    {
        _obf2178.HideWindow();
    }

    if(_obf2179.IsShowWindow())
    {
        _obf2179.HideWindow();
    }

    if(_obf2183.IsShowWindow())
    {
        _obf2183.HideWindow();
    }

    _obf2486.HideWindow();
    return;
}

function OnClickButton(string strID)
{
    local int i, dot;
    local array<UIEventManager.SkillInfo> skills;

    dot = InStr(strID, ".");

    while(dot >= 0)
    {
        strID = Mid(strID, dot + 1);
        dot = InStr(strID, ".");
    }

    switch(Caps(strID))
    {
        case "BTNCLOSE":
            _obf245();
            return;

        case "BTNQUESTION":
            AddSystemMessage(
                "Buff: categorias a esquerda, presets a direita. Seta salva; silhueta aplica.",
                _obf33(176, 155, 96, 255)
            );
            return;

        case "BTNAUTOBUFF":
            _obf161("Automatic", true);
            return;

        case "BTNNOBLESSE":
            _obf161("GetBuff=1323,1", true);
            return;

        case "BTNHEAL":
            _obf161("GetBuff=Heal", true);
            return;

        case "BTNDISPELBUFFS":
            _obf161("CancelAll", true);
            return;

        case "BTNCHANGE":
            _obf1285();
            return;

        case "BTNBACK":
            _obf576();
            return;

        case "BTNPRESETCLOSE":
            _obf2178.HideWindow();
            _obf2179.HideWindow();
            return;

        case "BTNADDPRESET":
            _obf161(
                "CreatePreset=" $ string(_obf2205),
                true
            );
            return;

        case "BTNBUFFME":
            _obf161(
                "UsePreset=" $ string(_obf2205),
                true
            );
            return;

        case "BTNREFRESH":
        case "BTNCONFIRM":
            _obf2179.HideWindow();

            _obf161(
                "RefreshPreset=" $ string(_obf2205),
                true
            );
            return;

        case "BTNCANCEL":
            _obf2179.HideWindow();
            return;

        case "BTNPRESETHIT":
            return;
    }

    for(i = 0; i < 24; i++)
    {
        if(Caps(strID) == ("BUFF" $ string(i)))
        {
            skills = _obf389(_obf2206);

            if(i < skills.Length)
            {
                if(skills[i].SkillID > 0)
                {
                    _obf161(
                        "GetBuff="
                        $ string(skills[i].SkillID)
                        $ ","
                        $ string(skills[i].SkillLevel),
                        true
                    );
                }
            }

            return;
        }
    }

    for(i = 0; i < 6; i++)
    {
        if(Caps(strID) == ("DEFAULTSCHEME" $ string(i)))
        {
            _obf2178.HideWindow();
            _obf2179.HideWindow();
            _obf2183.HideWindow();

            _obf2206 = i;

            _obf2176.ShowWindow();
            _obf2177.HideWindow();

            _obf1269(i);
            return;
        }

        if(Caps(strID) == ("USERSCHEME" $ string(i)))
        {
            _obf2205 = i;
            _obf161("GetPreset=" $ string(i));
            return;
        }
    }
}

function OnTimer(int _obf3340)
{
    switch(_obf3340)
    {
        case 98700:
            _obf2486.KillTimer(98700);
            _obf2486.HideWindow();
            _obf2178.HideWindow();
            _obf2183.HideWindow();
            _obf2179.HideWindow();
            _obf576();
            break;

        default:
            break;
    }

    return;
}

function Clear()
{
    _obf2486.HideWindow();
    _obf2178.HideWindow();
    _obf2183.HideWindow();
    _obf2179.HideWindow();

    _obf576();

    _obf2197.Length = 0;
    _obf2198.Length = 0;
    _obf2199.Length = 0;
    _obf2200.Length = 0;
    _obf2201.Length = 0;
    _obf2202.Length = 0;

    bPet = false;
    return;
}

function OnExitState(name _obf2211)
{
    Clear();
    return;
}

function OnEvent(int _obf5449, string _obf3273)
{
    local string AccessMessage;

    switch (_obf5449)
    {
        case 140:
            ParseString(
                _obf3273,
                "Msg",
                AccessMessage
            );

            if (
                AccessMessage ==
                "CustomEvent=BuffAccessV1|DENIED"
            )
            {
                bVipBuffOpenPermit = False;

                _obf2486.SetAlpha(0);
                _obf2486.HideWindow();
            }
            break;

        case 1900:
            _obf1018();
            break;

        case 99978:
            // Evento enviado pelo servidor apos validar o acesso.
            if (!_obf2486.IsShowWindow())
            {
                bVipBuffOpenPermit = True;
                _obf2486.ShowWindow();
            }
            break;

        case 99979:
            _obf1088(_obf3273);
            break;

        case 99980:
            _obf1271(_obf3273);
            break;

        case 99995:
            HandleHide();
            break;

        case 580:
            _obf174(_obf3273);
            break;
    }
}

function _obf174(string _obf3273)
{
    local int _obf5420;

    ParseInt(_obf3273, "Index", _obf5420);

    switch(_obf5420)
    {
        case 283:
        case 1721:
            _obf245();
            break;

        default:
            break;
    }

    return;
}

function _obf161(string _obf2213, optional bool _obf2214)
{
    local string command;

    command = "BuffEngine_" $ _obf2213;

    if(_obf2214 && bPet)
    {
        command = command $ "_isServitor";
    }

    RequestBypassToServer(command);
}

function _obf1285()
{
    bPet = !bPet;
    _obf577();
    return;
}

function _obf577()
{
    if(bPet)
    {
        _obf2196.SetTexture(
            "BuffsIcon.Icon.iconServitor",
            "BuffsIcon.Icon.iconServitor",
            "BuffsIcon.Icon.iconServitor"
        );

        _obf2196.SetTooltipCustomType(
            _obf169(
                "Alvo: Servitor/Pet",
                "Buffs vao para o pet. Clique para voltar ao player."
            )
        );
    }
    else
    {
        _obf2196.SetTexture(
            "BuffsIcon.Icon.iconPlayer",
            "BuffsIcon.Icon.iconPlayer",
            "BuffsIcon.Icon.iconPlayer"
        );

        _obf2196.SetTooltipCustomType(
            _obf169(
                "Alvo: Player",
                "Buffs vao para voce. Clique para buffar o pet."
            )
        );
    }

    return;
}

function _obf1273(int _obf2220)
{
    local UIEventManager.Rect _obf5338, _obf5333;

    _obf5338 = _obf28(
        _obf1929 $ ".Scheme.UserScheme" $ string(_obf2220)
    ).GetRect();

    _obf5333 = _obf2486.GetRect();

    if(!_obf2183.IsShowWindow())
    {
        _obf2183.ShowWindow();
    }

    _obf2183.SetAnchor(
        _obf1929,
        "TopLeft",
        "TopLeft",
        _obf5338.nX - _obf5333.nX + 70,
        _obf5338.nY - _obf5333.nY
    );

    return;
}

function _obf576()
{
    _obf2176.HideWindow();
    _obf2177.ShowWindow();
    return;
}

function _obf1271(string _obf3273)
{
    local int i, SkillID, SkillLevel, category;
    local UIEventManager.SkillInfo SkillInfo;

    if(!ParseInt(_obf3273, "cat", category))
    {
        return;
    }

    if(category < 0 || category > 5)
    {
        return;
    }

    _obf1090(category);

    for(i = 0; i < 24; i++)
    {
        SkillID = 0;
        SkillLevel = 0;

        if(ParseInt(_obf3273, "id_" $ string(i), SkillID))
        {
            if(ParseInt(
                _obf3273,
                "lvl_" $ string(i),
                SkillLevel))
            {
                if(GetSkillInfo(SkillID, SkillLevel, SkillInfo))
                {
                    _obf1160(SkillInfo, category);
                }
            }
        }
    }

    if(_obf2176.IsShowWindow())
    {
        if(_obf2206 == category)
        {
            _obf1269(category);
        }
    }
}

function _obf1269(int _obf2223)
{
    local int i;
    local array<UIEventManager.SkillInfo> skills;
    local string textureBase, skillName, texturePath;

    if (_obf2223 < 0 || _obf2223 > 5)
        return;

    if (_obf2176 == None)
        return;

    textureBase = "BuffsIcon.Icon.skill";
    skills = _obf389(_obf2223);

    // Primeiro prepara as texturas e a visibilidade.
    for (i = 0; i < 24; i++)
    {
        if (_obf2180[i] != None)
        {
            _obf2180[i].HideWindow();

            if (i < skills.Length)
            {
                if (skills[i].SkillID > 0)
                {
                    skillName = _obf1171(skills[i].SkillID);
                    texturePath = textureBase$skillName;

                    _obf2180[i].SetTexture(
                        texturePath,
                        texturePath$"_down",
                        texturePath$"_over"
                    );

                    _obf2180[i].ShowWindow();
                }
            }
        }
    }

    // Posiciona os icones.
    _obf1033(skills);

    // Aplica por ultimo o mesmo tooltip da pagina principal.
    for (i = 0; i < skills.Length && i < 24; i++)
    {
        if (_obf2180[i] != None)
        {
            if (skills[i].SkillID > 0)
            {
                _obf2180[i].SetTooltipCustomType(
                    _obf1022(skills[i])
                );
            }
        }
    }
}

function string _obf1171(int SkillID)
{
    local string SkillName;

    SkillName = string(SkillID);

    switch(Len(SkillName))
    {
        case 1:
            return "000" $ SkillName;

        case 2:
            return "00" $ SkillName;

        case 3:
            return "0" $ SkillName;

        case 4:
            return SkillName;

        default:
            return SkillName;
            break;
    }
}

function _obf1160(
    UIEventManager.SkillInfo SkillInfo,
    int _obf2223)
{
    switch(_obf2223)
    {
        case 0:
            _obf2197[_obf2197.Length] = SkillInfo;
            break;

        case 1:
            _obf2198[_obf2198.Length] = SkillInfo;
            break;

        case 2:
            _obf2199[_obf2199.Length] = SkillInfo;
            break;

        case 3:
            _obf2200[_obf2200.Length] = SkillInfo;
            break;

        case 4:
            _obf2201[_obf2201.Length] = SkillInfo;
            break;

        case 5:
            _obf2202[_obf2202.Length] = SkillInfo;
            break;

        default:
            break;
    }

    return;
}

function array<UIEventManager.SkillInfo> _obf389(int _obf2223)
{
    switch(_obf2223)
    {
        case 0:
            return _obf2197;

        case 1:
            return _obf2198;

        case 2:
            return _obf2199;

        case 3:
            return _obf2200;

        case 4:
            return _obf2201;

        case 5:
            return _obf2202;

        default:
            break;
    }
}

function _obf1090(int _obf2223)
{
    switch(_obf2223)
    {
        case 0:
            _obf2197.Length = 0;
            break;

        case 1:
            _obf2198.Length = 0;
            break;

        case 2:
            _obf2199.Length = 0;
            break;

        case 3:
            _obf2200.Length = 0;
            break;

        case 4:
            _obf2201.Length = 0;
            break;

        case 5:
            _obf2202.Length = 0;
            break;

        default:
            break;
    }

    return;
}

function _obf1088(string _obf3273)
{
    local UIEventManager.StatusIconInfo _obf5458;
    local string _obf2232;
    local int _obf5804, SkillID, SkillLevel, _obf2233;
    local int _obf2234, UserClass, _obf2220, _obf2235;
    local int _obf2236, buffCount;

    ParseInt(_obf3273, "newPreset", _obf2235);

    if(_obf2235 == 1)
    {
        ParseInt(_obf3273, "presetID", _obf2236);

        if(_obf2236 < 0 || _obf2236 > 5)
        {
            return;
        }

        _obf2205 = _obf2236;
        _obf1273(_obf2236);

        if(_obf2178.IsShowWindow())
        {
            _obf2178.HideWindow();
        }

        return;
    }

    _obf2203.Clear();
    _obf2204.Clear();

    if(_obf2183.IsShowWindow())
    {
        _obf2183.HideWindow();
    }

    if(!_obf2178.IsShowWindow())
    {
        _obf2178.ShowWindow();
    }

    _obf2178.EnableWindow();
    _obf2178.SetFocus();

    if(_obf2179.IsShowWindow())
    {
        _obf2179.HideWindow();
    }

    ParseString(_obf3273, "PresetName", _obf2232);
    ParseInt(_obf3273, "UserClass", UserClass);
    ParseInt(_obf3273, "presetID", _obf2220);

    if(_obf2220 < 0 || _obf2220 > 5)
    {
        return;
    }

    _obf2205 = _obf2220;
    _obf2233 = 0;

    _obf2203.InsertRow(_obf2233);
    _obf2204.InsertRow(_obf2233);

    for(_obf5804 = 0; _obf5804 < 40; _obf5804++)
    {
        if(!ParseInt(
            _obf3273,
            "id_" $ string(_obf5804),
            SkillID))
        {
            SkillID = -1;
        }

        ParseInt(
            _obf3273,
            "lvl_" $ string(_obf5804),
            SkillLevel
        );

        if(_obf1048(SkillID, SkillLevel, _obf5458))
        {
            buffCount++;

            if(!_obf1075(_obf5458.ClassID))
            {
                if(_obf2234 == 12 || _obf2234 == 24)
                {
                    _obf2233++;
                    _obf2203.InsertRow(_obf2233);
                    _obf2234 = 0;
                }

                _obf2203.AddCol(_obf2233, _obf5458);
                _obf2234++;

                goto J0x268;
            }

            _obf2204.AddCol(0, _obf5458);
        }

        J0x268:
    }

    _obf58(_obf1929 $ ".Preset.pName").SetText(
        _obf2232
    );

    _obf58(_obf1929 $ ".Preset.pUserClass").SetText(
        GetClassType(UserClass)
        $ " (" $ string(buffCount) $ "/40)"
    );

    _obf46(_obf1929 $ ".Preset.texIcon").SetTexture(
        GetClassIconName(UserClass) $ "_big"
    );

    _obf2178.SetAnchor(
        _obf1929,
        "TopLeft",
        "TopLeft",
        _obf1063(),
        _obf1056(_obf2220)
    );

    _obf2178.EnableWindow();
    _obf2178.SetFocus();
    return;
}

function bool _obf1075(int SkillID)
{
    switch(SkillID)
    {
        case 4551:
        case 4552:
        case 4553:
        case 4554:
            return true;

        default:
            return false;
            break;
    }
}

function int _obf1063()
{
    return 652;
}

function int _obf1056(int _obf2242)
{
    switch(_obf2242)
    {
        case 0:
            return 119;

        case 1:
            return 158;

        case 2:
            return 200;

        case 3:
            return 243;

        case 4:
            return 287;

        case 5:
            return 332;

        default:
            return 119;
            break;
    }
}

function bool _obf1048(
    int SkillID,
    int SkillLevel,
    out UIEventManager.StatusIconInfo _obf5458)
{
    local UIEventManager.SkillInfo SkillInfo;

    if(GetSkillInfo(SkillID, SkillLevel, SkillInfo))
    {
        _obf5458.Name = SkillInfo.SkillName;
        _obf5458.IconName = SkillInfo.TexName;
        _obf5458.Size = 16;
        _obf5458.Description = SkillInfo.SkillDesc;
        _obf5458.BackTex = "L2UI.EtcWndBack.AbnormalBack";
        _obf5458.RemainTime = -1;
        _obf5458.ClassID = SkillID;
        _obf5458.Level = SkillLevel;
        _obf5458.bShow = true;
        _obf5458.bShortItem = false;
        _obf5458.bEtcItem = true;

        return true;
    }

    return false;
}

function _obf1033(array<UIEventManager.SkillInfo> _obf2225)
{
    local int i, anchorX, anchorY;
    local bool oddCount;

    oddCount = bool(float(_obf2225.Length) % float(2));

    for(i = 0; i < _obf2225.Length && i < 24; i++)
    {
        if(_obf2180[i] != None)
        {
            anchorX = _obf1031(oddCount, i);
            anchorY = _obf1030(oddCount, i);

            _obf2180[i].SetAnchor(
                _obf1929 $ ".Buffs",
                "TopLeft",
                "TopLeft",
                anchorX,
                anchorY
            );
        }
    }
}

function int _obf1031(bool _obf2246, int _obf2247)
{
    if(_obf2246)
    {
        return _obf2207[_obf2247];
    }
    else
    {
        return _obf2207[_obf2247 + 24];
    }
}

function int _obf1030(bool _obf2246, int _obf2247)
{
    if(_obf2246)
    {
        return _obf2208[_obf2247];
    }
    else
    {
        return _obf2208[_obf2247 + 24];
    }
}

function _obf1027()
{
    _obf2207.Length = 0;
    _obf2208.Length = 0;

    _obf45(308, 24);
    _obf45(263, 27);
    _obf45(352, 27);
    _obf45(220, 38);
    _obf45(395, 38);
    _obf45(179, 54);
    _obf45(437, 54);
    _obf45(141, 78);
    _obf45(474, 78);
    _obf45(107, 107);
    _obf45(509, 107);
    _obf45(79, 141);
    _obf45(538, 141);
    _obf45(55, 179);
    _obf45(561, 179);
    _obf45(38, 220);
    _obf45(578, 220);
    _obf45(27, 264);
    _obf45(588, 264);
    _obf45(25, 309);
    _obf45(592, 309);
    _obf45(28, 353);
    _obf45(588, 353);
    _obf45(38, 397);

    _obf45(286, 24);
    _obf45(330, 24);
    _obf45(241, 31);
    _obf45(374, 31);
    _obf45(198, 45);
    _obf45(416, 45);
    _obf45(159, 66);
    _obf45(456, 66);
    _obf45(123, 92);
    _obf45(492, 92);
    _obf45(92, 123);
    _obf45(523, 123);
    _obf45(66, 159);
    _obf45(550, 159);
    _obf45(46, 198);
    _obf45(570, 198);
    _obf45(31, 241);
    _obf45(584, 241);
    _obf45(25, 285);
    _obf45(590, 285);
    _obf45(25, 331);
    _obf45(591, 331);
    _obf45(32, 374);
    _obf45(584, 374);

    return;
}

function _obf45(int X, int Y)
{
    local int _obf5420;

    _obf5420 = _obf2207.Length;

    _obf2207.Length = _obf5420 + 1;
    _obf2208.Length = _obf5420 + 1;

    _obf2207[_obf5420] = X;
    _obf2208[_obf5420] = Y;

    return;
}

function WindowHandle _obf28(string Path)
{
    return GetHandle(Path);
}

function ButtonHandle _obf29(string Path)
{
    return ButtonHandle(GetHandle(Path));
}

function TextureHandle _obf46(string Path)
{
    return TextureHandle(GetHandle(Path));
}

function TextBoxHandle _obf58(string Path)
{
    return TextBoxHandle(GetHandle(Path));
}

function StatusIconHandle _obf616(string Path)
{
    return StatusIconHandle(GetHandle(Path));
}

function L2Util _obf22()
{
    return L2Util(GetScript("L2Util"));
}

function Color _obf33(int R, int G, int B, int A)
{
    local Color C;

    C.R = byte(R);
    C.G = byte(G);
    C.B = byte(B);
    C.A = byte(A);

    return C;
}

function string _obf89(string Text, int MaxWidth)
{
    local string Out, Word, Line;
    local int i, Sp;

    if(InStr(Text, "\\n") > -1)
    {
        return Text;
    }

    Out = "";
    Line = "";
    i = 0;

    J0xWrap:

    if(i < Len(Text))
    {
        Sp = InStr(Mid(Text, i), " ");

        if(Sp == -1)
        {
            Word = Mid(Text, i);
            i = Len(Text);
        }
        else
        {
            Word = Left(Mid(Text, i), Sp);
            i = i + Sp + 1;
        }

        if((Len(Line) + Len(Word)) > (MaxWidth / 6))
        {
            if(Out == "")
            {
                Out = Line;
            }
            else
            {
                Out = Out $ "\\n" $ Line;
            }

            Line = Word $ " ";
        }
        else
        {
            Line = Line $ Word $ " ";
        }

        goto J0xWrap;
    }

    if(Line != "")
    {
        if(Out == "")
        {
            Out = Line;
        }
        else
        {
            Out = Out $ "\\n" $ Line;
        }
    }

    return Out;
}

function UIEventManager.CustomTooltip _obf23(string Text)
{
    local UIEventManager.CustomTooltip ToolTip;
    local UIEventManager.DrawItemInfo Info;

    ToolTip.MinimumWidth = 40;
    ToolTip.DrawList.Length = 1;

    Info.eType = DIT_TEXT;
    Info.nOffSetX = 2;
    Info.nOffSetY = 0;
    Info.t_bDrawOneLine = true;
    Info.t_color = _obf33(255, 220, 150, 255);
    Info.t_strText = Text;

    ToolTip.DrawList[0] = Info;

    return ToolTip;
}

function UIEventManager.CustomTooltip _obf169(
    string _obf5356,
    optional string _obf5458)
{
    local int _obf5804;
    local UIEventManager.CustomTooltip ToolTip;

    ToolTip.MinimumWidth = 240;
    _obf5804 = 0;

    if(_obf5458 != "")
    {
        ToolTip.DrawList.Length = 2;
    }
    else
    {
        ToolTip.DrawList.Length = 1;
    }

    ToolTip.DrawList[_obf5804].eType = DIT_TEXT;
    ToolTip.DrawList[_obf5804].nOffSetX = 2;
    ToolTip.DrawList[_obf5804].nOffSetY = 0;
    ToolTip.DrawList[_obf5804].t_bDrawOneLine = true;

    ToolTip.DrawList[_obf5804].t_color =
        _obf33(255, 220, 150, 255);

    ToolTip.DrawList[_obf5804].t_strText = _obf5356;

    if(_obf5458 != "")
    {
        _obf5804++;

        ToolTip.DrawList[_obf5804].eType = DIT_TEXT;
        ToolTip.DrawList[_obf5804].nOffSetX = 2;
        ToolTip.DrawList[_obf5804].nOffSetY = 3;
        ToolTip.DrawList[_obf5804].bLineBreak = true;
        ToolTip.DrawList[_obf5804].t_bDrawOneLine = false;

        ToolTip.DrawList[_obf5804].t_color =
            _obf33(176, 155, 121, 255);

        ToolTip.DrawList[_obf5804].t_strText =
            _obf89(_obf5458, 230);
    }

    return ToolTip;
}

function UIEventManager.CustomTooltip _obf1022(
    UIEventManager.SkillInfo SkillData
)
{
    local UIEventManager.SkillInfo UpdatedInfo;
    local string BuffName;

    BuffName = SkillData.SkillName;

    if (GetSkillInfo(
        SkillData.SkillID,
        SkillData.SkillLevel,
        UpdatedInfo
    ))
    {
        if (UpdatedInfo.SkillName != "")
            BuffName = UpdatedInfo.SkillName;
    }

    if (BuffName == "")
        BuffName = "Buff #"$string(SkillData.SkillID);

    return _obf23(BuffName);
}

function _obf1018()
{
    local int _obf5804;

    for(_obf5804 = 0; _obf5804 < 6; _obf5804++)
    {
        _obf2182[_obf5804].SetTooltipCustomType(
            _obf23("Preset " $ string(_obf5804 + 1))
        );
    }

    _obf2192.SetTooltipCustomType(
        _obf169(
            "Ajuda",
            "Esquerda: categorias. Direita: presets 1-6. Topo: Noblesse, Heal e Auto. Seta azul salva o preset; silhueta aplica."
        )
    );

    _obf2184.SetTooltipCustomType(_obf23("Fechar"));

    _obf2188.SetTooltipCustomType(
        _obf169(
            "Atualizar preset",
            "Salva seus buffs atuais neste preset."
        )
    );

    _obf2187.SetTooltipCustomType(
        _obf169(
            "Aplicar preset",
            "Usa os buffs salvos neste preset."
        )
    );

    _obf2193.SetTooltipCustomType(
        _obf169(
            "Auto Buff",
            "Aplica o pacote automatico de buffs."
        )
    );

    _obf577();
    AtualizarTooltipsBuffWnd();

    return;
}

function AtualizarTooltipsBuffWnd()
{
    local int i;
    local string categoryName;

    for(i = 0; i < 6; i++)
    {
        switch(i)
        {
            case 0:
                categoryName = "Prophet";
                break;

            case 1:
                categoryName = "Songs";
                break;

            case 2:
                categoryName = "Dances";
                break;

            case 3:
                categoryName = "Special";
                break;

            case 4:
                categoryName = "Protection";
                break;

            case 5:
                categoryName = "Chant / Pa'agrio";
                break;
        }

        _obf2181[i].SetTooltipCustomType(
            _obf23(categoryName)
        );

        _obf2182[i].SetTooltipCustomType(
            _obf23("Lista " $ string(i + 1))
        );
    }

    _obf2189.SetTooltipCustomType(
        _obf169(
            "Remover efeitos",
            "Remove todos os efeitos do alvo selecionado."
        )
    );

    _obf2185.SetTooltipCustomType(
        _obf23("Voltar para as categorias")
    );

    _obf2183.SetTooltipCustomType(
        _obf169(
            "Criar lista",
            "Salva os buffs atuais do alvo nesta lista."
        )
    );

    _obf2186.SetTooltipCustomType(
        _obf23("Fechar lista")
    );

    _obf2190.SetTooltipCustomType(
        _obf23("Confirmar atualizacao")
    );

    _obf2191.SetTooltipCustomType(
        _obf23("Cancelar")
    );
}

