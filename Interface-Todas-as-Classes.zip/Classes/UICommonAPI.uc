//================================================================================
// UICommonAPI.
//================================================================================

class UICommonAPI extends UIScript;

struct ChatItemProperty
{
    var int Kind;
    var string Text1;
    var string Text2;
    var string Text3;
    var string Text4;
};

var int Time;
var CustomTooltip MINFO;
var bool SuperRaceShop;
var array<int> NewItemObjectIDs;



enum DialogDefaultAction {
  EDefaultNone,
  EDefaultOK,
  EDefaultCancel
};

enum EDialogType {
  DIALOG_OKCancel,
  DIALOG_OK,
  DIALOG_OKCancelInput,
  DIALOG_OKInput,
  DIALOG_Warning,
  DIALOG_Notice,
  DIALOG_NumberPad,
  DIALOG_Progress
};



enum HeaderPosition
{
    Header_Head,
    Header_MidBody,
    Header_LowBody
};

struct PlayerStatusInfo
{
    var int CreatureID;
    var int CurHP;
    var int MaxHP;
    var int CurMP;
    var int MaxMP;
    var int Team;
};

struct infoautobuff
{
    var int Id;
    var string Name;
    var bool answermatha;
    var int quequierestuax2;
};



const EV_ExecOnScreenEffect= 3010;
const EV_ShowOnScreenEffect= 3000;
const EV_ShowOnScreenEvent= 2990;
const EV_ShowMagicSkillUse= 2980;
const EV_Support= 2970;
const EV_TargetHold= 2961;
const EV_TargetShotdown= 2960;
const EV_OpenDialogQuit= 2940;
const EV_OpenDialogRestart= 2930;


function bool xxIsValidItemID(ItemInfo Id)
{
    // End:0x24
    if((Id.ClassID < 1) && Id.ServerID < 1)
    {
        return false;
    }
    return true;

}

function xxheaderhp(
    out float zzfloat,
    out float zzfloatador)
{
    local Vector CameraLocation;
    local Rotator CameraRotation;
    local Vector CameraForward;
    local Vector CameraRight;
    local Vector CameraUp;

    local Actor PlayerActor;
    local Pawn TargetPawn;
    local LineagePlayerController Controller;
    local UserInfo TargetInfo;

    local Vector HeadLocation;
    local Matrix ProjectionMatrix;
    local Matrix ViewMatrix;
    local Matrix CombinedMatrix;
    local Plane HeadPlane;
    local Plane ProjectedPoint;

    local int ScreenWidth;
    local int ScreenHeight;

    local float Width;
    local float Height;
    local float Aspect;
    local float Calibration;
    local float PercentX;
    local float PercentY;
    local float ScreenX;
    local float ScreenY;
    local float HeadOffset;

    local bool bFound;

    // Mantem a barra fora da tela se nao encontrar o alvo.
    zzfloat = -10000.0;
    zzfloatador = -10000.0;

    if (!GetTargetInfo(TargetInfo))
    {
        return;
    }

    if (!GetPlayerActor(PlayerActor))
    {
        return;
    }

    if (!GetPlayerController(Controller))
    {
        return;
    }

    GetCurrentResolution(ScreenWidth, ScreenHeight);

    if (ScreenWidth <= 0 || ScreenHeight <= 0)
    {
        return;
    }

    foreach PlayerActor.CollidingActors(
        class'Engine.Pawn',
        TargetPawn,
        50.0,
        TargetInfo.Loc)
    {
        if (TargetPawn.CreatureID != TargetInfo.nID)
        {
            continue;
        }

        if (TargetPawn.bRide)
        {
            continue;
        }

        HeadLocation = TargetPawn.Location;
        HeadOffset = 0.0;

        if (TargetPawn.RidePawn != None)
        {
            HeadOffset = 6.0;
        }

        // NPC nao atacavel pode informar HP zero sem estar morto.
        if (TargetInfo.nCurHP > 0
            || !TargetInfo.bCanBeAttacked)
        {
            HeadLocation.Z =
                HeadLocation.Z
                + TargetPawn.CollisionHeight
                + TargetPawn.NameOffset
                + HeadOffset;
        }
        else
        {
            HeadLocation.Z =
                HeadLocation.Z
                + TargetPawn.DeadNameOffset
                + HeadOffset;
        }

        bFound = true;
        break;
    }

    if (!bFound)
    {
        return;
    }

    Controller.PlayerCalcView(
        PlayerActor,
        CameraLocation,
        CameraRotation
    );

    GetAxes(
        CameraRotation,
        CameraForward,
        CameraRight,
        CameraUp
    );

    if (((HeadLocation - CameraLocation)
        Dot CameraForward) <= 0.0)
    {
        return;
    }

    Width = float(ScreenWidth);
    Height = float(ScreenHeight);
    Aspect = Width / Height;

    // Mantem a projecao utilizada pela interface atual.
    ProjectionMatrix = xxfaaxa(
        50.0,
        0.1,
        1000.0,
        Aspect
    );

    ViewMatrix = xxbgdfaa(
        CameraLocation,
        CameraForward,
        CameraRight,
        CameraUp
    );

    CombinedMatrix = xxeraaxac(
        ProjectionMatrix,
        ViewMatrix
    );

    HeadPlane = xxplanekaa(
        HeadLocation.X,
        HeadLocation.Y,
        HeadLocation.Z,
        1.0
    );

    ProjectedPoint = xxmujjkkasd(
        CombinedMatrix,
        HeadPlane
    );

    if (ProjectedPoint.W == 0.0)
    {
        return;
    }

    ProjectedPoint.X =
        ProjectedPoint.X / (ProjectedPoint.W / 1000.0);

    ProjectedPoint.Y =
        ProjectedPoint.Y / (ProjectedPoint.W / 1000.0);

    Calibration = (0.5729 * Aspect) / 1000.0;

    PercentX =
        (
            (
                ProjectedPoint.X * 0.5 * Width
                + Width / Calibration
            )
            / ((Width / Calibration) * 2.0)
        ) * 100.0;

    PercentY =
        (
            (
                ProjectedPoint.Y * 0.5 * Height
                + Height / Calibration
            )
            / ((Height / Calibration) * 2.0)
        ) * 100.0;

    ScreenX = ((100.0 - PercentX) * Width) / 100.0;
    ScreenY = (PercentY * Height) / 100.0;

    if (ScreenX < -100.0 || ScreenX > Width + 100.0
        || ScreenY < -100.0 || ScreenY > Height + 100.0)
    {
        return;
    }

    zzfloat = ScreenX;

    // Espacamento abaixo da referencia do nome, em pixels.
    zzfloatador = ScreenY + 3.0;
}

function Matrix xxbgdfaa(Vector zzvecgasdar, Vector zzweweaxa, Vector zzerahgfhfasa, Vector zzhtysdada)
{
    local Matrix zzhtyara;

    zzhtyara.XPlane = xxplanekaa(zzerahgfhfasa.X, zzhtysdada.X, -zzweweaxa.X, 0.0000000);
    zzhtyara.YPlane = xxplanekaa(zzerahgfhfasa.Y, zzhtysdada.Y, -zzweweaxa.Y, 0.0000000);
    zzhtyara.ZPlane = xxplanekaa(zzerahgfhfasa.Z, zzhtysdada.Z, -zzweweaxa.Z, 0.0000000);
    zzhtyara.WPlane = xxplanekaa(-1.0000000 * (zzerahgfhfasa Dot zzvecgasdar), -1.0000000 * (zzhtysdada Dot zzvecgasdar), zzweweaxa Dot zzvecgasdar, 1.0000000);
    return zzhtyara;

}

function xxheaderhpplayer(out float zzfloat, out float zzfloatador)
{
    local Vector zzvectoriador;
    local Rotator zzvectraa;
    local Vector zzvesada, zzvectoraa, zzvytaax;
    local float zzweawe, zzwerqeaa;
    local int zzweqeqq, zzbfgfdd;
    local float zzdweaaw, zzdasweaa, zzweasda, zzweqeqax;
    local Matrix zzmatraa, zzdweaas, zzmerasa;
    local Plane zzplkjfaa, zzweaewaxcvb;
    local UserInfo zzuserinfkaa;
    local Actor Actor;
    local Pawn zzPawnJugador;
    local LineagePlayerController zzcontri;
    local Vector zzbnbfghf;
    local float zzwtaaxa, zzbbfghaa, zzbgfasaxxa, zzbfghfgaw, zzbffjyuf, zznbgfhaa;

    // Validaciones iniciales
    if ( !GetTargetInfo(zzuserinfkaa)  || !GetPlayerActor(Actor) || !GetPlayerController(zzcontri)) {
        return;
    }

    // Configuración de constantes
    zzPawnJugador = Pawn(Actor);  // Aquí asignas el Pawn del jugador

    zzcontri.PlayerCalcView(Actor, zzvectoriador, zzvectraa);
    GetCurrentResolution(zzweqeqq, zzbfgfdd);
    zzweawe = float(zzweqeqq);
    zzwerqeaa = float(zzbfgfdd);
    GetAxes(zzvectraa, zzvesada, zzvectoraa, zzvytaax);

    zzdweaaw = 50.0;
    zzdasweaa = 0.1;
    zzweasda = 1000.0;
    zznbgfhaa = 1000.0;
    zzweqeqax = zzweawe / zzwerqeaa;
    zzmatraa = xxfaaxa(zzdweaaw, zzdasweaa, zzweasda, zzweqeqax);

    zzdweaas = xxbgdfaa(zzvectoriador, zzvesada, zzvectoraa, zzvytaax);
    zzmerasa = xxeraaxac(zzmatraa, zzdweaas);

    // Buscar Pawn correspondiente (Objetivo)
    foreach Actor.CollidingActors(Class'Engine.Pawn', zzPawnJugador, 2000.0, GetPlayerPosition()) {
        // Aquí usas zzPawnObjetivo como el Pawn del objetivo

        if (zzuserinfkaa.nID == zzPawnJugador.CreatureID) {
            if (zzPawnJugador.bRide || (zzuserinfkaa.bNpc && !zzuserinfkaa.bCanBeAttacked) || zzuserinfkaa.nMaxHP <= 0) {
                continue;
            }

            zzbnbfghf = zzPawnJugador.Location;
            zzPawnJugador.NameOffset = 15.0;

            if (zzuserinfkaa.nCurHP > 0) {
                zzbnbfghf.Z = (zzbnbfghf.Z + zzPawnJugador.CollisionHeight) + zzPawnJugador.NameOffset;
            } else {
                zzbnbfghf.Z = zzbnbfghf.Z + zzPawnJugador.CollisionHeight + zzPawnJugador.NameOffset;
            }

            break;
        }
    }

    // Proyección de coordenadas
    zzplkjfaa = xxplanekaa(zzbnbfghf.X, zzbnbfghf.Y, zzbnbfghf.Z, 1.0);
    zzweaewaxcvb = xxmujjkkasd(zzmerasa, zzplkjfaa);

    zzweaewaxcvb.X = zzweaewaxcvb.X / (zzweaewaxcvb.W / zznbgfhaa);
    zzweaewaxcvb.Y = zzweaewaxcvb.Y / (zzweaewaxcvb.W / zznbgfhaa);
    zzweaewaxcvb.Z = zzweaewaxcvb.Z / (zzweaewaxcvb.W / zznbgfhaa);

    zzbffjyuf = (0.5729 * zzweqeqax) / zznbgfhaa;
    zzbgfasaxxa = ((((zzweaewaxcvb.X * 0.5) * zzweawe) + (zzweawe / zzbffjyuf)) / ((zzweawe / zzbffjyuf) * 2.0)) * 100.0;
    zzbfghfgaw = ((((zzweaewaxcvb.Y * 0.5) * zzwerqeaa) + (zzwerqeaa / zzbffjyuf)) / ((zzwerqeaa / zzbffjyuf) * 2.0)) * 100.0;

    zzwtaaxa = ((100.0 - zzbgfasaxxa) * zzweawe) / 100.0;
    zzbbfghaa = (zzbfghfgaw * zzwerqeaa) / 100.0;

    // Validar si el objetivo está fuera de la pantalla
    if (((zzbnbfghf - zzvectoriador) Dot zzvesada) < 0) {
        zzfloat = -100.0;  // Ocultar barra
        zzfloatador = zzwerqeaa + 100.0;
    } else {
        zzfloat = zzwtaaxa;
        zzfloatador = zzbbfghaa;
    }

    return;
}

function xxheaderhpplayerByID(
    int CreatureID,
    out float zzfloat,
    out float zzfloatador,
    optional bool bAnchorPlayerBars)
{
    local Vector zzvectoriador;
    local Rotator zzvectraa;

    local Vector zzvesada;
    local Vector zzvectoraa;
    local Vector zzvytaax;

    local float zzweawe;
    local float zzwerqeaa;

    local int zzweqeqq;
    local int zzbfgfdd;

    local float zzdweaaw;
    local float zzdasweaa;
    local float zzweasda;
    local float zzweqeqax;

    local Matrix zzmatraa;
    local Matrix zzdweaas;
    local Matrix zzmerasa;

    local Plane zzplkjfaa;
    local Plane zzweaewaxcvb;

    local Actor Actor;
    local Pawn zzPawnJugador;
    local LineagePlayerController zzcontri;

    local Vector zzbnbfghf;

    local float zzwtaaxa;
    local float zzbbfghaa;
    local float zzbgfasaxxa;
    local float zzbfghfgaw;
    local float zzbffjyuf;
    local float zznbgfhaa;

    local bool bFound;

    bFound = false;

    if (!GetPlayerActor(Actor)
        || !GetPlayerController(zzcontri))
    {
        return;
    }

    zzPawnJugador = Pawn(Actor);

    zzcontri.PlayerCalcView(
        Actor,
        zzvectoriador,
        zzvectraa
    );

    GetCurrentResolution(zzweqeqq, zzbfgfdd);

    zzweawe = float(zzweqeqq);
    zzwerqeaa = float(zzbfgfdd);

    GetAxes(
        zzvectraa,
        zzvesada,
        zzvectoraa,
        zzvytaax
    );

    zzdweaaw = 50.0;
    zzdasweaa = 0.1;
    zzweasda = 1000.0;
    zznbgfhaa = 1000.0;

    zzweqeqax = zzweawe / zzwerqeaa;

    zzmatraa = xxfaaxa(
        zzdweaaw,
        zzdasweaa,
        zzweasda,
        zzweqeqax
    );

    zzdweaas = xxbgdfaa(
        zzvectoriador,
        zzvesada,
        zzvectoraa,
        zzvytaax
    );

    zzmerasa = xxeraaxac(
        zzmatraa,
        zzdweaas
    );

    foreach Actor.CollidingActors(
        Class'Engine.Pawn',
        zzPawnJugador,
        2000.0,
        GetPlayerPosition())
    {
        if (CreatureID == zzPawnJugador.CreatureID)
        {
            if (zzPawnJugador.bRide)
            {
                continue;
            }

            zzbnbfghf = zzPawnJugador.Location;

            if (bAnchorPlayerBars)
            {
                // Mantem a referencia original do nome.
                zzbnbfghf.Z =
                    zzbnbfghf.Z
                    + zzPawnJugador.CollisionHeight
                    + zzPawnJugador.NameOffset;
            }
            else
            {
                // Preserva a altura original do Skill Gauge.
                zzbnbfghf.Z =
                    zzbnbfghf.Z
                    + zzPawnJugador.CollisionHeight
                    + 15.0;
            }

            bFound = true;
            break;
        }
    }

    if (!bFound)
    {
        zzfloat = -100.0;
        zzfloatador = zzwerqeaa + 100.0;
        return;
    }

    zzplkjfaa = xxplanekaa(
        zzbnbfghf.X,
        zzbnbfghf.Y,
        zzbnbfghf.Z,
        1.0
    );

    zzweaewaxcvb = xxmujjkkasd(
        zzmerasa,
        zzplkjfaa
    );

    zzweaewaxcvb.X =
        zzweaewaxcvb.X
        / (zzweaewaxcvb.W / zznbgfhaa);

    zzweaewaxcvb.Y =
        zzweaewaxcvb.Y
        / (zzweaewaxcvb.W / zznbgfhaa);

    zzweaewaxcvb.Z =
        zzweaewaxcvb.Z
        / (zzweaewaxcvb.W / zznbgfhaa);

    zzbffjyuf =
        (0.5729 * zzweqeqax)
        / zznbgfhaa;

    zzbgfasaxxa =
        (
            (
                ((zzweaewaxcvb.X * 0.5) * zzweawe)
                + (zzweawe / zzbffjyuf)
            )
            / ((zzweawe / zzbffjyuf) * 2.0)
        ) * 100.0;

    zzbfghfgaw =
        (
            (
                ((zzweaewaxcvb.Y * 0.5) * zzwerqeaa)
                + (zzwerqeaa / zzbffjyuf)
            )
            / ((zzwerqeaa / zzbffjyuf) * 2.0)
        ) * 100.0;

    zzwtaaxa =
        ((100.0 - zzbgfasaxxa) * zzweawe)
        / 100.0;

    zzbbfghaa =
        (zzbfghfgaw * zzwerqeaa)
        / 100.0;

    if (((zzbnbfghf - zzvectoriador) Dot zzvesada) < 0)
    {
        zzfloat = -100.0;
        zzfloatador = zzwerqeaa + 100.0;
    }
    else
    {
        zzfloat = zzwtaaxa;

        if (bAnchorPlayerBars)
        {
            // Posicao original das barras quando esta a pe.
            zzfloatador = zzbbfghaa - 52.0;

            // Ajuste adicional somente quando montado.
            if (zzPawnJugador.RidePawn != None)
            {
                zzfloatador = zzfloatador - 32.0;
            }
        }
        else
        {
            // Preserva o posicionamento do Skill Gauge.
            zzfloatador = zzbbfghaa;
        }
    }
}
function Plane xxmujjkkasd(Matrix Matrix, Plane zzdwaa)
{
    local Plane zzdewqeaa;

    zzdewqeaa.X = (((Matrix.XPlane.X * zzdwaa.X) + (Matrix.YPlane.X * zzdwaa.Y)) + (Matrix.ZPlane.X * zzdwaa.Z)) + (Matrix.WPlane.X * zzdwaa.W);
    zzdewqeaa.Y = (((Matrix.XPlane.Y * zzdwaa.X) + (Matrix.YPlane.Y * zzdwaa.Y)) + (Matrix.ZPlane.Y * zzdwaa.Z)) + (Matrix.WPlane.Y * zzdwaa.W);
    zzdewqeaa.Z = (((Matrix.XPlane.Z * zzdwaa.X) + (Matrix.YPlane.Z * zzdwaa.Y)) + (Matrix.ZPlane.Z * zzdwaa.Z)) + (Matrix.WPlane.Z * zzdwaa.W);
    zzdewqeaa.W = (((Matrix.XPlane.W * zzdwaa.X) + (Matrix.YPlane.W * zzdwaa.Y)) + (Matrix.ZPlane.W * zzdwaa.Z)) + (Matrix.WPlane.W * zzdwaa.W);
    return zzdewqeaa;

}    
function Matrix xxeraaxac(Matrix A, Matrix B)
{
    local Matrix zzsdaweaa;

    zzsdaweaa.XPlane.X = (((A.XPlane.X * B.XPlane.X) + (A.YPlane.X * B.XPlane.Y)) + (A.ZPlane.X * B.XPlane.Z)) + (A.WPlane.X * B.XPlane.W);
    zzsdaweaa.XPlane.Y = (((A.XPlane.Y * B.XPlane.X) + (A.YPlane.Y * B.XPlane.Y)) + (A.ZPlane.Y * B.XPlane.Z)) + (A.WPlane.Y * B.XPlane.W);
    zzsdaweaa.XPlane.Z = (((A.XPlane.Z * B.XPlane.X) + (A.YPlane.Z * B.XPlane.Y)) + (A.ZPlane.Z * B.XPlane.Z)) + (A.WPlane.Z * B.XPlane.W);
    zzsdaweaa.XPlane.W = (((A.XPlane.W * B.XPlane.X) + (A.YPlane.W * B.XPlane.Y)) + (A.ZPlane.W * B.XPlane.Z)) + (A.WPlane.W * B.XPlane.W);
    zzsdaweaa.YPlane.X = (((A.XPlane.X * B.YPlane.X) + (A.YPlane.X * B.YPlane.Y)) + (A.ZPlane.X * B.YPlane.Z)) + (A.WPlane.X * B.YPlane.W);
    zzsdaweaa.YPlane.Y = (((A.XPlane.Y * B.YPlane.X) + (A.YPlane.Y * B.YPlane.Y)) + (A.ZPlane.Y * B.YPlane.Z)) + (A.WPlane.Y * B.YPlane.W);
    zzsdaweaa.YPlane.Z = (((A.XPlane.Z * B.YPlane.X) + (A.YPlane.Z * B.YPlane.Y)) + (A.ZPlane.Z * B.YPlane.Z)) + (A.WPlane.Z * B.YPlane.W);
    zzsdaweaa.YPlane.W = (((A.XPlane.W * B.YPlane.X) + (A.YPlane.W * B.YPlane.Y)) + (A.ZPlane.W * B.YPlane.Z)) + (A.WPlane.W * B.YPlane.W);
    zzsdaweaa.ZPlane.X = (((A.XPlane.X * B.ZPlane.X) + (A.YPlane.X * B.ZPlane.Y)) + (A.ZPlane.X * B.ZPlane.Z)) + (A.WPlane.X * B.ZPlane.W);
    zzsdaweaa.ZPlane.Y = (((A.XPlane.Y * B.ZPlane.X) + (A.YPlane.Y * B.ZPlane.Y)) + (A.ZPlane.Y * B.ZPlane.Z)) + (A.WPlane.Y * B.ZPlane.W);
    zzsdaweaa.ZPlane.Z = (((A.XPlane.Z * B.ZPlane.X) + (A.YPlane.Z * B.ZPlane.Y)) + (A.ZPlane.Z * B.ZPlane.Z)) + (A.WPlane.Z * B.ZPlane.W);
    zzsdaweaa.ZPlane.W = (((A.XPlane.W * B.ZPlane.X) + (A.YPlane.W * B.ZPlane.Y)) + (A.ZPlane.W * B.ZPlane.Z)) + (A.WPlane.W * B.ZPlane.W);
    zzsdaweaa.WPlane.X = (((A.XPlane.X * B.WPlane.X) + (A.YPlane.X * B.WPlane.Y)) + (A.ZPlane.X * B.WPlane.Z)) + (A.WPlane.X * B.WPlane.W);
    zzsdaweaa.WPlane.Y = (((A.XPlane.Y * B.WPlane.X) + (A.YPlane.Y * B.WPlane.Y)) + (A.ZPlane.Y * B.WPlane.Z)) + (A.WPlane.Y * B.WPlane.W);
    zzsdaweaa.WPlane.Z = (((A.XPlane.Z * B.WPlane.X) + (A.YPlane.Z * B.WPlane.Y)) + (A.ZPlane.Z * B.WPlane.Z)) + (A.WPlane.Z * B.WPlane.W);
    zzsdaweaa.WPlane.W = (((A.XPlane.W * B.WPlane.X) + (A.YPlane.W * B.WPlane.Y)) + (A.ZPlane.W * B.WPlane.Z)) + (A.WPlane.W * B.WPlane.W);
    return zzsdaweaa;
  
}

function Matrix xxfaaxa(float zzdweaaw, float zzfrraa, float zznbgytaa, float zzuiyraaa)
{
    local float zzuhjkmwaw, zzpoysaa, zztyeraxaa, zzrteranfga;
    local Matrix zzmatraa;

    zzuhjkmwaw = Tan(zzdweaaw / float(2)) * zzfrraa;
    zzpoysaa = -zzuhjkmwaw;
    zztyeraxaa = zzuhjkmwaw * zzuiyraaa;
    zzrteranfga = -zztyeraxaa;
    zzmatraa.XPlane = xxplanekaa((2.0000000 * zzfrraa) / (zztyeraxaa - zzrteranfga), 0.0000000, 0.0000000, 0.0000000);
    zzmatraa.YPlane = xxplanekaa(0.0000000, (2.0000000 * zzfrraa) / (zzuhjkmwaw - zzpoysaa), 0.0000000, 0.0000000);
    zzmatraa.ZPlane = xxplanekaa((zztyeraxaa + zzrteranfga) / (zztyeraxaa - zzrteranfga), (zzuhjkmwaw + zzpoysaa) / (zzuhjkmwaw - zzpoysaa), ((-1.0000000 * zznbgytaa) - zzfrraa) / (zznbgytaa - zzfrraa), -1.0000000);
    zzmatraa.WPlane = xxplanekaa(0.0000000, 0.0000000, ((-2.0000000 * zznbgytaa) * zzfrraa) / (zznbgytaa - zzfrraa), 0.0000000);
    return zzmatraa;
 
}
function Plane xxplanekaa(float zzweaa, float zzweraaa, float zzbfad, float zzweasa)
{
    local Plane zzbvsfweeqa;

    zzbvsfweeqa.X = zzweaa;
    zzbvsfweeqa.Y = zzweraaa;
    zzbvsfweeqa.Z = zzbfad;
    zzbvsfweeqa.W = zzweasa;
    return zzbvsfweeqa;

}        
function DialogShow (EDialogType dialogType, string strMessage)
{
  local DialogBox script;

  script = DialogBox(GetScript("DialogBox"));
  script.ShowDialog(dialogType,strMessage,string(self));
}

function DialogHide ()
{
  local DialogBox script;

  script = DialogBox(GetScript("DialogBox"));
  script.HideDialog();
}

function DialogSetDefaultOK ()
{
  local DialogBox script;

  script = DialogBox(GetScript("DialogBox"));
  script.SetDefaultAction(EDefaultOK);
}

function bool DialogIsMine ()
{
  local DialogBox script;

  script = DialogBox(GetScript("DialogBox"));
  if ( script.getTargetScript() == string(self) )
  {
    return True;
  }
  return False;
}

function DialogSetID (int Id)
{
  local DialogBox script;

  script = DialogBox(GetScript("DialogBox"));
  script.SetID(Id);
}

function DialogSetEditType (string strType)
{
  local DialogBox script;

  script = DialogBox(GetScript("DialogBox"));
  script.SetEditType(strType);
}

function string DialogGetString ()
{
  local DialogBox script;

  script = DialogBox(GetScript("DialogBox"));
  return script.GetEditMessage();
}

function DialogSetString (string strInput)
{
  local DialogBox script;

  script = DialogBox(GetScript("DialogBox"));
  script.SetEditMessage(strInput);
}

function int DialogGetID ()
{
  local DialogBox script;

  script = DialogBox(GetScript("DialogBox"));
  return script.GetID();
}

function DialogSetParamInt (int index)
{
  local DialogBox script;

  script = DialogBox(GetScript("DialogBox"));
  script.SetParamInt(index);
}

function DialogSetReservedInt (int Value)
{
  local DialogBox script;

  script = DialogBox(GetScript("DialogBox"));
  script.SetReservedInt(Value);
}

function DialogSetReservedInt2 (int Value)
{
  local DialogBox script;

  script = DialogBox(GetScript("DialogBox"));
  script.SetReservedInt2(Value);
}


function Color GetNumColor(string strCommaAdena)
{
    local Color ResultColor;
    local int L;

    // Inicializa los componentes de ResultColor con valores predeterminados.
    ResultColor.R = 220;
    ResultColor.G = 220;
    ResultColor.B = 220;
    ResultColor.A = 255;

    // Obtiene la longitud de la cadena strCommaAdena.
    L = Len(strCommaAdena);

    // Si la cadena contiene una coma, realiza una accion desconocida y almacena el resultado en comma_num.
    if (InStr(strCommaAdena, ",") != -1)
    {
        // Realiza una accion desconocida para obtener el valor de comma_num.
        // UnknownFunction163(comma_num);
    }

    // Si la longitud de la cadena es 5, devuelve ResultColor sin hacer mas calculos.
    if (L == 5)
    {
        return ResultColor;
    }

    // Ajusta la longitud a 5 para que se pueda utilizar en el siguiente switch.
    L = Clamp(L, 0, 5);

    // Asigna diferentes valores de color a ResultColor segun el valor de L.
    switch (L)
    {
        case 0:
            ResultColor.R = 105;
            ResultColor.G = 255;
            ResultColor.B = 255;
            break;

        case 1:
            ResultColor.R = 255;
            ResultColor.G = 128;
            ResultColor.B = 255;
            break;

        case 2:
            ResultColor.R = 255;
            ResultColor.G = 255;
            ResultColor.B = 0;
            break;

        case 3:
            ResultColor.R = 0;
            ResultColor.G = 255;
            ResultColor.B = 0;
            break;

        case 4:
            ResultColor.R = 255;
            ResultColor.G = 140;
            ResultColor.B = 0;
            break;

        case 5:
            ResultColor.R = 0;
            ResultColor.G = 110;
            ResultColor.B = 255;
            break;

        default:
            // Manejar otros casos, si es necesario.
            break;
    }

    // Devuelve ResultColor con los componentes actualizados.
    return ResultColor;
}

// Função para registrar um item como novo
static function AddNewItem(int ObjectID)
{
    local int i;
    // Evita duplicatas
    for (i = 0; i < default.NewItemObjectIDs.Length; i++)
    {
        if (default.NewItemObjectIDs[i] == ObjectID)
            return; 
    }
    default.NewItemObjectIDs[default.NewItemObjectIDs.Length] = ObjectID;
}

// Função para verificar se o item é novo
static function bool IsItemNew(int ObjectID)
{
    local int i;
    for (i = 0; i < default.NewItemObjectIDs.Length; i++)
    {
        if (default.NewItemObjectIDs[i] == ObjectID)
            return true;
    }
    return false;
}

// Função para remover o status de 'novo' quando o jogador clicar
static function ClearNewItem(int ObjectID)
{
    local int i;
    for (i = 0; i < default.NewItemObjectIDs.Length; i++)
    {
        if (default.NewItemObjectIDs[i] == ObjectID)
        {
            default.NewItemObjectIDs.Remove(i, 1);
            return;
        }
    }
}

// Função para limpar todos os itens novos de uma vez
static function ClearAllNewItems()
{
    default.NewItemObjectIDs.Length = 0;
}


function DialogSetReservedInt3 (int Value)
{
  local DialogBox script;

  script = DialogBox(GetScript("DialogBox"));
  script.SetReservedInt3(Value);
}

function int DialogGetReservedInt ()
{
  local DialogBox script;

  script = DialogBox(GetScript("DialogBox"));
  return script.GetReservedInt();
}

function int DialogGetReservedInt2 ()
{
  local DialogBox script;

  script = DialogBox(GetScript("DialogBox"));
  return script.GetReservedInt2();
}

function int DialogGetReservedInt3 ()
{
  local DialogBox script;

  script = DialogBox(GetScript("DialogBox"));
  return script.GetReservedInt3();
}

function DialogSetEditBoxMaxLength (int maxLength)
{
  local DialogBox script;

  script = DialogBox(GetScript("DialogBox"));
  script.SetEditBoxMaxLength(maxLength);
}

function string GetTimeStr (int idx)
{
  local string TimeStr;

  if ( idx > -1 )
  {
    if ( idx < 60 )
    {
      TimeStr = "" $ string(idx) $ " Sec.";
    } else {
      if ( idx < 3600 )
      {
        idx = idx / 60;
        TimeStr = "" $ string(idx) $ " Min.";
      } else {
        idx = idx / 3600;
        TimeStr = "" $ string(idx) $ " Hrs.";
      }
    }
    return TimeStr;
  }
}

function int Split( string strInput, string delim, out array<string> arrToken )
{
	local int arrSize;
	
	while ( InStr(strInput, delim)>0 )
	{
		arrToken.Insert(arrToken.Length, 1);
		arrToken[arrToken.Length-1] = Left(strInput, InStr(strInput, delim));
		strInput = Mid(strInput, InStr(strInput, delim)+1);
		arrSize = arrSize + 1;
	}
	arrToken.Insert(arrToken.Length, 1);
	arrToken[arrToken.Length-1] = strInput;
	arrSize = arrSize + 1;
	
	return arrSize;
}

function string esc (private string targetString, private string oldSubstring, private string newSubstring)
{
  local int index;
  local string result;

  result = "";
  index = InStr(targetString, oldSubstring);

  if (index != -1)
  {
    result = Mid(targetString, 0, index) $ newSubstring $ Mid(targetString, index + Len(oldSubstring), Len(targetString) - index - Len(oldSubstring));
  }
  else
  {
    result = targetString;
  }

  return result;
}






function bool StringsMatch (string index, string param)
{
  local bool idx;

  if ( index ~= param )
  {
    idx = True;
  }
  return idx;
}

function JoinArray (array<string> StringArray, out string out_Result, string delim, bool bIgnoreBlanks)
{
  local int i;
  local string S;

  i = 0;
  JL0007:
  if ( i < StringArray.Length )
  {
    if ( (StringArray[i] != "") ||  !bIgnoreBlanks )
    {
      if ( S != "" )
      {
        S = S $ delim;
      }
      S = S $ StringArray[i];
    }
    i++;
    goto JL0007;
  }
  out_Result = S;
}






function array<string> lista2(string val, string val2)
{
    local array<string> listastring;
    local int startPos;
    local int endPos;
    local string remaining;

    listastring.Length = 0;
    remaining = val;

    while (remaining != "")
    {
        startPos = InStr(remaining, val2);

        if (startPos == -1)
        {
            // Si no se encuentra más separadores, se agrega el elemento restante
            listastring[listastring.Length] = remaining;
            remaining = "";
        }
        else
        {
            endPos = startPos + Len(val2);
            // Se agrega el elemento encontrado a la lista
            listastring[listastring.Length] = Left(remaining, startPos - 1);
            // Se actualiza la cadena restante eliminando el elemento y el separador
            remaining = Mid(remaining, endPos);
        }
    }

    return listastring;
}


function array<string> xxlista23(string val, string val2)
{
    local array<string> listastring;
    local int startPos;
    
    local string remaining;

    listastring.Length = 0;
    remaining = val;

    while (remaining != "")
    {
        // Encontrar la posición de la próxima coma
        startPos = InStr(remaining, val2);

        if (startPos == -1)
        {
            // Si no se encuentra más separadores, agregar el elemento restante
            listastring[listastring.Length] = remaining;
            remaining = "";
        }
        else
        {
            // Agregar el elemento encontrado a la lista
            listastring[listastring.Length] = Left(remaining, startPos);
            // Actualizar la cadena restante eliminando el elemento y el separador
            remaining = Mid(remaining, startPos + Len(val2));
        }
    }

    return listastring;
}
function string xxgetcosaku211a(int ClassID)
{
    local string pasmua2a1;

    pasmua2a1 = "";
    switch(ClassID)
    {
        // End:0x38
        case 0:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_1";
            // End:0xE8E
            break;
        // End:0x61
        case 1:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_1";
            // End:0xE8E
            break;
        // End:0x8B
        case 2:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_1";
            // End:0xE8E
            break;
        // End:0xB5
        case 3:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_1";
            // End:0xE8E
            break;
        // End:0xDF
        case 4:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_1";
            // End:0xE8E
            break;
        // End:0x109
        case 5:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_3";
            // End:0xE8E
            break;
        // End:0x133
        case 6:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_3";
            // End:0xE8E
            break;
        // End:0x15D
        case 7:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_1";
            // End:0xE8E
            break;
        // End:0x187
        case 8:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_1";
            // End:0xE8E
            break;
        // End:0x1B1
        case 9:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_2";
            // End:0xE8E
            break;
        // End:0x1DB
        case 10:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_2";
            // End:0xE8E
            break;
        // End:0x205
        case 11:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_2";
            // End:0xE8E
            break;
        // End:0x22F
        case 12:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_5";
            // End:0xE8E
            break;
        // End:0x259
        case 13:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_5";
            // End:0xE8E
            break;
        // End:0x283
        case 14:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_7";
            // End:0xE8E
            break;
        // End:0x2AD
        case 15:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_2";
            // End:0xE8E
            break;
        // End:0x2D7
        case 16:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_6";
            // End:0xE8E
            break;
        // End:0x301
        case 17:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_6";
            // End:0xE8E
            break;
        // End:0x32B
        case 18:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_1";
            // End:0xE8E
            break;
        // End:0x355
        case 19:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_2";
            // End:0xE8E
            break;
        // End:0x37F
        case 20:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_3";
            // End:0xE8E
            break;
        // End:0x3A9
        case 21:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_4";
            // End:0xE8E
            break;
        // End:0x3D3
        case 22:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_1";
            // End:0xE8E
            break;
        // End:0x3FD
        case 23:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_1";
            // End:0xE8E
            break;
        // End:0x427
        case 24:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_2";
            // End:0xE8E
            break;
        // End:0x451
        case 25:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_2";
            // End:0xE8E
            break;
        // End:0x47B
        case 26:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_2";
            // End:0xE8E
            break;
        // End:0x4A5
        case 27:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_5";
            // End:0xE8E
            break;
        // End:0x4CF
        case 28:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_7";
            // End:0xE8E
            break;
        // End:0x4F9
        case 29:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_2";
            // End:0xE8E
            break;
        // End:0x523
        case 30:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_6";
            // End:0xE8E
            break;
        // End:0x54D
        case 31:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_1";
            // End:0xE8E
            break;
        // End:0x577
        case 32:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_1";
            // End:0xE8E
            break;
        // End:0x5A1
        case 33:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_3";
            // End:0xE8E
            break;
        // End:0x5CB
        case 34:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_4";
            // End:0xE8E
            break;
        // End:0x5F5
        case 35:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_1";
            // End:0xE8E
            break;
        // End:0x61F
        case 36:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_1";
            // End:0xE8E
            break;
        // End:0x649
        case 37:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_2";
            // End:0xE8E
            break;
        // End:0x673
        case 38:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_2";
            // End:0xE8E
            break;
        // End:0x69D
        case 39:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_2";
            // End:0xE8E
            break;
        // End:0x6C7
        case 40:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_5";
            // End:0xE8E
            break;
        // End:0x6F1
        case 41:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_7";
            // End:0xE8E
            break;
        // End:0x71B
        case 42:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_2";
            // End:0xE8E
            break;
        // End:0x745
        case 43:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_6";
            // End:0xE8E
            break;
        // End:0x76F
        case 44:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_1";
            // End:0xE8E
            break;
        // End:0x799
        case 45:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_1";
            // End:0xE8E
            break;
        // End:0x7C3
        case 46:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_1";
            // End:0xE8E
            break;
        // End:0x7ED
        case 47:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_1";
            // End:0xE8E
            break;
        // End:0x817
        case 48:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_1";
            // End:0xE8E
            break;
        // End:0x841
        case 49:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_2";
            // End:0xE8E
            break;
        // End:0x86B
        case 50:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_2";
            // End:0xE8E
            break;
        // End:0x895
        case 51:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_4";
            // End:0xE8E
            break;
        // End:0x8BF
        case 52:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_4";
            // End:0xE8E
            break;
        // End:0x8E9
        case 53:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_1";
            // End:0xE8E
            break;
        // End:0x913
        case 54:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_1";
            // End:0xE8E
            break;
        // End:0x93D
        case 55:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_1";
            // End:0xE8E
            break;
        // End:0x967
        case 56:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Brown_1";
            // End:0xE8E
            break;
        // End:0x991
        case 57:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Green_1";
            // End:0xE8E
            break;
        // End:0x9BA
        case 88:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_8";
            // End:0xE8E
            break;
        // End:0x9E3
        case 89:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_1";
            // End:0xE8E
            break;
        // End:0xA0C
        case 90:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_3";
            // End:0xE8E
            break;
        // End:0xA35
        case 91:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_3";
            // End:0xE8E
            break;
        // End:0xA5E
        case 92:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_2";
            // End:0xE8E
            break;
        // End:0xA87
        case 93:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_1";
            // End:0xE8E
            break;
        // End:0xAB0
        case 94:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_5";
            // End:0xE8E
            break;
        // End:0xAD9
        case 95:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_5";
            // End:0xE8E
            break;
        // End:0xB02
        case 96:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_7";
            // End:0xE8E
            break;
        // End:0xB2B
        case 97:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_6";
            // End:0xE8E
            break;
        // End:0xB54
        case 98:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_6";
            // End:0xE8E
            break;
        // End:0xB7D
        case 99:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_3";
            // End:0xE8E
            break;
        // End:0xBA6
        case 100:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_4";
            // End:0xE8E
            break;
        // End:0xBCF
        case 101:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_1";
            // End:0xE8E
            break;
        // End:0xBF8
        case 102:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_2";
            // End:0xE8E
            break;
        // End:0xC21
        case 103:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_5";
            // End:0xE8E
            break;
        // End:0xC4A
        case 104:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_7";
            // End:0xE8E
            break;
        // End:0xC73
        case 105:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_6";
            // End:0xE8E
            break;
        // End:0xC9C
        case 106:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_3";
            // End:0xE8E
            break;
        // End:0xCC5
        case 107:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_4";
            // End:0xE8E
            break;
        // End:0xCEE
        case 108:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_1";
            // End:0xE8E
            break;
        // End:0xD17
        case 109:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_2";
            // End:0xE8E
            break;
        // End:0xD40
        case 110:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_5";
            // End:0xE8E
            break;
        // End:0xD69
        case 111:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_7";
            // End:0xE8E
            break;
        // End:0xD92
        case 112:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_6";
            // End:0xE8E
            break;
        // End:0xDBB
        case 113:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_1";
            // End:0xE8E
            break;
        // End:0xDE4
        case 114:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_1";
            // End:0xE8E
            break;
        // End:0xE0D
        case 115:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_4";
            // End:0xE8E
            break;
        // End:0xE36
        case 116:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_4";
            // End:0xE8E
            break;
        // End:0xE5F
        case 117:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_1";
            // End:0xE8E
            break;
        // End:0xE88
        case 118:
            pasmua2a1 = "L2UI_CH3.StyleIcon_Blue_1";
            // End:0xE8E
            break;
        // End:0xFFFF
        default:
            // End:0xE8E
            break;
            break;
    }
    return pasmua2a1;

}


function bool xxchekaxmu2ax111(int Id)
{
    local bool loqueteax;

    switch(Id)
    {
        // End:0x0F
        case 276:
        // End:0x17
        case 273:
        // End:0x1F
        case 365:
        // End:0x27
        case 275:
        // End:0x2F
        case 274:
        // End:0x37
        case 271:
        // End:0x3F
        case 272:
        // End:0x47
        case 310:
        // End:0x4F
        case 264:
        // End:0x57
        case 265:
        // End:0x5F
        case 266:
        // End:0x67
        case 267:
        // End:0x6F
        case 268:
        // End:0x77
        case 269:
        // End:0x7F
        case 349:
        // End:0x87
        case 270:
        // End:0x8F
        case 304:
        // End:0x97
        case 305:
        // End:0x9F
        case 306:
        // End:0xA7
        case 308:
        // End:0xAF
        case 363:
        // End:0xB7
        case 364:
        // End:0xBF
        case 529:
        // End:0xC7
        case 277:
        // End:0xCF
        case 307:
        // End:0xD7
        case 309:
        // End:0xDF
        case 311:
        // End:0xE7
        case 366:
        // End:0xEF
        case 530:
        // End:0x102
        case 915:
            loqueteax = true;
            // End:0x105
            break;
        // End:0xFFFF
        default:
            break;
    }
    return loqueteax;

}

function bool xxgetcoinida2(int Id)
{
    local bool testkaxa;

    switch(Id)
    {
        // End:0x0F
        case 2057:
        // End:0x17
        case 2058:
        // End:0x2A
        case 2059:
            testkaxa = true;
            // End:0x2D
            break;
        // End:0xFFFF
        default:
            break;
    }
    return testkaxa;

}


function string xxgetcoasun2a(int id)
{
    local string parametroas2;

    parametroas2 = "";
    switch(id)
    {
        // End:0x30
        case 1:
            parametroas2 = "L2UI_CH3.texCount1";
            // End:0xAFB
            break;
        // End:0x52
        case 2:
            parametroas2 = "L2UI_CH3.texCount2";
            // End:0xAFB
            break;
        // End:0x74
        case 3:
            parametroas2 = "L2UI_CH3.texCount3";
            // End:0xAFB
            break;
        // End:0x96
        case 4:
            parametroas2 = "L2UI_CH3.texCount4";
            // End:0xAFB
            break;
        // End:0xB8
        case 5:
            parametroas2 = "L2UI_CH3.texCount5";
            // End:0xAFB
            break;
        // End:0xDA
        case 6:
            parametroas2 = "L2UI_CH3.texCount6";
            // End:0xAFB
            break;
        // End:0xFC
        case 7:
            parametroas2 = "L2UI_CH3.texCount7";
            // End:0xAFB
            break;
        // End:0x11E
        case 8:
            parametroas2 = "L2UI_CH3.texCount8";
            // End:0xAFB
            break;
        // End:0x140
        case 9:
            parametroas2 = "L2UI_CH3.texCount9";
            // End:0xAFB
            break;
        // End:0x163
        case 10:
            parametroas2 = "L2UI_CH3.texCount10";
            // End:0xAFB
            break;
        // End:0x186
        case 11:
            parametroas2 = "L2UI_CH3.texCount11";
            // End:0xAFB
            break;
        // End:0x1A9
        case 12:
            parametroas2 = "L2UI_CH3.texCount12";
            // End:0xAFB
            break;
        // End:0x1CC
        case 13:
            parametroas2 = "L2UI_CH3.texCount13";
            // End:0xAFB
            break;
        // End:0x1EF
        case 14:
            parametroas2 = "L2UI_CH3.texCount14";
            // End:0xAFB
            break;
        // End:0x212
        case 15:
            parametroas2 = "L2UI_CH3.texCount15";
            // End:0xAFB
            break;
        // End:0x235
        case 16:
            parametroas2 = "L2UI_CH3.texCount16";
            // End:0xAFB
            break;
        // End:0x258
        case 17:
            parametroas2 = "L2UI_CH3.texCount17";
            // End:0xAFB
            break;
        // End:0x27B
        case 18:
            parametroas2 = "L2UI_CH3.texCount18";
            // End:0xAFB
            break;
        // End:0x29E
        case 19:
            parametroas2 = "L2UI_CH3.texCount19";
            // End:0xAFB
            break;
        // End:0x2C1
        case 20:
            parametroas2 = "L2UI_CH3.texCount20";
            // End:0xAFB
            break;
        // End:0x2E4
        case 21:
            parametroas2 = "L2UI_CH3.texCount21";
            // End:0xAFB
            break;
        // End:0x307
        case 22:
            parametroas2 = "L2UI_CH3.texCount22";
            // End:0xAFB
            break;
        // End:0x32A
        case 23:
            parametroas2 = "L2UI_CH3.texCount23";
            // End:0xAFB
            break;
        // End:0x34D
        case 24:
            parametroas2 = "L2UI_CH3.texCount24";
            // End:0xAFB
            break;
        // End:0x370
        case 25:
            parametroas2 = "L2UI_CH3.texCount25";
            // End:0xAFB
            break;
        // End:0x393
        case 26:
            parametroas2 = "L2UI_CH3.texCount26";
            // End:0xAFB
            break;
        // End:0x3B6
        case 27:
            parametroas2 = "L2UI_CH3.texCount27";
            // End:0xAFB
            break;
        // End:0x3D9
        case 28:
            parametroas2 = "L2UI_CH3.texCount28";
            // End:0xAFB
            break;
        // End:0x3FC
        case 29:
            parametroas2 = "L2UI_CH3.texCount29";
            // End:0xAFB
            break;
        // End:0x41F
        case 30:
            parametroas2 = "L2UI_CH3.texCount30";
            // End:0xAFB
            break;
        // End:0x442
        case 31:
            parametroas2 = "L2UI_CH3.texCount31";
            // End:0xAFB
            break;
        // End:0x465
        case 32:
            parametroas2 = "L2UI_CH3.texCount32";
            // End:0xAFB
            break;
        // End:0x488
        case 33:
            parametroas2 = "L2UI_CH3.texCount33";
            // End:0xAFB
            break;
        // End:0x4AB
        case 34:
            parametroas2 = "L2UI_CH3.texCount34";
            // End:0xAFB
            break;
        // End:0x4CE
        case 35:
            parametroas2 = "L2UI_CH3.texCount35";
            // End:0xAFB
            break;
        // End:0x4F1
        case 36:
            parametroas2 = "L2UI_CH3.texCount36";
            // End:0xAFB
            break;
        // End:0x514
        case 37:
            parametroas2 = "L2UI_CH3.texCount37";
            // End:0xAFB
            break;
        // End:0x537
        case 38:
            parametroas2 = "L2UI_CH3.texCount38";
            // End:0xAFB
            break;
        // End:0x55A
        case 39:
            parametroas2 = "L2UI_CH3.texCount39";
            // End:0xAFB
            break;
        // End:0x57D
        case 40:
            parametroas2 = "L2UI_CH3.texCount40";
            // End:0xAFB
            break;
        // End:0x5A0
        case 41:
            parametroas2 = "L2UI_CH3.texCount41";
            // End:0xAFB
            break;
        // End:0x5C3
        case 42:
            parametroas2 = "L2UI_CH3.texCount42";
            // End:0xAFB
            break;
        // End:0x5E6
        case 43:
            parametroas2 = "L2UI_CH3.texCount43";
            // End:0xAFB
            break;
        // End:0x609
        case 44:
            parametroas2 = "L2UI_CH3.texCount44";
            // End:0xAFB
            break;
        // End:0x62C
        case 45:
            parametroas2 = "L2UI_CH3.texCount45";
            // End:0xAFB
            break;
        // End:0x64F
        case 46:
            parametroas2 = "L2UI_CH3.texCount46";
            // End:0xAFB
            break;
        // End:0x672
        case 47:
            parametroas2 = "L2UI_CH3.texCount47";
            // End:0xAFB
            break;
        // End:0x695
        case 48:
            parametroas2 = "L2UI_CH3.texCount48";
            // End:0xAFB
            break;
        // End:0x6B8
        case 49:
            parametroas2 = "L2UI_CH3.texCount49";
            // End:0xAFB
            break;
        // End:0x6DB
        case 50:
            parametroas2 = "L2UI_CH3.texCount50";
            // End:0xAFB
            break;
        // End:0x6FE
        case 51:
            parametroas2 = "L2UI_CH3.texCount51";
            // End:0xAFB
            break;
        // End:0x721
        case 52:
            parametroas2 = "L2UI_CH3.texCount52";
            // End:0xAFB
            break;
        // End:0x744
        case 53:
            parametroas2 = "L2UI_CH3.texCount53";
            // End:0xAFB
            break;
        // End:0x767
        case 54:
            parametroas2 = "L2UI_CH3.texCount54";
            // End:0xAFB
            break;
        // End:0x78A
        case 55:
            parametroas2 = "L2UI_CH3.texCount55";
            // End:0xAFB
            break;
        // End:0x7AD
        case 56:
            parametroas2 = "L2UI_CH3.texCount56";
            // End:0xAFB
            break;
        // End:0x7D0
        case 57:
            parametroas2 = "L2UI_CH3.texCount57";
            // End:0xAFB
            break;
        // End:0x7F3
        case 58:
            parametroas2 = "L2UI_CH3.texCount58";
            // End:0xAFB
            break;
        // End:0x816
        case 59:
            parametroas2 = "L2UI_CH3.texCount59";
            // End:0xAFB
            break;
        // End:0x839
        case 60:
            parametroas2 = "L2UI_CH3.texCount60";
            // End:0xAFB
            break;
        // End:0x85C
        case 61:
            parametroas2 = "L2UI_CH3.texCount61";
            // End:0xAFB
            break;
        // End:0x87F
        case 62:
            parametroas2 = "L2UI_CH3.texCount62";
            // End:0xAFB
            break;
        // End:0x8A2
        case 63:
            parametroas2 = "L2UI_CH3.texCount63";
            // End:0xAFB
            break;
        // End:0x8C5
        case 64:
            parametroas2 = "L2UI_CH3.texCount64";
            // End:0xAFB
            break;
        // End:0x8E8
        case 65:
            parametroas2 = "L2UI_CH3.texCount65";
            // End:0xAFB
            break;
        // End:0x90B
        case 66:
            parametroas2 = "L2UI_CH3.texCount66";
            // End:0xAFB
            break;
        // End:0x92E
        case 67:
            parametroas2 = "L2UI_CH3.texCount67";
            // End:0xAFB
            break;
        // End:0x951
        case 68:
            parametroas2 = "L2UI_CH3.texCount68";
            // End:0xAFB
            break;
        // End:0x974
        case 69:
            parametroas2 = "L2UI_CH3.texCount69";
            // End:0xAFB
            break;
        // End:0x997
        case 70:
            parametroas2 = "L2UI_CH3.texCount70";
            // End:0xAFB
            break;
        // End:0x9BA
        case 71:
            parametroas2 = "L2UI_CH3.texCount71";
            // End:0xAFB
            break;
        // End:0x9DD
        case 72:
            parametroas2 = "L2UI_CH3.texCount72";
            // End:0xAFB
            break;
        // End:0xA00
        case 73:
            parametroas2 = "L2UI_CH3.texCount73";
            // End:0xAFB
            break;
        // End:0xA23
        case 74:
            parametroas2 = "L2UI_CH3.texCount74";
            // End:0xAFB
            break;
        // End:0xA46
        case 75:
            parametroas2 = "L2UI_CH3.texCount75";
            // End:0xAFB
            break;
        // End:0xA69
        case 76:
            parametroas2 = "L2UI_CH3.texCount76";
            // End:0xAFB
            break;
        // End:0xA8C
        case 77:
            parametroas2 = "L2UI_CH3.texCount77";
            // End:0xAFB
            break;
        // End:0xAAF
        case 78:
            parametroas2 = "L2UI_CH3.texCount78";
            // End:0xAFB
            break;
        // End:0xAD2
        case 79:
            parametroas2 = "L2UI_CH3.texCount79";
            // End:0xAFB
            break;
        // End:0xAF5
        case 80:
            parametroas2 = "L2UI_CH3.texCount80";
            // End:0xAFB
            break;
        // End:0xFFFF
        default:
            // End:0xAFB
            break;
            break;
    }
    return parametroas2;

}

function bool checkidaoa(int Id)
{
    local bool chelakua;

    chelakua = false;
    switch(Id)
    {
        // End:0x14
        case 28:
        // End:0x19
        case 92:
        // End:0x1E
        case 101:
        // End:0x23
        case 102:
        // End:0x28
        case 105:
        // End:0x2D
        case 115:
        // End:0x32
        case 129:
        // End:0x3A
        case 1069:
        // End:0x42
        case 1083:
        // End:0x4A
        case 1160:
        // End:0x52
        case 1164:
        // End:0x5A
        case 1167:
        // End:0x62
        case 1168:
        // End:0x6A
        case 1184:
        // End:0x72
        case 1201:
        // End:0x7A
        case 1206:
        // End:0x82
        case 1222:
        // End:0x8A
        case 1223:
        // End:0x92
        case 1224:
        // End:0x97
        case 100:
        // End:0x9C
        case 95:
        // End:0xA1
        case 96:
        // End:0xA6
        case 120:
        // End:0xAB
        case 223:
        // End:0xB3
        case 1092:
        // End:0xBB
        case 1095:
        // End:0xC3
        case 1096:
        // End:0xCB
        case 1097:
        // End:0xD3
        case 1099:
        // End:0xDB
        case 1100:
        // End:0xE3
        case 1101:
        // End:0xEB
        case 1102:
        // End:0xF3
        case 1107:
        // End:0xFB
        case 1208:
        // End:0x103
        case 1209:
        // End:0x108
        case 18:
        // End:0x10D
        case 48:
        // End:0x112
        case 65:
        // End:0x117
        case 84:
        // End:0x11C
        case 97:
        // End:0x121
        case 98:
        // End:0x126
        case 103:
        // End:0x12B
        case 106:
        // End:0x130
        case 107:
        // End:0x135
        case 116:
        // End:0x13A
        case 122:
        // End:0x13F
        case 127:
        // End:0x147
        case 260:
        // End:0x14F
        case 279:
        // End:0x157
        case 281:
        // End:0x15F
        case 1042:
        // End:0x167
        case 1049:
        // End:0x16F
        case 1064:
        // End:0x177
        case 1071:
        // End:0x17F
        case 1072:
        // End:0x187
        case 1074:
        // End:0x18F
        case 1104:
        // End:0x197
        case 1108:
        // End:0x19F
        case 1169:
        // End:0x1A7
        case 1170:
        // End:0x1AF
        case 1183:
        // End:0x1B7
        case 1210:
        // End:0x1BF
        case 1231:
        // End:0x1C7
        case 1233:
        // End:0x1CF
        case 1236:
        // End:0x1D7
        case 1237:
        // End:0x1DF
        case 1244:
        // End:0x1E7
        case 1246:
        // End:0x1EF
        case 1247:
        // End:0x1F7
        case 1248:
        // End:0x1FF
        case 286:
        // End:0x207
        case 1263:
        // End:0x20F
        case 1269:
        // End:0x217
        case 1272:
        // End:0x21F
        case 1289:
        // End:0x227
        case 1290:
        // End:0x22F
        case 1291:
        // End:0x237
        case 1298:
        // End:0x23F
        case 342:
        // End:0x247
        case 352:
        // End:0x24F
        case 353:
        // End:0x257
        case 354:
        // End:0x25F
        case 358:
        // End:0x267
        case 361:
        // End:0x26F
        case 362:
        // End:0x277
        case 367:
        // End:0x27F
        case 1336:
        // End:0x287
        case 1337:
        // End:0x28F
        case 1338:
        // End:0x297
        case 1339:
        // End:0x29F
        case 1340:
        // End:0x2A7
        case 1341:
        // End:0x2AF
        case 1342:
        // End:0x2B7
        case 1343:
        // End:0x2BF
        case 1358:
        // End:0x2C7
        case 1359:
        // End:0x2CF
        case 1360:
        // End:0x2D7
        case 1361:
        // End:0x2DF
        case 1366:
        // End:0x2E7
        case 1367:
        // End:0x2EF
        case 1375:
        // End:0x2F7
        case 1376:
        // End:0x2FF
        case 400:
        // End:0x307
        case 401:
        // End:0x30F
        case 402:
        // End:0x317
        case 403:
        // End:0x31F
        case 404:
        // End:0x327
        case 407:
        // End:0x32F
        case 408:
        // End:0x337
        case 412:
        // End:0x33F
        case 1380:
        // End:0x347
        case 1381:
        // End:0x34F
        case 1382:
        // End:0x357
        case 1383:
        // End:0x35F
        case 1384:
        // End:0x367
        case 1385:
        // End:0x36F
        case 1386:
        // End:0x377
        case 1394:
        // End:0x37F
        case 1396:
        // End:0x387
        case 437:
        // End:0x38F
        case 452:
        // End:0x397
        case 485:
        // End:0x39F
        case 1435:
        // End:0x3A7
        case 494:
        // End:0x3AF
        case 495:
        // End:0x3B7
        case 501:
        // End:0x3BF
        case 1437:
        // End:0x3C7
        case 1445:
        // End:0x3CF
        case 1446:
        // End:0x3D7
        case 1447:
        // End:0x3DF
        case 1448:
        // End:0x3E7
        case 509:
        // End:0x3EF
        case 522:
        // End:0x3F7
        case 523:
        // End:0x3FF
        case 531:
        // End:0x407
        case 537:
        // End:0x40F
        case 1452:
        // End:0x417
        case 1454:
        // End:0x41F
        case 1455:
        // End:0x427
        case 1458:
        // End:0x42F
        case 1462:
        // End:0x437
        case 1467:
        // End:0x43F
        case 1468:
        // End:0x447
        case 559:
        // End:0x44F
        case 564:
        // End:0x457
        case 571:
        // End:0x45F
        case 573:
        // End:0x467
        case 578:
        // End:0x46F
        case 581:
        // End:0x477
        case 582:
        // End:0x47F
        case 588:
        // End:0x487
        case 1481:
        // End:0x48F
        case 1482:
        // End:0x497
        case 1483:
        // End:0x49F
        case 1484:
        // End:0x4A7
        case 1485:
        // End:0x4AF
        case 1486:
        // End:0x4B7
        case 627:
        // End:0x4BF
        case 680:
        // End:0x4C7
        case 681:
        // End:0x4CF
        case 682:
        // End:0x4D7
        case 683:
        // End:0x4DF
        case 686:
        // End:0x4E7
        case 688:
        // End:0x4EF
        case 692:
        // End:0x4F7
        case 695:
        // End:0x4FF
        case 696:
        // End:0x507
        case 708:
        // End:0x50F
        case 716:
        // End:0x517
        case 730:
        // End:0x51F
        case 732:
        // End:0x527
        case 736:
        // End:0x52F
        case 741:
        // End:0x537
        case 747:
        // End:0x53F
        case 749:
        // End:0x547
        case 752:
        // End:0x54F
        case 762:
        // End:0x557
        case 763:
        // End:0x55F
        case 774:
        // End:0x567
        case 775:
        // End:0x56F
        case 776:
        // End:0x577
        case 1495:
        // End:0x57F
        case 1508:
        // End:0x587
        case 1509:
        // End:0x58F
        case 1511:
        // End:0x597
        case 1512:
        // End:0x59F
        case 791:
        // End:0x5A7
        case 792:
        // End:0x5AF
        case 793:
        // End:0x5B7
        case 794:
        // End:0x5BF
        case 798:
        // End:0x5C7
        case 808:
        // End:0x5CF
        case 1524:
        // End:0x5D7
        case 1525:
        // End:0x5DF
        case 835:
        // End:0x5E7
        case 1529:
        // End:0x5EF
        case 877:
        // End:0x5F7
        case 879:
        // End:0x5FF
        case 883:
        // End:0x607
        case 886:
        // End:0x60F
        case 887:
        // End:0x617
        case 899:
        // End:0x61F
        case 904:
        // End:0x627
        case 905:
        // End:0x62F
        case 909:
        // End:0x637
        case 910:
        // End:0x63F
        case 927:
        // End:0x647
        case 1539:
        // End:0x64F
        case 1540:
        // End:0x657
        case 1541:
        // End:0x65F
        case 949:
        // End:0x667
        case 954:
        // End:0x66F
        case 1546:
        // End:0x677
        case 969:
        // End:0x67F
        case 973:
        // End:0x687
        case 974:
        // End:0x68F
        case 977:
        // End:0x697
        case 978:
        // End:0x69F
        case 979:
        // End:0x6A7
        case 980:
        // End:0x6AF
        case 981:
        // End:0x6B7
        case 985:
        // End:0x6BF
        case 991:
        // End:0x6C7
        case 1554:
        // End:0x6CF
        case 1555:
        // End:0x6D7
        case 995:
        // End:0x6DF
        case 996:
        // End:0x6E7
        case 997:
        // End:0x6EF
        case 2074:
        // End:0x6F7
        case 2234:
        // End:0x6FF
        case 2239:
        // End:0x707
        case 2399:
        // End:0x70F
        case 2839:
        // End:0x717
        case 3005:
        // End:0x71F
        case 3016:
        // End:0x727
        case 3020:
        // End:0x72F
        case 3021:
        // End:0x737
        case 3024:
        // End:0x73F
        case 3040:
        // End:0x747
        case 3041:
        // End:0x74F
        case 3052:
        // End:0x757
        case 3053:
        // End:0x75F
        case 3054:
        // End:0x767
        case 3055:
        // End:0x76F
        case 3061:
        // End:0x777
        case 3062:
        // End:0x77F
        case 3070:
        // End:0x787
        case 3074:
        // End:0x78F
        case 3075:
        // End:0x797
        case 3078:
        // End:0x79F
        case 3079:
        // End:0x7A7
        case 3571:
        // End:0x7AF
        case 3574:
        // End:0x7B7
        case 3577:
        // End:0x7BF
        case 3579:
        // End:0x7C7
        case 3584:
        // End:0x7CF
        case 3586:
        // End:0x7D7
        case 3588:
        // End:0x7DF
        case 3590:
        // End:0x7E7
        case 3594:
        // End:0x7EF
        case 3083:
        // End:0x7F7
        case 3084:
        // End:0x7FF
        case 3085:
        // End:0x807
        case 3086:
        // End:0x80F
        case 3087:
        // End:0x817
        case 3088:
        // End:0x81F
        case 3089:
        // End:0x827
        case 3090:
        // End:0x82F
        case 3091:
        // End:0x837
        case 3092:
        // End:0x83F
        case 3093:
        // End:0x847
        case 3094:
        // End:0x84F
        case 3096:
        // End:0x857
        case 3097:
        // End:0x85F
        case 3098:
        // End:0x867
        case 3099:
        // End:0x86F
        case 3100:
        // End:0x877
        case 3101:
        // End:0x87F
        case 3102:
        // End:0x887
        case 3103:
        // End:0x88F
        case 3104:
        // End:0x897
        case 3105:
        // End:0x89F
        case 3106:
        // End:0x8A7
        case 3107:
        // End:0x8AF
        case 3111:
        // End:0x8B7
        case 3112:
        // End:0x8BF
        case 3113:
        // End:0x8C7
        case 3114:
        // End:0x8CF
        case 3115:
        // End:0x8D7
        case 3116:
        // End:0x8DF
        case 3117:
        // End:0x8E7
        case 3118:
        // End:0x8EF
        case 3119:
        // End:0x8F7
        case 3120:
        // End:0x8FF
        case 3121:
        // End:0x907
        case 3122:
        // End:0x90F
        case 3137:
        // End:0x917
        case 3187:
        // End:0x91F
        case 3188:
        // End:0x927
        case 3189:
        // End:0x92F
        case 3190:
        // End:0x937
        case 3191:
        // End:0x93F
        case 3192:
        // End:0x947
        case 3193:
        // End:0x94F
        case 3194:
        // End:0x957
        case 3195:
        // End:0x95F
        case 3196:
        // End:0x967
        case 3197:
        // End:0x96F
        case 3198:
        // End:0x977
        case 3331:
        // End:0x97F
        case 8240:
        // End:0x987
        case 8276:
        // End:0x98F
        case 8357:
        // End:0x997
        case 7007:
        // End:0x99F
        case 4018:
        // End:0x9A7
        case 4019:
        // End:0x9AF
        case 4034:
        // End:0x9B7
        case 4035:
        // End:0x9BF
        case 4036:
        // End:0x9C7
        case 4037:
        // End:0x9CF
        case 4038:
        // End:0x9D7
        case 4046:
        // End:0x9DF
        case 4047:
        // End:0x9E7
        case 4052:
        // End:0x9EF
        case 4053:
        // End:0x9F7
        case 4054:
        // End:0x9FF
        case 4055:
        // End:0xA07
        case 4063:
        // End:0xA0F
        case 4064:
        // End:0xA17
        case 4070:
        // End:0xA1F
        case 4072:
        // End:0xA27
        case 4073:
        // End:0xA2F
        case 4075:
        // End:0xA37
        case 4076:
        // End:0xA3F
        case 4082:
        // End:0xA47
        case 4088:
        // End:0xA4F
        case 4098:
        // End:0xA57
        case 4102:
        // End:0xA5F
        case 4104:
        // End:0xA67
        case 4106:
        // End:0xA6F
        case 4107:
        // End:0xA77
        case 4108:
        // End:0xA7F
        case 4109:
        // End:0xA87
        case 4111:
        // End:0xA8F
        case 4117:
        // End:0xA97
        case 4118:
        // End:0xA9F
        case 4119:
        // End:0xAA7
        case 4120:
        // End:0xAAF
        case 4126:
        // End:0xAB7
        case 4131:
        // End:0xABF
        case 4140:
        // End:0xAC7
        case 4145:
        // End:0xACF
        case 4146:
        // End:0xAD7
        case 4148:
        // End:0xADF
        case 4149:
        // End:0xAE7
        case 4150:
        // End:0xAEF
        case 4153:
        // End:0xAF7
        case 4162:
        // End:0xAFF
        case 4164:
        // End:0xB07
        case 4165:
        // End:0xB0F
        case 4166:
        // End:0xB17
        case 4167:
        // End:0xB1F
        case 4182:
        // End:0xB27
        case 4183:
        // End:0xB2F
        case 4184:
        // End:0xB37
        case 4185:
        // End:0xB3F
        case 4186:
        // End:0xB47
        case 4187:
        // End:0xB4F
        case 4188:
        // End:0xB57
        case 4189:
        // End:0xB5F
        case 4190:
        // End:0xB67
        case 4196:
        // End:0xB6F
        case 4197:
        // End:0xB77
        case 4198:
        // End:0xB7F
        case 4199:
        // End:0xB87
        case 4200:
        // End:0xB8F
        case 4201:
        // End:0xB97
        case 4202:
        // End:0xB9F
        case 4203:
        // End:0xBA7
        case 4204:
        // End:0xBAF
        case 4205:
        // End:0xBB7
        case 4206:
        // End:0xBBF
        case 4215:
        // End:0xBC7
        case 4219:
        // End:0xBCF
        case 4236:
        // End:0xBD7
        case 4237:
        // End:0xBDF
        case 4238:
        // End:0xBE7
        case 4243:
        // End:0xBEF
        case 4245:
        // End:0xBF7
        case 4249:
        // End:0xBFF
        case 4258:
        // End:0xC07
        case 4259:
        // End:0xC0F
        case 4315:
        // End:0xC17
        case 4319:
        // End:0xC1F
        case 4320:
        // End:0xC27
        case 4321:
        // End:0xC2F
        case 4361:
        // End:0xC37
        case 4362:
        // End:0xC3F
        case 4363:
        // End:0xC47
        case 4382:
        // End:0xC4F
        case 4515:
        // End:0xC57
        case 4533:
        // End:0xC5F
        case 4534:
        // End:0xC67
        case 4535:
        // End:0xC6F
        case 4536:
        // End:0xC77
        case 4537:
        // End:0xC7F
        case 4538:
        // End:0xC87
        case 4539:
        // End:0xC8F
        case 4540:
        // End:0xC97
        case 4541:
        // End:0xC9F
        case 4547:
        // End:0xCA7
        case 4577:
        // End:0xCAF
        case 4578:
        // End:0xCB7
        case 4579:
        // End:0xCBF
        case 4580:
        // End:0xCC7
        case 4581:
        // End:0xCCF
        case 4582:
        // End:0xCD7
        case 4583:
        // End:0xCDF
        case 4584:
        // End:0xCE7
        case 4586:
        // End:0xCEF
        case 4587:
        // End:0xCF7
        case 4589:
        // End:0xCFF
        case 4590:
        // End:0xD07
        case 4591:
        // End:0xD0F
        case 4592:
        // End:0xD17
        case 4593:
        // End:0xD1F
        case 4594:
        // End:0xD27
        case 4596:
        // End:0xD2F
        case 4597:
        // End:0xD37
        case 4598:
        // End:0xD3F
        case 4599:
        // End:0xD47
        case 4600:
        // End:0xD4F
        case 4602:
        // End:0xD57
        case 4603:
        // End:0xD5F
        case 4604:
        // End:0xD67
        case 4605:
        // End:0xD6F
        case 4606:
        // End:0xD77
        case 4615:
        // End:0xD7F
        case 4620:
        // End:0xD87
        case 4624:
        // End:0xD8F
        case 4625:
        // End:0xD97
        case 4640:
        // End:0xD9F
        case 4643:
        // End:0xDA7
        case 4649:
        // End:0xDAF
        case 4657:
        // End:0xDB7
        case 4658:
        // End:0xDBF
        case 4659:
        // End:0xDC7
        case 4660:
        // End:0xDCF
        case 4661:
        // End:0xDD7
        case 4662:
        // End:0xDDF
        case 4670:
        // End:0xDE7
        case 4683:
        // End:0xDEF
        case 4684:
        // End:0xDF7
        case 4688:
        // End:0xDFF
        case 4689:
        // End:0xE07
        case 4694:
        // End:0xE0F
        case 4695:
        // End:0xE17
        case 4696:
        // End:0xE1F
        case 4705:
        // End:0xE27
        case 4706:
        // End:0xE2F
        case 4708:
        // End:0xE37
        case 4710:
        // End:0xE3F
        case 4169:
        // End:0xE47
        case 4724:
        // End:0xE4F
        case 4725:
        // End:0xE57
        case 4726:
        // End:0xE5F
        case 4727:
        // End:0xE67
        case 4728:
        // End:0xE6F
        case 4172:
        // End:0xE77
        case 4180:
        // End:0xE7F
        case 4744:
        // End:0xE87
        case 4745:
        // End:0xE8F
        case 4746:
        // End:0xE97
        case 4747:
        // End:0xE9F
        case 4748:
        // End:0xEA7
        case 4208:
        // End:0xEAF
        case 4759:
        // End:0xEB7
        case 4760:
        // End:0xEBF
        case 4761:
        // End:0xEC7
        case 4762:
        // End:0xECF
        case 4763:
        // End:0xED7
        case 4496:
        // End:0xEDF
        case 4769:
        // End:0xEE7
        case 4770:
        // End:0xEEF
        case 4771:
        // End:0xEF7
        case 4772:
        // End:0xEFF
        case 4773:
        // End:0xF07
        case 4463:
        // End:0xF0F
        case 4464:
        // End:0xF17
        case 4465:
        // End:0xF1F
        case 4466:
        // End:0xF27
        case 4467:
        // End:0xF2F
        case 4473:
        // End:0xF37
        case 4480:
        // End:0xF3F
        case 4481:
        // End:0xF47
        case 4482:
        // End:0xF4F
        case 4483:
        // End:0xF57
        case 4486:
        // End:0xF5F
        case 4487:
        // End:0xF67
        case 4488:
        // End:0xF6F
        case 4492:
        // End:0xF77
        case 4991:
        // End:0xF7F
        case 4992:
        // End:0xF87
        case 5004:
        // End:0xF8F
        case 5012:
        // End:0xF97
        case 5016:
        // End:0xF9F
        case 5020:
        // End:0xFA7
        case 5022:
        // End:0xFAF
        case 5023:
        // End:0xFB7
        case 5024:
        // End:0xFBF
        case 5037:
        // End:0xFC7
        case 5068:
        // End:0xFCF
        case 5069:
        // End:0xFD7
        case 5070:
        // End:0xFDF
        case 5071:
        // End:0xFE7
        case 5072:
        // End:0xFEF
        case 5081:
        // End:0xFF7
        case 5083:
        // End:0xFFF
        case 5085:
        // End:0x1007
        case 5086:
        // End:0x100F
        case 5092:
        // End:0x1017
        case 5112:
        // End:0x101F
        case 5114:
        // End:0x1027
        case 5116:
        // End:0x102F
        case 5117:
        // End:0x1037
        case 5120:
        // End:0x103F
        case 5134:
        // End:0x1047
        case 5137:
        // End:0x104F
        case 5138:
        // End:0x1057
        case 5140:
        // End:0x105F
        case 5145:
        // End:0x1067
        case 5160:
        // End:0x106F
        case 5166:
        // End:0x1077
        case 5167:
        // End:0x107F
        case 5168:
        // End:0x1087
        case 5169:
        // End:0x108F
        case 5170:
        // End:0x1097
        case 5171:
        // End:0x109F
        case 5172:
        // End:0x10A7
        case 5173:
        // End:0x10AF
        case 5174:
        // End:0x10B7
        case 5175:
        // End:0x10BF
        case 5176:
        // End:0x10C7
        case 5177:
        // End:0x10CF
        case 5183:
        // End:0x10D7
        case 5196:
        // End:0x10DF
        case 5197:
        // End:0x10E7
        case 5198:
        // End:0x10EF
        case 5199:
        // End:0x10F7
        case 5202:
        // End:0x10FF
        case 5203:
        // End:0x1107
        case 5206:
        // End:0x110F
        case 5207:
        // End:0x1117
        case 5219:
        // End:0x111F
        case 5220:
        // End:0x1127
        case 7066:
        // End:0x112F
        case 7067:
        // End:0x1137
        case 7076:
        // End:0x113F
        case 7077:
        // End:0x1147
        case 7080:
        // End:0x114F
        case 5229:
        // End:0x1157
        case 5230:
        // End:0x115F
        case 5231:
        // End:0x1167
        case 5232:
        // End:0x116F
        case 5238:
        // End:0x1177
        case 5240:
        // End:0x117F
        case 5241:
        // End:0x1187
        case 5242:
        // End:0x118F
        case 5243:
        // End:0x1197
        case 5247:
        // End:0x119F
        case 5250:
        // End:0x11A7
        case 5251:
        // End:0x11AF
        case 5252:
        // End:0x11B7
        case 5253:
        // End:0x11BF
        case 5254:
        // End:0x11C7
        case 5255:
        // End:0x11CF
        case 5256:
        // End:0x11D7
        case 5258:
        // End:0x11DF
        case 5259:
        // End:0x11E7
        case 5260:
        // End:0x11EF
        case 5261:
        // End:0x11F7
        case 5264:
        // End:0x11FF
        case 5266:
        // End:0x1207
        case 5268:
        // End:0x120F
        case 5269:
        // End:0x1217
        case 5270:
        // End:0x121F
        case 5271:
        // End:0x1227
        case 5301:
        // End:0x122F
        case 5302:
        // End:0x1237
        case 5303:
        // End:0x123F
        case 5304:
        // End:0x1247
        case 5305:
        // End:0x124F
        case 5306:
        // End:0x1257
        case 5307:
        // End:0x125F
        case 5308:
        // End:0x1267
        case 5309:
        // End:0x126F
        case 5333:
        // End:0x1277
        case 5362:
        // End:0x127F
        case 5363:
        // End:0x1287
        case 5364:
        // End:0x128F
        case 5365:
        // End:0x1297
        case 5366:
        // End:0x129F
        case 5367:
        // End:0x12A7
        case 5368:
        // End:0x12AF
        case 5369:
        // End:0x12B7
        case 5370:
        // End:0x12BF
        case 5394:
        // End:0x12C7
        case 5399:
        // End:0x12CF
        case 5401:
        // End:0x12D7
        case 5422:
        // End:0x12DF
        case 5423:
        // End:0x12E7
        case 5424:
        // End:0x12EF
        case 5431:
        // End:0x12F7
        case 5434:
        // End:0x12FF
        case 5435:
        // End:0x1307
        case 5443:
        // End:0x130F
        case 5444:
        // End:0x1317
        case 5447:
        // End:0x131F
        case 5456:
        // End:0x1327
        case 5459:
        // End:0x132F
        case 5460:
        // End:0x1337
        case 5481:
        // End:0x133F
        case 5482:
        // End:0x1347
        case 5495:
        // End:0x134F
        case 5496:
        // End:0x1357
        case 5497:
        // End:0x135F
        case 5500:
        // End:0x1367
        case 5501:
        // End:0x136F
        case 5502:
        // End:0x1377
        case 5505:
        // End:0x137F
        case 5506:
        // End:0x1387
        case 5507:
        // End:0x138F
        case 5508:
        // End:0x1397
        case 5509:
        // End:0x139F
        case 5510:
        // End:0x13A7
        case 5511:
        // End:0x13AF
        case 5512:
        // End:0x13B7
        case 5523:
        // End:0x13BF
        case 5529:
        // End:0x13C7
        case 5530:
        // End:0x13CF
        case 5551:
        // End:0x13D7
        case 5565:
        // End:0x13DF
        case 5566:
        // End:0x13E7
        case 5567:
        // End:0x13EF
        case 5568:
        // End:0x13F7
        case 5569:
        // End:0x13FF
        case 5581:
        // End:0x1407
        case 5583:
        // End:0x140F
        case 5584:
        // End:0x1417
        case 5585:
        // End:0x141F
        case 5592:
        // End:0x1427
        case 5594:
        // End:0x142F
        case 5595:
        // End:0x1437
        case 5596:
        // End:0x143F
        case 5600:
        // End:0x1447
        case 5602:
        // End:0x144F
        case 5623:
        // End:0x1457
        case 5624:
        // End:0x145F
        case 5625:
        // End:0x1467
        case 5660:
        // End:0x146F
        case 5661:
        // End:0x1477
        case 5665:
        // End:0x147F
        case 5666:
        // End:0x1487
        case 5667:
        // End:0x148F
        case 5668:
        // End:0x1497
        case 5669:
        // End:0x149F
        case 5670:
        // End:0x14A7
        case 5671:
        // End:0x14AF
        case 5672:
        // End:0x14B7
        case 5673:
        // End:0x14BF
        case 5679:
        // End:0x14C7
        case 5683:
        // End:0x14CF
        case 5687:
        // End:0x14D7
        case 5688:
        // End:0x14DF
        case 5693:
        // End:0x14E7
        case 5696:
        // End:0x14EF
        case 5697:
        // End:0x14F7
        case 5703:
        // End:0x14FF
        case 5706:
        // End:0x1507
        case 5707:
        // End:0x150F
        case 5715:
        // End:0x1517
        case 5716:
        // End:0x151F
        case 5733:
        // End:0x1527
        case 5735:
        // End:0x152F
        case 5747:
        // End:0x1537
        case 5764:
        // End:0x153F
        case 5778:
        // End:0x1547
        case 5794:
        // End:0x154F
        case 5795:
        // End:0x1557
        case 5796:
        // End:0x155F
        case 5797:
        // End:0x1567
        case 5798:
        // End:0x156F
        case 5799:
        // End:0x1577
        case 5800:
        // End:0x157F
        case 5801:
        // End:0x1587
        case 5802:
        // End:0x158F
        case 5803:
        // End:0x1597
        case 5804:
        // End:0x159F
        case 5806:
        // End:0x15A7
        case 5807:
        // End:0x15AF
        case 5808:
        // End:0x15B7
        case 5809:
        // End:0x15BF
        case 5810:
        // End:0x15C7
        case 5811:
        // End:0x15CF
        case 5812:
        // End:0x15D7
        case 5813:
        // End:0x15DF
        case 5814:
        // End:0x15E7
        case 5831:
        // End:0x15EF
        case 5832:
        // End:0x15F7
        case 5843:
        // End:0x15FF
        case 5846:
        // End:0x1607
        case 5849:
        // End:0x160F
        case 5851:
        // End:0x1617
        case 5854:
        // End:0x161F
        case 5855:
        // End:0x1627
        case 5860:
        // End:0x162F
        case 5861:
        // End:0x1637
        case 5866:
        // End:0x163F
        case 5867:
        // End:0x1647
        case 5868:
        // End:0x164F
        case 5869:
        // End:0x1657
        case 5870:
        // End:0x165F
        case 5871:
        // End:0x1667
        case 5872:
        // End:0x166F
        case 5873:
        // End:0x1677
        case 5874:
        // End:0x167F
        case 5875:
        // End:0x1687
        case 5876:
        // End:0x168F
        case 5877:
        // End:0x1697
        case 5878:
        // End:0x169F
        case 5879:
        // End:0x16A7
        case 5880:
        // End:0x16AF
        case 5881:
        // End:0x16B7
        case 5882:
        // End:0x16BF
        case 5883:
        // End:0x16C7
        case 5884:
        // End:0x16CF
        case 5885:
        // End:0x16D7
        case 5886:
        // End:0x16DF
        case 5887:
        // End:0x16E7
        case 5888:
        // End:0x16EF
        case 5889:
        // End:0x16F7
        case 5890:
        // End:0x16FF
        case 5891:
        // End:0x1707
        case 5892:
        // End:0x170F
        case 5893:
        // End:0x1717
        case 5894:
        // End:0x171F
        case 5895:
        // End:0x1727
        case 5896:
        // End:0x172F
        case 5897:
        // End:0x1737
        case 5898:
        // End:0x173F
        case 5899:
        // End:0x1747
        case 5900:
        // End:0x174F
        case 5901:
        // End:0x1757
        case 5903:
        // End:0x175F
        case 5904:
        // End:0x1767
        case 5905:
        // End:0x176F
        case 5907:
        // End:0x1777
        case 5908:
        // End:0x177F
        case 5912:
        // End:0x1787
        case 5914:
        // End:0x178F
        case 5919:
        // End:0x1797
        case 5921:
        // End:0x179F
        case 5922:
        // End:0x17A7
        case 5937:
        // End:0x17AF
        case 5941:
        // End:0x17B7
        case 5942:
        // End:0x17BF
        case 5943:
        // End:0x17C7
        case 5944:
        // End:0x17CF
        case 5945:
        // End:0x17D7
        case 5960:
        // End:0x17DF
        case 5961:
        // End:0x17E7
        case 5967:
        // End:0x17EF
        case 5969:
        // End:0x17F7
        case 5981:
        // End:0x17FF
        case 5984:
        // End:0x1807
        case 5992:
        // End:0x180F
        case 5993:
        // End:0x1817
        case 5994:
        // End:0x181F
        case 6024:
        // End:0x1827
        case 6033:
        // End:0x182F
        case 6090:
        // End:0x1837
        case 6091:
        // End:0x183F
        case 6092:
        // End:0x1847
        case 6095:
        // End:0x184F
        case 6125:
        // End:0x1857
        case 6126:
        // End:0x185F
        case 6129:
        // End:0x1867
        case 6130:
        // End:0x186F
        case 6131:
        // End:0x1877
        case 6132:
        // End:0x187F
        case 6133:
        // End:0x1887
        case 6134:
        // End:0x188F
        case 6135:
        // End:0x1897
        case 6140:
        // End:0x189F
        case 6141:
        // End:0x18A7
        case 6142:
        // End:0x18AF
        case 6146:
        // End:0x18B7
        case 6148:
        // End:0x18BF
        case 6149:
        // End:0x18C7
        case 6150:
        // End:0x18CF
        case 6151:
        // End:0x18D7
        case 6152:
        // End:0x18DF
        case 6153:
        // End:0x18E7
        case 6154:
        // End:0x18EF
        case 6155:
        // End:0x18F7
        case 6166:
        // End:0x18FF
        case 6167:
        // End:0x1907
        case 6168:
        // End:0x190F
        case 6169:
        // End:0x1917
        case 6187:
        // End:0x191F
        case 6189:
        // End:0x1927
        case 6190:
        // End:0x192F
        case 6205:
        // End:0x1937
        case 6206:
        // End:0x193F
        case 6237:
        // End:0x1947
        case 6238:
        // End:0x194F
        case 6240:
        // End:0x1957
        case 6250:
        // End:0x195F
        case 6263:
        // End:0x1967
        case 6266:
        // End:0x196F
        case 6269:
        // End:0x1977
        case 6273:
        // End:0x197F
        case 6274:
        // End:0x1987
        case 6275:
        // End:0x198F
        case 6276:
        // End:0x1997
        case 6280:
        // End:0x199F
        case 6281:
        // End:0x19A7
        case 6283:
        // End:0x19AF
        case 6299:
        // End:0x19B7
        case 6300:
        // End:0x19BF
        case 6304:
        // End:0x19C7
        case 6306:
        // End:0x19CF
        case 6307:
        // End:0x19D7
        case 6308:
        // End:0x19DF
        case 6309:
        // End:0x19E7
        case 6312:
        // End:0x19EF
        case 6314:
        // End:0x19F7
        case 6320:
        // End:0x19FF
        case 6326:
        // End:0x1A07
        case 6328:
        // End:0x1A0F
        case 6331:
        // End:0x1A17
        case 6332:
        // End:0x1A1F
        case 6333:
        // End:0x1A27
        case 6334:
        // End:0x1A2F
        case 6335:
        // End:0x1A37
        case 6336:
        // End:0x1A3F
        case 6339:
        // End:0x1A47
        case 6340:
        // End:0x1A4F
        case 6342:
        // End:0x1A57
        case 6370:
        // End:0x1A5F
        case 6373:
        // End:0x1A67
        case 6374:
        // End:0x1A6F
        case 6375:
        // End:0x1A77
        case 6378:
        // End:0x1A7F
        case 6379:
        // End:0x1A87
        case 6380:
        // End:0x1A8F
        case 6381:
        // End:0x1A97
        case 6382:
        // End:0x1A9F
        case 6383:
        // End:0x1AA7
        case 6384:
        // End:0x1AAF
        case 6385:
        // End:0x1AB7
        case 6386:
        // End:0x1ABF
        case 6389:
        // End:0x1AC7
        case 6390:
        // End:0x1ACF
        case 6391:
        // End:0x1AD7
        case 6392:
        // End:0x1ADF
        case 6395:
        // End:0x1AE7
        case 6396:
        // End:0x1AEF
        case 6397:
        // End:0x1AF7
        case 6398:
        // End:0x1AFF
        case 6400:
        // End:0x1B07
        case 6402:
        // End:0x1B0F
        case 6403:
        // End:0x1B17
        case 6404:
        // End:0x1B1F
        case 6406:
        // End:0x1B27
        case 6407:
        // End:0x1B2F
        case 6408:
        // End:0x1B37
        case 6410:
        // End:0x1B3F
        case 6414:
        // End:0x1B47
        case 6416:
        // End:0x1B4F
        case 6417:
        // End:0x1B57
        case 6418:
        // End:0x1B5F
        case 6423:
        // End:0x1B67
        case 6428:
        // End:0x1B6F
        case 6435:
        // End:0x1B77
        case 6436:
        // End:0x1B7F
        case 6437:
        // End:0x1B87
        case 6438:
        // End:0x1B8F
        case 6439:
        // End:0x1B97
        case 6440:
        // End:0x1B9F
        case 6441:
        // End:0x1BA7
        case 6618:
        // End:0x1BAF
        case 6619:
        // End:0x1BB7
        case 6622:
        // End:0x1BBF
        case 6624:
        // End:0x1BC7
        case 6650:
        // End:0x1BCF
        case 6651:
        // End:0x1BD7
        case 6662:
        // End:0x1BDF
        case 6677:
        // End:0x1BE7
        case 6688:
        // End:0x1BEF
        case 6690:
        // End:0x1BF7
        case 6697:
        // End:0x1BFF
        case 6698:
        // End:0x1C07
        case 6705:
        // End:0x1C0F
        case 6733:
        // End:0x1C17
        case 6734:
        // End:0x1C1F
        case 6735:
        // End:0x1C27
        case 6738:
        // End:0x1C2F
        case 6743:
        // End:0x1C37
        case 6744:
        // End:0x1C3F
        case 6746:
        // End:0x1C47
        case 6748:
        // End:0x1C4F
        case 6750:
        // End:0x1C57
        case 6751:
        // End:0x1C5F
        case 6754:
        // End:0x1C67
        case 6757:
        // End:0x1C6F
        case 6760:
        // End:0x1C77
        case 6761:
        // End:0x1C7F
        case 6763:
        // End:0x1C87
        case 6768:
        // End:0x1C8F
        case 6769:
        // End:0x1C97
        case 6772:
        // End:0x1C9F
        case 6774:
        // End:0x1CA7
        case 6775:
        // End:0x1CAF
        case 6776:
        // End:0x1CB7
        case 6777:
        // End:0x1CBF
        case 6779:
        // End:0x1CC7
        case 6815:
        // End:0x1CCF
        case 6816:
        // End:0x1CD7
        case 6819:
        // End:0x1CDF
        case 6821:
        // End:0x1CE7
        case 6822:
        // End:0x1CEF
        case 6825:
        // End:0x1CF7
        case 6827:
        // End:0x1CFF
        case 6828:
        // End:0x1D07
        case 6830:
        // End:0x1D0F
        case 6836:
        // End:0x1D17
        case 6840:
        // End:0x1D1F
        case 6853:
        // End:0x1D27
        case 6854:
        // End:0x1D2F
        case 6862:
        // End:0x1D37
        case 6863:
        // End:0x1D3F
        case 6865:
        // End:0x1D47
        case 6873:
        // End:0x1D4F
        case 6875:
        // End:0x1D57
        case 6878:
        // End:0x1D5F
        case 6880:
        // End:0x1D67
        case 6882:
        // End:0x1D6F
        case 6890:
        // End:0x1D77
        case 6897:
        // End:0x1D7F
        case 6912:
        // End:0x1D87
        case 23069:
        // End:0x1D8F
        case 23070:
        // End:0x1D97
        case 23071:
        // End:0x1D9F
        case 23124:
        // End:0x1DA7
        case 23169:
        // End:0x1DAF
        case 23170:
        // End:0x1DB7
        case 6921:
        // End:0x1DBF
        case 23298:
        // End:0x1DC7
        case 23299:
        // End:0x1DCF
        case 23300:
        // End:0x1DD7
        case 23319:
        // End:0x1DDF
        case 23320:
        // End:0x1DE7
        case 23321:
        // End:0x1DEF
        case 23322:
        // End:0x1E02
        case 23323:
            chelakua = true;
            // End:0x1E05
            break;
        // End:0xFFFF
        default:
            break;
    }
    return chelakua;

}







function xxkeybindshortcut()
{
    local bool isanswer;

    isanswer = GetOptionBool("Game", "EnterChatting");
    // End:0x24A
    if(isanswer)
    {
        Class'UIAPI_TEXTURECTRL'.static.SetTexture("ShortcutWnd.ShortcutWndHorizontal.keybinds", "L2UI_CH3.KeyBind.keybindF1F2");
        Class'UIAPI_TEXTURECTRL'.static.SetTexture("ShortcutWnd.ShortcutWndVertical.keybinds_v", "L2UI_CH3.KeyBind.keybindF1F2_v");
        Class'UIAPI_TEXTURECTRL'.static.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.keybinds", "L2UI_CH3.KeyBind.keybind12");
        Class'UIAPI_TEXTURECTRL'.static.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.keybinds", "L2UI_CH3.KeyBind.keybindQW");
        Class'UIAPI_TEXTURECTRL'.static.SetTexture("ShortcutWnd.ShortcutWndVertical_1.keybinds_v", "L2UI_CH3.KeyBind.keybind12_v");
        Class'UIAPI_TEXTURECTRL'.static.SetTexture("ShortcutWnd.ShortcutWndVertical_2.keybinds_v", "L2UI_CH3.KeyBind.keybindQW_v");        
    }
    else
    {
        Class'UIAPI_TEXTURECTRL'.static.SetTexture("ShortcutWnd.ShortcutWndHorizontal.keybinds", "L2UI_CH3.KeyBind.keybindF1F2");
        Class'UIAPI_TEXTURECTRL'.static.SetTexture("ShortcutWnd.ShortcutWndVertical.keybinds_v", "L2UI_CH3.KeyBind.keybindF1F2_v");
        Class'UIAPI_TEXTURECTRL'.static.SetTexture("ShortcutWnd.ShortcutWndHorizontal_1.keybinds", "L2UI_CH3.Null");
        Class'UIAPI_TEXTURECTRL'.static.SetTexture("ShortcutWnd.ShortcutWndHorizontal_2.keybinds", "L2UI_CH3.Null");
        Class'UIAPI_TEXTURECTRL'.static.SetTexture("ShortcutWnd.ShortcutWndVertical_1.keybinds_v", "L2UI_CH3.Null");
        Class'UIAPI_TEXTURECTRL'.static.SetTexture("ShortcutWnd.ShortcutWndVertical_2.keybinds_v", "L2UI_CH3.Null");
    }
    return;
}



function ShowWindow (string a_ControlID)
{
  Class'UIAPI_WINDOW'.static.ShowWindow(a_ControlID);
}

function ShowWindowWithFocus (string a_ControlID)
{
  Class'UIAPI_WINDOW'.static.ShowWindow(a_ControlID);
  Class'UIAPI_WINDOW'.static.SetFocus(a_ControlID);
}


function float calculeflo(int i, int x)
{
    return float(i) / float(x);
   
}

function bool calculebol(int i, int o)
{
    return i == o;

}
function bool calculemixmax(int i, int o)
{
    return i > o;

}
function calculemenosmenosa(out int i)
{
    i--;
    return;
}

function bool calculesame(string i, string o)
{
    return i == o;

}

function bool calculemulti(bool i, bool o)
{
    return i || o;

}

function int calculeresta(int i, int o)
{
    return i - o;
    
}


function int calculesuma(int i, int o)
{
    return i + o;
  
}


function bool calculemenor(int i, int o)
{
    return i < o;

}
function caculemasmas(out int i)
{
    i++;
    return;
}


function bool calculeand2(bool i, bool o)
{
    return i && o;
  
}

function bool calculedesigual(bool i)
{
    return !i;

}


function string calculeburgatugar(string i, string o)
{
    return i $ o;
 
}

function bool calculemayorigual(int i, int o)
{
    return i >= o;

}

function bool calculemenorigual(int i, int o)
{
    return i <= o;

}


function calculetamax3ia(out int i)
{
    ++i;
    return;
}












function showfocutios(string param)
{
    // End:0x1C
    if(IsShowWindow(param))
    {
        HideWindow(param);        
    }
    else
    {
        ShowWindow(param);
        Class'UIAPI_WINDOW'.static.SetFocus(param);
    }
    return;
}



function function11(string string_1, int int_1, int int_2)
{
    local ButtonHandle button_1;
    local CustomTooltip custom_1;
    local int int_3;

    // End:0x16
    if(int_2 == 0)
    {
        int_3 = 1;
    }
    button_1 = ButtonHandle(GetHandle(string_1));
    custom_1.DrawList.Length = 2;
    custom_1.DrawList[0].eType = DIT_TEXT;
    custom_1.DrawList[0].nOffSetY = 6;
    custom_1.DrawList[int_3].t_color.R = 106;
    custom_1.DrawList[int_3].t_color.G = 106;
    custom_1.DrawList[int_3].t_color.B = 106;
    custom_1.DrawList[int_3].t_color.A = byte(255);
    custom_1.DrawList[0].bLineBreak = true;
    custom_1.DrawList[0].t_bDrawOneLine = true;
    custom_1.DrawList[1].eType = DIT_TEXT;
    custom_1.DrawList[1].nOffSetY = 6;
    custom_1.DrawList[int_2].t_color.R = 218;
    custom_1.DrawList[int_2].t_color.G = 190;
    custom_1.DrawList[int_2].t_color.B = 1;
    custom_1.DrawList[int_2].t_color.A = byte(255);
    custom_1.DrawList[1].bLineBreak = true;
    custom_1.DrawList[1].t_bDrawOneLine = true;
    button_1.SetTooltipCustomType(custom_1);
    return;
}

function function5(string strID, out ItemInfo Info)
{
    local int tmpInt;

    ParseInt(strID, "classID", Info.ClassID);
    ParseInt(strID, "level", Info.Level);
    ParseString(strID, "name", Info.Name);
    ParseString(strID, "additionalName", Info.AdditionalName);
    ParseString(strID, "iconName", Info.IconName);
    ParseString(strID, "description", Info.Description);
    ParseInt(strID, "itemType", Info.ItemType);
    ParseInt(strID, "serverID", Info.ServerID);
    ParseInt(strID, "itemNum", Info.ItemNum);
    ParseInt(strID, "slotBitType", Info.SlotBitType);
    ParseInt(strID, "enchanted", Info.Enchanted);
    ParseInt(strID, "blessed", Info.Blessed);
    ParseInt(strID, "damaged", Info.Damaged);
    // End:0x1C5
    if(ParseInt(strID, "equipped", tmpInt))
    {
        Info.bEquipped = bool(tmpInt);
    }
    ParseInt(strID, "price", Info.Price);
    ParseInt(strID, "reserved", Info.Reserved);
    ParseInt(strID, "defaultPrice", Info.DefaultPrice);
    ParseInt(strID, "refineryOp1", Info.RefineryOp1);
    ParseInt(strID, "refineryOp2", Info.RefineryOp2);
    ParseInt(strID, "currentDurability", Info.CurrentDurability);
    ParseInt(strID, "weight", Info.Weight);
    ParseInt(strID, "materialType", Info.MaterialType);
    ParseInt(strID, "weaponType", Info.WeaponType);
    ParseInt(strID, "physicalDamage", Info.PhysicalDamage);
    ParseInt(strID, "magicalDamage", Info.MagicalDamage);
    ParseInt(strID, "shieldDefense", Info.ShieldDefense);
    ParseInt(strID, "shieldDefenseRate", Info.ShieldDefenseRate);
    ParseInt(strID, "durability", Info.Durability);
    ParseInt(strID, "crystalType", Info.CrystalType);
    ParseInt(strID, "randomDamage", Info.RandomDamage);
    ParseInt(strID, "critical", Info.Critical);
    ParseInt(strID, "hitModify", Info.HitModify);
    ParseInt(strID, "attackSpeed", Info.AttackSpeed);
    ParseInt(strID, "mpConsume", Info.MpConsume);
    ParseInt(strID, "avoidModify", Info.AvoidModify);
    ParseInt(strID, "soulshotCount", Info.SoulshotCount);
    ParseInt(strID, "spiritshotCount", Info.SpiritshotCount);
    ParseInt(strID, "armorType", Info.ArmorType);
    ParseInt(strID, "physicalDefense", Info.PhysicalDefense);
    ParseInt(strID, "magicalDefense", Info.MagicalDefense);
    ParseInt(strID, "mpBonus", Info.MpBonus);
    ParseInt(strID, "consumeType", Info.ConsumeType);
    ParseInt(strID, "ItemSubType", Info.ItemSubType);
    ParseString(strID, "iconNameEx1", Info.IconNameEx1);
    ParseString(strID, "iconNameEx2", Info.IconNameEx2);
    ParseString(strID, "iconNameEx3", Info.IconNameEx3);
    ParseString(strID, "iconNameEx4", Info.IconNameEx4);
    // End:0x65A
    if(ParseInt(strID, "arrow", tmpInt))
    {
        Info.bArrow = bool(tmpInt);
    }
    // End:0x688
    if(ParseInt(strID, "recipe", tmpInt))
    {
        Info.bRecipe = bool(tmpInt);
    }
    // End:0x6FB
    if((Info.Enchanted >  0) &&  (Info.Enchanted <= 25))
    {
        Info.ForeTexture = ("Interface.Inventory_ENCHANTNUMBER_SMALL_" $  string(Info.Enchanted));
    }
}



function string GetDetailedClassIconName (int ClassID, int iconType)
{
  local string iconSize;

  iconSize = "";
  if ( (iconType == 1) )
  {
    iconSize = "_Big";
  }
  if ( (iconType == 2) )
  {
    iconSize = "_Small";
  }
  switch (ClassID)
  {
    case 0:
    case 10:
    return ("L2UI_CH3.ClassMark.PlayerStatusWnd_ClassMark_human" $ iconSize);
    break;
    case 18:
    case 25:
    return ("L2UI_CH3.ClassMark.PlayerStatusWnd_ClassMark_elf" $ iconSize);
    break;
    case 31:
    case 38:
    return ("L2UI_CH3.ClassMark.PlayerStatusWnd_ClassMark_darkelf" $ iconSize);
    break;
    case 44:
    case 49:
    return ("L2UI_CH3.ClassMark.PlayerStatusWnd_ClassMark_orc" $ iconSize);
    break;
    case 53:
    return ("L2UI_CH3.ClassMark.PlayerStatusWnd_ClassMark_dwarf" $ iconSize);
    break;
    default:
    return (("L2UI_CH3.ClassMark.PlayerStatusWnd_ClassMark_" $ string(ClassID)) $ iconSize);
    break;
  }
}



function SetItemTextLink(ItemInfo a_ID)
{
    local ChatWnd scriptChat;
    local string Token;

    if(a_ID.ServerID <= 0 || a_ID.ClassID <= 0)
    {
        class'interface.OMGzExtWnd'.static.DebugLog(
            "[ChatItemLink] Item invalido: objectId="
            $ string(a_ID.ServerID)
            $ " itemId=" $ string(a_ID.ClassID)
        );
        return;
    }

    scriptChat = ChatWnd(GetScript("ChatWnd"));

    if(scriptChat == None)
    {
        class'interface.OMGzExtWnd'.static.DebugLog(
            "[ChatItemLink] ChatWnd nao encontrado."
        );
        return;
    }

    Token = "<" $ string(a_ID.ServerID)
        $ "|" $ string(a_ID.ClassID) $ ">";

    class'interface.OMGzExtWnd'.static.DebugLog(
        "[ChatItemLink] Item selecionado: objectId="
        $ string(a_ID.ServerID)
        $ " itemId=" $ string(a_ID.ClassID)
    );

    scriptChat.HandleTextLinkLButtonClick(Token);
}


function int SkillTypeP(int SkillID)
{
    switch(SkillID)
    {
        // End:0x0F
        case 846:
        // End:0x17
        case 3001:
        // End:0x1F
        case 3002:
        // End:0x27
        case 3003:
        // End:0x2F
        case 3004:
        // End:0x37
        case 3006:
        // End:0x3F
        case 3007:
        // End:0x47
        case 3008:
        // End:0x4F
        case 3009:
        // End:0x57
        case 3010:
        // End:0x5F
        case 3011:
        // End:0x67
        case 3012:
        // End:0x6F
        case 3013:
        // End:0x77
        case 3014:
        // End:0x7F
        case 3018:
        // End:0x87
        case 3019:
        // End:0x8F
        case 3023:
        // End:0x97
        case 3043:
        // End:0x9F
        case 3026:
        // End:0xA7
        case 3027:
        // End:0xAF
        case 3028:
        // End:0xB7
        case 3029:
        // End:0xBF
        case 3030:
        // End:0xC7
        case 3031:
        // End:0xCF
        case 3032:
        // End:0xD7
        case 3033:
        // End:0xDF
        case 3034:
        // End:0xE7
        case 3035:
        // End:0xEF
        case 3036:
        // End:0xF7
        case 3037:
        // End:0xFF
        case 3038:
        // End:0x107
        case 3042:
        // End:0x10F
        case 3044:
        // End:0x117
        case 3045:
        // End:0x11F
        case 3046:
        // End:0x127
        case 3047:
        // End:0x12F
        case 3048:
        // End:0x137
        case 3050:
        // End:0x13F
        case 3051:
        // End:0x147
        case 3056:
        // End:0x14F
        case 3057:
        // End:0x157
        case 3058:
        // End:0x15F
        case 3063:
        // End:0x167
        case 3064:
        // End:0x16F
        case 3065:
        // End:0x177
        case 3066:
        // End:0x17F
        case 3067:
        // End:0x187
        case 3068:
        // End:0x18F
        case 3069:
        // End:0x197
        case 3071:
        // End:0x19F
        case 3072:
        // End:0x1A7
        case 3073:
        // End:0x1AF
        case 3076:
        // End:0x1B7
        case 3077:
        // End:0x1BF
        case 3500:
        // End:0x1C7
        case 3501:
        // End:0x1CF
        case 3502:
        // End:0x1D7
        case 3503:
        // End:0x1DF
        case 3504:
        // End:0x1E7
        case 3505:
        // End:0x1EF
        case 3506:
        // End:0x1F7
        case 3507:
        // End:0x1FF
        case 3508:
        // End:0x207
        case 3509:
        // End:0x20F
        case 3510:
        // End:0x217
        case 3511:
        // End:0x21F
        case 3512:
        // End:0x227
        case 3513:
        // End:0x22F
        case 3514:
        // End:0x237
        case 3515:
        // End:0x23F
        case 3516:
        // End:0x247
        case 3517:
        // End:0x24F
        case 3518:
        // End:0x257
        case 3519:
        // End:0x25F
        case 3520:
        // End:0x267
        case 3521:
        // End:0x26F
        case 3522:
        // End:0x277
        case 3523:
        // End:0x27F
        case 3524:
        // End:0x287
        case 3525:
        // End:0x28F
        case 3526:
        // End:0x297
        case 3527:
        // End:0x29F
        case 3528:
        // End:0x2A7
        case 3529:
        // End:0x2AF
        case 3530:
        // End:0x2B7
        case 3531:
        // End:0x2BF
        case 3532:
        // End:0x2C7
        case 3533:
        // End:0x2CF
        case 3534:
        // End:0x2D7
        case 3535:
        // End:0x2DF
        case 3536:
        // End:0x2E7
        case 3537:
        // End:0x2EF
        case 3538:
        // End:0x2F7
        case 3539:
        // End:0x2FF
        case 3540:
        // End:0x307
        case 3541:
        // End:0x30F
        case 3542:
        // End:0x317
        case 3543:
        // End:0x31F
        case 3544:
        // End:0x327
        case 3545:
        // End:0x32F
        case 3546:
        // End:0x337
        case 3547:
        // End:0x33F
        case 3548:
        // End:0x347
        case 3549:
        // End:0x34F
        case 3550:
        // End:0x357
        case 3551:
        // End:0x35F
        case 3552:
        // End:0x367
        case 3553:
        // End:0x36F
        case 3554:
        // End:0x377
        case 3555:
        // End:0x37F
        case 3556:
        // End:0x387
        case 3557:
        // End:0x38F
        case 3558:
        // End:0x397
        case 3559:
        // End:0x39F
        case 3560:
        // End:0x3A7
        case 3561:
        // End:0x3AF
        case 3562:
        // End:0x3B7
        case 3563:
        // End:0x3BF
        case 3564:
        // End:0x3C7
        case 3565:
        // End:0x3CF
        case 3566:
        // End:0x3D7
        case 3567:
        // End:0x3DF
        case 3568:
        // End:0x3E7
        case 3569:
        // End:0x3EF
        case 3570:
        // End:0x3F7
        case 3572:
        // End:0x3FF
        case 3573:
        // End:0x407
        case 3575:
        // End:0x40F
        case 3576:
        // End:0x417
        case 3578:
        // End:0x41F
        case 3580:
        // End:0x427
        case 3582:
        // End:0x42F
        case 3583:
        // End:0x437
        case 3585:
        // End:0x43F
        case 3587:
        // End:0x447
        case 3589:
        // End:0x44F
        case 3591:
        // End:0x457
        case 3593:
        // End:0x45F
        case 3595:
        // End:0x467
        case 3597:
        // End:0x46F
        case 3599:
        // End:0x477
        case 3600:
        // End:0x47F
        case 3601:
        // End:0x487
        case 3602:
        // End:0x48F
        case 3603:
        // End:0x497
        case 3604:
        // End:0x49F
        case 3605:
        // End:0x4A7
        case 3606:
        // End:0x4AF
        case 3607:
        // End:0x4B7
        case 3608:
        // End:0x4BF
        case 3609:
        // End:0x4C7
        case 3610:
        // End:0x4CF
        case 3611:
        // End:0x4D7
        case 3612:
        // End:0x4DF
        case 3613:
        // End:0x4E7
        case 3614:
        // End:0x4EF
        case 3615:
        // End:0x4F7
        case 3616:
        // End:0x4FF
        case 3617:
        // End:0x507
        case 3618:
        // End:0x50F
        case 3619:
        // End:0x517
        case 3620:
        // End:0x51F
        case 3621:
        // End:0x527
        case 3622:
        // End:0x52F
        case 3623:
        // End:0x537
        case 3624:
        // End:0x53F
        case 3625:
        // End:0x547
        case 3629:
        // End:0x54F
        case 3207:
        // End:0x557
        case 3208:
        // End:0x55F
        case 3209:
        // End:0x567
        case 3210:
        // End:0x56F
        case 3211:
        // End:0x577
        case 3212:
        // End:0x57F
        case 3213:
        // End:0x587
        case 3214:
        // End:0x58F
        case 3215:
        // End:0x597
        case 3216:
        // End:0x59F
        case 3217:
        // End:0x5A7
        case 3218:
        // End:0x5AF
        case 3219:
        // End:0x5B7
        case 3220:
        // End:0x5BF
        case 3221:
        // End:0x5C7
        case 3222:
        // End:0x5CF
        case 3223:
        // End:0x5D7
        case 3224:
        // End:0x5DF
        case 3225:
        // End:0x5E7
        case 3226:
        // End:0x5EF
        case 3227:
        // End:0x5F7
        case 3228:
        // End:0x5FF
        case 3229:
        // End:0x607
        case 3230:
        // End:0x60F
        case 3231:
        // End:0x617
        case 3232:
        // End:0x61F
        case 3233:
        // End:0x627
        case 3234:
        // End:0x62F
        case 3235:
        // End:0x637
        case 3236:
        // End:0x63F
        case 3237:
        // End:0x647
        case 3238:
        // End:0x64F
        case 3239:
        // End:0x657
        case 3240:
        // End:0x65F
        case 3241:
        // End:0x667
        case 3243:
        // End:0x66F
        case 3244:
        // End:0x677
        case 3245:
        // End:0x67F
        case 3246:
        // End:0x687
        case 3247:
        // End:0x68F
        case 3248:
        // End:0x697
        case 3249:
        // End:0x69F
        case 3250:
        // End:0x6A7
        case 3251:
        // End:0x6AF
        case 3252:
        // End:0x6B7
        case 3253:
        // End:0x6BF
        case 3254:
        // End:0x6C7
        case 3255:
        // End:0x6CF
        case 3256:
        // End:0x6D7
        case 3257:
        // End:0x6DF
        case 3258:
        // End:0x6E7
        case 3259:
        // End:0x6EF
        case 3293:
        // End:0x6F7
        case 3294:
        // End:0x6FF
        case 3295:
        // End:0x707
        case 3296:
        // End:0x70F
        case 3297:
        // End:0x717
        case 3298:
        // End:0x71F
        case 3299:
        // End:0x727
        case 3300:
        // End:0x72F
        case 3301:
        // End:0x737
        case 3302:
        // End:0x73F
        case 3303:
        // End:0x747
        case 3304:
        // End:0x74F
        case 3305:
        // End:0x757
        case 3306:
        // End:0x75F
        case 3307:
        // End:0x767
        case 3308:
        // End:0x76F
        case 3309:
        // End:0x777
        case 3310:
        // End:0x77F
        case 3311:
        // End:0x787
        case 3312:
        // End:0x78F
        case 3313:
        // End:0x797
        case 3314:
        // End:0x79F
        case 3315:
        // End:0x7A7
        case 3316:
        // End:0x7AF
        case 3317:
        // End:0x7B7
        case 3319:
        // End:0x7BF
        case 3320:
        // End:0x7C7
        case 3322:
        // End:0x7CF
        case 3323:
        // End:0x7D7
        case 3324:
        // End:0x7DF
        case 3325:
        // End:0x7E7
        case 3326:
        // End:0x7EF
        case 3327:
        // End:0x7F7
        case 3338:
        // End:0x7FF
        case 3339:
        // End:0x807
        case 3340:
        // End:0x80F
        case 3341:
        // End:0x817
        case 3342:
        // End:0x81F
        case 3343:
        // End:0x827
        case 3344:
        // End:0x82F
        case 3345:
        // End:0x837
        case 3346:
        // End:0x83F
        case 3347:
        // End:0x847
        case 3348:
        // End:0x84F
        case 3349:
        // End:0x857
        case 3350:
        // End:0x85F
        case 3351:
        // End:0x867
        case 3352:
        // End:0x86F
        case 3353:
        // End:0x877
        case 3354:
        // End:0x87F
        case 3355:
        // End:0x887
        case 3356:
        // End:0x88F
        case 3357:
        // End:0x897
        case 3358:
        // End:0x89F
        case 3360:
        // End:0x8A7
        case 3362:
        // End:0x8AF
        case 3363:
        // End:0x8B7
        case 3364:
        // End:0x8BF
        case 3365:
        // End:0x8C7
        case 3366:
        // End:0x8CF
        case 3367:
        // End:0x8D7
        case 3368:
        // End:0x8DF
        case 3369:
        // End:0x8E7
        case 3370:
        // End:0x8EF
        case 3371:
        // End:0x8F7
        case 3372:
        // End:0x8FF
        case 3373:
        // End:0x907
        case 3374:
        // End:0x90F
        case 3375:
        // End:0x917
        case 3376:
        // End:0x91F
        case 3377:
        // End:0x927
        case 3378:
        // End:0x92F
        case 3379:
        // End:0x937
        case 3380:
        // End:0x93F
        case 3381:
        // End:0x947
        case 3382:
        // End:0x94F
        case 3383:
        // End:0x957
        case 3384:
        // End:0x95F
        case 3385:
        // End:0x967
        case 3386:
        // End:0x96F
        case 3387:
        // End:0x977
        case 3388:
        // End:0x97F
        case 3389:
        // End:0x987
        case 3390:
        // End:0x98F
        case 3391:
        // End:0x997
        case 3392:
        // End:0x99F
        case 3393:
        // End:0x9A7
        case 3394:
        // End:0x9AF
        case 3395:
        // End:0x9B7
        case 3396:
        // End:0x9BF
        case 3397:
        // End:0x9C7
        case 3398:
        // End:0x9CF
        case 3399:
        // End:0x9D7
        case 3400:
        // End:0x9DF
        case 3401:
        // End:0x9E7
        case 3402:
        // End:0x9EF
        case 3403:
        // End:0x9F7
        case 3406:
        // End:0x9FF
        case 3411:
        // End:0xA07
        case 3412:
        // End:0xA0F
        case 3413:
        // End:0xA17
        case 3414:
        // End:0xA1F
        case 3415:
        // End:0xA27
        case 3416:
        // End:0xA2F
        case 3417:
        // End:0xA37
        case 3419:
        // End:0xA3F
        case 3420:
        // End:0xA47
        case 3426:
        // End:0xA4F
        case 3427:
        // End:0xA57
        case 3439:
        // End:0xA5F
        case 3440:
        // End:0xA67
        case 3441:
        // End:0xA6F
        case 3442:
        // End:0xA77
        case 3443:
        // End:0xA7F
        case 3444:
        // End:0xA87
        case 3445:
        // End:0xA8F
        case 3446:
        // End:0xA97
        case 3447:
        // End:0xA9F
        case 3448:
        // End:0xAA7
        case 3449:
        // End:0xAAF
        case 3450:
        // End:0xAB7
        case 3451:
        // End:0xABF
        case 3452:
        // End:0xAC7
        case 3453:
        // End:0xACF
        case 3454:
        // End:0xAD7
        case 3455:
        // End:0xADF
        case 3456:
        // End:0xAE7
        case 3457:
        // End:0xAEF
        case 3458:
        // End:0xAF7
        case 3459:
        // End:0xAFF
        case 3460:
        // End:0xB07
        case 3461:
        // End:0xB0F
        case 3462:
        // End:0xB17
        case 3463:
        // End:0xB1F
        case 3464:
        // End:0xB27
        case 3465:
        // End:0xB2F
        case 3466:
        // End:0xB37
        case 3467:
        // End:0xB3F
        case 3468:
        // End:0xB47
        case 3469:
        // End:0xB4F
        case 3470:
        // End:0xB57
        case 3471:
        // End:0xB5F
        case 3472:
        // End:0xB67
        case 3473:
        // End:0xB6F
        case 3474:
        // End:0xB77
        case 3475:
        // End:0xB7F
        case 3476:
        // End:0xB87
        case 3477:
        // End:0xB8F
        case 3478:
        // End:0xB97
        case 3479:
        // End:0xB9F
        case 3480:
        // End:0xBA7
        case 3481:
        // End:0xBAF
        case 3482:
        // End:0xBB7
        case 3483:
        // End:0xBBF
        case 3484:
        // End:0xBC7
        case 3485:
        // End:0xBCF
        case 3486:
        // End:0xBD7
        case 3489:
        // End:0xBDF
        case 3490:
        // End:0xBE7
        case 3491:
        // End:0xBEF
        case 3492:
        // End:0xBF7
        case 3493:
        // End:0xBFF
        case 3494:
        // End:0xC07
        case 3495:
        // End:0xC0F
        case 3497:
        // End:0xC17
        case 3498:
        // End:0xC1F
        case 3634:
        // End:0xC27
        case 3635:
        // End:0xC2F
        case 3636:
        // End:0xC37
        case 3637:
        // End:0xC3F
        case 3638:
        // End:0xC47
        case 3639:
        // End:0xC4F
        case 3640:
        // End:0xC57
        case 3641:
        // End:0xC5F
        case 3642:
        // End:0xC67
        case 3643:
        // End:0xC6F
        case 3644:
        // End:0xC77
        case 3645:
        // End:0xC7F
        case 3646:
        // End:0xC87
        case 3647:
        // End:0xC8F
        case 3648:
        // End:0xC97
        case 3649:
        // End:0xC9F
        case 3650:
        // End:0xCA7
        case 3651:
        // End:0xCAF
        case 3652:
        // End:0xCB7
        case 3653:
        // End:0xCBF
        case 3654:
        // End:0xCC7
        case 3655:
        // End:0xCCF
        case 3656:
        // End:0xCD7
        case 3657:
        // End:0xCDF
        case 3658:
        // End:0xCE7
        case 3659:
        // End:0xCEF
        case 3660:
        // End:0xCF7
        case 3661:
        // End:0xCFF
        case 3662:
        // End:0xD07
        case 3663:
        // End:0xD0F
        case 3666:
        // End:0xD17
        case 3667:
        // End:0xD1F
        case 3668:
        // End:0xD27
        case 3669:
        // End:0xD2F
        case 3670:
        // End:0xD37
        case 3671:
        // End:0xD3F
        case 3672:
        // End:0xD47
        case 3673:
        // End:0xD4F
        case 3674:
        // End:0xD57
        case 3675:
        // End:0xD5F
        case 3676:
        // End:0xD67
        case 3677:
        // End:0xD6F
        case 3678:
        // End:0xD77
        case 3679:
        // End:0xD7F
        case 3680:
        // End:0xD87
        case 3681:
        // End:0xD8F
        case 3682:
        // End:0xD97
        case 3683:
        // End:0xD9F
        case 3684:
        // End:0xDA7
        case 3685:
        // End:0xDAF
        case 3686:
        // End:0xDB7
        case 3687:
        // End:0xDBF
        case 3688:
        // End:0xDC7
        case 3689:
        // End:0xDCF
        case 3690:
        // End:0xDD7
        case 3691:
        // End:0xDDF
        case 3692:
        // End:0xDE7
        case 3693:
        // End:0xDEF
        case 3694:
        // End:0xDF7
        case 3695:
        // End:0xDFF
        case 3696:
        // End:0xE07
        case 3697:
        // End:0xE0F
        case 3698:
        // End:0xE17
        case 3699:
        // End:0xE1F
        case 3700:
        // End:0xE27
        case 3701:
        // End:0xE2F
        case 3702:
        // End:0xE37
        case 3703:
        // End:0xE3F
        case 3704:
        // End:0xE47
        case 3705:
        // End:0xE4F
        case 3706:
        // End:0xE57
        case 3707:
        // End:0xE5F
        case 3708:
        // End:0xE67
        case 3709:
        // End:0xE6F
        case 3710:
        // End:0xE77
        case 3711:
        // End:0xE7F
        case 3712:
        // End:0xE87
        case 3713:
        // End:0xE8F
        case 3714:
        // End:0xE97
        case 3715:
        // End:0xE9F
        case 3716:
        // End:0xEA7
        case 3717:
        // End:0xEAF
        case 3718:
        // End:0xEB7
        case 3719:
        // End:0xEBF
        case 3720:
        // End:0xEC7
        case 3721:
        // End:0xECF
        case 3722:
        // End:0xED7
        case 3723:
        // End:0xEDF
        case 3724:
        // End:0xEE7
        case 3725:
        // End:0xEEF
        case 3726:
        // End:0xEF7
        case 3727:
        // End:0xEFF
        case 3728:
        // End:0xF07
        case 3729:
        // End:0xF0F
        case 3730:
        // End:0xF17
        case 3731:
        // End:0xF1F
        case 3732:
        // End:0xF27
        case 3733:
        // End:0xF2F
        case 3734:
        // End:0xF37
        case 3735:
        // End:0xF3F
        case 3736:
        // End:0xF47
        case 3737:
        // End:0xF4F
        case 3738:
        // End:0xF57
        case 3739:
        // End:0xF5F
        case 3740:
        // End:0xF67
        case 3741:
        // End:0xF6F
        case 3742:
        // End:0xF77
        case 3743:
        // End:0xF7F
        case 3744:
        // End:0xF87
        case 3745:
        // End:0xF8F
        case 3746:
        // End:0xF97
        case 3747:
        // End:0xF9F
        case 3748:
        // End:0xFA7
        case 3749:
        // End:0xFAF
        case 3750:
        // End:0xFB7
        case 3751:
        // End:0xFBF
        case 3752:
        // End:0xFC7
        case 3753:
        // End:0xFCF
        case 3754:
        // End:0xFD7
        case 3755:
        // End:0xFDF
        case 3756:
        // End:0xFE7
        case 3757:
        // End:0xFEF
        case 3758:
        // End:0xFF7
        case 3759:
        // End:0xFFF
        case 3760:
        // End:0x1007
        case 3761:
        // End:0x100F
        case 3762:
        // End:0x1017
        case 3763:
        // End:0x101F
        case 3764:
        // End:0x1027
        case 3765:
        // End:0x102F
        case 3766:
        // End:0x1037
        case 3767:
        // End:0x103F
        case 3768:
        // End:0x1047
        case 3769:
        // End:0x104F
        case 3770:
        // End:0x1057
        case 3771:
        // End:0x105F
        case 3772:
        // End:0x1067
        case 3773:
        // End:0x106F
        case 3774:
        // End:0x1077
        case 3775:
        // End:0x107F
        case 3776:
        // End:0x1087
        case 3777:
        // End:0x108F
        case 3778:
        // End:0x1097
        case 3779:
        // End:0x109F
        case 3780:
        // End:0x10A7
        case 3781:
        // End:0x10AF
        case 3782:
        // End:0x10B7
        case 3783:
        // End:0x10BF
        case 3784:
        // End:0x10C7
        case 3785:
        // End:0x10CF
        case 3786:
        // End:0x10D7
        case 3787:
        // End:0x10DF
        case 3788:
        // End:0x10E7
        case 3789:
        // End:0x10EF
        case 3790:
        // End:0x10F7
        case 3791:
        // End:0x10FF
        case 3792:
        // End:0x1107
        case 3793:
        // End:0x110F
        case 3794:
        // End:0x1117
        case 3795:
        // End:0x111F
        case 3796:
        // End:0x1127
        case 3797:
        // End:0x112F
        case 3798:
        // End:0x1137
        case 3799:
        // End:0x113F
        case 3800:
        // End:0x1147
        case 3801:
        // End:0x114F
        case 3802:
        // End:0x1157
        case 3803:
        // End:0x115F
        case 3804:
        // End:0x1167
        case 3805:
        // End:0x116F
        case 3806:
        // End:0x1177
        case 3807:
        // End:0x117F
        case 3808:
        // End:0x1187
        case 3809:
        // End:0x118F
        case 3810:
        // End:0x1197
        case 3811:
        // End:0x119F
        case 3812:
        // End:0x11A7
        case 3813:
        // End:0x11AF
        case 3814:
        // End:0x11B7
        case 3815:
        // End:0x11BF
        case 3816:
        // End:0x11C7
        case 3817:
        // End:0x11CF
        case 3818:
        // End:0x11D7
        case 3819:
        // End:0x11DF
        case 3820:
        // End:0x11E7
        case 3821:
        // End:0x11EF
        case 3822:
        // End:0x11F7
        case 3823:
        // End:0x11FF
        case 3824:
        // End:0x1207
        case 3825:
        // End:0x120F
        case 3826:
        // End:0x1217
        case 3827:
        // End:0x121F
        case 3828:
        // End:0x1227
        case 3829:
        // End:0x122F
        case 3830:
        // End:0x1237
        case 3831:
        // End:0x123F
        case 3832:
        // End:0x1247
        case 3833:
        // End:0x124F
        case 3834:
        // End:0x1257
        case 3835:
        // End:0x125F
        case 3836:
        // End:0x1267
        case 3837:
        // End:0x126F
        case 3838:
        // End:0x1277
        case 3839:
        // End:0x127F
        case 3840:
        // End:0x1287
        case 3841:
        // End:0x128F
        case 3842:
        // End:0x1297
        case 3843:
        // End:0x129F
        case 3844:
        // End:0x12A7
        case 3845:
        // End:0x12AF
        case 3846:
        // End:0x12B7
        case 3847:
        // End:0x12BF
        case 3848:
        // End:0x12C7
        case 3849:
        // End:0x12CF
        case 3850:
        // End:0x12D7
        case 3851:
        // End:0x12DF
        case 3852:
        // End:0x12E7
        case 3853:
        // End:0x12EF
        case 3854:
        // End:0x12F7
        case 3855:
        // End:0x12FF
        case 3856:
        // End:0x1307
        case 3857:
        // End:0x130F
        case 3858:
        // End:0x1317
        case 3859:
        // End:0x131F
        case 3860:
        // End:0x1327
        case 3861:
        // End:0x132F
        case 3862:
        // End:0x1337
        case 3863:
        // End:0x133F
        case 3864:
        // End:0x1347
        case 3865:
        // End:0x134F
        case 3867:
        // End:0x1357
        case 3868:
        // End:0x135F
        case 3869:
        // End:0x1367
        case 3870:
        // End:0x136F
        case 3871:
        // End:0x1377
        case 3872:
        // End:0x137F
        case 3873:
        // End:0x1387
        case 3874:
        // End:0x138F
        case 3875:
        // End:0x1397
        case 3876:
        // End:0x139F
        case 3877:
        // End:0x13A7
        case 3878:
        // End:0x13AF
        case 3879:
        // End:0x13B7
        case 3880:
        // End:0x13BF
        case 3881:
        // End:0x13C7
        case 3882:
        // End:0x13CF
        case 3883:
        // End:0x13D7
        case 3884:
        // End:0x13DF
        case 3885:
        // End:0x13E7
        case 3886:
        // End:0x13EF
        case 3887:
        // End:0x13F7
        case 3888:
        // End:0x13FF
        case 3889:
        // End:0x1407
        case 3890:
        // End:0x140F
        case 3891:
        // End:0x1417
        case 3892:
        // End:0x141F
        case 3893:
        // End:0x1427
        case 3894:
        // End:0x142F
        case 3895:
        // End:0x1437
        case 3896:
        // End:0x143F
        case 3897:
        // End:0x1447
        case 3898:
        // End:0x144F
        case 3899:
        // End:0x1457
        case 3900:
        // End:0x145F
        case 3901:
        // End:0x1467
        case 3902:
        // End:0x146F
        case 3904:
        // End:0x1477
        case 3905:
        // End:0x147F
        case 3906:
        // End:0x1487
        case 3907:
        // End:0x148F
        case 3908:
        // End:0x1497
        case 3909:
        // End:0x149F
        case 3910:
        // End:0x14A7
        case 3911:
        // End:0x14AF
        case 3912:
        // End:0x14B7
        case 3913:
        // End:0x14BF
        case 3914:
        // End:0x14C7
        case 3915:
        // End:0x14CF
        case 3916:
        // End:0x14D7
        case 3917:
        // End:0x14DF
        case 3918:
        // End:0x14E7
        case 3919:
        // End:0x14EF
        case 3920:
        // End:0x14F7
        case 3921:
        // End:0x14FF
        case 3922:
        // End:0x1507
        case 3923:
        // End:0x150F
        case 3924:
        // End:0x1517
        case 3925:
        // End:0x151F
        case 3926:
        // End:0x1527
        case 3927:
        // End:0x152F
        case 3928:
        // End:0x1537
        case 3929:
        // End:0x153F
        case 3930:
        // End:0x1547
        case 3931:
        // End:0x154F
        case 3932:
        // End:0x1557
        case 3933:
        // End:0x155F
        case 3934:
        // End:0x1567
        case 3935:
        // End:0x156F
        case 3936:
        // End:0x1577
        case 3937:
        // End:0x157F
        case 3938:
        // End:0x1587
        case 3939:
        // End:0x158F
        case 3940:
        // End:0x1597
        case 3941:
        // End:0x159F
        case 3942:
        // End:0x15A7
        case 3943:
        // End:0x15AF
        case 3944:
        // End:0x15B7
        case 3945:
        // End:0x15BF
        case 3946:
        // End:0x15C7
        case 3947:
        // End:0x15CF
        case 3948:
        // End:0x15D7
        case 3949:
        // End:0x15DF
        case 3950:
        // End:0x15E7
        case 3951:
        // End:0x15EF
        case 3952:
        // End:0x15F7
        case 3953:
        // End:0x15FF
        case 3954:
        // End:0x1607
        case 3955:
        // End:0x160F
        case 3956:
        // End:0x1617
        case 3957:
        // End:0x161F
        case 3958:
        // End:0x1627
        case 3959:
        // End:0x162F
        case 3960:
        // End:0x1637
        case 3961:
        // End:0x163F
        case 3962:
        // End:0x1647
        case 3963:
        // End:0x164F
        case 3964:
        // End:0x1657
        case 3965:
        // End:0x165F
        case 3966:
        // End:0x1667
        case 3967:
        // End:0x166F
        case 3968:
        // End:0x1677
        case 3969:
        // End:0x167F
        case 3970:
        // End:0x1687
        case 3971:
        // End:0x168F
        case 3972:
        // End:0x1697
        case 3973:
        // End:0x169F
        case 3974:
        // End:0x16A7
        case 3975:
        // End:0x16AF
        case 3976:
        // End:0x16B7
        case 3977:
        // End:0x16BF
        case 3978:
        // End:0x16C7
        case 3979:
        // End:0x16CF
        case 3980:
        // End:0x16D7
        case 3981:
        // End:0x16DF
        case 3982:
        // End:0x16E7
        case 3983:
        // End:0x16EF
        case 3984:
        // End:0x16F7
        case 3985:
        // End:0x16FF
        case 3986:
        // End:0x1707
        case 3987:
        // End:0x170F
        case 3988:
        // End:0x1717
        case 3989:
        // End:0x171F
        case 3990:
        // End:0x1727
        case 3991:
        // End:0x172F
        case 3992:
        // End:0x1737
        case 3993:
        // End:0x173F
        case 3994:
        // End:0x1747
        case 3995:
        // End:0x174F
        case 3996:
        // End:0x1757
        case 3997:
        // End:0x175F
        case 3998:
        // End:0x1767
        case 3999:
        // End:0x1771
        case 3866:
            return 1;
        // End:0x1776
        case 113:
        // End:0x177B
        case 141:
        // End:0x1780
        case 142:
        // End:0x1785
        case 153:
        // End:0x178A
        case 208:
        // End:0x178F
        case 209:
        // End:0x1794
        case 216:
        // End:0x1799
        case 217:
        // End:0x179E
        case 227:
        // End:0x17A3
        case 231:
        // End:0x17A8
        case 232:
        // End:0x17AD
        case 233:
        // End:0x17B2
        case 234:
        // End:0x17B7
        case 235:
        // End:0x17BC
        case 236:
        // End:0x17C1
        case 239:
        // End:0x17C6
        case 244:
        // End:0x17CB
        case 172:
        // End:0x17D0
        case 205:
        // End:0x17D5
        case 210:
        // End:0x17DA
        case 248:
        // End:0x17DF
        case 249:
        // End:0x17E4
        case 250:
        // End:0x17E9
        case 251:
        // End:0x17EE
        case 252:
        // End:0x17F3
        case 253:
        // End:0x17FB
        case 257:
        // End:0x1800
        case 144:
        // End:0x1808
        case 258:
        // End:0x1810
        case 259:
        // End:0x1818
        case 293:
        // End:0x1820
        case 1315:
        // End:0x1828
        case 1316:
        // End:0x1830
        case 1317:
        // End:0x1838
        case 1318:
        // End:0x1840
        case 1319:
        // End:0x1848
        case 1320:
        // End:0x1850
        case 463:
        // End:0x1858
        case 464:
        // End:0x1860
        case 465:
        // End:0x1868
        case 472:
        // End:0x1870
        case 473:
        // End:0x1878
        case 474:
        // End:0x1880
        case 532:
        // End:0x1888
        case 533:
        // End:0x1890
        case 534:
        // End:0x1898
        case 535:
        // End:0x18A0
        case 818:
        // End:0x18A8
        case 819:
        // End:0x18B0
        case 820:
        // End:0x18B8
        case 923:
        // End:0x18C0
        case 925:
        // End:0x18C8
        case 926:
        // End:0x18D0
        case 934:
        // End:0x18D8
        case 935:
        // End:0x18E0
        case 936:
        // End:0x18E8
        case 937:
        // End:0x18F0
        case 938:
        // End:0x18F8
        case 946:
        // End:0x1900
        case 952:
        // End:0x1908
        case 964:
        // End:0x1910
        case 967:
        // End:0x1918
        case 4414:
        // End:0x1926
        case 4415:
            return 2;
            // End:0x192E
            break;
        // End:0xFFFF
        default:
            return 0;
            break;
    }    
 
}


function int SkillType(int SkillID)
{
    switch(SkillID)
    {
        // End:0x0F
        case 698:
        // End:0x17
        case 699:
        // End:0x1F
        case 701:
        // End:0x27
        case 702:
        // End:0x2F
        case 262:
        // End:0x34
        case 44:
        // End:0x39
        case 45:
        // End:0x3E
        case 49:
        // End:0x43
        case 69:
        // End:0x48
        case 70:
        // End:0x50
        case 283:
        // End:0x55
        case 46:
        // End:0x5D
        case 323:
        // End:0x65
        case 324:
        // End:0x6A
        case 10:
        // End:0x6F
        case 21:
        // End:0x74
        case 58:
        // End:0x79
        case 61:
        // End:0x7E
        case 67:
        // End:0x86
        case 779:
        // End:0x8E
        case 449:
        // End:0x93
        case 2:
        // End:0x98
        case 22:
        // End:0x9D
        case 33:
        // End:0xA5
        case 780:
        // End:0xAD
        case 278:
        // End:0xB5
        case 289:
        // End:0xBD
        case 1027:
        // End:0xC5
        case 1554:
        // End:0xCD
        case 1555:
        // End:0xD5
        case 1056:
        // End:0xDD
        case 1126:
        // End:0xE5
        case 1127:
        // End:0xED
        case 1172:
        // End:0xF5
        case 1174:
        // End:0xFD
        case 1175:
        // End:0x105
        case 1177:
        // End:0x10D
        case 1181:
        // End:0x115
        case 1183:
        // End:0x11D
        case 1216:
        // End:0x125
        case 1226:
        // End:0x12D
        case 1227:
        // End:0x135
        case 1231:
        // End:0x13D
        case 1235:
        // End:0x145
        case 1264:
        // End:0x14D
        case 1265:
        // End:0x155
        case 1274:
        // End:0x15D
        case 1275:
        // End:0x165
        case 1288:
        // End:0x16D
        case 1290:
        // End:0x175
        case 1293:
        // End:0x17D
        case 1295:
        // End:0x185
        case 1340:
        // End:0x18D
        case 1342:
        // End:0x195
        case 1417:
        // End:0x19D
        case 1421:
        // End:0x1A5
        case 1453:
        // End:0x1AD
        case 1455:
        // End:0x1B5
        case 1468:
        // End:0x1BD
        case 1011:
        // End:0x1C5
        case 1012:
        // End:0x1CD
        case 1015:
        // End:0x1D5
        case 1277:
        // End:0x1DD
        case 1280:
        // End:0x1E5
        case 1300:
        // End:0x1ED
        case 1301:
        // End:0x1F5
        case 1329:
        // End:0x1FD
        case 1332:
        // End:0x205
        case 1403:
        // End:0x20D
        case 1407:
        // End:0x215
        case 1424:
        // End:0x21D
        case 1558:
        // End:0x225
        case 782:
        // End:0x22D
        case 1028:
        // End:0x235
        case 1031:
        // End:0x23D
        case 1050:
        // End:0x245
        case 1217:
        // End:0x24D
        case 1219:
        // End:0x255
        case 1255:
        // End:0x25D
        case 1273:
        // End:0x265
        case 1395:
        // End:0x26D
        case 1398:
        // End:0x275
        case 1401:
        // End:0x27D
        case 1428:
        // End:0x285
        case 1430:
        // End:0x28D
        case 1550:
        // End:0x295
        case 1552:
        // End:0x29D
        case 1013:
        // End:0x2A5
        case 1016:
        // End:0x2AD
        case 1020:
        // End:0x2B5
        case 1111:
        // End:0x2BD
        case 1147:
        // End:0x2C5
        case 1151:
        // End:0x2CD
        case 1157:
        // End:0x2D5
        case 1171:
        // End:0x2DD
        case 1220:
        // End:0x2E5
        case 1225:
        // End:0x2ED
        case 1230:
        // End:0x2F5
        case 1233:
        // End:0x2FD
        case 1289:
        // End:0x305
        case 1292:
        // End:0x30D
        case 1296:
        // End:0x315
        case 1339:
        // End:0x31D
        case 1419:
        // End:0x325
        case 1451:
        // End:0x32D
        case 1452:
        // End:0x335
        case 1467:
        // End:0x33D
        case 1129:
        // End:0x345
        case 1148:
        // End:0x34D
        case 1154:
        // End:0x355
        case 1155:
        // End:0x35D
        case 1156:
        // End:0x365
        case 1159:
        // End:0x36D
        case 1234:
        // End:0x375
        case 1334:
        // End:0x37D
        case 1343:
        // End:0x385
        case 1422:
        // End:0x38D
        case 1423:
        // End:0x395
        case 1276:
        // End:0x39D
        case 1279:
        // End:0x3A5
        case 1328:
        // End:0x3AD
        case 1331:
        // End:0x3B5
        case 1406:
        // End:0x3BD
        case 781:
        // End:0x3C5
        case 1075:
        // End:0x3CD
        case 1218:
        // End:0x3D5
        case 1254:
        // End:0x3DD
        case 1258:
        // End:0x3E5
        case 1271:
        // End:0x3ED
        case 1311:
        // End:0x3F5
        case 1335:
        // End:0x3FD
        case 1399:
        // End:0x405
        case 1402:
        // End:0x40D
        case 1409:
        // End:0x415
        case 1425:
        // End:0x41D
        case 1426:
        // End:0x425
        case 1018:
        // End:0x42D
        case 1412:
        // End:0x435
        case 1128:
        // End:0x43D
        case 1176:
        // End:0x445
        case 1178:
        // End:0x44D
        case 1228:
        // End:0x455
        case 1239:
        // End:0x45D
        case 1266:
        // End:0x465
        case 1267:
        // End:0x46D
        case 1291:
        // End:0x475
        case 1294:
        // End:0x47D
        case 1341:
        // End:0x485
        case 1420:
        // End:0x48D
        case 1456:
        // End:0x495
        case 1458:
        // End:0x49D
        case 1278:
        // End:0x4A5
        case 1281:
        // End:0x4AD
        case 1330:
        // End:0x4B5
        case 1333:
        // End:0x4BD
        case 1408:
        // End:0x4C5
        case 1530:
        // End:0x4CD
        case 783:
        // End:0x4D5
        case 1551:
        // End:0x4DD
        case 1090:
        // End:0x4E5
        case 1100:
        // End:0x4ED
        case 1101:
        // End:0x4F5
        case 1102:
        // End:0x4FD
        case 1107:
        // End:0x505
        case 1108:
        // End:0x50D
        case 1210:
        // End:0x515
        case 1213:
        // End:0x51D
        case 1229:
        // End:0x525
        case 1245:
        // End:0x52D
        case 1256:
        // End:0x535
        case 1305:
        // End:0x53D
        case 1306:
        // End:0x545
        case 1429:
        // End:0x54F
        case 831:
            return 1;
        // End:0x554
        case 130:
        // End:0x55C
        case 917:
        // End:0x564
        case 287:
        // End:0x56C
        case 421:
        // End:0x571
        case 75:
        // End:0x576
        case 78:
        // End:0x57B
        case 80:
        // End:0x580
        case 87:
        // End:0x585
        case 88:
        // End:0x58D
        case 359:
        // End:0x592
        case 104:
        // End:0x59A
        case 360:
        // End:0x59F
        case 121:
        // End:0x5A7
        case 700:
        // End:0x5AF
        case 703:
        // End:0x5B7
        case 297:
        // End:0x5BF
        case 442:
        // End:0x5C7
        case 451:
        // End:0x5CF
        case 527:
        // End:0x5D7
        case 528:
        // End:0x5DC
        case 72:
        // End:0x5E1
        case 82:
        // End:0x5E9
        case 341:
        // End:0x5F1
        case 350:
        // End:0x5F6
        case 110:
        // End:0x5FB
        case 112:
        // End:0x603
        case 368:
        // End:0x60B
        case 913:
        // End:0x613
        case 916:
        // End:0x61B
        case 406:
        // End:0x623
        case 438:
        // End:0x62B
        case 982:
        // End:0x633
        case 760:
        // End:0x638
        case 86:
        // End:0x640
        case 439:
        // End:0x645
        case 4:
        // End:0x64A
        case 99:
        // End:0x64F
        case 111:
        // End:0x657
        case 821:
        // End:0x65F
        case 356:
        // End:0x667
        case 357:
        // End:0x66F
        case 922:
        // End:0x677
        case 411:
        // End:0x67F
        case 445:
        // End:0x684
        case 131:
        // End:0x68C
        case 303:
        // End:0x694
        case 313:
        // End:0x69C
        case 415:
        // End:0x6A4
        case 416:
        // End:0x6A9
        case 77:
        // End:0x6AE
        case 91:
        // End:0x6B3
        case 123:
        // End:0x6B8
        case 230:
        // End:0x6C0
        case 351:
        // End:0x6C8
        case 529:
        // End:0x6D0
        case 764:
        // End:0x6D8
        case 264:
        // End:0x6E0
        case 265:
        // End:0x6E8
        case 266:
        // End:0x6F0
        case 267:
        // End:0x6F8
        case 268:
        // End:0x700
        case 269:
        // End:0x708
        case 270:
        // End:0x710
        case 304:
        // End:0x718
        case 305:
        // End:0x720
        case 306:
        // End:0x728
        case 308:
        // End:0x730
        case 349:
        // End:0x738
        case 363:
        // End:0x740
        case 364:
        // End:0x748
        case 988:
        // End:0x750
        case 355:
        // End:0x758
        case 410:
        // End:0x760
        case 446:
        // End:0x768
        case 413:
        // End:0x770
        case 1040:
        // End:0x778
        case 1047:
        // End:0x780
        case 1068:
        // End:0x788
        case 1078:
        // End:0x790
        case 1145:
        // End:0x798
        case 1182:
        // End:0x7A0
        case 1238:
        // End:0x7A8
        case 1286:
        // End:0x7B0
        case 1532:
        // End:0x7B8
        case 1139:
        // End:0x7C0
        case 1140:
        // End:0x7C8
        case 1141:
        // End:0x7D0
        case 1299:
        // End:0x7D8
        case 1347:
        // End:0x7E0
        case 1349:
        // End:0x7E8
        case 1496:
        // End:0x7F0
        case 1547:
        // End:0x7F8
        case 1033:
        // End:0x800
        case 1035:
        // End:0x808
        case 1043:
        // End:0x810
        case 1044:
        // End:0x818
        case 1073:
        // End:0x820
        case 1087:
        // End:0x828
        case 1204:
        // End:0x830
        case 1243:
        // End:0x838
        case 1257:
        // End:0x840
        case 1259:
        // End:0x848
        case 1303:
        // End:0x850
        case 1304:
        // End:0x858
        case 1353:
        // End:0x860
        case 1354:
        // End:0x868
        case 1355:
        // End:0x870
        case 1393:
        // End:0x878
        case 1397:
        // End:0x880
        case 1460:
        // End:0x888
        case 1503:
        // End:0x890
        case 1504:
        // End:0x898
        case 1533:
        // End:0x8A0
        case 1144:
        // End:0x8A8
        case 1232:
        // End:0x8B0
        case 1285:
        // End:0x8B8
        case 1346:
        // End:0x8C0
        case 1062:
        // End:0x8C8
        case 1077:
        // End:0x8D0
        case 1085:
        // End:0x8D8
        case 1191:
        // End:0x8E0
        case 1307:
        // End:0x8E8
        case 1410:
        // End:0x8F0
        case 1418:
        // End:0x8F8
        case 1459:
        // End:0x900
        case 1032:
        // End:0x908
        case 1036:
        // End:0x910
        case 1045:
        // End:0x918
        case 1048:
        // End:0x920
        case 1086:
        // End:0x928
        case 1189:
        // End:0x930
        case 1240:
        // End:0x938
        case 1242:
        // End:0x940
        case 1352:
        // End:0x948
        case 1356:
        // End:0x950
        case 1388:
        // End:0x958
        case 1389:
        // End:0x960
        case 1392:
        // End:0x968
        case 1411:
        // End:0x970
        case 1499:
        // End:0x978
        case 1501:
        // End:0x980
        case 1548:
        // End:0x988
        case 271:
        // End:0x990
        case 272:
        // End:0x998
        case 273:
        // End:0x9A0
        case 274:
        // End:0x9A8
        case 275:
        // End:0x9B0
        case 276:
        // End:0x9B8
        case 277:
        // End:0x9C0
        case 307:
        // End:0x9C8
        case 309:
        // End:0x9D0
        case 310:
        // End:0x9D8
        case 311:
        // End:0x9E0
        case 365:
        // End:0x9E8
        case 366:
        // End:0x9F0
        case 530:
        // End:0x9F8
        case 765:
        // End:0xA00
        case 989:
        // End:0xA08
        case 447:
        // End:0xA10
        case 414:
        // End:0xA18
        case 1146:
        // End:0xA20
        case 1287:
        // End:0xA28
        case 1457:
        // End:0xA30
        case 1348:
        // End:0xA38
        case 1059:
        // End:0xA40
        case 1268:
        // End:0xA48
        case 1357:
        // End:0xA50
        case 1500:
        // End:0xA58
        case 1502:
        // End:0xA60
        case 1531:
        // End:0xA65
        case 94:
        // End:0xA6A
        case 139:
        // End:0xA6F
        case 176:
        // End:0xA77
        case 420:
        // End:0xA7F
        case 423:
        // End:0xA87
        case 536:
        // End:0xA8C
        case 76:
        // End:0xA91
        case 83:
        // End:0xA96
        case 109:
        // End:0xA9E
        case 282:
        // End:0xAA6
        case 292:
        // End:0xAAE
        case 298:
        // End:0xAB6
        case 425:
        // End:0xABE
        case 441:
        // End:0xAC6
        case 443:
        // End:0xACE
        case 1249:
        // End:0xAD6
        case 1250:
        // End:0xADE
        case 1260:
        // End:0xAE6
        case 1261:
        // End:0xAEE
        case 1282:
        // End:0xAF6
        case 1364:
        // End:0xAFE
        case 1365:
        // End:0xB06
        case 1414:
        // End:0xB0E
        case 1415:
        // End:0xB16
        case 1416:
        // End:0xB1E
        case 1427:
        // End:0xB26
        case 1536:
        // End:0xB2E
        case 1537:
        // End:0xB36
        case 1538:
        // End:0xB3E
        case 1563:
        // End:0xB46
        case 1002:
        // End:0xB4E
        case 1003:
        // End:0xB56
        case 1004:
        // End:0xB5E
        case 1005:
        // End:0xB66
        case 1006:
        // End:0xB6E
        case 1007:
        // End:0xB76
        case 1008:
        // End:0xB7E
        case 1009:
        // End:0xB86
        case 1010:
        // End:0xB8E
        case 1251:
        // End:0xB96
        case 1252:
        // End:0xB9E
        case 1253:
        // End:0xBA6
        case 1284:
        // End:0xBAE
        case 1308:
        // End:0xBB6
        case 1309:
        // End:0xBBE
        case 1310:
        // End:0xBC6
        case 1362:
        // End:0xBCE
        case 1363:
        // End:0xBD6
        case 1390:
        // End:0xBDE
        case 1391:
        // End:0xBE6
        case 1413:
        // End:0xBEE
        case 1461:
        // End:0xBF6
        case 1517:
        // End:0xBFE
        case 1518:
        // End:0xC06
        case 1519:
        // End:0xC0E
        case 1535:
        // End:0xC16
        case 1549:
        // End:0xC1E
        case 1562:
        // End:0xC26
        case 1561:
        // End:0xC2E
        case 823:
        // End:0xC36
        case 824:
        // End:0xC3E
        case 825:
        // End:0xC46
        case 826:
        // End:0xC4E
        case 827:
        // End:0xC56
        case 828:
        // End:0xC5E
        case 829:
        // End:0xC69
        case 830:
            return 2;
        // End:0xC71
        case 774:
        // End:0xC79
        case 286:
        // End:0xC81
        case 452:
        // End:0xC89
        case 361:
        // End:0xC8E
        case 116:
        // End:0xC96
        case 775:
        // End:0xC9B
        case 92:
        // End:0xCA0
        case 97:
        // End:0xCA8
        case 353:
        // End:0xCB0
        case 400:
        // End:0xCB8
        case 403:
        // End:0xCC0
        case 404:
        // End:0xCC8
        case 405:
        // End:0xCCD
        case 65:
        // End:0xCD5
        case 342:
        // End:0xCDA
        case 103:
        // End:0xCDF
        case 127:
        // End:0xCE7
        case 401:
        // End:0xCEF
        case 450:
        // End:0xCF7
        case 531:
        // End:0xCFC
        case 51:
        // End:0xD01
        case 96:
        // End:0xD06
        case 106:
        // End:0xD0E
        case 358:
        // End:0xD16
        case 412:
        // End:0xD1E
        case 991:
        // End:0xD26
        case 354:
        // End:0xD2B
        case 15:
        // End:0xD30
        case 102:
        // End:0xD35
        case 107:
        // End:0xD3D
        case 352:
        // End:0xD45
        case 402:
        // End:0xD4A
        case 98:
        // End:0xD52
        case 407:
        // End:0xD57
        case 105:
        // End:0xD5C
        case 115:
        // End:0xD61
        case 122:
        // End:0xD66
        case 129:
        // End:0xD6E
        case 279:
        // End:0xD76
        case 1069:
        // End:0xD7E
        case 1071:
        // End:0xD86
        case 1072:
        // End:0xD8E
        case 1164:
        // End:0xD96
        case 1169:
        // End:0xD9E
        case 1184:
        // End:0xDA6
        case 1206:
        // End:0xDAE
        case 1223:
        // End:0xDB6
        case 1236:
        // End:0xDBE
        case 1237:
        // End:0xDC6
        case 1338:
        // End:0xDCE
        case 1454:
        // End:0xDD6
        case 1350:
        // End:0xDDE
        case 1380:
        // End:0xDE6
        case 1384:
        // End:0xDEE
        case 1201:
        // End:0xDF6
        case 1359:
        // End:0xDFE
        case 1394:
        // End:0xE06
        case 1400:
        // End:0xE0E
        case 1074:
        // End:0xE16
        case 1083:
        // End:0xE1E
        case 1160:
        // End:0xE26
        case 1167:
        // End:0xE2E
        case 1168:
        // End:0xE36
        case 1222:
        // End:0xE3E
        case 1064:
        // End:0xE46
        case 1163:
        // End:0xE4E
        case 1170:
        // End:0xE56
        case 1263:
        // End:0xE5E
        case 1269:
        // End:0xE66
        case 1298:
        // End:0xE6E
        case 1336:
        // End:0xE76
        case 1337:
        // End:0xE7E
        case 1344:
        // End:0xE86
        case 1345:
        // End:0xE8E
        case 1381:
        // End:0xE96
        case 1382:
        // End:0xE9E
        case 1351:
        // End:0xEA6
        case 1383:
        // End:0xEAE
        case 1386:
        // End:0xEB6
        case 1034:
        // End:0xEBE
        case 1042:
        // End:0xEC6
        case 1049:
        // End:0xECE
        case 1360:
        // End:0xED6
        case 1361:
        // End:0xEDE
        case 1396:
        // End:0xEE6
        case 1272:
        // End:0xEEE
        case 1358:
        // End:0xEF3
        case 84:
        // End:0xEFB
        case 408:
        // End:0xF03
        case 1224:
        // End:0xF0B
        case 1385:
        // End:0xF13
        case 1508:
        // End:0xF1B
        case 1539:
        // End:0xF23
        case 362:
        // End:0xF28
        case 95:
        // End:0xF30
        case 281:
        // End:0xF38
        case 1092:
        // End:0xF40
        case 1095:
        // End:0xF48
        case 1096:
        // End:0xF50
        case 1097:
        // End:0xF58
        case 1099:
        // End:0xF60
        case 1104:
        // End:0xF68
        case 1105:
        // End:0xF70
        case 1208:
        // End:0xF78
        case 1209:
        // End:0xF80
        case 1246:
        // End:0xF88
        case 1247:
        // End:0xF90
        case 1248:
        // End:0xF98
        case 1366:
        // End:0xFA0
        case 1367:
        // End:0xFA8
        case 1462:
        // End:0xFB3
        case 1244:
            return 3;
        // End:0xFBB
        case 325:
        // End:0xFC3
        case 326:
        // End:0xFCB
        case 327:
        // End:0xFD3
        case 1323:
        // End:0xFDB
        case 1324:
        // End:0xFE3
        case 1325:
        // End:0xFEB
        case 1326:
        // End:0xFF3
        case 1327:
        // End:0xFFB
        case 395:
        // End:0x1003
        case 396:
        // End:0x100B
        case 1374:
        // End:0x1013
        case 1375:
        // End:0x101E
        case 1376:
            return 4;
        // End:0x1023
        case 60:
        // End:0x1028
        case 196:
        // End:0x102D
        case 197:
        // End:0x1032
        case 221:
        // End:0x1037
        case 115:
        // End:0x103F
        case 256:
        // End:0x1047
        case 312:
        // End:0x104F
        case 317:
        // End:0x1057
        case 318:
        // End:0x105F
        case 322:
        // End:0x1067
        case 334:
        // End:0x106F
        case 335:
        // End:0x1077
        case 336:
        // End:0x107F
        case 337:
        // End:0x1087
        case 338:
        // End:0x108F
        case 339:
        // End:0x1097
        case 340:
        // End:0x109F
        case 422:
        // End:0x10A7
        case 424:
        // End:0x10AF
        case 1262:
        // End:0x10B7
        case 288:
        // End:0x10BF
        case 296:
        // End:0x10C4
        case 222:
        // End:0x10C9
        case 226:
        // End:0x10D1
        case 1283:
        // End:0x10DF
        case 1001:
            return 5;
            // End:0x10E7
            break;
        // End:0xFFFF
        default:
            return 0;
            break;
    }    

}
  function RefineryParam(int Id, out string ResultParam)
{
    local string param;

    switch(Id)
    {
        // End:0x28
        case 14578:
            param = "1,3,1,Winter,1";
            // End:0xEE51
            break;
        // End:0x4A
        case 14579:
            param = "1,3,1,Agility,1";
            // End:0xEE51
            break;
        // End:0x6A
        case 14580:
            param = "1,3,1,Bleed,1";
            // End:0xEE51
            break;
        // End:0x8B
        case 14581:
            param = "1,3,1,Ritual,1";
            // End:0xEE51
            break;
        // End:0xAB
        case 14582:
            param = "1,3,1,Stone,1";
            // End:0xEE51
            break;
        // End:0xCA
        case 14583:
            param = "1,3,1,Fear,1";
            // End:0xEE51
            break;
        // End:0xEF
        case 14584:
            param = "1,3,1,Prominence,1";
            // End:0xEE51
            break;
        // End:0x10F
        case 14585:
            param = "1,3,1,Peace,1";
            // End:0xEE51
            break;
        // End:0x12F
        case 14586:
            param = "1,3,3,Charm,1";
            // End:0xEE51
            break;
        // End:0x154
        case 14587:
            param = "1,3,1,Aggression,1";
            // End:0xEE51
            break;
        // End:0x177
        case 14588:
            param = "1,3,1,Guidance,1";
            // End:0xEE51
            break;
        // End:0x196
        case 14589:
            param = "1,3,1,Hold,1";
            // End:0xEE51
            break;
        // End:0x1BC
        case 14590:
            param = "1,3,1,Solar Flare,1";
            // End:0xEE51
            break;
        // End:0x1E3
        case 14591:
            param = "1,3,1,Heal Empower,1";
            // End:0xEE51
            break;
        // End:0x204
        case 14592:
            param = "1,3,1,Prayer,1";
            // End:0xEE51
            break;
        // End:0x223
        case 14593:
            param = "1,3,1,Heal,1";
            // End:0xEE51
            break;
        // End:0x245
        case 14594:
            param = "1,3,1,Empower,1";
            // End:0xEE51
            break;
        // End:0x265
        case 14595:
            param = "1,3,1,Cheer,1";
            // End:0xEE51
            break;
        // End:0x28B
        case 14596:
            param = "1,3,1,Battle Roar,1";
            // End:0xEE51
            break;
        // End:0x2B2
        case 14597:
            param = "1,3,1,Blessed Body,1";
            // End:0xEE51
            break;
        // End:0x2D9
        case 14598:
            param = "1,3,1,Blessed Soul,1";
            // End:0xEE51
            break;
        // End:0x301
        case 14599:
            param = "1,3,1,Magic Barrier,1";
            // End:0xEE51
            break;
        // End:0x325
        case 14600:
            param = "1,3,1,Mana Burn,1";
            // End:0xEE51
            break;
        // End:0x349
        case 14601:
            param = "1,3,1,Mana Gain,1";
            // End:0xEE51
            break;
        // End:0x36C
        case 14602:
            param = "1,3,1,Recharge,1";
            // End:0xEE51
            break;
        // End:0x391
        case 14603:
            param = "1,3,1,Aura Flare,1";
            // End:0xEE51
            break;
        // End:0x3B1
        case 14604:
            param = "1,3,1,Might,1";
            // End:0xEE51
            break;
        // End:0x3D4
        case 14605:
            param = "1,3,1,Paralyze,1";
            // End:0xEE51
            break;
        // End:0x3F5
        case 14606:
            param = "1,3,1,Shield,1";
            // End:0xEE51
            break;
        // End:0x416
        case 14607:
            param = "1,3,1,Poison,1";
            // End:0xEE51
            break;
        // End:0x43E
        case 14608:
            param = "1,3,1,Duel Weakness,1";
            // End:0xEE51
            break;
        // End:0x463
        case 14609:
            param = "1,3,1,Duel Might,1";
            // End:0xEE51
            break;
        // End:0x484
        case 14610:
            param = "1,3,1,Recall,1";
            // End:0xEE51
            break;
        // End:0x4AB
        case 14611:
            param = "1,3,1,Resurrection,1";
            // End:0xEE51
            break;
        // End:0x4D0
        case 14612:
            param = "1,3,1,Self Stone,1";
            // End:0xEE51
            break;
        // End:0x4FA
        case 14613:
            param = "1,3,1,Self Prominence,1";
            // End:0xEE51
            break;
        // End:0x525
        case 14614:
            param = "1,3,1,Self Solar Flare,1";
            // End:0xEE51
            break;
        // End:0x54F
        case 14615:
            param = "1,3,1,Self Aura Flare,1";
            // End:0xEE51
            break;
        // End:0x57B
        case 14616:
            param = "1,3,1,Self Shadow Flare,1";
            // End:0xEE51
            break;
        // End:0x5A6
        case 14617:
            param = "1,3,1,Self Hydro Blast,1";
            // End:0xEE51
            break;
        // End:0x5CF
        case 14618:
            param = "1,3,1,Self Hurricane,1";
            // End:0xEE51
            break;
        // End:0x5EF
        case 14619:
            param = "1,3,1,Sleep,1";
            // End:0xEE51
            break;
        // End:0x60E
        case 14620:
            param = "1,3,1,Slow,1";
            // End:0xEE51
            break;
        // End:0x62D
        case 14621:
            param = "1,3,1,Stun,1";
            // End:0xEE51
            break;
        // End:0x650
        case 14622:
            param = "1,3,1,Ae Stone,1";
            // End:0xEE51
            break;
        // End:0x678
        case 14623:
            param = "1,3,1,Ae Prominence,1";
            // End:0xEE51
            break;
        // End:0x6A1
        case 14624:
            param = "1,3,1,Ae Solar Flare,1";
            // End:0xEE51
            break;
        // End:0x6C9
        case 14625:
            param = "1,3,1,Ae Aura Flare,1";
            // End:0xEE51
            break;
        // End:0x6F3
        case 14626:
            param = "1,3,1,Ae Shadow Flare,1";
            // End:0xEE51
            break;
        // End:0x71C
        case 14627:
            param = "1,3,1,Ae Hydro Blast,1";
            // End:0xEE51
            break;
        // End:0x743
        case 14628:
            param = "1,3,1,Ae Hurricane,1";
            // End:0xEE51
            break;
        // End:0x763
        case 14629:
            param = "1,3,1,Trick,1";
            // End:0xEE51
            break;
        // End:0x784
        case 14630:
            param = "1,3,1,Medusa,1";
            // End:0xEE51
            break;
        // End:0x7AB
        case 14631:
            param = "1,3,1,Shadow Flare,1";
            // End:0xEE51
            break;
        // End:0x7CC
        case 14632:
            param = "1,3,1,Unlock,1";
            // End:0xEE51
            break;
        // End:0x7F5
        case 14633:
            param = "1,3,1,Vampiric Touch,1";
            // End:0xEE51
            break;
        // End:0x81B
        case 14634:
            param = "1,3,1,Hydro Blast,1";
            // End:0xEE51
            break;
        // End:0x83F
        case 14635:
            param = "1,3,1,Hurricane,1";
            // End:0xEE51
            break;
        // End:0x869
        case 14636:
            param = "1,3,3,Physical Winter,1";
            // End:0xEE51
            break;
        // End:0x892
        case 14637:
            param = "1,3,3,Physical Bleed,1";
            // End:0xEE51
            break;
        // End:0x8BA
        case 14638:
            param = "1,3,3,Physical Fear,1";
            // End:0xEE51
            break;
        // End:0x8E2
        case 14639:
            param = "1,3,3,Physical Hold,1";
            // End:0xEE51
            break;
        // End:0x90C
        case 14640:
            param = "1,3,3,Physical Poison,1";
            // End:0xEE51
            break;
        // End:0x936
        case 14641:
            param = "1,3,3,Physical Medusa,1";
            // End:0xEE51
            break;
        // End:0x960
        case 14642:
            param = "1,3,3,Critical Winter,1";
            // End:0xEE51
            break;
        // End:0x989
        case 14643:
            param = "1,3,3,Critical Bleed,1";
            // End:0xEE51
            break;
        // End:0x9B1
        case 14644:
            param = "1,3,3,Critical Fear,1";
            // End:0xEE51
            break;
        // End:0x9D9
        case 14645:
            param = "1,3,3,Critical Hold,1";
            // End:0xEE51
            break;
        // End:0xA03
        case 14646:
            param = "1,3,3,Critical Poison,1";
            // End:0xEE51
            break;
        // End:0xA2D
        case 14647:
            param = "1,3,3,Critical Medusa,1";
            // End:0xEE51
            break;
        // End:0xA4E
        case 14648:
            param = "1,3,3,Winter,1";
            // End:0xEE51
            break;
        // End:0xA70
        case 14649:
            param = "1,3,3,Agility,1";
            // End:0xEE51
            break;
        // End:0xA90
        case 14650:
            param = "1,3,3,Bleed,1";
            // End:0xEE51
            break;
        // End:0xAB1
        case 14651:
            param = "1,3,3,Ritual,1";
            // End:0xEE51
            break;
        // End:0xAD1
        case 14652:
            param = "1,3,3,Focus,1";
            // End:0xEE51
            break;
        // End:0xAF1
        case 14653:
            param = "1,3,3,Charm,1";
            // End:0xEE51
            break;
        // End:0xB14
        case 14654:
            param = "1,3,3,Guidance,1";
            // End:0xEE51
            break;
        // End:0xB33
        case 14655:
            param = "1,3,3,Hold,1";
            // End:0xEE51
            break;
        // End:0xB54
        case 14656:
            param = "1,3,3,Prayer,1";
            // End:0xEE51
            break;
        // End:0xB73
        case 14657:
            param = "1,3,3,Heal,1";
            // End:0xEE51
            break;
        // End:0xB95
        case 14658:
            param = "1,3,3,Empower,1";
            // End:0xEE51
            break;
        // End:0xBBA
        case 14659:
            param = "1,3,3,Wild Magic,1";
            // End:0xEE51
            break;
        // End:0xBDA
        case 14660:
            param = "1,3,3,Cheer,1";
            // End:0xEE51
            break;
        // End:0xC01
        case 14661:
            param = "1,3,3,Blessed Body,1";
            // End:0xEE51
            break;
        // End:0xC28
        case 14662:
            param = "1,3,3,Blessed Soul,1";
            // End:0xEE51
            break;
        // End:0xC50
        case 14663:
            param = "1,3,3,Magic Barrier,1";
            // End:0xEE51
            break;
        // End:0xC70
        case 14664:
            param = "1,3,3,Might,1";
            // End:0xEE51
            break;
        // End:0xC91
        case 14665:
            param = "1,3,3,Shield,1";
            // End:0xEE51
            break;
        // End:0xCB2
        case 14666:
            param = "1,3,3,Poison,1";
            // End:0xEE51
            break;
        // End:0xCDA
        case 14667:
            param = "1,3,3,Duel Weakness,1";
            // End:0xEE51
            break;
        // End:0xCFF
        case 14668:
            param = "1,3,3,Duel Might,1";
            // End:0xEE51
            break;
        // End:0xD1F
        case 14669:
            param = "1,3,3,Sleep,1";
            // End:0xEE51
            break;
        // End:0xD3E
        case 14670:
            param = "1,3,3,Slow,1";
            // End:0xEE51
            break;
        // End:0xD67
        case 14671:
            param = "1,3,3,Magical Winter,1";
            // End:0xEE51
            break;
        // End:0xD8F
        case 14672:
            param = "1,3,3,Magical Bleed,1";
            // End:0xEE51
            break;
        // End:0xDB6
        case 14673:
            param = "1,3,3,Magical Fear,1";
            // End:0xEE51
            break;
        // End:0xDDD
        case 14674:
            param = "1,3,3,Magical Hold,1";
            // End:0xEE51
            break;
        // End:0xE06
        case 14675:
            param = "1,3,3,Magical Poison,1";
            // End:0xEE51
            break;
        // End:0xE2F
        case 14676:
            param = "1,3,3,Magical Medusa,1";
            // End:0xEE51
            break;
        // End:0xE56
        case 14677:
            param = "1,3,2,Heal Empower,1";
            // End:0xEE51
            break;
        // End:0xE77
        case 14678:
            param = "1,3,2,Prayer,1";
            // End:0xEE51
            break;
        // End:0xE99
        case 14679:
            param = "1,3,2,Empower,1";
            // End:0xEE51
            break;
        // End:0xEC1
        case 14680:
            param = "1,3,2,Magic Barrier,1";
            // End:0xEE51
            break;
        // End:0xEE1
        case 14681:
            param = "1,3,2,Might,1";
            // End:0xEE51
            break;
        // End:0xF02
        case 14682:
            param = "1,3,2,Shield,1";
            // End:0xEE51
            break;
        // End:0xF27
        case 14683:
            param = "1,3,2,Duel Might,1";
            // End:0xEE51
            break;
        // End:0xF4E
        case 14684:
            param = "1,3,2,Weight Limit,1";
            // End:0xEE51
            break;
        // End:0xF6E
        case 14685:
            param = "1,4,1,Focus,1";
            // End:0xEE51
            break;
        // End:0xF8E
        case 14686:
            param = "1,4,1,Focus,1";
            // End:0xEE51
            break;
        // End:0xFAE
        case 14687:
            param = "1,4,1,Focus,1";
            // End:0xEE51
            break;
        // End:0xFCE
        case 14688:
            param = "1,4,1,Focus,1";
            // End:0xEE51
            break;
        // End:0xFED
        case 14689:
            param = "1,4,1,Doom,1";
            // End:0xEE51
            break;
        // End:0x100E
        case 14690:
            param = "1,4,1,Recall,2";
            // End:0xEE51
            break;
        // End:0x1039
        case 14691:
            param = "1,4,1,Celestial Shield,1";
            // End:0xEE51
            break;
        // End:0x105E
        case 14692:
            param = "1,4,1,Wild Magic,1";
            // End:0xEE51
            break;
        // End:0x1083
        case 14693:
            param = "1,4,1,Wild Magic,1";
            // End:0xEE51
            break;
        // End:0x10A5
        case 14694:
            param = "1,4,1,Silence,1";
            // End:0xEE51
            break;
        // End:0x10CA
        case 14695:
            param = "1,4,1,Wild Magic,1";
            // End:0xEE51
            break;
        // End:0x10EF
        case 14696:
            param = "1,4,1,Wild Magic,1";
            // End:0xEE51
            break;
        // End:0x1111
        case 14697:
            param = "1,4,1,Silence,1";
            // End:0xEE51
            break;
        // End:0x1133
        case 14698:
            param = "1,4,1,Silence,1";
            // End:0xEE51
            break;
        // End:0x1155
        case 14699:
            param = "1,4,1,Silence,1";
            // End:0xEE51
            break;
        // End:0x1177
        case 14700:
            param = "1,4,1,Silence,1";
            // End:0xEE51
            break;
        // End:0x1199
        case 14701:
            param = "1,4,1,Silence,1";
            // End:0xEE51
            break;
        // End:0x11C1
        case 14702:
            param = "1,4,1,Vampiric Rage,1";
            // End:0xEE51
            break;
        // End:0x11E9
        case 14703:
            param = "1,4,3,Physical Doom,1";
            // End:0xEE51
            break;
        // End:0x1216
        case 14704:
            param = "1,4,3,Physical Mana Burn,1";
            // End:0xEE51
            break;
        // End:0x1242
        case 14705:
            param = "1,4,3,Physical Paralyze,1";
            // End:0xEE51
            break;
        // End:0x126D
        case 14706:
            param = "1,4,3,Physical Silence,1";
            // End:0xEE51
            break;
        // End:0x1296
        case 14707:
            param = "1,4,3,Physical Sleep,1";
            // End:0xEE51
            break;
        // End:0x12BE
        case 14708:
            param = "1,4,3,Physical Stun,1";
            // End:0xEE51
            break;
        // End:0x12E6
        case 14709:
            param = "1,4,3,Critical Doom,1";
            // End:0xEE51
            break;
        // End:0x1313
        case 14710:
            param = "1,4,3,Critical Mana Burn,1";
            // End:0xEE51
            break;
        // End:0x133F
        case 14711:
            param = "1,4,3,Critical Paralyze,1";
            // End:0xEE51
            break;
        // End:0x136A
        case 14712:
            param = "1,4,3,Critical Silence,1";
            // End:0xEE51
            break;
        // End:0x1393
        case 14713:
            param = "1,4,3,Critical Sleep,1";
            // End:0xEE51
            break;
        // End:0x13BB
        case 14714:
            param = "1,4,3,Critical Stun,1";
            // End:0xEE51
            break;
        // End:0x13DA
        case 14715:
            param = "1,4,3,Doom,1";
            // End:0xEE51
            break;
        // End:0x13F9
        case 14716:
            param = "1,4,3,Fear,1";
            // End:0xEE51
            break;
        // End:0x141D
        case 14717:
            param = "1,4,3,Mana Gain,1";
            // End:0xEE51
            break;
        // End:0x1440
        case 14718:
            param = "1,4,3,Recharge,1";
            // End:0xEE51
            break;
        // End:0x1463
        case 14719:
            param = "1,4,3,Paralyze,1";
            // End:0xEE51
            break;
        // End:0x1485
        case 14720:
            param = "1,4,3,Silence,1";
            // End:0xEE51
            break;
        // End:0x14A4
        case 14721:
            param = "1,4,3,Stun,1";
            // End:0xEE51
            break;
        // End:0x14C5
        case 14722:
            param = "1,4,3,Medusa,1";
            // End:0xEE51
            break;
        // End:0x14EC
        case 14723:
            param = "1,4,3,Magical Doom,1";
            // End:0xEE51
            break;
        // End:0x1518
        case 14724:
            param = "1,4,3,Magical Mana Burn,1";
            // End:0xEE51
            break;
        // End:0x1543
        case 14725:
            param = "1,4,3,Magical Paralyze,1";
            // End:0xEE51
            break;
        // End:0x156D
        case 14726:
            param = "1,4,3,Magical Silence,1";
            // End:0xEE51
            break;
        // End:0x1595
        case 14727:
            param = "1,4,3,Magical Sleep,1";
            // End:0xEE51
            break;
        // End:0x15BC
        case 14728:
            param = "1,4,3,Magical Stun,1";
            // End:0xEE51
            break;
        // End:0x15DE
        case 14729:
            param = "1,4,2,Agility,1";
            // End:0xEE51
            break;
        // End:0x1600
        case 14730:
            param = "1,4,2,Agility,1";
            // End:0xEE51
            break;
        // End:0x1620
        case 14731:
            param = "1,4,2,Focus,1";
            // End:0xEE51
            break;
        // End:0x1640
        case 14732:
            param = "1,4,2,Focus,1";
            // End:0xEE51
            break;
        // End:0x1663
        case 14733:
            param = "1,4,2,Guidance,1";
            // End:0xEE51
            break;
        // End:0x1688
        case 14734:
            param = "1,4,2,Wild Magic,1";
            // End:0xEE51
            break;
        // End:0x16AC
        case 14735:
            param = "1,4,2,Mana Gain,1";
            // End:0xEE51
            break;
        // End:0x16D0
        case 14736:
            param = "1,4,2,Mana Gain,1";
            // End:0xEE51
            break;
        // End:0x16F4
        case 14737:
            param = "1,4,2,Mana Gain,1";
            // End:0xEE51
            break;
        // End:0x1718
        case 14738:
            param = "1,4,2,Mana Gain,1";
            // End:0xEE51
            break;
        // End:0x1739
        case 14756:
            param = "1,3,1,Winter,2";
            // End:0xEE51
            break;
        // End:0x175B
        case 14757:
            param = "1,3,1,Agility,2";
            // End:0xEE51
            break;
        // End:0x177B
        case 14758:
            param = "1,3,1,Bleed,2";
            // End:0xEE51
            break;
        // End:0x179C
        case 14759:
            param = "1,3,1,Ritual,2";
            // End:0xEE51
            break;
        // End:0x17BC
        case 14760:
            param = "1,3,1,Stone,2";
            // End:0xEE51
            break;
        // End:0x17DB
        case 14761:
            param = "1,3,1,Fear,2";
            // End:0xEE51
            break;
        // End:0x1800
        case 14762:
            param = "1,3,1,Prominence,2";
            // End:0xEE51
            break;
        // End:0x1820
        case 14763:
            param = "1,3,1,Peace,2";
            // End:0xEE51
            break;
        // End:0x1840
        case 14764:
            param = "1,3,1,Charm,2";
            // End:0xEE51
            break;
        // End:0x1865
        case 14765:
            param = "1,3,1,Aggression,2";
            // End:0xEE51
            break;
        // End:0x1888
        case 14766:
            param = "1,3,1,Guidance,2";
            // End:0xEE51
            break;
        // End:0x18A7
        case 14767:
            param = "1,3,1,Hold,2";
            // End:0xEE51
            break;
        // End:0x18CD
        case 14768:
            param = "1,3,1,Solar Flare,2";
            // End:0xEE51
            break;
        // End:0x18F4
        case 14769:
            param = "1,3,1,Heal Empower,2";
            // End:0xEE51
            break;
        // End:0x1915
        case 14770:
            param = "1,3,1,Prayer,2";
            // End:0xEE51
            break;
        // End:0x1934
        case 14771:
            param = "1,3,1,Heal,2";
            // End:0xEE51
            break;
        // End:0x1956
        case 14772:
            param = "1,3,1,Empower,2";
            // End:0xEE51
            break;
        // End:0x1976
        case 14773:
            param = "1,3,1,Cheer,2";
            // End:0xEE51
            break;
        // End:0x199C
        case 14774:
            param = "1,3,1,Battle Roar,2";
            // End:0xEE51
            break;
        // End:0x19C3
        case 14775:
            param = "1,3,1,Blessed Body,2";
            // End:0xEE51
            break;
        // End:0x19EA
        case 14776:
            param = "1,3,1,Blessed Soul,2";
            // End:0xEE51
            break;
        // End:0x1A12
        case 14777:
            param = "1,3,1,Magic Barrier,2";
            // End:0xEE51
            break;
        // End:0x1A36
        case 14778:
            param = "1,3,1,Mana Burn,2";
            // End:0xEE51
            break;
        // End:0x1A5A
        case 14779:
            param = "1,3,1,Mana Gain,2";
            // End:0xEE51
            break;
        // End:0x1A7D
        case 14780:
            param = "1,3,1,Recharge,2";
            // End:0xEE51
            break;
        // End:0x1AA2
        case 14781:
            param = "1,3,1,Aura Flare,2";
            // End:0xEE51
            break;
        // End:0x1AC2
        case 14782:
            param = "1,3,1,Might,2";
            // End:0xEE51
            break;
        // End:0x1AE5
        case 14783:
            param = "1,3,1,Paralyze,2";
            // End:0xEE51
            break;
        // End:0x1B06
        case 14784:
            param = "1,3,1,Shield,2";
            // End:0xEE51
            break;
        // End:0x1B27
        case 14785:
            param = "1,3,1,Poison,2";
            // End:0xEE51
            break;
        // End:0x1B4F
        case 14786:
            param = "1,3,1,Duel Weakness,2";
            // End:0xEE51
            break;
        // End:0x1B74
        case 14787:
            param = "1,3,1,Duel Might,2";
            // End:0xEE51
            break;
        // End:0x1B95
        case 14788:
            param = "1,3,1,Recall,1";
            // End:0xEE51
            break;
        // End:0x1BBC
        case 14789:
            param = "1,3,1,Resurrection,2";
            // End:0xEE51
            break;
        // End:0x1BE1
        case 14790:
            param = "1,3,1,Self Stone,2";
            // End:0xEE51
            break;
        // End:0x1C0B
        case 14791:
            param = "1,3,1,Self Prominence,2";
            // End:0xEE51
            break;
        // End:0x1C36
        case 14792:
            param = "1,3,1,Self Solar Flare,2";
            // End:0xEE51
            break;
        // End:0x1C60
        case 14793:
            param = "1,3,1,Self Aura Flare,2";
            // End:0xEE51
            break;
        // End:0x1C8C
        case 14794:
            param = "1,3,1,Self Shadow Flare,2";
            // End:0xEE51
            break;
        // End:0x1CB7
        case 14795:
            param = "1,3,1,Self Hydro Blast,2";
            // End:0xEE51
            break;
        // End:0x1CE0
        case 14796:
            param = "1,3,1,Self Hurricane,2";
            // End:0xEE51
            break;
        // End:0x1D00
        case 14797:
            param = "1,3,1,Sleep,2";
            // End:0xEE51
            break;
        // End:0x1D1F
        case 14798:
            param = "1,3,1,Slow,2";
            // End:0xEE51
            break;
        // End:0x1D3E
        case 14799:
            param = "1,3,1,Stun,2";
            // End:0xEE51
            break;
        // End:0x1D61
        case 14800:
            param = "1,3,1,Ae Stone,2";
            // End:0xEE51
            break;
        // End:0x1D89
        case 14801:
            param = "1,3,1,Ae Prominence,2";
            // End:0xEE51
            break;
        // End:0x1DB2
        case 14802:
            param = "1,3,1,Ae Solar Flare,2";
            // End:0xEE51
            break;
        // End:0x1DDA
        case 14803:
            param = "1,3,1,Ae Aura Flare,2";
            // End:0xEE51
            break;
        // End:0x1E04
        case 14804:
            param = "1,3,1,Ae Shadow Flare,2";
            // End:0xEE51
            break;
        // End:0x1E2D
        case 14805:
            param = "1,3,1,Ae Hydro Blast,2";
            // End:0xEE51
            break;
        // End:0x1E54
        case 14806:
            param = "1,3,1,Ae Hurricane,2";
            // End:0xEE51
            break;
        // End:0x1E74
        case 14807:
            param = "1,3,1,Trick,2";
            // End:0xEE51
            break;
        // End:0x1E95
        case 14808:
            param = "1,3,1,Medusa,2";
            // End:0xEE51
            break;
        // End:0x1EBC
        case 14809:
            param = "1,3,1,Shadow Flare,2";
            // End:0xEE51
            break;
        // End:0x1EDD
        case 14810:
            param = "1,3,1,Unlock,2";
            // End:0xEE51
            break;
        // End:0x1F06
        case 14811:
            param = "1,3,1,Vampiric Touch,2";
            // End:0xEE51
            break;
        // End:0x1F2C
        case 14812:
            param = "1,3,1,Hydro Blast,2";
            // End:0xEE51
            break;
        // End:0x1F50
        case 14813:
            param = "1,3,1,Hurricane,2";
            // End:0xEE51
            break;
        // End:0x1F7A
        case 14814:
            param = "1,3,3,Physical Winter,2";
            // End:0xEE51
            break;
        // End:0x1FA3
        case 14815:
            param = "1,3,3,Physical Bleed,2";
            // End:0xEE51
            break;
        // End:0x1FCB
        case 14816:
            param = "1,3,3,Physical Fear,2";
            // End:0xEE51
            break;
        // End:0x1FF3
        case 14817:
            param = "1,3,3,Physical Hold,2";
            // End:0xEE51
            break;
        // End:0x201D
        case 14818:
            param = "1,3,3,Physical Poison,2";
            // End:0xEE51
            break;
        // End:0x2047
        case 14819:
            param = "1,3,3,Physical Medusa,2";
            // End:0xEE51
            break;
        // End:0x2071
        case 14820:
            param = "1,3,3,Critical Winter,2";
            // End:0xEE51
            break;
        // End:0x209A
        case 14821:
            param = "1,3,3,Critical Bleed,2";
            // End:0xEE51
            break;
        // End:0x20C2
        case 14822:
            param = "1,3,3,Critical Fear,2";
            // End:0xEE51
            break;
        // End:0x20EA
        case 14823:
            param = "1,3,3,Critical Hold,2";
            // End:0xEE51
            break;
        // End:0x2114
        case 14824:
            param = "1,3,3,Critical Poison,2";
            // End:0xEE51
            break;
        // End:0x213E
        case 14825:
            param = "1,3,3,Critical Medusa,2";
            // End:0xEE51
            break;
        // End:0x215F
        case 14826:
            param = "1,3,3,Winter,2";
            // End:0xEE51
            break;
        // End:0x2181
        case 14827:
            param = "1,3,3,Agility,2";
            // End:0xEE51
            break;
        // End:0x21A1
        case 14828:
            param = "1,3,3,Bleed,2";
            // End:0xEE51
            break;
        // End:0x21C2
        case 14829:
            param = "1,3,3,Ritual,2";
            // End:0xEE51
            break;
        // End:0x21E2
        case 14830:
            param = "1,3,3,Focus,2";
            // End:0xEE51
            break;
        // End:0x2202
        case 14831:
            param = "1,3,3,Charm,2";
            // End:0xEE51
            break;
        // End:0x2225
        case 14832:
            param = "1,3,3,Guidance,2";
            // End:0xEE51
            break;
        // End:0x2244
        case 14833:
            param = "1,3,3,Hold,2";
            // End:0xEE51
            break;
        // End:0x2265
        case 14834:
            param = "1,3,3,Prayer,2";
            // End:0xEE51
            break;
        // End:0x2284
        case 14835:
            param = "1,3,3,Heal,2";
            // End:0xEE51
            break;
        // End:0x22A6
        case 14836:
            param = "1,3,3,Empower,2";
            // End:0xEE51
            break;
        // End:0x22CB
        case 14837:
            param = "1,3,3,Wild Magic,2";
            // End:0xEE51
            break;
        // End:0x22EB
        case 14838:
            param = "1,3,3,Cheer,2";
            // End:0xEE51
            break;
        // End:0x2312
        case 14839:
            param = "1,3,3,Blessed Body,2";
            // End:0xEE51
            break;
        // End:0x2339
        case 14840:
            param = "1,3,3,Blessed Soul,2";
            // End:0xEE51
            break;
        // End:0x2361
        case 14841:
            param = "1,3,3,Magic Barrier,2";
            // End:0xEE51
            break;
        // End:0x2381
        case 14842:
            param = "1,3,3,Might,2";
            // End:0xEE51
            break;
        // End:0x23A2
        case 14843:
            param = "1,3,3,Shield,2";
            // End:0xEE51
            break;
        // End:0x23C3
        case 14844:
            param = "1,3,3,Poison,2";
            // End:0xEE51
            break;
        // End:0x23EB
        case 14845:
            param = "1,3,3,Duel Weakness,2";
            // End:0xEE51
            break;
        // End:0x2410
        case 14846:
            param = "1,3,3,Duel Might,2";
            // End:0xEE51
            break;
        // End:0x2430
        case 14847:
            param = "1,3,3,Sleep,2";
            // End:0xEE51
            break;
        // End:0x244F
        case 14848:
            param = "1,3,3,Slow,2";
            // End:0xEE51
            break;
        // End:0x2478
        case 14849:
            param = "1,3,3,Magical Winter,2";
            // End:0xEE51
            break;
        // End:0x24A0
        case 14850:
            param = "1,3,3,Magical Bleed,2";
            // End:0xEE51
            break;
        // End:0x24C7
        case 14851:
            param = "1,3,3,Magical Fear,2";
            // End:0xEE51
            break;
        // End:0x24EE
        case 14852:
            param = "1,3,3,Magical Hold,2";
            // End:0xEE51
            break;
        // End:0x2517
        case 14853:
            param = "1,3,3,Magical Poison,2";
            // End:0xEE51
            break;
        // End:0x2540
        case 14854:
            param = "1,3,3,Magical Medusa,2";
            // End:0xEE51
            break;
        // End:0x2567
        case 14855:
            param = "1,3,2,Heal Empower,2";
            // End:0xEE51
            break;
        // End:0x2588
        case 14856:
            param = "1,3,2,Prayer,2";
            // End:0xEE51
            break;
        // End:0x25AA
        case 14857:
            param = "1,3,2,Empower,2";
            // End:0xEE51
            break;
        // End:0x25D2
        case 14858:
            param = "1,3,2,Magic Barrier,2";
            // End:0xEE51
            break;
        // End:0x25F2
        case 14859:
            param = "1,3,2,Might,2";
            // End:0xEE51
            break;
        // End:0x2613
        case 14860:
            param = "1,3,2,Shield,2";
            // End:0xEE51
            break;
        // End:0x2638
        case 14861:
            param = "1,3,2,Duel Might,2";
            // End:0xEE51
            break;
        // End:0x265F
        case 14862:
            param = "1,3,2,Weight Limit,2";
            // End:0xEE51
            break;
        // End:0x267F
        case 14863:
            param = "1,4,1,Focus,2";
            // End:0xEE51
            break;
        // End:0x269F
        case 14864:
            param = "1,4,1,Focus,2";
            // End:0xEE51
            break;
        // End:0x26BF
        case 14865:
            param = "1,4,1,Focus,2";
            // End:0xEE51
            break;
        // End:0x26DF
        case 14866:
            param = "1,4,1,Focus,2";
            // End:0xEE51
            break;
        // End:0x26FE
        case 14867:
            param = "1,4,1,Doom,2";
            // End:0xEE51
            break;
        // End:0x271F
        case 14868:
            param = "1,4,1,Recall,2";
            // End:0xEE51
            break;
        // End:0x274A
        case 14869:
            param = "1,4,1,Celestial Shield,1";
            // End:0xEE51
            break;
        // End:0x276F
        case 14870:
            param = "1,4,1,Wild Magic,2";
            // End:0xEE51
            break;
        // End:0x2796
        case 14871:
            param = "1,4,1,Party Recall,1";
            // End:0xEE51
            break;
        // End:0x27B8
        case 14872:
            param = "1,4,1,Silence,2";
            // End:0xEE51
            break;
        // End:0x27D9
        case 14873:
            param = "1,4,1,Recall,2";
            // End:0xEE51
            break;
        // End:0x27FA
        case 14874:
            param = "1,4,1,Recall,2";
            // End:0xEE51
            break;
        // End:0x281C
        case 14875:
            param = "1,4,1,Silence,2";
            // End:0xEE51
            break;
        // End:0x283E
        case 14876:
            param = "1,4,1,Silence,2";
            // End:0xEE51
            break;
        // End:0x2860
        case 14877:
            param = "1,4,1,Silence,2";
            // End:0xEE51
            break;
        // End:0x2882
        case 14878:
            param = "1,4,1,Silence,2";
            // End:0xEE51
            break;
        // End:0x28A4
        case 14879:
            param = "1,4,1,Silence,2";
            // End:0xEE51
            break;
        // End:0x28CC
        case 14880:
            param = "1,4,1,Vampiric Rage,2";
            // End:0xEE51
            break;
        // End:0x28F4
        case 14881:
            param = "1,4,3,Physical Doom,2";
            // End:0xEE51
            break;
        // End:0x2921
        case 14882:
            param = "1,4,3,Physical Mana Burn,2";
            // End:0xEE51
            break;
        // End:0x294D
        case 14883:
            param = "1,4,3,Physical Paralyze,2";
            // End:0xEE51
            break;
        // End:0x2978
        case 14884:
            param = "1,4,3,Physical Silence,2";
            // End:0xEE51
            break;
        // End:0x29A1
        case 14885:
            param = "1,4,3,Physical Sleep,2";
            // End:0xEE51
            break;
        // End:0x29C9
        case 14886:
            param = "1,4,3,Physical Stun,2";
            // End:0xEE51
            break;
        // End:0x29F1
        case 14887:
            param = "1,4,3,Critical Doom,2";
            // End:0xEE51
            break;
        // End:0x2A1E
        case 14888:
            param = "1,4,3,Critical Mana Burn,2";
            // End:0xEE51
            break;
        // End:0x2A4A
        case 14889:
            param = "1,4,3,Critical Paralyze,2";
            // End:0xEE51
            break;
        // End:0x2A75
        case 14890:
            param = "1,4,3,Critical Silence,2";
            // End:0xEE51
            break;
        // End:0x2A9E
        case 14891:
            param = "1,4,3,Critical Sleep,2";
            // End:0xEE51
            break;
        // End:0x2AC6
        case 14892:
            param = "1,4,3,Critical Stun,2";
            // End:0xEE51
            break;
        // End:0x2AE5
        case 14893:
            param = "1,4,3,Doom,2";
            // End:0xEE51
            break;
        // End:0x2B04
        case 14894:
            param = "1,4,3,Fear,2";
            // End:0xEE51
            break;
        // End:0x2B28
        case 14895:
            param = "1,4,3,Mana Gain,2";
            // End:0xEE51
            break;
        // End:0x2B4B
        case 14896:
            param = "1,4,3,Recharge,2";
            // End:0xEE51
            break;
        // End:0x2B6E
        case 14897:
            param = "1,4,3,Paralyze,2";
            // End:0xEE51
            break;
        // End:0x2B90
        case 14898:
            param = "1,4,3,Silence,2";
            // End:0xEE51
            break;
        // End:0x2BAF
        case 14899:
            param = "1,4,3,Stun,2";
            // End:0xEE51
            break;
        // End:0x2BD0
        case 14900:
            param = "1,4,3,Medusa,2";
            // End:0xEE51
            break;
        // End:0x2BF7
        case 14901:
            param = "1,4,3,Magical Doom,2";
            // End:0xEE51
            break;
        // End:0x2C23
        case 14902:
            param = "1,4,3,Magical Mana Burn,2";
            // End:0xEE51
            break;
        // End:0x2C4E
        case 14903:
            param = "1,4,3,Magical Paralyze,2";
            // End:0xEE51
            break;
        // End:0x2C78
        case 14904:
            param = "1,4,3,Magical Silence,2";
            // End:0xEE51
            break;
        // End:0x2CA0
        case 14905:
            param = "1,4,3,Magical Sleep,2";
            // End:0xEE51
            break;
        // End:0x2CC7
        case 14906:
            param = "1,4,3,Magical Stun,2";
            // End:0xEE51
            break;
        // End:0x2CE9
        case 14907:
            param = "1,4,2,Agility,2";
            // End:0xEE51
            break;
        // End:0x2D0B
        case 14908:
            param = "1,4,2,Agility,2";
            // End:0xEE51
            break;
        // End:0x2D2B
        case 14909:
            param = "1,4,2,Focus,2";
            // End:0xEE51
            break;
        // End:0x2D4B
        case 14910:
            param = "1,4,2,Focus,2";
            // End:0xEE51
            break;
        // End:0x2D6E
        case 14911:
            param = "1,4,2,Guidance,2";
            // End:0xEE51
            break;
        // End:0x2D93
        case 14912:
            param = "1,4,2,Wild Magic,2";
            // End:0xEE51
            break;
        // End:0x2DB7
        case 14913:
            param = "1,4,2,Mana Gain,2";
            // End:0xEE51
            break;
        // End:0x2DDB
        case 14914:
            param = "1,4,2,Mana Gain,2";
            // End:0xEE51
            break;
        // End:0x2DFF
        case 14915:
            param = "1,4,2,Mana Gain,2";
            // End:0xEE51
            break;
        // End:0x2E23
        case 14916:
            param = "1,4,2,Mana Gain,2";
            // End:0xEE51
            break;
        // End:0x2E44
        case 14934:
            param = "1,3,1,Winter,3";
            // End:0xEE51
            break;
        // End:0x2E66
        case 14935:
            param = "1,3,1,Agility,3";
            // End:0xEE51
            break;
        // End:0x2E86
        case 14936:
            param = "1,3,1,Bleed,3";
            // End:0xEE51
            break;
        // End:0x2EA7
        case 14937:
            param = "1,3,1,Ritual,3";
            // End:0xEE51
            break;
        // End:0x2EC7
        case 14938:
            param = "1,3,1,Stone,3";
            // End:0xEE51
            break;
        // End:0x2EE6
        case 14939:
            param = "1,3,1,Fear,3";
            // End:0xEE51
            break;
        // End:0x2F0B
        case 14940:
            param = "1,3,1,Prominence,3";
            // End:0xEE51
            break;
        // End:0x2F2B
        case 14941:
            param = "1,3,1,Peace,3";
            // End:0xEE51
            break;
        // End:0x2F4B
        case 14942:
            param = "1,3,1,Charm,3";
            // End:0xEE51
            break;
        // End:0x2F70
        case 14943:
            param = "1,3,1,Aggression,3";
            // End:0xEE51
            break;
        // End:0x2F93
        case 14944:
            param = "1,3,1,Guidance,3";
            // End:0xEE51
            break;
        // End:0x2FB2
        case 14945:
            param = "1,3,1,Hold,3";
            // End:0xEE51
            break;
        // End:0x2FD8
        case 14946:
            param = "1,3,1,Solar Flare,3";
            // End:0xEE51
            break;
        // End:0x2FFF
        case 14947:
            param = "1,3,1,Heal Empower,3";
            // End:0xEE51
            break;
        // End:0x3020
        case 14948:
            param = "1,3,1,Prayer,3";
            // End:0xEE51
            break;
        // End:0x303F
        case 14949:
            param = "1,3,1,Heal,3";
            // End:0xEE51
            break;
        // End:0x3061
        case 14950:
            param = "1,3,1,Empower,3";
            // End:0xEE51
            break;
        // End:0x3081
        case 14951:
            param = "1,3,1,Cheer,3";
            // End:0xEE51
            break;
        // End:0x30A7
        case 14952:
            param = "1,3,1,Battle Roar,3";
            // End:0xEE51
            break;
        // End:0x30CE
        case 14953:
            param = "1,3,1,Blessed Body,3";
            // End:0xEE51
            break;
        // End:0x30F5
        case 14954:
            param = "1,3,1,Blessed Soul,3";
            // End:0xEE51
            break;
        // End:0x311D
        case 14955:
            param = "1,3,1,Magic Barrier,3";
            // End:0xEE51
            break;
        // End:0x3141
        case 14956:
            param = "1,3,1,Mana Burn,3";
            // End:0xEE51
            break;
        // End:0x3165
        case 14957:
            param = "1,3,1,Mana Gain,3";
            // End:0xEE51
            break;
        // End:0x3188
        case 14958:
            param = "1,3,1,Recharge,3";
            // End:0xEE51
            break;
        // End:0x31AD
        case 14959:
            param = "1,3,1,Aura Flare,3";
            // End:0xEE51
            break;
        // End:0x31CD
        case 14960:
            param = "1,3,1,Might,3";
            // End:0xEE51
            break;
        // End:0x31F0
        case 14961:
            param = "1,3,1,Paralyze,3";
            // End:0xEE51
            break;
        // End:0x3211
        case 14962:
            param = "1,3,1,Shield,3";
            // End:0xEE51
            break;
        // End:0x3232
        case 14963:
            param = "1,3,1,Poison,3";
            // End:0xEE51
            break;
        // End:0x325A
        case 14964:
            param = "1,3,1,Duel Weakness,3";
            // End:0xEE51
            break;
        // End:0x327F
        case 14965:
            param = "1,3,1,Duel Might,3";
            // End:0xEE51
            break;
        // End:0x32A0
        case 14966:
            param = "1,3,1,Recall,1";
            // End:0xEE51
            break;
        // End:0x32C7
        case 14967:
            param = "1,3,1,Resurrection,3";
            // End:0xEE51
            break;
        // End:0x32EC
        case 14968:
            param = "1,3,1,Self Stone,3";
            // End:0xEE51
            break;
        // End:0x3316
        case 14969:
            param = "1,3,1,Self Prominence,3";
            // End:0xEE51
            break;
        // End:0x3341
        case 14970:
            param = "1,3,1,Self Solar Flare,3";
            // End:0xEE51
            break;
        // End:0x336B
        case 14971:
            param = "1,3,1,Self Aura Flare,3";
            // End:0xEE51
            break;
        // End:0x3397
        case 14972:
            param = "1,3,1,Self Shadow Flare,3";
            // End:0xEE51
            break;
        // End:0x33C2
        case 14973:
            param = "1,3,1,Self Hydro Blast,3";
            // End:0xEE51
            break;
        // End:0x33EB
        case 14974:
            param = "1,3,1,Self Hurricane,3";
            // End:0xEE51
            break;
        // End:0x340B
        case 14975:
            param = "1,3,1,Sleep,3";
            // End:0xEE51
            break;
        // End:0x342A
        case 14976:
            param = "1,3,1,Slow,3";
            // End:0xEE51
            break;
        // End:0x3449
        case 14977:
            param = "1,3,1,Stun,3";
            // End:0xEE51
            break;
        // End:0x346C
        case 14978:
            param = "1,3,1,Ae Stone,3";
            // End:0xEE51
            break;
        // End:0x3494
        case 14979:
            param = "1,3,1,Ae Prominence,3";
            // End:0xEE51
            break;
        // End:0x34BD
        case 14980:
            param = "1,3,1,Ae Solar Flare,3";
            // End:0xEE51
            break;
        // End:0x34E5
        case 14981:
            param = "1,3,1,Ae Aura Flare,3";
            // End:0xEE51
            break;
        // End:0x350F
        case 14982:
            param = "1,3,1,Ae Shadow Flare,3";
            // End:0xEE51
            break;
        // End:0x3538
        case 14983:
            param = "1,3,1,Ae Hydro Blast,3";
            // End:0xEE51
            break;
        // End:0x355F
        case 14984:
            param = "1,3,1,Ae Hurricane,3";
            // End:0xEE51
            break;
        // End:0x357F
        case 14985:
            param = "1,3,1,Trick,3";
            // End:0xEE51
            break;
        // End:0x35A0
        case 14986:
            param = "1,3,1,Medusa,3";
            // End:0xEE51
            break;
        // End:0x35C7
        case 14987:
            param = "1,3,1,Shadow Flare,3";
            // End:0xEE51
            break;
        // End:0x35E8
        case 14988:
            param = "1,3,1,Unlock,3";
            // End:0xEE51
            break;
        // End:0x3611
        case 14989:
            param = "1,3,1,Vampiric Touch,3";
            // End:0xEE51
            break;
        // End:0x3637
        case 14990:
            param = "1,3,1,Hydro Blast,3";
            // End:0xEE51
            break;
        // End:0x365B
        case 14991:
            param = "1,3,1,Hurricane,3";
            // End:0xEE51
            break;
        // End:0x3685
        case 14992:
            param = "1,3,3,Physical Winter,3";
            // End:0xEE51
            break;
        // End:0x36AE
        case 14993:
            param = "1,3,3,Physical Bleed,3";
            // End:0xEE51
            break;
        // End:0x36D6
        case 14994:
            param = "1,3,3,Physical Fear,3";
            // End:0xEE51
            break;
        // End:0x36FE
        case 14995:
            param = "1,3,3,Physical Hold,3";
            // End:0xEE51
            break;
        // End:0x3728
        case 14996:
            param = "1,3,3,Physical Poison,3";
            // End:0xEE51
            break;
        // End:0x3752
        case 14997:
            param = "1,3,3,Physical Medusa,3";
            // End:0xEE51
            break;
        // End:0x377C
        case 14998:
            param = "1,3,3,Critical Winter,3";
            // End:0xEE51
            break;
        // End:0x37A5
        case 14999:
            param = "1,3,3,Critical Bleed,3";
            // End:0xEE51
            break;
        // End:0x37CD
        case 15000:
            param = "1,3,3,Critical Fear,3";
            // End:0xEE51
            break;
        // End:0x37F5
        case 15001:
            param = "1,3,3,Critical Hold,3";
            // End:0xEE51
            break;
        // End:0x381F
        case 15002:
            param = "1,3,3,Critical Poison,3";
            // End:0xEE51
            break;
        // End:0x3849
        case 15003:
            param = "1,3,3,Critical Medusa,3";
            // End:0xEE51
            break;
        // End:0x386A
        case 15004:
            param = "1,3,3,Winter,3";
            // End:0xEE51
            break;
        // End:0x388C
        case 15005:
            param = "1,3,3,Agility,3";
            // End:0xEE51
            break;
        // End:0x38AC
        case 15006:
            param = "1,3,3,Bleed,3";
            // End:0xEE51
            break;
        // End:0x38CD
        case 15007:
            param = "1,3,3,Ritual,3";
            // End:0xEE51
            break;
        // End:0x38ED
        case 15008:
            param = "1,3,3,Focus,3";
            // End:0xEE51
            break;
        // End:0x390D
        case 15009:
            param = "1,3,3,Charm,3";
            // End:0xEE51
            break;
        // End:0x3930
        case 15010:
            param = "1,3,3,Guidance,3";
            // End:0xEE51
            break;
        // End:0x394F
        case 15011:
            param = "1,3,3,Hold,3";
            // End:0xEE51
            break;
        // End:0x3970
        case 15012:
            param = "1,3,3,Prayer,3";
            // End:0xEE51
            break;
        // End:0x398F
        case 15013:
            param = "1,3,3,Heal,3";
            // End:0xEE51
            break;
        // End:0x39B1
        case 15014:
            param = "1,3,3,Empower,3";
            // End:0xEE51
            break;
        // End:0x39D6
        case 15015:
            param = "1,3,3,Wild Magic,3";
            // End:0xEE51
            break;
        // End:0x39F6
        case 15016:
            param = "1,3,3,Cheer,3";
            // End:0xEE51
            break;
        // End:0x3A1D
        case 15017:
            param = "1,3,3,Blessed Body,3";
            // End:0xEE51
            break;
        // End:0x3A44
        case 15018:
            param = "1,3,3,Blessed Soul,3";
            // End:0xEE51
            break;
        // End:0x3A6C
        case 15019:
            param = "1,3,3,Magic Barrier,3";
            // End:0xEE51
            break;
        // End:0x3A8C
        case 15020:
            param = "1,3,3,Might,3";
            // End:0xEE51
            break;
        // End:0x3AAD
        case 15021:
            param = "1,3,3,Shield,3";
            // End:0xEE51
            break;
        // End:0x3ACE
        case 15022:
            param = "1,3,3,Poison,3";
            // End:0xEE51
            break;
        // End:0x3AF6
        case 15023:
            param = "1,3,3,Duel Weakness,3";
            // End:0xEE51
            break;
        // End:0x3B1B
        case 15024:
            param = "1,3,3,Duel Might,3";
            // End:0xEE51
            break;
        // End:0x3B3B
        case 15025:
            param = "1,3,3,Sleep,3";
            // End:0xEE51
            break;
        // End:0x3B5A
        case 15026:
            param = "1,3,3,Slow,3";
            // End:0xEE51
            break;
        // End:0x3B83
        case 15027:
            param = "1,3,3,Magical Winter,3";
            // End:0xEE51
            break;
        // End:0x3BAB
        case 15028:
            param = "1,3,3,Magical Bleed,3";
            // End:0xEE51
            break;
        // End:0x3BD2
        case 15029:
            param = "1,3,3,Magical Fear,3";
            // End:0xEE51
            break;
        // End:0x3BF9
        case 15030:
            param = "1,3,3,Magical Hold,3";
            // End:0xEE51
            break;
        // End:0x3C22
        case 15031:
            param = "1,3,3,Magical Poison,3";
            // End:0xEE51
            break;
        // End:0x3C4B
        case 15032:
            param = "1,3,3,Magical Medusa,3";
            // End:0xEE51
            break;
        // End:0x3C72
        case 15033:
            param = "1,3,2,Heal Empower,3";
            // End:0xEE51
            break;
        // End:0x3C93
        case 15034:
            param = "1,3,2,Prayer,3";
            // End:0xEE51
            break;
        // End:0x3CB5
        case 15035:
            param = "1,3,2,Empower,3";
            // End:0xEE51
            break;
        // End:0x3CDD
        case 15036:
            param = "1,3,2,Magic Barrier,3";
            // End:0xEE51
            break;
        // End:0x3CFD
        case 15037:
            param = "1,3,2,Might,3";
            // End:0xEE51
            break;
        // End:0x3D1E
        case 15038:
            param = "1,3,2,Shield,3";
            // End:0xEE51
            break;
        // End:0x3D43
        case 15039:
            param = "1,3,2,Duel Might,3";
            // End:0xEE51
            break;
        // End:0x3D6A
        case 15040:
            param = "1,3,2,Weight Limit,3";
            // End:0xEE51
            break;
        // End:0x3D8A
        case 15041:
            param = "1,4,1,Focus,3";
            // End:0xEE51
            break;
        // End:0x3DAA
        case 15042:
            param = "1,4,1,Focus,3";
            // End:0xEE51
            break;
        // End:0x3DCA
        case 15043:
            param = "1,4,1,Focus,3";
            // End:0xEE51
            break;
        // End:0x3DEA
        case 15044:
            param = "1,4,1,Focus,3";
            // End:0xEE51
            break;
        // End:0x3E09
        case 15045:
            param = "1,4,1,Doom,3";
            // End:0xEE51
            break;
        // End:0x3E2A
        case 15046:
            param = "1,4,1,Recall,2";
            // End:0xEE51
            break;
        // End:0x3E55
        case 15047:
            param = "1,4,1,Celestial Shield,1";
            // End:0xEE51
            break;
        // End:0x3E7A
        case 15048:
            param = "1,4,1,Wild Magic,3";
            // End:0xEE51
            break;
        // End:0x3EA1
        case 15049:
            param = "1,4,1,Party Recall,1";
            // End:0xEE51
            break;
        // End:0x3EC3
        case 15050:
            param = "1,4,1,Silence,3";
            // End:0xEE51
            break;
        // End:0x3EEA
        case 15051:
            param = "1,4,1,Party Recall,1";
            // End:0xEE51
            break;
        // End:0x3F11
        case 15052:
            param = "1,4,1,Party Recall,1";
            // End:0xEE51
            break;
        // End:0x3F38
        case 15053:
            param = "1,4,1,Party Recall,1";
            // End:0xEE51
            break;
        // End:0x3F5A
        case 15054:
            param = "1,4,1,Silence,3";
            // End:0xEE51
            break;
        // End:0x3F7C
        case 15055:
            param = "1,4,1,Silence,3";
            // End:0xEE51
            break;
        // End:0x3F9E
        case 15056:
            param = "1,4,1,Silence,3";
            // End:0xEE51
            break;
        // End:0x3FC0
        case 15057:
            param = "1,4,1,Silence,3";
            // End:0xEE51
            break;
        // End:0x3FE8
        case 15058:
            param = "1,4,1,Vampiric Rage,3";
            // End:0xEE51
            break;
        // End:0x4010
        case 15059:
            param = "1,4,3,Physical Doom,3";
            // End:0xEE51
            break;
        // End:0x403D
        case 15060:
            param = "1,4,3,Physical Mana Burn,3";
            // End:0xEE51
            break;
        // End:0x4069
        case 15061:
            param = "1,4,3,Physical Paralyze,3";
            // End:0xEE51
            break;
        // End:0x4094
        case 15062:
            param = "1,4,3,Physical Silence,3";
            // End:0xEE51
            break;
        // End:0x40BD
        case 15063:
            param = "1,4,3,Physical Sleep,3";
            // End:0xEE51
            break;
        // End:0x40E5
        case 15064:
            param = "1,4,3,Physical Stun,3";
            // End:0xEE51
            break;
        // End:0x410D
        case 15065:
            param = "1,4,3,Critical Doom,3";
            // End:0xEE51
            break;
        // End:0x413A
        case 15066:
            param = "1,4,3,Critical Mana Burn,3";
            // End:0xEE51
            break;
        // End:0x4166
        case 15067:
            param = "1,4,3,Critical Paralyze,3";
            // End:0xEE51
            break;
        // End:0x4191
        case 15068:
            param = "1,4,3,Critical Silence,3";
            // End:0xEE51
            break;
        // End:0x41BA
        case 15069:
            param = "1,4,3,Critical Sleep,3";
            // End:0xEE51
            break;
        // End:0x41E2
        case 15070:
            param = "1,4,3,Critical Stun,3";
            // End:0xEE51
            break;
        // End:0x4201
        case 15071:
            param = "1,4,3,Doom,3";
            // End:0xEE51
            break;
        // End:0x4220
        case 15072:
            param = "1,4,3,Fear,3";
            // End:0xEE51
            break;
        // End:0x4244
        case 15073:
            param = "1,4,3,Mana Gain,3";
            // End:0xEE51
            break;
        // End:0x4267
        case 15074:
            param = "1,4,3,Recharge,3";
            // End:0xEE51
            break;
        // End:0x428A
        case 15075:
            param = "1,4,3,Paralyze,3";
            // End:0xEE51
            break;
        // End:0x42AC
        case 15076:
            param = "1,4,3,Silence,3";
            // End:0xEE51
            break;
        // End:0x42CB
        case 15077:
            param = "1,4,3,Stun,3";
            // End:0xEE51
            break;
        // End:0x42EC
        case 15078:
            param = "1,4,3,Medusa,3";
            // End:0xEE51
            break;
        // End:0x4313
        case 15079:
            param = "1,4,3,Magical Doom,3";
            // End:0xEE51
            break;
        // End:0x433F
        case 15080:
            param = "1,4,3,Magical Mana Burn,3";
            // End:0xEE51
            break;
        // End:0x436A
        case 15081:
            param = "1,4,3,Magical Paralyze,3";
            // End:0xEE51
            break;
        // End:0x4394
        case 15082:
            param = "1,4,3,Magical Silence,3";
            // End:0xEE51
            break;
        // End:0x43BC
        case 15083:
            param = "1,4,3,Magical Sleep,3";
            // End:0xEE51
            break;
        // End:0x43E3
        case 15084:
            param = "1,4,3,Magical Stun,3";
            // End:0xEE51
            break;
        // End:0x4405
        case 15085:
            param = "1,4,2,Agility,3";
            // End:0xEE51
            break;
        // End:0x4427
        case 15086:
            param = "1,4,2,Agility,3";
            // End:0xEE51
            break;
        // End:0x4447
        case 15087:
            param = "1,4,2,Focus,3";
            // End:0xEE51
            break;
        // End:0x4467
        case 15088:
            param = "1,4,2,Focus,3";
            // End:0xEE51
            break;
        // End:0x448A
        case 15089:
            param = "1,4,2,Guidance,3";
            // End:0xEE51
            break;
        // End:0x44AF
        case 15090:
            param = "1,4,2,Wild Magic,3";
            // End:0xEE51
            break;
        // End:0x44D3
        case 15091:
            param = "1,4,2,Mana Gain,3";
            // End:0xEE51
            break;
        // End:0x44F7
        case 15092:
            param = "1,4,2,Mana Gain,3";
            // End:0xEE51
            break;
        // End:0x451B
        case 15093:
            param = "1,4,2,Mana Gain,3";
            // End:0xEE51
            break;
        // End:0x453F
        case 15094:
            param = "1,4,2,Mana Gain,3";
            // End:0xEE51
            break;
        // End:0x4560
        case 15112:
            param = "1,3,1,Winter,4";
            // End:0xEE51
            break;
        // End:0x4582
        case 15113:
            param = "1,3,1,Agility,4";
            // End:0xEE51
            break;
        // End:0x45A2
        case 15114:
            param = "1,3,1,Bleed,4";
            // End:0xEE51
            break;
        // End:0x45C3
        case 15115:
            param = "1,3,1,Ritual,4";
            // End:0xEE51
            break;
        // End:0x45E3
        case 15116:
            param = "1,3,1,Stone,4";
            // End:0xEE51
            break;
        // End:0x4602
        case 15117:
            param = "1,3,1,Fear,4";
            // End:0xEE51
            break;
        // End:0x4627
        case 15118:
            param = "1,3,1,Prominence,4";
            // End:0xEE51
            break;
        // End:0x4647
        case 15119:
            param = "1,3,1,Peace,4";
            // End:0xEE51
            break;
        // End:0x4667
        case 15120:
            param = "1,3,1,Charm,4";
            // End:0xEE51
            break;
        // End:0x468C
        case 15121:
            param = "1,3,1,Aggression,4";
            // End:0xEE51
            break;
        // End:0x46AF
        case 15122:
            param = "1,3,1,Guidance,4";
            // End:0xEE51
            break;
        // End:0x46CE
        case 15123:
            param = "1,3,1,Hold,4";
            // End:0xEE51
            break;
        // End:0x46F4
        case 15124:
            param = "1,3,1,Solar Flare,4";
            // End:0xEE51
            break;
        // End:0x471B
        case 15125:
            param = "1,3,1,Heal Empower,4";
            // End:0xEE51
            break;
        // End:0x473C
        case 15126:
            param = "1,3,1,Prayer,4";
            // End:0xEE51
            break;
        // End:0x475B
        case 15127:
            param = "1,3,1,Heal,4";
            // End:0xEE51
            break;
        // End:0x477D
        case 15128:
            param = "1,3,1,Empower,4";
            // End:0xEE51
            break;
        // End:0x479D
        case 15129:
            param = "1,3,1,Cheer,4";
            // End:0xEE51
            break;
        // End:0x47C3
        case 15130:
            param = "1,3,1,Battle Roar,4";
            // End:0xEE51
            break;
        // End:0x47EA
        case 15131:
            param = "1,3,1,Blessed Body,4";
            // End:0xEE51
            break;
        // End:0x4811
        case 15132:
            param = "1,3,1,Blessed Soul,4";
            // End:0xEE51
            break;
        // End:0x4839
        case 15133:
            param = "1,3,1,Magic Barrier,4";
            // End:0xEE51
            break;
        // End:0x485D
        case 15134:
            param = "1,3,1,Mana Burn,4";
            // End:0xEE51
            break;
        // End:0x4881
        case 15135:
            param = "1,3,1,Mana Gain,4";
            // End:0xEE51
            break;
        // End:0x48A4
        case 15136:
            param = "1,3,1,Recharge,4";
            // End:0xEE51
            break;
        // End:0x48C9
        case 15137:
            param = "1,3,1,Aura Flare,4";
            // End:0xEE51
            break;
        // End:0x48E9
        case 15138:
            param = "1,3,1,Might,4";
            // End:0xEE51
            break;
        // End:0x490C
        case 15139:
            param = "1,3,1,Paralyze,4";
            // End:0xEE51
            break;
        // End:0x492D
        case 15140:
            param = "1,3,1,Shield,4";
            // End:0xEE51
            break;
        // End:0x494E
        case 15141:
            param = "1,3,1,Poison,4";
            // End:0xEE51
            break;
        // End:0x4976
        case 15142:
            param = "1,3,1,Duel Weakness,4";
            // End:0xEE51
            break;
        // End:0x499B
        case 15143:
            param = "1,3,1,Duel Might,4";
            // End:0xEE51
            break;
        // End:0x49BC
        case 15144:
            param = "1,3,1,Recall,1";
            // End:0xEE51
            break;
        // End:0x49E3
        case 15145:
            param = "1,3,1,Resurrection,4";
            // End:0xEE51
            break;
        // End:0x4A08
        case 15146:
            param = "1,3,1,Self Stone,4";
            // End:0xEE51
            break;
        // End:0x4A32
        case 15147:
            param = "1,3,1,Self Prominence,4";
            // End:0xEE51
            break;
        // End:0x4A5D
        case 15148:
            param = "1,3,1,Self Solar Flare,4";
            // End:0xEE51
            break;
        // End:0x4A87
        case 15149:
            param = "1,3,1,Self Aura Flare,4";
            // End:0xEE51
            break;
        // End:0x4AB3
        case 15150:
            param = "1,3,1,Self Shadow Flare,4";
            // End:0xEE51
            break;
        // End:0x4ADE
        case 15151:
            param = "1,3,1,Self Hydro Blast,4";
            // End:0xEE51
            break;
        // End:0x4B07
        case 15152:
            param = "1,3,1,Self Hurricane,4";
            // End:0xEE51
            break;
        // End:0x4B27
        case 15153:
            param = "1,3,1,Sleep,4";
            // End:0xEE51
            break;
        // End:0x4B46
        case 15154:
            param = "1,3,1,Slow,4";
            // End:0xEE51
            break;
        // End:0x4B65
        case 15155:
            param = "1,3,1,Stun,4";
            // End:0xEE51
            break;
        // End:0x4B88
        case 15156:
            param = "1,3,1,Ae Stone,4";
            // End:0xEE51
            break;
        // End:0x4BB0
        case 15157:
            param = "1,3,1,Ae Prominence,4";
            // End:0xEE51
            break;
        // End:0x4BD9
        case 15158:
            param = "1,3,1,Ae Solar Flare,4";
            // End:0xEE51
            break;
        // End:0x4C01
        case 15159:
            param = "1,3,1,Ae Aura Flare,4";
            // End:0xEE51
            break;
        // End:0x4C2B
        case 15160:
            param = "1,3,1,Ae Shadow Flare,4";
            // End:0xEE51
            break;
        // End:0x4C54
        case 15161:
            param = "1,3,1,Ae Hydro Blast,4";
            // End:0xEE51
            break;
        // End:0x4C7B
        case 15162:
            param = "1,3,1,Ae Hurricane,4";
            // End:0xEE51
            break;
        // End:0x4C9B
        case 15163:
            param = "1,3,1,Trick,4";
            // End:0xEE51
            break;
        // End:0x4CBC
        case 15164:
            param = "1,3,1,Medusa,4";
            // End:0xEE51
            break;
        // End:0x4CE3
        case 15165:
            param = "1,3,1,Shadow Flare,4";
            // End:0xEE51
            break;
        // End:0x4D04
        case 15166:
            param = "1,3,1,Unlock,4";
            // End:0xEE51
            break;
        // End:0x4D2D
        case 15167:
            param = "1,3,1,Vampiric Touch,4";
            // End:0xEE51
            break;
        // End:0x4D53
        case 15168:
            param = "1,3,1,Hydro Blast,4";
            // End:0xEE51
            break;
        // End:0x4D77
        case 15169:
            param = "1,3,1,Hurricane,4";
            // End:0xEE51
            break;
        // End:0x4DA1
        case 15170:
            param = "1,3,3,Physical Winter,4";
            // End:0xEE51
            break;
        // End:0x4DCA
        case 15171:
            param = "1,3,3,Physical Bleed,4";
            // End:0xEE51
            break;
        // End:0x4DF2
        case 15172:
            param = "1,3,3,Physical Fear,4";
            // End:0xEE51
            break;
        // End:0x4E1A
        case 15173:
            param = "1,3,3,Physical Hold,4";
            // End:0xEE51
            break;
        // End:0x4E44
        case 15174:
            param = "1,3,3,Physical Poison,4";
            // End:0xEE51
            break;
        // End:0x4E6E
        case 15175:
            param = "1,3,3,Physical Medusa,4";
            // End:0xEE51
            break;
        // End:0x4E98
        case 15176:
            param = "1,3,3,Critical Winter,4";
            // End:0xEE51
            break;
        // End:0x4EC1
        case 15177:
            param = "1,3,3,Critical Bleed,4";
            // End:0xEE51
            break;
        // End:0x4EE9
        case 15178:
            param = "1,3,3,Critical Fear,4";
            // End:0xEE51
            break;
        // End:0x4F11
        case 15179:
            param = "1,3,3,Critical Hold,4";
            // End:0xEE51
            break;
        // End:0x4F3B
        case 15180:
            param = "1,3,3,Critical Poison,4";
            // End:0xEE51
            break;
        // End:0x4F65
        case 15181:
            param = "1,3,3,Critical Medusa,4";
            // End:0xEE51
            break;
        // End:0x4F86
        case 15182:
            param = "1,3,3,Winter,4";
            // End:0xEE51
            break;
        // End:0x4FA8
        case 15183:
            param = "1,3,3,Agility,4";
            // End:0xEE51
            break;
        // End:0x4FC8
        case 15184:
            param = "1,3,3,Bleed,4";
            // End:0xEE51
            break;
        // End:0x4FE9
        case 15185:
            param = "1,3,3,Ritual,4";
            // End:0xEE51
            break;
        // End:0x5009
        case 15186:
            param = "1,3,3,Focus,4";
            // End:0xEE51
            break;
        // End:0x5029
        case 15187:
            param = "1,3,3,Charm,4";
            // End:0xEE51
            break;
        // End:0x504C
        case 15188:
            param = "1,3,3,Guidance,4";
            // End:0xEE51
            break;
        // End:0x506B
        case 15189:
            param = "1,3,3,Hold,4";
            // End:0xEE51
            break;
        // End:0x508C
        case 15190:
            param = "1,3,3,Prayer,4";
            // End:0xEE51
            break;
        // End:0x50AB
        case 15191:
            param = "1,3,3,Heal,4";
            // End:0xEE51
            break;
        // End:0x50CD
        case 15192:
            param = "1,3,3,Empower,4";
            // End:0xEE51
            break;
        // End:0x50F2
        case 15193:
            param = "1,3,3,Wild Magic,4";
            // End:0xEE51
            break;
        // End:0x5112
        case 15194:
            param = "1,3,3,Cheer,4";
            // End:0xEE51
            break;
        // End:0x5139
        case 15195:
            param = "1,3,3,Blessed Body,4";
            // End:0xEE51
            break;
        // End:0x5160
        case 15196:
            param = "1,3,3,Blessed Soul,4";
            // End:0xEE51
            break;
        // End:0x5188
        case 15197:
            param = "1,3,3,Magic Barrier,4";
            // End:0xEE51
            break;
        // End:0x51A8
        case 15198:
            param = "1,3,3,Might,4";
            // End:0xEE51
            break;
        // End:0x51C9
        case 15199:
            param = "1,3,3,Shield,4";
            // End:0xEE51
            break;
        // End:0x51EA
        case 15200:
            param = "1,3,3,Poison,4";
            // End:0xEE51
            break;
        // End:0x5212
        case 15201:
            param = "1,3,3,Duel Weakness,4";
            // End:0xEE51
            break;
        // End:0x5237
        case 15202:
            param = "1,3,3,Duel Might,4";
            // End:0xEE51
            break;
        // End:0x5257
        case 15203:
            param = "1,3,3,Sleep,4";
            // End:0xEE51
            break;
        // End:0x5276
        case 15204:
            param = "1,3,3,Slow,4";
            // End:0xEE51
            break;
        // End:0x529F
        case 15205:
            param = "1,3,3,Magical Winter,4";
            // End:0xEE51
            break;
        // End:0x52C7
        case 15206:
            param = "1,3,3,Magical Bleed,4";
            // End:0xEE51
            break;
        // End:0x52EE
        case 15207:
            param = "1,3,3,Magical Fear,4";
            // End:0xEE51
            break;
        // End:0x5315
        case 15208:
            param = "1,3,3,Magical Hold,4";
            // End:0xEE51
            break;
        // End:0x533E
        case 15209:
            param = "1,3,3,Magical Poison,4";
            // End:0xEE51
            break;
        // End:0x5367
        case 15210:
            param = "1,3,3,Magical Medusa,4";
            // End:0xEE51
            break;
        // End:0x538E
        case 15211:
            param = "1,3,2,Heal Empower,4";
            // End:0xEE51
            break;
        // End:0x53AF
        case 15212:
            param = "1,3,2,Prayer,4";
            // End:0xEE51
            break;
        // End:0x53D1
        case 15213:
            param = "1,3,2,Empower,4";
            // End:0xEE51
            break;
        // End:0x53F9
        case 15214:
            param = "1,3,2,Magic Barrier,4";
            // End:0xEE51
            break;
        // End:0x5419
        case 15215:
            param = "1,3,2,Might,4";
            // End:0xEE51
            break;
        // End:0x543A
        case 15216:
            param = "1,3,2,Shield,4";
            // End:0xEE51
            break;
        // End:0x545F
        case 15217:
            param = "1,3,2,Duel Might,4";
            // End:0xEE51
            break;
        // End:0x5486
        case 15218:
            param = "1,3,2,Weight Limit,4";
            // End:0xEE51
            break;
        // End:0x54A8
        case 15219:
            param = "1,4,1,Refresh,1";
            // End:0xEE51
            break;
        // End:0x54CA
        case 15220:
            param = "1,4,1,Clarity,1";
            // End:0xEE51
            break;
        // End:0x54EA
        case 15221:
            param = "1,4,1,Focus,4";
            // End:0xEE51
            break;
        // End:0x5513
        case 15222:
            param = "1,4,1,Reflect Damage,1";
            // End:0xEE51
            break;
        // End:0x5532
        case 15223:
            param = "1,4,1,Doom,4";
            // End:0xEE51
            break;
        // End:0x5553
        case 15224:
            param = "1,4,1,Recall,2";
            // End:0xEE51
            break;
        // End:0x557E
        case 15225:
            param = "1,4,1,Celestial Shield,1";
            // End:0xEE51
            break;
        // End:0x55A3
        case 15226:
            param = "1,4,1,Wild Magic,4";
            // End:0xEE51
            break;
        // End:0x55CA
        case 15227:
            param = "1,4,1,Party Recall,1";
            // End:0xEE51
            break;
        // End:0x55EC
        case 15228:
            param = "1,4,1,Silence,4";
            // End:0xEE51
            break;
        // End:0x5614
        case 15229:
            param = "1,4,1,Skill Refresh,1";
            // End:0xEE51
            break;
        // End:0x563C
        case 15230:
            param = "1,4,1,Skill Clarity,1";
            // End:0xEE51
            break;
        // End:0x5664
        case 15231:
            param = "1,4,1,Music Refresh,1";
            // End:0xEE51
            break;
        // End:0x568C
        case 15232:
            param = "1,4,1,Music Clarity,1";
            // End:0xEE51
            break;
        // End:0x56B4
        case 15233:
            param = "1,4,1,Spell Refresh,1";
            // End:0xEE51
            break;
        // End:0x56DC
        case 15234:
            param = "1,4,1,Spell Clarity,1";
            // End:0xEE51
            break;
        // End:0x5704
        case 15235:
            param = "1,4,1,Spell Clarity,1";
            // End:0xEE51
            break;
        // End:0x572C
        case 15236:
            param = "1,4,1,Vampiric Rage,4";
            // End:0xEE51
            break;
        // End:0x5754
        case 15237:
            param = "1,4,3,Physical Doom,4";
            // End:0xEE51
            break;
        // End:0x5781
        case 15238:
            param = "1,4,3,Physical Mana Burn,4";
            // End:0xEE51
            break;
        // End:0x57AD
        case 15239:
            param = "1,4,3,Physical Paralyze,4";
            // End:0xEE51
            break;
        // End:0x57D8
        case 15240:
            param = "1,4,3,Physical Silence,4";
            // End:0xEE51
            break;
        // End:0x5801
        case 15241:
            param = "1,4,3,Physical Sleep,4";
            // End:0xEE51
            break;
        // End:0x5829
        case 15242:
            param = "1,4,3,Physical Stun,4";
            // End:0xEE51
            break;
        // End:0x5851
        case 15243:
            param = "1,4,3,Critical Doom,4";
            // End:0xEE51
            break;
        // End:0x587E
        case 15244:
            param = "1,4,3,Critical Mana Burn,4";
            // End:0xEE51
            break;
        // End:0x58AA
        case 15245:
            param = "1,4,3,Critical Paralyze,4";
            // End:0xEE51
            break;
        // End:0x58D5
        case 15246:
            param = "1,4,3,Critical Silence,4";
            // End:0xEE51
            break;
        // End:0x58FE
        case 15247:
            param = "1,4,3,Critical Sleep,4";
            // End:0xEE51
            break;
        // End:0x5926
        case 15248:
            param = "1,4,3,Critical Stun,4";
            // End:0xEE51
            break;
        // End:0x5945
        case 15249:
            param = "1,4,3,Doom,4";
            // End:0xEE51
            break;
        // End:0x5964
        case 15250:
            param = "1,4,3,Fear,4";
            // End:0xEE51
            break;
        // End:0x5988
        case 15251:
            param = "1,4,3,Mana Gain,4";
            // End:0xEE51
            break;
        // End:0x59AB
        case 15252:
            param = "1,4,3,Recharge,4";
            // End:0xEE51
            break;
        // End:0x59CE
        case 15253:
            param = "1,4,3,Paralyze,4";
            // End:0xEE51
            break;
        // End:0x59F0
        case 15254:
            param = "1,4,3,Silence,4";
            // End:0xEE51
            break;
        // End:0x5A0F
        case 15255:
            param = "1,4,3,Stun,4";
            // End:0xEE51
            break;
        // End:0x5A30
        case 15256:
            param = "1,4,3,Medusa,4";
            // End:0xEE51
            break;
        // End:0x5A57
        case 15257:
            param = "1,4,3,Magical Doom,4";
            // End:0xEE51
            break;
        // End:0x5A83
        case 15258:
            param = "1,4,3,Magical Mana Burn,4";
            // End:0xEE51
            break;
        // End:0x5AAE
        case 15259:
            param = "1,4,3,Magical Paralyze,4";
            // End:0xEE51
            break;
        // End:0x5AD8
        case 15260:
            param = "1,4,3,Magical Silence,4";
            // End:0xEE51
            break;
        // End:0x5B00
        case 15261:
            param = "1,4,3,Magical Sleep,4";
            // End:0xEE51
            break;
        // End:0x5B27
        case 15262:
            param = "1,4,3,Magical Stun,4";
            // End:0xEE51
            break;
        // End:0x5B49
        case 15263:
            param = "1,4,2,Clarity,1";
            // End:0xEE51
            break;
        // End:0x5B6B
        case 15264:
            param = "1,4,2,Agility,4";
            // End:0xEE51
            break;
        // End:0x5B8B
        case 15265:
            param = "1,4,2,Focus,4";
            // End:0xEE51
            break;
        // End:0x5BB4
        case 15266:
            param = "1,4,2,Reflect Damage,1";
            // End:0xEE51
            break;
        // End:0x5BD7
        case 15267:
            param = "1,4,2,Guidance,4";
            // End:0xEE51
            break;
        // End:0x5BFC
        case 15268:
            param = "1,4,2,Wild Magic,4";
            // End:0xEE51
            break;
        // End:0x5C20
        case 15269:
            param = "1,4,2,Mana Gain,4";
            // End:0xEE51
            break;
        // End:0x5C48
        case 15270:
            param = "1,4,2,Skill Clarity,1";
            // End:0xEE51
            break;
        // End:0x5C70
        case 15271:
            param = "1,4,2,Music Clarity,1";
            // End:0xEE51
            break;
        // End:0x5C98
        case 15272:
            param = "1,4,2,Spell Clarity,1";
            // End:0xEE51
            break;
        // End:0x5CB9
        case 15290:
            param = "1,3,1,Winter,5";
            // End:0xEE51
            break;
        // End:0x5CDB
        case 15291:
            param = "1,3,1,Agility,5";
            // End:0xEE51
            break;
        // End:0x5CFB
        case 15292:
            param = "1,3,1,Bleed,5";
            // End:0xEE51
            break;
        // End:0x5D1C
        case 15293:
            param = "1,3,1,Ritual,5";
            // End:0xEE51
            break;
        // End:0x5D3C
        case 15294:
            param = "1,3,1,Stone,5";
            // End:0xEE51
            break;
        // End:0x5D5B
        case 15295:
            param = "1,3,1,Fear,5";
            // End:0xEE51
            break;
        // End:0x5D80
        case 15296:
            param = "1,3,1,Prominence,5";
            // End:0xEE51
            break;
        // End:0x5DA0
        case 15297:
            param = "1,3,1,Peace,5";
            // End:0xEE51
            break;
        // End:0x5DC0
        case 15298:
            param = "1,3,1,Charm,5";
            // End:0xEE51
            break;
        // End:0x5DE5
        case 15299:
            param = "1,3,1,Aggression,5";
            // End:0xEE51
            break;
        // End:0x5E08
        case 15300:
            param = "1,3,1,Guidance,5";
            // End:0xEE51
            break;
        // End:0x5E27
        case 15301:
            param = "1,3,1,Hold,5";
            // End:0xEE51
            break;
        // End:0x5E4D
        case 15302:
            param = "1,3,1,Solar Flare,5";
            // End:0xEE51
            break;
        // End:0x5E74
        case 15303:
            param = "1,3,1,Heal Empower,5";
            // End:0xEE51
            break;
        // End:0x5E95
        case 15304:
            param = "1,3,1,Prayer,5";
            // End:0xEE51
            break;
        // End:0x5EB4
        case 15305:
            param = "1,3,1,Heal,5";
            // End:0xEE51
            break;
        // End:0x5ED6
        case 15306:
            param = "1,3,1,Empower,5";
            // End:0xEE51
            break;
        // End:0x5EF6
        case 15307:
            param = "1,3,1,Cheer,5";
            // End:0xEE51
            break;
        // End:0x5F1C
        case 15308:
            param = "1,3,1,Battle Roar,5";
            // End:0xEE51
            break;
        // End:0x5F43
        case 15309:
            param = "1,3,1,Blessed Body,5";
            // End:0xEE51
            break;
        // End:0x5F6A
        case 15310:
            param = "1,3,1,Blessed Soul,5";
            // End:0xEE51
            break;
        // End:0x5F92
        case 15311:
            param = "1,3,1,Magic Barrier,5";
            // End:0xEE51
            break;
        // End:0x5FB6
        case 15312:
            param = "1,3,1,Mana Burn,5";
            // End:0xEE51
            break;
        // End:0x5FDA
        case 15313:
            param = "1,3,1,Mana Gain,5";
            // End:0xEE51
            break;
        // End:0x5FFD
        case 15314:
            param = "1,3,1,Recharge,5";
            // End:0xEE51
            break;
        // End:0x6022
        case 15315:
            param = "1,3,1,Aura Flare,5";
            // End:0xEE51
            break;
        // End:0x6042
        case 15316:
            param = "1,3,1,Might,5";
            // End:0xEE51
            break;
        // End:0x6065
        case 15317:
            param = "1,3,1,Paralyze,5";
            // End:0xEE51
            break;
        // End:0x6086
        case 15318:
            param = "1,3,1,Shield,5";
            // End:0xEE51
            break;
        // End:0x60A7
        case 15319:
            param = "1,3,1,Poison,5";
            // End:0xEE51
            break;
        // End:0x60CF
        case 15320:
            param = "1,3,1,Duel Weakness,5";
            // End:0xEE51
            break;
        // End:0x60F4
        case 15321:
            param = "1,3,1,Duel Might,5";
            // End:0xEE51
            break;
        // End:0x6115
        case 15322:
            param = "1,3,1,Recall,1";
            // End:0xEE51
            break;
        // End:0x613C
        case 15323:
            param = "1,3,1,Resurrection,5";
            // End:0xEE51
            break;
        // End:0x6161
        case 15324:
            param = "1,3,1,Self Stone,5";
            // End:0xEE51
            break;
        // End:0x618B
        case 15325:
            param = "1,3,1,Self Prominence,5";
            // End:0xEE51
            break;
        // End:0x61B6
        case 15326:
            param = "1,3,1,Self Solar Flare,5";
            // End:0xEE51
            break;
        // End:0x61E0
        case 15327:
            param = "1,3,1,Self Aura Flare,5";
            // End:0xEE51
            break;
        // End:0x620C
        case 15328:
            param = "1,3,1,Self Shadow Flare,5";
            // End:0xEE51
            break;
        // End:0x6237
        case 15329:
            param = "1,3,1,Self Hydro Blast,5";
            // End:0xEE51
            break;
        // End:0x6260
        case 15330:
            param = "1,3,1,Self Hurricane,5";
            // End:0xEE51
            break;
        // End:0x6280
        case 15331:
            param = "1,3,1,Sleep,5";
            // End:0xEE51
            break;
        // End:0x629F
        case 15332:
            param = "1,3,1,Slow,5";
            // End:0xEE51
            break;
        // End:0x62BE
        case 15333:
            param = "1,3,1,Stun,5";
            // End:0xEE51
            break;
        // End:0x62E1
        case 15334:
            param = "1,3,1,Ae Stone,5";
            // End:0xEE51
            break;
        // End:0x6309
        case 15335:
            param = "1,3,1,Ae Prominence,5";
            // End:0xEE51
            break;
        // End:0x6332
        case 15336:
            param = "1,3,1,Ae Solar Flare,5";
            // End:0xEE51
            break;
        // End:0x635A
        case 15337:
            param = "1,3,1,Ae Aura Flare,5";
            // End:0xEE51
            break;
        // End:0x6384
        case 15338:
            param = "1,3,1,Ae Shadow Flare,5";
            // End:0xEE51
            break;
        // End:0x63AD
        case 15339:
            param = "1,3,1,Ae Hydro Blast,5";
            // End:0xEE51
            break;
        // End:0x63D4
        case 15340:
            param = "1,3,1,Ae Hurricane,5";
            // End:0xEE51
            break;
        // End:0x63F4
        case 15341:
            param = "1,3,1,Trick,5";
            // End:0xEE51
            break;
        // End:0x6415
        case 15342:
            param = "1,3,1,Medusa,5";
            // End:0xEE51
            break;
        // End:0x643C
        case 15343:
            param = "1,3,1,Shadow Flare,5";
            // End:0xEE51
            break;
        // End:0x645D
        case 15344:
            param = "1,3,1,Unlock,5";
            // End:0xEE51
            break;
        // End:0x6486
        case 15345:
            param = "1,3,1,Vampiric Touch,5";
            // End:0xEE51
            break;
        // End:0x64AC
        case 15346:
            param = "1,3,1,Hydro Blast,5";
            // End:0xEE51
            break;
        // End:0x64D0
        case 15347:
            param = "1,3,1,Hurricane,5";
            // End:0xEE51
            break;
        // End:0x64FA
        case 15348:
            param = "1,3,3,Physical Winter,5";
            // End:0xEE51
            break;
        // End:0x6523
        case 15349:
            param = "1,3,3,Physical Bleed,5";
            // End:0xEE51
            break;
        // End:0x654B
        case 15350:
            param = "1,3,3,Physical Fear,5";
            // End:0xEE51
            break;
        // End:0x6573
        case 15351:
            param = "1,3,3,Physical Hold,5";
            // End:0xEE51
            break;
        // End:0x659D
        case 15352:
            param = "1,3,3,Physical Poison,5";
            // End:0xEE51
            break;
        // End:0x65C7
        case 15353:
            param = "1,3,3,Physical Medusa,5";
            // End:0xEE51
            break;
        // End:0x65F1
        case 15354:
            param = "1,3,3,Critical Winter,5";
            // End:0xEE51
            break;
        // End:0x661A
        case 15355:
            param = "1,3,3,Critical Bleed,5";
            // End:0xEE51
            break;
        // End:0x6642
        case 15356:
            param = "1,3,3,Critical Fear,5";
            // End:0xEE51
            break;
        // End:0x666A
        case 15357:
            param = "1,3,3,Critical Hold,5";
            // End:0xEE51
            break;
        // End:0x6694
        case 15358:
            param = "1,3,3,Critical Poison,5";
            // End:0xEE51
            break;
        // End:0x66BE
        case 15359:
            param = "1,3,3,Critical Medusa,5";
            // End:0xEE51
            break;
        // End:0x66DF
        case 15360:
            param = "1,3,3,Winter,5";
            // End:0xEE51
            break;
        // End:0x6701
        case 15361:
            param = "1,3,3,Agility,5";
            // End:0xEE51
            break;
        // End:0x6721
        case 15362:
            param = "1,3,3,Bleed,5";
            // End:0xEE51
            break;
        // End:0x6742
        case 15363:
            param = "1,3,3,Ritual,5";
            // End:0xEE51
            break;
        // End:0x6762
        case 15364:
            param = "1,3,3,Focus,5";
            // End:0xEE51
            break;
        // End:0x6782
        case 15365:
            param = "1,3,3,Charm,5";
            // End:0xEE51
            break;
        // End:0x67A5
        case 15366:
            param = "1,3,3,Guidance,5";
            // End:0xEE51
            break;
        // End:0x67C4
        case 15367:
            param = "1,3,3,Hold,5";
            // End:0xEE51
            break;
        // End:0x67E5
        case 15368:
            param = "1,3,3,Prayer,5";
            // End:0xEE51
            break;
        // End:0x6804
        case 15369:
            param = "1,3,3,Heal,5";
            // End:0xEE51
            break;
        // End:0x6826
        case 15370:
            param = "1,3,3,Empower,5";
            // End:0xEE51
            break;
        // End:0x684B
        case 15371:
            param = "1,3,3,Wild Magic,5";
            // End:0xEE51
            break;
        // End:0x686B
        case 15372:
            param = "1,3,3,Cheer,5";
            // End:0xEE51
            break;
        // End:0x6892
        case 15373:
            param = "1,3,3,Blessed Body,5";
            // End:0xEE51
            break;
        // End:0x68B9
        case 15374:
            param = "1,3,3,Blessed Soul,5";
            // End:0xEE51
            break;
        // End:0x68E1
        case 15375:
            param = "1,3,3,Magic Barrier,5";
            // End:0xEE51
            break;
        // End:0x6901
        case 15376:
            param = "1,3,3,Might,5";
            // End:0xEE51
            break;
        // End:0x6922
        case 15377:
            param = "1,3,3,Shield,5";
            // End:0xEE51
            break;
        // End:0x6943
        case 15378:
            param = "1,3,3,Poison,5";
            // End:0xEE51
            break;
        // End:0x696B
        case 15379:
            param = "1,3,3,Duel Weakness,5";
            // End:0xEE51
            break;
        // End:0x6990
        case 15380:
            param = "1,3,3,Duel Might,5";
            // End:0xEE51
            break;
        // End:0x69B0
        case 15381:
            param = "1,3,3,Sleep,5";
            // End:0xEE51
            break;
        // End:0x69CF
        case 15382:
            param = "1,3,3,Slow,5";
            // End:0xEE51
            break;
        // End:0x69F8
        case 15383:
            param = "1,3,3,Magical Winter,5";
            // End:0xEE51
            break;
        // End:0x6A20
        case 15384:
            param = "1,3,3,Magical Bleed,5";
            // End:0xEE51
            break;
        // End:0x6A47
        case 15385:
            param = "1,3,3,Magical Fear,5";
            // End:0xEE51
            break;
        // End:0x6A6E
        case 15386:
            param = "1,3,3,Magical Hold,5";
            // End:0xEE51
            break;
        // End:0x6A97
        case 15387:
            param = "1,3,3,Magical Poison,5";
            // End:0xEE51
            break;
        // End:0x6AC0
        case 15388:
            param = "1,3,3,Magical Medusa,5";
            // End:0xEE51
            break;
        // End:0x6AE7
        case 15389:
            param = "1,3,2,Heal Empower,5";
            // End:0xEE51
            break;
        // End:0x6B08
        case 15390:
            param = "1,3,2,Prayer,5";
            // End:0xEE51
            break;
        // End:0x6B2A
        case 15391:
            param = "1,3,2,Empower,5";
            // End:0xEE51
            break;
        // End:0x6B52
        case 15392:
            param = "1,3,2,Magic Barrier,5";
            // End:0xEE51
            break;
        // End:0x6B72
        case 15393:
            param = "1,3,2,Might,5";
            // End:0xEE51
            break;
        // End:0x6B93
        case 15394:
            param = "1,3,2,Shield,5";
            // End:0xEE51
            break;
        // End:0x6BB8
        case 15395:
            param = "1,3,2,Duel Might,5";
            // End:0xEE51
            break;
        // End:0x6BDF
        case 15396:
            param = "1,3,2,Weight Limit,5";
            // End:0xEE51
            break;
        // End:0x6C01
        case 15397:
            param = "1,4,1,Refresh,1";
            // End:0xEE51
            break;
        // End:0x6C23
        case 15398:
            param = "1,4,1,Clarity,1";
            // End:0xEE51
            break;
        // End:0x6C43
        case 15399:
            param = "1,4,1,Focus,5";
            // End:0xEE51
            break;
        // End:0x6C6C
        case 15400:
            param = "1,4,1,Reflect Damage,1";
            // End:0xEE51
            break;
        // End:0x6C8B
        case 15401:
            param = "1,4,1,Doom,5";
            // End:0xEE51
            break;
        // End:0x6CAC
        case 15402:
            param = "1,4,1,Recall,2";
            // End:0xEE51
            break;
        // End:0x6CD7
        case 15403:
            param = "1,4,1,Celestial Shield,1";
            // End:0xEE51
            break;
        // End:0x6CFC
        case 15404:
            param = "1,4,1,Wild Magic,5";
            // End:0xEE51
            break;
        // End:0x6D23
        case 15405:
            param = "1,4,1,Party Recall,2";
            // End:0xEE51
            break;
        // End:0x6D45
        case 15406:
            param = "1,4,1,Silence,5";
            // End:0xEE51
            break;
        // End:0x6D6D
        case 15407:
            param = "1,4,1,Skill Refresh,1";
            // End:0xEE51
            break;
        // End:0x6D95
        case 15408:
            param = "1,4,1,Skill Clarity,1";
            // End:0xEE51
            break;
        // End:0x6DBD
        case 15409:
            param = "1,4,1,Music Refresh,1";
            // End:0xEE51
            break;
        // End:0x6DE5
        case 15410:
            param = "1,4,1,Music Clarity,1";
            // End:0xEE51
            break;
        // End:0x6E0D
        case 15411:
            param = "1,4,1,Spell Refresh,1";
            // End:0xEE51
            break;
        // End:0x6E35
        case 15412:
            param = "1,4,1,Spell Clarity,1";
            // End:0xEE51
            break;
        // End:0x6E57
        case 15413:
            param = "1,4,1,Stealth,1";
            // End:0xEE51
            break;
        // End:0x6E7F
        case 15414:
            param = "1,4,1,Vampiric Rage,5";
            // End:0xEE51
            break;
        // End:0x6EA7
        case 15415:
            param = "1,4,3,Physical Doom,5";
            // End:0xEE51
            break;
        // End:0x6ED4
        case 15416:
            param = "1,4,3,Physical Mana Burn,5";
            // End:0xEE51
            break;
        // End:0x6F00
        case 15417:
            param = "1,4,3,Physical Paralyze,5";
            // End:0xEE51
            break;
        // End:0x6F2B
        case 15418:
            param = "1,4,3,Physical Silence,5";
            // End:0xEE51
            break;
        // End:0x6F54
        case 15419:
            param = "1,4,3,Physical Sleep,5";
            // End:0xEE51
            break;
        // End:0x6F7C
        case 15420:
            param = "1,4,3,Physical Stun,5";
            // End:0xEE51
            break;
        // End:0x6FA4
        case 15421:
            param = "1,4,3,Critical Doom,5";
            // End:0xEE51
            break;
        // End:0x6FD1
        case 15422:
            param = "1,4,3,Critical Mana Burn,5";
            // End:0xEE51
            break;
        // End:0x6FFD
        case 15423:
            param = "1,4,3,Critical Paralyze,5";
            // End:0xEE51
            break;
        // End:0x7028
        case 15424:
            param = "1,4,3,Critical Silence,5";
            // End:0xEE51
            break;
        // End:0x7051
        case 15425:
            param = "1,4,3,Critical Sleep,5";
            // End:0xEE51
            break;
        // End:0x7079
        case 15426:
            param = "1,4,3,Critical Stun,5";
            // End:0xEE51
            break;
        // End:0x7098
        case 15427:
            param = "1,4,3,Doom,5";
            // End:0xEE51
            break;
        // End:0x70B7
        case 15428:
            param = "1,4,3,Fear,5";
            // End:0xEE51
            break;
        // End:0x70DB
        case 15429:
            param = "1,4,3,Mana Gain,5";
            // End:0xEE51
            break;
        // End:0x70FE
        case 15430:
            param = "1,4,3,Recharge,5";
            // End:0xEE51
            break;
        // End:0x7121
        case 15431:
            param = "1,4,3,Paralyze,5";
            // End:0xEE51
            break;
        // End:0x7143
        case 15432:
            param = "1,4,3,Silence,5";
            // End:0xEE51
            break;
        // End:0x7162
        case 15433:
            param = "1,4,3,Stun,5";
            // End:0xEE51
            break;
        // End:0x7183
        case 15434:
            param = "1,4,3,Medusa,5";
            // End:0xEE51
            break;
        // End:0x71AA
        case 15435:
            param = "1,4,3,Magical Doom,5";
            // End:0xEE51
            break;
        // End:0x71D6
        case 15436:
            param = "1,4,3,Magical Mana Burn,5";
            // End:0xEE51
            break;
        // End:0x7201
        case 15437:
            param = "1,4,3,Magical Paralyze,5";
            // End:0xEE51
            break;
        // End:0x722B
        case 15438:
            param = "1,4,3,Magical Silence,5";
            // End:0xEE51
            break;
        // End:0x7253
        case 15439:
            param = "1,4,3,Magical Sleep,5";
            // End:0xEE51
            break;
        // End:0x727A
        case 15440:
            param = "1,4,3,Magical Stun,5";
            // End:0xEE51
            break;
        // End:0x729C
        case 15441:
            param = "1,4,2,Clarity,1";
            // End:0xEE51
            break;
        // End:0x72BE
        case 15442:
            param = "1,4,2,Agility,5";
            // End:0xEE51
            break;
        // End:0x72DE
        case 15443:
            param = "1,4,2,Focus,5";
            // End:0xEE51
            break;
        // End:0x7307
        case 15444:
            param = "1,4,2,Reflect Damage,1";
            // End:0xEE51
            break;
        // End:0x732A
        case 15445:
            param = "1,4,2,Guidance,5";
            // End:0xEE51
            break;
        // End:0x734F
        case 15446:
            param = "1,4,2,Wild Magic,5";
            // End:0xEE51
            break;
        // End:0x7373
        case 15447:
            param = "1,4,2,Mana Gain,5";
            // End:0xEE51
            break;
        // End:0x739B
        case 15448:
            param = "1,4,2,Skill Clarity,1";
            // End:0xEE51
            break;
        // End:0x73C3
        case 15449:
            param = "1,4,2,Music Clarity,1";
            // End:0xEE51
            break;
        // End:0x73EB
        case 15450:
            param = "1,4,2,Spell Clarity,1";
            // End:0xEE51
            break;
        // End:0x740C
        case 15468:
            param = "1,3,1,Winter,6";
            // End:0xEE51
            break;
        // End:0x742E
        case 15469:
            param = "1,3,1,Agility,6";
            // End:0xEE51
            break;
        // End:0x744E
        case 15470:
            param = "1,3,1,Bleed,6";
            // End:0xEE51
            break;
        // End:0x746F
        case 15471:
            param = "1,3,1,Ritual,6";
            // End:0xEE51
            break;
        // End:0x748F
        case 15472:
            param = "1,3,1,Stone,6";
            // End:0xEE51
            break;
        // End:0x74AE
        case 15473:
            param = "1,3,1,Fear,6";
            // End:0xEE51
            break;
        // End:0x74D3
        case 15474:
            param = "1,3,1,Prominence,6";
            // End:0xEE51
            break;
        // End:0x74F3
        case 15475:
            param = "1,3,1,Peace,6";
            // End:0xEE51
            break;
        // End:0x7513
        case 15476:
            param = "1,3,1,Charm,6";
            // End:0xEE51
            break;
        // End:0x7538
        case 15477:
            param = "1,3,1,Aggression,6";
            // End:0xEE51
            break;
        // End:0x755B
        case 15478:
            param = "1,3,1,Guidance,6";
            // End:0xEE51
            break;
        // End:0x757A
        case 15479:
            param = "1,3,1,Hold,6";
            // End:0xEE51
            break;
        // End:0x75A0
        case 15480:
            param = "1,3,1,Solar Flare,6";
            // End:0xEE51
            break;
        // End:0x75C7
        case 15481:
            param = "1,3,1,Heal Empower,6";
            // End:0xEE51
            break;
        // End:0x75E8
        case 15482:
            param = "1,3,1,Prayer,6";
            // End:0xEE51
            break;
        // End:0x7607
        case 15483:
            param = "1,3,1,Heal,6";
            // End:0xEE51
            break;
        // End:0x7629
        case 15484:
            param = "1,3,1,Empower,6";
            // End:0xEE51
            break;
        // End:0x7649
        case 15485:
            param = "1,3,1,Cheer,6";
            // End:0xEE51
            break;
        // End:0x766F
        case 15486:
            param = "1,3,1,Battle Roar,6";
            // End:0xEE51
            break;
        // End:0x7696
        case 15487:
            param = "1,3,1,Blessed Body,6";
            // End:0xEE51
            break;
        // End:0x76BD
        case 15488:
            param = "1,3,1,Blessed Soul,6";
            // End:0xEE51
            break;
        // End:0x76E5
        case 15489:
            param = "1,3,1,Magic Barrier,6";
            // End:0xEE51
            break;
        // End:0x7709
        case 15490:
            param = "1,3,1,Mana Burn,6";
            // End:0xEE51
            break;
        // End:0x772D
        case 15491:
            param = "1,3,1,Mana Gain,6";
            // End:0xEE51
            break;
        // End:0x7750
        case 15492:
            param = "1,3,1,Recharge,6";
            // End:0xEE51
            break;
        // End:0x7775
        case 15493:
            param = "1,3,1,Aura Flare,6";
            // End:0xEE51
            break;
        // End:0x7795
        case 15494:
            param = "1,3,1,Might,6";
            // End:0xEE51
            break;
        // End:0x77B8
        case 15495:
            param = "1,3,1,Paralyze,6";
            // End:0xEE51
            break;
        // End:0x77D9
        case 15496:
            param = "1,3,1,Shield,6";
            // End:0xEE51
            break;
        // End:0x77FA
        case 15497:
            param = "1,3,1,Poison,6";
            // End:0xEE51
            break;
        // End:0x7822
        case 15498:
            param = "1,3,1,Duel Weakness,6";
            // End:0xEE51
            break;
        // End:0x7847
        case 15499:
            param = "1,3,1,Duel Might,6";
            // End:0xEE51
            break;
        // End:0x7868
        case 15500:
            param = "1,3,1,Recall,1";
            // End:0xEE51
            break;
        // End:0x788F
        case 15501:
            param = "1,3,1,Resurrection,6";
            // End:0xEE51
            break;
        // End:0x78B4
        case 15502:
            param = "1,3,1,Self Stone,6";
            // End:0xEE51
            break;
        // End:0x78DE
        case 15503:
            param = "1,3,1,Self Prominence,6";
            // End:0xEE51
            break;
        // End:0x7909
        case 15504:
            param = "1,3,1,Self Solar Flare,6";
            // End:0xEE51
            break;
        // End:0x7933
        case 15505:
            param = "1,3,1,Self Aura Flare,6";
            // End:0xEE51
            break;
        // End:0x795F
        case 15506:
            param = "1,3,1,Self Shadow Flare,6";
            // End:0xEE51
            break;
        // End:0x798A
        case 15507:
            param = "1,3,1,Self Hydro Blast,6";
            // End:0xEE51
            break;
        // End:0x79B3
        case 15508:
            param = "1,3,1,Self Hurricane,6";
            // End:0xEE51
            break;
        // End:0x79D3
        case 15509:
            param = "1,3,1,Sleep,6";
            // End:0xEE51
            break;
        // End:0x79F2
        case 15510:
            param = "1,3,1,Slow,6";
            // End:0xEE51
            break;
        // End:0x7A11
        case 15511:
            param = "1,3,1,Stun,6";
            // End:0xEE51
            break;
        // End:0x7A34
        case 15512:
            param = "1,3,1,Ae Stone,6";
            // End:0xEE51
            break;
        // End:0x7A5C
        case 15513:
            param = "1,3,1,Ae Prominence,6";
            // End:0xEE51
            break;
        // End:0x7A85
        case 15514:
            param = "1,3,1,Ae Solar Flare,6";
            // End:0xEE51
            break;
        // End:0x7AAD
        case 15515:
            param = "1,3,1,Ae Aura Flare,6";
            // End:0xEE51
            break;
        // End:0x7AD7
        case 15516:
            param = "1,3,1,Ae Shadow Flare,6";
            // End:0xEE51
            break;
        // End:0x7B00
        case 15517:
            param = "1,3,1,Ae Hydro Blast,6";
            // End:0xEE51
            break;
        // End:0x7B27
        case 15518:
            param = "1,3,1,Ae Hurricane,6";
            // End:0xEE51
            break;
        // End:0x7B47
        case 15519:
            param = "1,3,1,Trick,6";
            // End:0xEE51
            break;
        // End:0x7B68
        case 15520:
            param = "1,3,1,Medusa,6";
            // End:0xEE51
            break;
        // End:0x7B8F
        case 15521:
            param = "1,3,1,Shadow Flare,6";
            // End:0xEE51
            break;
        // End:0x7BB0
        case 15522:
            param = "1,3,1,Unlock,6";
            // End:0xEE51
            break;
        // End:0x7BD9
        case 15523:
            param = "1,3,1,Vampiric Touch,6";
            // End:0xEE51
            break;
        // End:0x7BFF
        case 15524:
            param = "1,3,1,Hydro Blast,6";
            // End:0xEE51
            break;
        // End:0x7C23
        case 15525:
            param = "1,3,1,Hurricane,6";
            // End:0xEE51
            break;
        // End:0x7C4D
        case 15526:
            param = "1,3,3,Physical Winter,6";
            // End:0xEE51
            break;
        // End:0x7C76
        case 15527:
            param = "1,3,3,Physical Bleed,6";
            // End:0xEE51
            break;
        // End:0x7C9E
        case 15528:
            param = "1,3,3,Physical Fear,6";
            // End:0xEE51
            break;
        // End:0x7CC6
        case 15529:
            param = "1,3,3,Physical Hold,6";
            // End:0xEE51
            break;
        // End:0x7CF0
        case 15530:
            param = "1,3,3,Physical Poison,6";
            // End:0xEE51
            break;
        // End:0x7D1A
        case 15531:
            param = "1,3,3,Physical Medusa,6";
            // End:0xEE51
            break;
        // End:0x7D44
        case 15532:
            param = "1,3,3,Critical Winter,6";
            // End:0xEE51
            break;
        // End:0x7D6D
        case 15533:
            param = "1,3,3,Critical Bleed,6";
            // End:0xEE51
            break;
        // End:0x7D95
        case 15534:
            param = "1,3,3,Critical Fear,6";
            // End:0xEE51
            break;
        // End:0x7DBD
        case 15535:
            param = "1,3,3,Critical Hold,6";
            // End:0xEE51
            break;
        // End:0x7DE7
        case 15536:
            param = "1,3,3,Critical Poison,6";
            // End:0xEE51
            break;
        // End:0x7E11
        case 15537:
            param = "1,3,3,Critical Medusa,6";
            // End:0xEE51
            break;
        // End:0x7E32
        case 15538:
            param = "1,3,3,Winter,6";
            // End:0xEE51
            break;
        // End:0x7E54
        case 15539:
            param = "1,3,3,Agility,6";
            // End:0xEE51
            break;
        // End:0x7E74
        case 15540:
            param = "1,3,3,Bleed,6";
            // End:0xEE51
            break;
        // End:0x7E95
        case 15541:
            param = "1,3,3,Ritual,6";
            // End:0xEE51
            break;
        // End:0x7EB5
        case 15542:
            param = "1,3,3,Focus,6";
            // End:0xEE51
            break;
        // End:0x7ED5
        case 15543:
            param = "1,3,3,Charm,6";
            // End:0xEE51
            break;
        // End:0x7EF8
        case 15544:
            param = "1,3,3,Guidance,6";
            // End:0xEE51
            break;
        // End:0x7F17
        case 15545:
            param = "1,3,3,Hold,6";
            // End:0xEE51
            break;
        // End:0x7F38
        case 15546:
            param = "1,3,3,Prayer,6";
            // End:0xEE51
            break;
        // End:0x7F57
        case 15547:
            param = "1,3,3,Heal,6";
            // End:0xEE51
            break;
        // End:0x7F79
        case 15548:
            param = "1,3,3,Empower,6";
            // End:0xEE51
            break;
        // End:0x7F9E
        case 15549:
            param = "1,3,3,Wild Magic,6";
            // End:0xEE51
            break;
        // End:0x7FBE
        case 15550:
            param = "1,3,3,Cheer,6";
            // End:0xEE51
            break;
        // End:0x7FE5
        case 15551:
            param = "1,3,3,Blessed Body,6";
            // End:0xEE51
            break;
        // End:0x800C
        case 15552:
            param = "1,3,3,Blessed Soul,6";
            // End:0xEE51
            break;
        // End:0x8034
        case 15553:
            param = "1,3,3,Magic Barrier,6";
            // End:0xEE51
            break;
        // End:0x8054
        case 15554:
            param = "1,3,3,Might,6";
            // End:0xEE51
            break;
        // End:0x8075
        case 15555:
            param = "1,3,3,Shield,6";
            // End:0xEE51
            break;
        // End:0x8096
        case 15556:
            param = "1,3,3,Poison,6";
            // End:0xEE51
            break;
        // End:0x80BE
        case 15557:
            param = "1,3,3,Duel Weakness,6";
            // End:0xEE51
            break;
        // End:0x80E3
        case 15558:
            param = "1,3,3,Duel Might,6";
            // End:0xEE51
            break;
        // End:0x8103
        case 15559:
            param = "1,3,3,Sleep,6";
            // End:0xEE51
            break;
        // End:0x8122
        case 15560:
            param = "1,3,3,Slow,6";
            // End:0xEE51
            break;
        // End:0x814B
        case 15561:
            param = "1,3,3,Magical Winter,6";
            // End:0xEE51
            break;
        // End:0x8173
        case 15562:
            param = "1,3,3,Magical Bleed,6";
            // End:0xEE51
            break;
        // End:0x819A
        case 15563:
            param = "1,3,3,Magical Fear,6";
            // End:0xEE51
            break;
        // End:0x81C1
        case 15564:
            param = "1,3,3,Magical Hold,6";
            // End:0xEE51
            break;
        // End:0x81EA
        case 15565:
            param = "1,3,3,Magical Poison,6";
            // End:0xEE51
            break;
        // End:0x8213
        case 15566:
            param = "1,3,3,Magical Medusa,6";
            // End:0xEE51
            break;
        // End:0x823A
        case 15567:
            param = "1,3,2,Heal Empower,6";
            // End:0xEE51
            break;
        // End:0x825B
        case 15568:
            param = "1,3,2,Prayer,6";
            // End:0xEE51
            break;
        // End:0x827D
        case 15569:
            param = "1,3,2,Empower,6";
            // End:0xEE51
            break;
        // End:0x82A5
        case 15570:
            param = "1,3,2,Magic Barrier,6";
            // End:0xEE51
            break;
        // End:0x82C5
        case 15571:
            param = "1,3,2,Might,6";
            // End:0xEE51
            break;
        // End:0x82E6
        case 15572:
            param = "1,3,2,Shield,6";
            // End:0xEE51
            break;
        // End:0x830B
        case 15573:
            param = "1,3,2,Duel Might,6";
            // End:0xEE51
            break;
        // End:0x8332
        case 15574:
            param = "1,3,2,Weight Limit,6";
            // End:0xEE51
            break;
        // End:0x8354
        case 15575:
            param = "1,4,1,Refresh,1";
            // End:0xEE51
            break;
        // End:0x8376
        case 15576:
            param = "1,4,1,Clarity,1";
            // End:0xEE51
            break;
        // End:0x8396
        case 15577:
            param = "1,4,1,Focus,6";
            // End:0xEE51
            break;
        // End:0x83BF
        case 15578:
            param = "1,4,1,Reflect Damage,1";
            // End:0xEE51
            break;
        // End:0x83DE
        case 15579:
            param = "1,4,1,Doom,6";
            // End:0xEE51
            break;
        // End:0x83FF
        case 15580:
            param = "1,4,1,Recall,2";
            // End:0xEE51
            break;
        // End:0x842A
        case 15581:
            param = "1,4,1,Celestial Shield,1";
            // End:0xEE51
            break;
        // End:0x844F
        case 15582:
            param = "1,4,1,Wild Magic,6";
            // End:0xEE51
            break;
        // End:0x8476
        case 15583:
            param = "1,4,1,Party Recall,2";
            // End:0xEE51
            break;
        // End:0x8498
        case 15584:
            param = "1,4,1,Silence,6";
            // End:0xEE51
            break;
        // End:0x84C0
        case 15585:
            param = "1,4,1,Skill Refresh,1";
            // End:0xEE51
            break;
        // End:0x84E8
        case 15586:
            param = "1,4,1,Skill Clarity,1";
            // End:0xEE51
            break;
        // End:0x8510
        case 15587:
            param = "1,4,1,Music Refresh,1";
            // End:0xEE51
            break;
        // End:0x8538
        case 15588:
            param = "1,4,1,Music Clarity,1";
            // End:0xEE51
            break;
        // End:0x8560
        case 15589:
            param = "1,4,1,Spell Refresh,1";
            // End:0xEE51
            break;
        // End:0x8588
        case 15590:
            param = "1,4,1,Spell Clarity,1";
            // End:0xEE51
            break;
        // End:0x85AA
        case 15591:
            param = "1,4,1,Stealth,1";
            // End:0xEE51
            break;
        // End:0x85D2
        case 15592:
            param = "1,4,1,Vampiric Rage,6";
            // End:0xEE51
            break;
        // End:0x85FA
        case 15593:
            param = "1,4,3,Physical Doom,6";
            // End:0xEE51
            break;
        // End:0x8627
        case 15594:
            param = "1,4,3,Physical Mana Burn,6";
            // End:0xEE51
            break;
        // End:0x8653
        case 15595:
            param = "1,4,3,Physical Paralyze,6";
            // End:0xEE51
            break;
        // End:0x867E
        case 15596:
            param = "1,4,3,Physical Silence,6";
            // End:0xEE51
            break;
        // End:0x86A7
        case 15597:
            param = "1,4,3,Physical Sleep,6";
            // End:0xEE51
            break;
        // End:0x86CF
        case 15598:
            param = "1,4,3,Physical Stun,6";
            // End:0xEE51
            break;
        // End:0x86F7
        case 15599:
            param = "1,4,3,Critical Doom,6";
            // End:0xEE51
            break;
        // End:0x8724
        case 15600:
            param = "1,4,3,Critical Mana Burn,6";
            // End:0xEE51
            break;
        // End:0x8750
        case 15601:
            param = "1,4,3,Critical Paralyze,6";
            // End:0xEE51
            break;
        // End:0x877B
        case 15602:
            param = "1,4,3,Critical Silence,6";
            // End:0xEE51
            break;
        // End:0x87A4
        case 15603:
            param = "1,4,3,Critical Sleep,6";
            // End:0xEE51
            break;
        // End:0x87CC
        case 15604:
            param = "1,4,3,Critical Stun,6";
            // End:0xEE51
            break;
        // End:0x87EB
        case 15605:
            param = "1,4,3,Doom,6";
            // End:0xEE51
            break;
        // End:0x880A
        case 15606:
            param = "1,4,3,Fear,6";
            // End:0xEE51
            break;
        // End:0x882E
        case 15607:
            param = "1,4,3,Mana Gain,6";
            // End:0xEE51
            break;
        // End:0x8851
        case 15608:
            param = "1,4,3,Recharge,6";
            // End:0xEE51
            break;
        // End:0x8874
        case 15609:
            param = "1,4,3,Paralyze,6";
            // End:0xEE51
            break;
        // End:0x8896
        case 15610:
            param = "1,4,3,Silence,6";
            // End:0xEE51
            break;
        // End:0x88B5
        case 15611:
            param = "1,4,3,Stun,6";
            // End:0xEE51
            break;
        // End:0x88D6
        case 15612:
            param = "1,4,3,Medusa,6";
            // End:0xEE51
            break;
        // End:0x88FD
        case 15613:
            param = "1,4,3,Magical Doom,6";
            // End:0xEE51
            break;
        // End:0x8929
        case 15614:
            param = "1,4,3,Magical Mana Burn,6";
            // End:0xEE51
            break;
        // End:0x8954
        case 15615:
            param = "1,4,3,Magical Paralyze,6";
            // End:0xEE51
            break;
        // End:0x897E
        case 15616:
            param = "1,4,3,Magical Silence,6";
            // End:0xEE51
            break;
        // End:0x89A6
        case 15617:
            param = "1,4,3,Magical Sleep,6";
            // End:0xEE51
            break;
        // End:0x89CD
        case 15618:
            param = "1,4,3,Magical Stun,6";
            // End:0xEE51
            break;
        // End:0x89EF
        case 15619:
            param = "1,4,2,Clarity,1";
            // End:0xEE51
            break;
        // End:0x8A11
        case 15620:
            param = "1,4,2,Agility,6";
            // End:0xEE51
            break;
        // End:0x8A31
        case 15621:
            param = "1,4,2,Focus,6";
            // End:0xEE51
            break;
        // End:0x8A5A
        case 15622:
            param = "1,4,2,Reflect Damage,1";
            // End:0xEE51
            break;
        // End:0x8A7D
        case 15623:
            param = "1,4,2,Guidance,6";
            // End:0xEE51
            break;
        // End:0x8AA2
        case 15624:
            param = "1,4,2,Wild Magic,6";
            // End:0xEE51
            break;
        // End:0x8AC6
        case 15625:
            param = "1,4,2,Mana Gain,6";
            // End:0xEE51
            break;
        // End:0x8AEE
        case 15626:
            param = "1,4,2,Skill Clarity,1";
            // End:0xEE51
            break;
        // End:0x8B16
        case 15627:
            param = "1,4,2,Music Clarity,1";
            // End:0xEE51
            break;
        // End:0x8B3E
        case 15628:
            param = "1,4,2,Spell Clarity,1";
            // End:0xEE51
            break;
        // End:0x8B5F
        case 15646:
            param = "1,3,1,Winter,7";
            // End:0xEE51
            break;
        // End:0x8B81
        case 15647:
            param = "1,3,1,Agility,7";
            // End:0xEE51
            break;
        // End:0x8BA1
        case 15648:
            param = "1,3,1,Bleed,7";
            // End:0xEE51
            break;
        // End:0x8BC2
        case 15649:
            param = "1,3,1,Ritual,7";
            // End:0xEE51
            break;
        // End:0x8BE2
        case 15650:
            param = "1,3,1,Stone,7";
            // End:0xEE51
            break;
        // End:0x8C01
        case 15651:
            param = "1,3,1,Fear,7";
            // End:0xEE51
            break;
        // End:0x8C26
        case 15652:
            param = "1,3,1,Prominence,7";
            // End:0xEE51
            break;
        // End:0x8C46
        case 15653:
            param = "1,3,1,Peace,7";
            // End:0xEE51
            break;
        // End:0x8C66
        case 15654:
            param = "1,3,1,Charm,7";
            // End:0xEE51
            break;
        // End:0x8C8B
        case 15655:
            param = "1,3,1,Aggression,7";
            // End:0xEE51
            break;
        // End:0x8CAE
        case 15656:
            param = "1,3,1,Guidance,7";
            // End:0xEE51
            break;
        // End:0x8CCD
        case 15657:
            param = "1,3,1,Hold,7";
            // End:0xEE51
            break;
        // End:0x8CF3
        case 15658:
            param = "1,3,1,Solar Flare,7";
            // End:0xEE51
            break;
        // End:0x8D1A
        case 15659:
            param = "1,3,1,Heal Empower,7";
            // End:0xEE51
            break;
        // End:0x8D3B
        case 15660:
            param = "1,3,1,Prayer,7";
            // End:0xEE51
            break;
        // End:0x8D5A
        case 15661:
            param = "1,3,1,Heal,7";
            // End:0xEE51
            break;
        // End:0x8D7C
        case 15662:
            param = "1,3,1,Empower,7";
            // End:0xEE51
            break;
        // End:0x8D9C
        case 15663:
            param = "1,3,1,Cheer,7";
            // End:0xEE51
            break;
        // End:0x8DC2
        case 15664:
            param = "1,3,1,Battle Roar,7";
            // End:0xEE51
            break;
        // End:0x8DE9
        case 15665:
            param = "1,3,1,Blessed Body,7";
            // End:0xEE51
            break;
        // End:0x8E10
        case 15666:
            param = "1,3,1,Blessed Soul,7";
            // End:0xEE51
            break;
        // End:0x8E38
        case 15667:
            param = "1,3,1,Magic Barrier,7";
            // End:0xEE51
            break;
        // End:0x8E5C
        case 15668:
            param = "1,3,1,Mana Burn,7";
            // End:0xEE51
            break;
        // End:0x8E80
        case 15669:
            param = "1,3,1,Mana Gain,7";
            // End:0xEE51
            break;
        // End:0x8EA3
        case 15670:
            param = "1,3,1,Recharge,7";
            // End:0xEE51
            break;
        // End:0x8EC8
        case 15671:
            param = "1,3,1,Aura Flare,7";
            // End:0xEE51
            break;
        // End:0x8EE8
        case 15672:
            param = "1,3,1,Might,7";
            // End:0xEE51
            break;
        // End:0x8F0B
        case 15673:
            param = "1,3,1,Paralyze,7";
            // End:0xEE51
            break;
        // End:0x8F2C
        case 15674:
            param = "1,3,1,Shield,7";
            // End:0xEE51
            break;
        // End:0x8F4D
        case 15675:
            param = "1,3,1,Poison,7";
            // End:0xEE51
            break;
        // End:0x8F75
        case 15676:
            param = "1,3,1,Duel Weakness,7";
            // End:0xEE51
            break;
        // End:0x8F9A
        case 15677:
            param = "1,3,1,Duel Might,7";
            // End:0xEE51
            break;
        // End:0x8FBB
        case 15678:
            param = "1,3,1,Recall,1";
            // End:0xEE51
            break;
        // End:0x8FE2
        case 15679:
            param = "1,3,1,Resurrection,7";
            // End:0xEE51
            break;
        // End:0x9007
        case 15680:
            param = "1,3,1,Self Stone,7";
            // End:0xEE51
            break;
        // End:0x9031
        case 15681:
            param = "1,3,1,Self Prominence,7";
            // End:0xEE51
            break;
        // End:0x905C
        case 15682:
            param = "1,3,1,Self Solar Flare,7";
            // End:0xEE51
            break;
        // End:0x9086
        case 15683:
            param = "1,3,1,Self Aura Flare,7";
            // End:0xEE51
            break;
        // End:0x90B2
        case 15684:
            param = "1,3,1,Self Shadow Flare,7";
            // End:0xEE51
            break;
        // End:0x90DD
        case 15685:
            param = "1,3,1,Self Hydro Blast,7";
            // End:0xEE51
            break;
        // End:0x9106
        case 15686:
            param = "1,3,1,Self Hurricane,7";
            // End:0xEE51
            break;
        // End:0x9126
        case 15687:
            param = "1,3,1,Sleep,7";
            // End:0xEE51
            break;
        // End:0x9145
        case 15688:
            param = "1,3,1,Slow,7";
            // End:0xEE51
            break;
        // End:0x9164
        case 15689:
            param = "1,3,1,Stun,7";
            // End:0xEE51
            break;
        // End:0x9187
        case 15690:
            param = "1,3,1,Ae Stone,7";
            // End:0xEE51
            break;
        // End:0x91AF
        case 15691:
            param = "1,3,1,Ae Prominence,7";
            // End:0xEE51
            break;
        // End:0x91D8
        case 15692:
            param = "1,3,1,Ae Solar Flare,7";
            // End:0xEE51
            break;
        // End:0x9200
        case 15693:
            param = "1,3,1,Ae Aura Flare,7";
            // End:0xEE51
            break;
        // End:0x922A
        case 15694:
            param = "1,3,1,Ae Shadow Flare,7";
            // End:0xEE51
            break;
        // End:0x9253
        case 15695:
            param = "1,3,1,Ae Hydro Blast,7";
            // End:0xEE51
            break;
        // End:0x927A
        case 15696:
            param = "1,3,1,Ae Hurricane,7";
            // End:0xEE51
            break;
        // End:0x929A
        case 15697:
            param = "1,3,1,Trick,7";
            // End:0xEE51
            break;
        // End:0x92BB
        case 15698:
            param = "1,3,1,Medusa,7";
            // End:0xEE51
            break;
        // End:0x92E2
        case 15699:
            param = "1,3,1,Shadow Flare,7";
            // End:0xEE51
            break;
        // End:0x9303
        case 15700:
            param = "1,3,1,Unlock,7";
            // End:0xEE51
            break;
        // End:0x932C
        case 15701:
            param = "1,3,1,Vampiric Touch,7";
            // End:0xEE51
            break;
        // End:0x9352
        case 15702:
            param = "1,3,1,Hydro Blast,7";
            // End:0xEE51
            break;
        // End:0x9376
        case 15703:
            param = "1,3,1,Hurricane,7";
            // End:0xEE51
            break;
        // End:0x93A0
        case 15704:
            param = "1,3,3,Physical Winter,7";
            // End:0xEE51
            break;
        // End:0x93C9
        case 15705:
            param = "1,3,3,Physical Bleed,7";
            // End:0xEE51
            break;
        // End:0x93F1
        case 15706:
            param = "1,3,3,Physical Fear,7";
            // End:0xEE51
            break;
        // End:0x9419
        case 15707:
            param = "1,3,3,Physical Hold,7";
            // End:0xEE51
            break;
        // End:0x9443
        case 15708:
            param = "1,3,3,Physical Poison,7";
            // End:0xEE51
            break;
        // End:0x946D
        case 15709:
            param = "1,3,3,Physical Medusa,7";
            // End:0xEE51
            break;
        // End:0x9497
        case 15710:
            param = "1,3,3,Critical Winter,7";
            // End:0xEE51
            break;
        // End:0x94C0
        case 15711:
            param = "1,3,3,Critical Bleed,7";
            // End:0xEE51
            break;
        // End:0x94E8
        case 15712:
            param = "1,3,3,Critical Fear,7";
            // End:0xEE51
            break;
        // End:0x9510
        case 15713:
            param = "1,3,3,Critical Hold,7";
            // End:0xEE51
            break;
        // End:0x953A
        case 15714:
            param = "1,3,3,Critical Poison,7";
            // End:0xEE51
            break;
        // End:0x9564
        case 15715:
            param = "1,3,3,Critical Medusa,7";
            // End:0xEE51
            break;
        // End:0x9585
        case 15716:
            param = "1,3,3,Winter,7";
            // End:0xEE51
            break;
        // End:0x95A7
        case 15717:
            param = "1,3,3,Agility,7";
            // End:0xEE51
            break;
        // End:0x95C7
        case 15718:
            param = "1,3,3,Bleed,7";
            // End:0xEE51
            break;
        // End:0x95E8
        case 15719:
            param = "1,3,3,Ritual,7";
            // End:0xEE51
            break;
        // End:0x9608
        case 15720:
            param = "1,3,3,Focus,7";
            // End:0xEE51
            break;
        // End:0x9628
        case 15721:
            param = "1,3,3,Charm,7";
            // End:0xEE51
            break;
        // End:0x964B
        case 15722:
            param = "1,3,3,Guidance,7";
            // End:0xEE51
            break;
        // End:0x966A
        case 15723:
            param = "1,3,3,Hold,7";
            // End:0xEE51
            break;
        // End:0x968B
        case 15724:
            param = "1,3,3,Prayer,7";
            // End:0xEE51
            break;
        // End:0x96AA
        case 15725:
            param = "1,3,3,Heal,7";
            // End:0xEE51
            break;
        // End:0x96CC
        case 15726:
            param = "1,3,3,Empower,7";
            // End:0xEE51
            break;
        // End:0x96F1
        case 15727:
            param = "1,3,3,Wild Magic,7";
            // End:0xEE51
            break;
        // End:0x9711
        case 15728:
            param = "1,3,3,Cheer,7";
            // End:0xEE51
            break;
        // End:0x9738
        case 15729:
            param = "1,3,3,Blessed Body,7";
            // End:0xEE51
            break;
        // End:0x975F
        case 15730:
            param = "1,3,3,Blessed Soul,7";
            // End:0xEE51
            break;
        // End:0x9787
        case 15731:
            param = "1,3,3,Magic Barrier,7";
            // End:0xEE51
            break;
        // End:0x97A7
        case 15732:
            param = "1,3,3,Might,7";
            // End:0xEE51
            break;
        // End:0x97C8
        case 15733:
            param = "1,3,3,Shield,7";
            // End:0xEE51
            break;
        // End:0x97E9
        case 15734:
            param = "1,3,3,Poison,7";
            // End:0xEE51
            break;
        // End:0x9811
        case 15735:
            param = "1,3,3,Duel Weakness,7";
            // End:0xEE51
            break;
        // End:0x9836
        case 15736:
            param = "1,3,3,Duel Might,7";
            // End:0xEE51
            break;
        // End:0x9856
        case 15737:
            param = "1,3,3,Sleep,7";
            // End:0xEE51
            break;
        // End:0x9875
        case 15738:
            param = "1,3,3,Slow,7";
            // End:0xEE51
            break;
        // End:0x989E
        case 15739:
            param = "1,3,3,Magical Winter,7";
            // End:0xEE51
            break;
        // End:0x98C6
        case 15740:
            param = "1,3,3,Magical Bleed,7";
            // End:0xEE51
            break;
        // End:0x98ED
        case 15741:
            param = "1,3,3,Magical Fear,7";
            // End:0xEE51
            break;
        // End:0x9914
        case 15742:
            param = "1,3,3,Magical Hold,7";
            // End:0xEE51
            break;
        // End:0x993D
        case 15743:
            param = "1,3,3,Magical Poison,7";
            // End:0xEE51
            break;
        // End:0x9966
        case 15744:
            param = "1,3,3,Magical Medusa,7";
            // End:0xEE51
            break;
        // End:0x998D
        case 15745:
            param = "1,3,2,Heal Empower,7";
            // End:0xEE51
            break;
        // End:0x99AE
        case 15746:
            param = "1,3,2,Prayer,7";
            // End:0xEE51
            break;
        // End:0x99D0
        case 15747:
            param = "1,3,2,Empower,7";
            // End:0xEE51
            break;
        // End:0x99F8
        case 15748:
            param = "1,3,2,Magic Barrier,7";
            // End:0xEE51
            break;
        // End:0x9A18
        case 15749:
            param = "1,3,2,Might,7";
            // End:0xEE51
            break;
        // End:0x9A39
        case 15750:
            param = "1,3,2,Shield,7";
            // End:0xEE51
            break;
        // End:0x9A5E
        case 15751:
            param = "1,3,2,Duel Might,7";
            // End:0xEE51
            break;
        // End:0x9A85
        case 15752:
            param = "1,3,2,Weight Limit,7";
            // End:0xEE51
            break;
        // End:0x9AA7
        case 15753:
            param = "1,4,1,Refresh,2";
            // End:0xEE51
            break;
        // End:0x9AC9
        case 15754:
            param = "1,4,1,Clarity,2";
            // End:0xEE51
            break;
        // End:0x9AE9
        case 15755:
            param = "1,4,1,Focus,7";
            // End:0xEE51
            break;
        // End:0x9B12
        case 15756:
            param = "1,4,1,Reflect Damage,2";
            // End:0xEE51
            break;
        // End:0x9B31
        case 15757:
            param = "1,4,1,Doom,7";
            // End:0xEE51
            break;
        // End:0x9B52
        case 15758:
            param = "1,4,1,Recall,2";
            // End:0xEE51
            break;
        // End:0x9B7D
        case 15759:
            param = "1,4,1,Celestial Shield,1";
            // End:0xEE51
            break;
        // End:0x9BA2
        case 15760:
            param = "1,4,1,Wild Magic,7";
            // End:0xEE51
            break;
        // End:0x9BC9
        case 15761:
            param = "1,4,1,Party Recall,2";
            // End:0xEE51
            break;
        // End:0x9BEB
        case 15762:
            param = "1,4,1,Silence,7";
            // End:0xEE51
            break;
        // End:0x9C13
        case 15763:
            param = "1,4,1,Skill Refresh,2";
            // End:0xEE51
            break;
        // End:0x9C3B
        case 15764:
            param = "1,4,1,Skill Clarity,2";
            // End:0xEE51
            break;
        // End:0x9C63
        case 15765:
            param = "1,4,1,Music Refresh,2";
            // End:0xEE51
            break;
        // End:0x9C8B
        case 15766:
            param = "1,4,1,Music Clarity,2";
            // End:0xEE51
            break;
        // End:0x9CB3
        case 15767:
            param = "1,4,1,Spell Refresh,2";
            // End:0xEE51
            break;
        // End:0x9CDB
        case 15768:
            param = "1,4,1,Spell Clarity,2";
            // End:0xEE51
            break;
        // End:0x9CFD
        case 15769:
            param = "1,4,1,Stealth,1";
            // End:0xEE51
            break;
        // End:0x9D25
        case 15770:
            param = "1,4,1,Vampiric Rage,7";
            // End:0xEE51
            break;
        // End:0x9D4D
        case 15771:
            param = "1,4,3,Physical Doom,7";
            // End:0xEE51
            break;
        // End:0x9D7A
        case 15772:
            param = "1,4,3,Physical Mana Burn,7";
            // End:0xEE51
            break;
        // End:0x9DA6
        case 15773:
            param = "1,4,3,Physical Paralyze,7";
            // End:0xEE51
            break;
        // End:0x9DD1
        case 15774:
            param = "1,4,3,Physical Silence,7";
            // End:0xEE51
            break;
        // End:0x9DFA
        case 15775:
            param = "1,4,3,Physical Sleep,7";
            // End:0xEE51
            break;
        // End:0x9E22
        case 15776:
            param = "1,4,3,Physical Stun,7";
            // End:0xEE51
            break;
        // End:0x9E4A
        case 15777:
            param = "1,4,3,Critical Doom,7";
            // End:0xEE51
            break;
        // End:0x9E77
        case 15778:
            param = "1,4,3,Critical Mana Burn,7";
            // End:0xEE51
            break;
        // End:0x9EA3
        case 15779:
            param = "1,4,3,Critical Paralyze,7";
            // End:0xEE51
            break;
        // End:0x9ECE
        case 15780:
            param = "1,4,3,Critical Silence,7";
            // End:0xEE51
            break;
        // End:0x9EF7
        case 15781:
            param = "1,4,3,Critical Sleep,7";
            // End:0xEE51
            break;
        // End:0x9F1F
        case 15782:
            param = "1,4,3,Critical Stun,7";
            // End:0xEE51
            break;
        // End:0x9F3E
        case 15783:
            param = "1,4,3,Doom,7";
            // End:0xEE51
            break;
        // End:0x9F5D
        case 15784:
            param = "1,4,3,Fear,7";
            // End:0xEE51
            break;
        // End:0x9F81
        case 15785:
            param = "1,4,3,Mana Gain,7";
            // End:0xEE51
            break;
        // End:0x9FA4
        case 15786:
            param = "1,4,3,Recharge,7";
            // End:0xEE51
            break;
        // End:0x9FC7
        case 15787:
            param = "1,4,3,Paralyze,7";
            // End:0xEE51
            break;
        // End:0x9FE9
        case 15788:
            param = "1,4,3,Silence,7";
            // End:0xEE51
            break;
        // End:0xA008
        case 15789:
            param = "1,4,3,Stun,7";
            // End:0xEE51
            break;
        // End:0xA029
        case 15790:
            param = "1,4,3,Medusa,7";
            // End:0xEE51
            break;
        // End:0xA050
        case 15791:
            param = "1,4,3,Magical Doom,7";
            // End:0xEE51
            break;
        // End:0xA07C
        case 15792:
            param = "1,4,3,Magical Mana Burn,7";
            // End:0xEE51
            break;
        // End:0xA0A7
        case 15793:
            param = "1,4,3,Magical Paralyze,7";
            // End:0xEE51
            break;
        // End:0xA0D1
        case 15794:
            param = "1,4,3,Magical Silence,7";
            // End:0xEE51
            break;
        // End:0xA0F9
        case 15795:
            param = "1,4,3,Magical Sleep,7";
            // End:0xEE51
            break;
        // End:0xA120
        case 15796:
            param = "1,4,3,Magical Stun,7";
            // End:0xEE51
            break;
        // End:0xA142
        case 15797:
            param = "1,4,2,Clarity,2";
            // End:0xEE51
            break;
        // End:0xA164
        case 15798:
            param = "1,4,2,Agility,7";
            // End:0xEE51
            break;
        // End:0xA184
        case 15799:
            param = "1,4,2,Focus,7";
            // End:0xEE51
            break;
        // End:0xA1AD
        case 15800:
            param = "1,4,2,Reflect Damage,2";
            // End:0xEE51
            break;
        // End:0xA1D0
        case 15801:
            param = "1,4,2,Guidance,7";
            // End:0xEE51
            break;
        // End:0xA1F5
        case 15802:
            param = "1,4,2,Wild Magic,7";
            // End:0xEE51
            break;
        // End:0xA219
        case 15803:
            param = "1,4,2,Mana Gain,7";
            // End:0xEE51
            break;
        // End:0xA241
        case 15804:
            param = "1,4,2,Skill Clarity,2";
            // End:0xEE51
            break;
        // End:0xA269
        case 15805:
            param = "1,4,2,Music Clarity,2";
            // End:0xEE51
            break;
        // End:0xA291
        case 15806:
            param = "1,4,2,Spell Clarity,2";
            // End:0xEE51
            break;
        // End:0xA2B2
        case 15824:
            param = "1,3,1,Winter,8";
            // End:0xEE51
            break;
        // End:0xA2D4
        case 15825:
            param = "1,3,1,Agility,8";
            // End:0xEE51
            break;
        // End:0xA2F4
        case 15826:
            param = "1,3,1,Bleed,8";
            // End:0xEE51
            break;
        // End:0xA315
        case 15827:
            param = "1,3,1,Ritual,8";
            // End:0xEE51
            break;
        // End:0xA335
        case 15828:
            param = "1,3,1,Stone,8";
            // End:0xEE51
            break;
        // End:0xA354
        case 15829:
            param = "1,3,1,Fear,8";
            // End:0xEE51
            break;
        // End:0xA379
        case 15830:
            param = "1,3,1,Prominence,8";
            // End:0xEE51
            break;
        // End:0xA399
        case 15831:
            param = "1,3,1,Peace,8";
            // End:0xEE51
            break;
        // End:0xA3B9
        case 15832:
            param = "1,3,1,Charm,8";
            // End:0xEE51
            break;
        // End:0xA3DE
        case 15833:
            param = "1,3,1,Aggression,8";
            // End:0xEE51
            break;
        // End:0xA401
        case 15834:
            param = "1,3,1,Guidance,8";
            // End:0xEE51
            break;
        // End:0xA420
        case 15835:
            param = "1,3,1,Hold,8";
            // End:0xEE51
            break;
        // End:0xA446
        case 15836:
            param = "1,3,1,Solar Flare,8";
            // End:0xEE51
            break;
        // End:0xA46D
        case 15837:
            param = "1,3,1,Heal Empower,8";
            // End:0xEE51
            break;
        // End:0xA48E
        case 15838:
            param = "1,3,1,Prayer,8";
            // End:0xEE51
            break;
        // End:0xA4AD
        case 15839:
            param = "1,3,1,Heal,8";
            // End:0xEE51
            break;
        // End:0xA4CF
        case 15840:
            param = "1,3,1,Empower,8";
            // End:0xEE51
            break;
        // End:0xA4EF
        case 15841:
            param = "1,3,1,Cheer,8";
            // End:0xEE51
            break;
        // End:0xA515
        case 15842:
            param = "1,3,1,Battle Roar,8";
            // End:0xEE51
            break;
        // End:0xA53C
        case 15843:
            param = "1,3,1,Blessed Body,8";
            // End:0xEE51
            break;
        // End:0xA563
        case 15844:
            param = "1,3,1,Blessed Soul,8";
            // End:0xEE51
            break;
        // End:0xA58B
        case 15845:
            param = "1,3,1,Magic Barrier,8";
            // End:0xEE51
            break;
        // End:0xA5AF
        case 15846:
            param = "1,3,1,Mana Burn,8";
            // End:0xEE51
            break;
        // End:0xA5D3
        case 15847:
            param = "1,3,1,Mana Gain,8";
            // End:0xEE51
            break;
        // End:0xA5F6
        case 15848:
            param = "1,3,1,Recharge,8";
            // End:0xEE51
            break;
        // End:0xA61B
        case 15849:
            param = "1,3,1,Aura Flare,8";
            // End:0xEE51
            break;
        // End:0xA63B
        case 15850:
            param = "1,3,1,Might,8";
            // End:0xEE51
            break;
        // End:0xA65E
        case 15851:
            param = "1,3,1,Paralyze,8";
            // End:0xEE51
            break;
        // End:0xA67F
        case 15852:
            param = "1,3,1,Shield,8";
            // End:0xEE51
            break;
        // End:0xA6A0
        case 15853:
            param = "1,3,1,Poison,8";
            // End:0xEE51
            break;
        // End:0xA6C8
        case 15854:
            param = "1,3,1,Duel Weakness,8";
            // End:0xEE51
            break;
        // End:0xA6ED
        case 15855:
            param = "1,3,1,Duel Might,8";
            // End:0xEE51
            break;
        // End:0xA70E
        case 15856:
            param = "1,3,1,Recall,1";
            // End:0xEE51
            break;
        // End:0xA735
        case 15857:
            param = "1,3,1,Resurrection,8";
            // End:0xEE51
            break;
        // End:0xA75A
        case 15858:
            param = "1,3,1,Self Stone,8";
            // End:0xEE51
            break;
        // End:0xA784
        case 15859:
            param = "1,3,1,Self Prominence,8";
            // End:0xEE51
            break;
        // End:0xA7AF
        case 15860:
            param = "1,3,1,Self Solar Flare,8";
            // End:0xEE51
            break;
        // End:0xA7D9
        case 15861:
            param = "1,3,1,Self Aura Flare,8";
            // End:0xEE51
            break;
        // End:0xA805
        case 15862:
            param = "1,3,1,Self Shadow Flare,8";
            // End:0xEE51
            break;
        // End:0xA830
        case 15863:
            param = "1,3,1,Self Hydro Blast,8";
            // End:0xEE51
            break;
        // End:0xA859
        case 15864:
            param = "1,3,1,Self Hurricane,8";
            // End:0xEE51
            break;
        // End:0xA879
        case 15865:
            param = "1,3,1,Sleep,8";
            // End:0xEE51
            break;
        // End:0xA898
        case 15866:
            param = "1,3,1,Slow,8";
            // End:0xEE51
            break;
        // End:0xA8B7
        case 15867:
            param = "1,3,1,Stun,8";
            // End:0xEE51
            break;
        // End:0xA8DA
        case 15868:
            param = "1,3,1,Ae Stone,8";
            // End:0xEE51
            break;
        // End:0xA902
        case 15869:
            param = "1,3,1,Ae Prominence,8";
            // End:0xEE51
            break;
        // End:0xA92B
        case 15870:
            param = "1,3,1,Ae Solar Flare,8";
            // End:0xEE51
            break;
        // End:0xA953
        case 15871:
            param = "1,3,1,Ae Aura Flare,8";
            // End:0xEE51
            break;
        // End:0xA97D
        case 15872:
            param = "1,3,1,Ae Shadow Flare,8";
            // End:0xEE51
            break;
        // End:0xA9A6
        case 15873:
            param = "1,3,1,Ae Hydro Blast,8";
            // End:0xEE51
            break;
        // End:0xA9CD
        case 15874:
            param = "1,3,1,Ae Hurricane,8";
            // End:0xEE51
            break;
        // End:0xA9ED
        case 15875:
            param = "1,3,1,Trick,8";
            // End:0xEE51
            break;
        // End:0xAA0E
        case 15876:
            param = "1,3,1,Medusa,8";
            // End:0xEE51
            break;
        // End:0xAA35
        case 15877:
            param = "1,3,1,Shadow Flare,8";
            // End:0xEE51
            break;
        // End:0xAA56
        case 15878:
            param = "1,3,1,Unlock,8";
            // End:0xEE51
            break;
        // End:0xAA7F
        case 15879:
            param = "1,3,1,Vampiric Touch,8";
            // End:0xEE51
            break;
        // End:0xAAA5
        case 15880:
            param = "1,3,1,Hydro Blast,8";
            // End:0xEE51
            break;
        // End:0xAAC9
        case 15881:
            param = "1,3,1,Hurricane,8";
            // End:0xEE51
            break;
        // End:0xAAF3
        case 15882:
            param = "1,3,3,Physical Winter,8";
            // End:0xEE51
            break;
        // End:0xAB1C
        case 15883:
            param = "1,3,3,Physical Bleed,8";
            // End:0xEE51
            break;
        // End:0xAB44
        case 15884:
            param = "1,3,3,Physical Fear,8";
            // End:0xEE51
            break;
        // End:0xAB6C
        case 15885:
            param = "1,3,3,Physical Hold,8";
            // End:0xEE51
            break;
        // End:0xAB96
        case 15886:
            param = "1,3,3,Physical Poison,8";
            // End:0xEE51
            break;
        // End:0xABC0
        case 15887:
            param = "1,3,3,Physical Medusa,8";
            // End:0xEE51
            break;
        // End:0xABEA
        case 15888:
            param = "1,3,3,Critical Winter,8";
            // End:0xEE51
            break;
        // End:0xAC13
        case 15889:
            param = "1,3,3,Critical Bleed,8";
            // End:0xEE51
            break;
        // End:0xAC3B
        case 15890:
            param = "1,3,3,Critical Fear,8";
            // End:0xEE51
            break;
        // End:0xAC63
        case 15891:
            param = "1,3,3,Critical Hold,8";
            // End:0xEE51
            break;
        // End:0xAC8D
        case 15892:
            param = "1,3,3,Critical Poison,8";
            // End:0xEE51
            break;
        // End:0xACB7
        case 15893:
            param = "1,3,3,Critical Medusa,8";
            // End:0xEE51
            break;
        // End:0xACD8
        case 15894:
            param = "1,3,3,Winter,8";
            // End:0xEE51
            break;
        // End:0xACFA
        case 15895:
            param = "1,3,3,Agility,8";
            // End:0xEE51
            break;
        // End:0xAD1A
        case 15896:
            param = "1,3,3,Bleed,8";
            // End:0xEE51
            break;
        // End:0xAD3B
        case 15897:
            param = "1,3,3,Ritual,8";
            // End:0xEE51
            break;
        // End:0xAD5B
        case 15898:
            param = "1,3,3,Focus,8";
            // End:0xEE51
            break;
        // End:0xAD7B
        case 15899:
            param = "1,3,3,Charm,8";
            // End:0xEE51
            break;
        // End:0xAD9E
        case 15900:
            param = "1,3,3,Guidance,8";
            // End:0xEE51
            break;
        // End:0xADBD
        case 15901:
            param = "1,3,3,Hold,8";
            // End:0xEE51
            break;
        // End:0xADDE
        case 15902:
            param = "1,3,3,Prayer,8";
            // End:0xEE51
            break;
        // End:0xADFD
        case 15903:
            param = "1,3,3,Heal,8";
            // End:0xEE51
            break;
        // End:0xAE1F
        case 15904:
            param = "1,3,3,Empower,8";
            // End:0xEE51
            break;
        // End:0xAE44
        case 15905:
            param = "1,3,3,Wild Magic,8";
            // End:0xEE51
            break;
        // End:0xAE64
        case 15906:
            param = "1,3,3,Cheer,8";
            // End:0xEE51
            break;
        // End:0xAE8B
        case 15907:
            param = "1,3,3,Blessed Body,8";
            // End:0xEE51
            break;
        // End:0xAEB2
        case 15908:
            param = "1,3,3,Blessed Soul,8";
            // End:0xEE51
            break;
        // End:0xAEDA
        case 15909:
            param = "1,3,3,Magic Barrier,8";
            // End:0xEE51
            break;
        // End:0xAEFA
        case 15910:
            param = "1,3,3,Might,8";
            // End:0xEE51
            break;
        // End:0xAF1B
        case 15911:
            param = "1,3,3,Shield,8";
            // End:0xEE51
            break;
        // End:0xAF3C
        case 15912:
            param = "1,3,3,Poison,8";
            // End:0xEE51
            break;
        // End:0xAF64
        case 15913:
            param = "1,3,3,Duel Weakness,8";
            // End:0xEE51
            break;
        // End:0xAF89
        case 15914:
            param = "1,3,3,Duel Might,8";
            // End:0xEE51
            break;
        // End:0xAFA9
        case 15915:
            param = "1,3,3,Sleep,8";
            // End:0xEE51
            break;
        // End:0xAFC8
        case 15916:
            param = "1,3,3,Slow,8";
            // End:0xEE51
            break;
        // End:0xAFF1
        case 15917:
            param = "1,3,3,Magical Winter,8";
            // End:0xEE51
            break;
        // End:0xB019
        case 15918:
            param = "1,3,3,Magical Bleed,8";
            // End:0xEE51
            break;
        // End:0xB040
        case 15919:
            param = "1,3,3,Magical Fear,8";
            // End:0xEE51
            break;
        // End:0xB067
        case 15920:
            param = "1,3,3,Magical Hold,8";
            // End:0xEE51
            break;
        // End:0xB090
        case 15921:
            param = "1,3,3,Magical Poison,8";
            // End:0xEE51
            break;
        // End:0xB0B9
        case 15922:
            param = "1,3,3,Magical Medusa,8";
            // End:0xEE51
            break;
        // End:0xB0E0
        case 15923:
            param = "1,3,2,Heal Empower,8";
            // End:0xEE51
            break;
        // End:0xB101
        case 15924:
            param = "1,3,2,Prayer,8";
            // End:0xEE51
            break;
        // End:0xB123
        case 15925:
            param = "1,3,2,Empower,8";
            // End:0xEE51
            break;
        // End:0xB14B
        case 15926:
            param = "1,3,2,Magic Barrier,8";
            // End:0xEE51
            break;
        // End:0xB16B
        case 15927:
            param = "1,3,2,Might,8";
            // End:0xEE51
            break;
        // End:0xB18C
        case 15928:
            param = "1,3,2,Shield,8";
            // End:0xEE51
            break;
        // End:0xB1B1
        case 15929:
            param = "1,3,2,Duel Might,8";
            // End:0xEE51
            break;
        // End:0xB1D8
        case 15930:
            param = "1,3,2,Weight Limit,8";
            // End:0xEE51
            break;
        // End:0xB1FA
        case 15931:
            param = "1,4,1,Refresh,2";
            // End:0xEE51
            break;
        // End:0xB21C
        case 15932:
            param = "1,4,1,Clarity,2";
            // End:0xEE51
            break;
        // End:0xB23C
        case 15933:
            param = "1,4,1,Focus,8";
            // End:0xEE51
            break;
        // End:0xB265
        case 15934:
            param = "1,4,1,Reflect Damage,2";
            // End:0xEE51
            break;
        // End:0xB284
        case 15935:
            param = "1,4,1,Doom,8";
            // End:0xEE51
            break;
        // End:0xB2A5
        case 15936:
            param = "1,4,1,Recall,2";
            // End:0xEE51
            break;
        // End:0xB2D0
        case 15937:
            param = "1,4,1,Celestial Shield,1";
            // End:0xEE51
            break;
        // End:0xB2F5
        case 15938:
            param = "1,4,1,Wild Magic,8";
            // End:0xEE51
            break;
        // End:0xB31C
        case 15939:
            param = "1,4,1,Party Recall,2";
            // End:0xEE51
            break;
        // End:0xB33E
        case 15940:
            param = "1,4,1,Silence,8";
            // End:0xEE51
            break;
        // End:0xB366
        case 15941:
            param = "1,4,1,Skill Refresh,2";
            // End:0xEE51
            break;
        // End:0xB38E
        case 15942:
            param = "1,4,1,Skill Clarity,2";
            // End:0xEE51
            break;
        // End:0xB3B6
        case 15943:
            param = "1,4,1,Music Refresh,2";
            // End:0xEE51
            break;
        // End:0xB3DE
        case 15944:
            param = "1,4,1,Music Clarity,2";
            // End:0xEE51
            break;
        // End:0xB406
        case 15945:
            param = "1,4,1,Spell Refresh,2";
            // End:0xEE51
            break;
        // End:0xB42E
        case 15946:
            param = "1,4,1,Spell Clarity,2";
            // End:0xEE51
            break;
        // End:0xB450
        case 15947:
            param = "1,4,1,Stealth,2";
            // End:0xEE51
            break;
        // End:0xB478
        case 15948:
            param = "1,4,1,Vampiric Rage,8";
            // End:0xEE51
            break;
        // End:0xB4A0
        case 15949:
            param = "1,4,3,Physical Doom,8";
            // End:0xEE51
            break;
        // End:0xB4CD
        case 15950:
            param = "1,4,3,Physical Mana Burn,8";
            // End:0xEE51
            break;
        // End:0xB4F9
        case 15951:
            param = "1,4,3,Physical Paralyze,8";
            // End:0xEE51
            break;
        // End:0xB524
        case 15952:
            param = "1,4,3,Physical Silence,8";
            // End:0xEE51
            break;
        // End:0xB54D
        case 15953:
            param = "1,4,3,Physical Sleep,8";
            // End:0xEE51
            break;
        // End:0xB575
        case 15954:
            param = "1,4,3,Physical Stun,8";
            // End:0xEE51
            break;
        // End:0xB59D
        case 15955:
            param = "1,4,3,Critical Doom,8";
            // End:0xEE51
            break;
        // End:0xB5CA
        case 15956:
            param = "1,4,3,Critical Mana Burn,8";
            // End:0xEE51
            break;
        // End:0xB5F6
        case 15957:
            param = "1,4,3,Critical Paralyze,8";
            // End:0xEE51
            break;
        // End:0xB621
        case 15958:
            param = "1,4,3,Critical Silence,8";
            // End:0xEE51
            break;
        // End:0xB64A
        case 15959:
            param = "1,4,3,Critical Sleep,8";
            // End:0xEE51
            break;
        // End:0xB672
        case 15960:
            param = "1,4,3,Critical Stun,8";
            // End:0xEE51
            break;
        // End:0xB691
        case 15961:
            param = "1,4,3,Doom,8";
            // End:0xEE51
            break;
        // End:0xB6B0
        case 15962:
            param = "1,4,3,Fear,8";
            // End:0xEE51
            break;
        // End:0xB6D4
        case 15963:
            param = "1,4,3,Mana Gain,8";
            // End:0xEE51
            break;
        // End:0xB6F7
        case 15964:
            param = "1,4,3,Recharge,8";
            // End:0xEE51
            break;
        // End:0xB71A
        case 15965:
            param = "1,4,3,Paralyze,8";
            // End:0xEE51
            break;
        // End:0xB73C
        case 15966:
            param = "1,4,3,Silence,8";
            // End:0xEE51
            break;
        // End:0xB75B
        case 15967:
            param = "1,4,3,Stun,8";
            // End:0xEE51
            break;
        // End:0xB77C
        case 15968:
            param = "1,4,3,Medusa,8";
            // End:0xEE51
            break;
        // End:0xB7A3
        case 15969:
            param = "1,4,3,Magical Doom,8";
            // End:0xEE51
            break;
        // End:0xB7CF
        case 15970:
            param = "1,4,3,Magical Mana Burn,8";
            // End:0xEE51
            break;
        // End:0xB7FA
        case 15971:
            param = "1,4,3,Magical Paralyze,8";
            // End:0xEE51
            break;
        // End:0xB824
        case 15972:
            param = "1,4,3,Magical Silence,8";
            // End:0xEE51
            break;
        // End:0xB84C
        case 15973:
            param = "1,4,3,Magical Sleep,8";
            // End:0xEE51
            break;
        // End:0xB873
        case 15974:
            param = "1,4,3,Magical Stun,8";
            // End:0xEE51
            break;
        // End:0xB895
        case 15975:
            param = "1,4,2,Clarity,2";
            // End:0xEE51
            break;
        // End:0xB8B7
        case 15976:
            param = "1,4,2,Agility,8";
            // End:0xEE51
            break;
        // End:0xB8D7
        case 15977:
            param = "1,4,2,Focus,8";
            // End:0xEE51
            break;
        // End:0xB900
        case 15978:
            param = "1,4,2,Reflect Damage,2";
            // End:0xEE51
            break;
        // End:0xB923
        case 15979:
            param = "1,4,2,Guidance,8";
            // End:0xEE51
            break;
        // End:0xB948
        case 15980:
            param = "1,4,2,Wild Magic,8";
            // End:0xEE51
            break;
        // End:0xB96C
        case 15981:
            param = "1,4,2,Mana Gain,8";
            // End:0xEE51
            break;
        // End:0xB994
        case 15982:
            param = "1,4,2,Skill Clarity,2";
            // End:0xEE51
            break;
        // End:0xB9BC
        case 15983:
            param = "1,4,2,Music Clarity,2";
            // End:0xEE51
            break;
        // End:0xB9E4
        case 15984:
            param = "1,4,2,Spell Clarity,2";
            // End:0xEE51
            break;
        // End:0xBA05
        case 16002:
            param = "1,3,1,Winter,9";
            // End:0xEE51
            break;
        // End:0xBA27
        case 16003:
            param = "1,3,1,Agility,9";
            // End:0xEE51
            break;
        // End:0xBA47
        case 16004:
            param = "1,3,1,Bleed,9";
            // End:0xEE51
            break;
        // End:0xBA68
        case 16005:
            param = "1,3,1,Ritual,9";
            // End:0xEE51
            break;
        // End:0xBA88
        case 16006:
            param = "1,3,1,Stone,9";
            // End:0xEE51
            break;
        // End:0xBAA7
        case 16007:
            param = "1,3,1,Fear,9";
            // End:0xEE51
            break;
        // End:0xBACC
        case 16008:
            param = "1,3,1,Prominence,9";
            // End:0xEE51
            break;
        // End:0xBAEC
        case 16009:
            param = "1,3,1,Peace,9";
            // End:0xEE51
            break;
        // End:0xBB0C
        case 16010:
            param = "1,3,1,Charm,9";
            // End:0xEE51
            break;
        // End:0xBB31
        case 16011:
            param = "1,3,1,Aggression,9";
            // End:0xEE51
            break;
        // End:0xBB54
        case 16012:
            param = "1,3,1,Guidance,9";
            // End:0xEE51
            break;
        // End:0xBB73
        case 16013:
            param = "1,3,1,Hold,9";
            // End:0xEE51
            break;
        // End:0xBB99
        case 16014:
            param = "1,3,1,Solar Flare,9";
            // End:0xEE51
            break;
        // End:0xBBC0
        case 16015:
            param = "1,3,1,Heal Empower,9";
            // End:0xEE51
            break;
        // End:0xBBE1
        case 16016:
            param = "1,3,1,Prayer,9";
            // End:0xEE51
            break;
        // End:0xBC00
        case 16017:
            param = "1,3,1,Heal,9";
            // End:0xEE51
            break;
        // End:0xBC22
        case 16018:
            param = "1,3,1,Empower,9";
            // End:0xEE51
            break;
        // End:0xBC42
        case 16019:
            param = "1,3,1,Cheer,9";
            // End:0xEE51
            break;
        // End:0xBC68
        case 16020:
            param = "1,3,1,Battle Roar,9";
            // End:0xEE51
            break;
        // End:0xBC8F
        case 16021:
            param = "1,3,1,Blessed Body,9";
            // End:0xEE51
            break;
        // End:0xBCB6
        case 16022:
            param = "1,3,1,Blessed Soul,9";
            // End:0xEE51
            break;
        // End:0xBCDE
        case 16023:
            param = "1,3,1,Magic Barrier,9";
            // End:0xEE51
            break;
        // End:0xBD02
        case 16024:
            param = "1,3,1,Mana Burn,9";
            // End:0xEE51
            break;
        // End:0xBD26
        case 16025:
            param = "1,3,1,Mana Gain,9";
            // End:0xEE51
            break;
        // End:0xBD49
        case 16026:
            param = "1,3,1,Recharge,9";
            // End:0xEE51
            break;
        // End:0xBD6E
        case 16027:
            param = "1,3,1,Aura Flare,9";
            // End:0xEE51
            break;
        // End:0xBD8E
        case 16028:
            param = "1,3,1,Might,9";
            // End:0xEE51
            break;
        // End:0xBDB1
        case 16029:
            param = "1,3,1,Paralyze,9";
            // End:0xEE51
            break;
        // End:0xBDD2
        case 16030:
            param = "1,3,1,Shield,9";
            // End:0xEE51
            break;
        // End:0xBDF3
        case 16031:
            param = "1,3,1,Poison,9";
            // End:0xEE51
            break;
        // End:0xBE1B
        case 16032:
            param = "1,3,1,Duel Weakness,9";
            // End:0xEE51
            break;
        // End:0xBE40
        case 16033:
            param = "1,3,1,Duel Might,9";
            // End:0xEE51
            break;
        // End:0xBE61
        case 16034:
            param = "1,3,1,Recall,1";
            // End:0xEE51
            break;
        // End:0xBE88
        case 16035:
            param = "1,3,1,Resurrection,9";
            // End:0xEE51
            break;
        // End:0xBEAD
        case 16036:
            param = "1,3,1,Self Stone,9";
            // End:0xEE51
            break;
        // End:0xBED7
        case 16037:
            param = "1,3,1,Self Prominence,9";
            // End:0xEE51
            break;
        // End:0xBF02
        case 16038:
            param = "1,3,1,Self Solar Flare,9";
            // End:0xEE51
            break;
        // End:0xBF2C
        case 16039:
            param = "1,3,1,Self Aura Flare,9";
            // End:0xEE51
            break;
        // End:0xBF58
        case 16040:
            param = "1,3,1,Self Shadow Flare,9";
            // End:0xEE51
            break;
        // End:0xBF83
        case 16041:
            param = "1,3,1,Self Hydro Blast,9";
            // End:0xEE51
            break;
        // End:0xBFAC
        case 16042:
            param = "1,3,1,Self Hurricane,9";
            // End:0xEE51
            break;
        // End:0xBFCC
        case 16043:
            param = "1,3,1,Sleep,9";
            // End:0xEE51
            break;
        // End:0xBFEB
        case 16044:
            param = "1,3,1,Slow,9";
            // End:0xEE51
            break;
        // End:0xC00A
        case 16045:
            param = "1,3,1,Stun,9";
            // End:0xEE51
            break;
        // End:0xC02D
        case 16046:
            param = "1,3,1,Ae Stone,9";
            // End:0xEE51
            break;
        // End:0xC055
        case 16047:
            param = "1,3,1,Ae Prominence,9";
            // End:0xEE51
            break;
        // End:0xC07E
        case 16048:
            param = "1,3,1,Ae Solar Flare,9";
            // End:0xEE51
            break;
        // End:0xC0A6
        case 16049:
            param = "1,3,1,Ae Aura Flare,9";
            // End:0xEE51
            break;
        // End:0xC0D0
        case 16050:
            param = "1,3,1,Ae Shadow Flare,9";
            // End:0xEE51
            break;
        // End:0xC0F9
        case 16051:
            param = "1,3,1,Ae Hydro Blast,9";
            // End:0xEE51
            break;
        // End:0xC120
        case 16052:
            param = "1,3,1,Ae Hurricane,9";
            // End:0xEE51
            break;
        // End:0xC140
        case 16053:
            param = "1,3,1,Trick,9";
            // End:0xEE51
            break;
        // End:0xC161
        case 16054:
            param = "1,3,1,Medusa,9";
            // End:0xEE51
            break;
        // End:0xC188
        case 16055:
            param = "1,3,1,Shadow Flare,9";
            // End:0xEE51
            break;
        // End:0xC1A9
        case 16056:
            param = "1,3,1,Unlock,9";
            // End:0xEE51
            break;
        // End:0xC1D2
        case 16057:
            param = "1,3,1,Vampiric Touch,9";
            // End:0xEE51
            break;
        // End:0xC1F8
        case 16058:
            param = "1,3,1,Hydro Blast,9";
            // End:0xEE51
            break;
        // End:0xC21C
        case 16059:
            param = "1,3,1,Hurricane,9";
            // End:0xEE51
            break;
        // End:0xC246
        case 16060:
            param = "1,3,3,Physical Winter,9";
            // End:0xEE51
            break;
        // End:0xC26F
        case 16061:
            param = "1,3,3,Physical Bleed,9";
            // End:0xEE51
            break;
        // End:0xC297
        case 16062:
            param = "1,3,3,Physical Fear,9";
            // End:0xEE51
            break;
        // End:0xC2BF
        case 16063:
            param = "1,3,3,Physical Hold,9";
            // End:0xEE51
            break;
        // End:0xC2E9
        case 16064:
            param = "1,3,3,Physical Poison,9";
            // End:0xEE51
            break;
        // End:0xC313
        case 16065:
            param = "1,3,3,Physical Medusa,9";
            // End:0xEE51
            break;
        // End:0xC33D
        case 16066:
            param = "1,3,3,Critical Winter,9";
            // End:0xEE51
            break;
        // End:0xC366
        case 16067:
            param = "1,3,3,Critical Bleed,9";
            // End:0xEE51
            break;
        // End:0xC38E
        case 16068:
            param = "1,3,3,Critical Fear,9";
            // End:0xEE51
            break;
        // End:0xC3B6
        case 16069:
            param = "1,3,3,Critical Hold,9";
            // End:0xEE51
            break;
        // End:0xC3E0
        case 16070:
            param = "1,3,3,Critical Poison,9";
            // End:0xEE51
            break;
        // End:0xC40A
        case 16071:
            param = "1,3,3,Critical Medusa,9";
            // End:0xEE51
            break;
        // End:0xC42B
        case 16072:
            param = "1,3,3,Winter,9";
            // End:0xEE51
            break;
        // End:0xC44D
        case 16073:
            param = "1,3,3,Agility,9";
            // End:0xEE51
            break;
        // End:0xC46D
        case 16074:
            param = "1,3,3,Bleed,9";
            // End:0xEE51
            break;
        // End:0xC48E
        case 16075:
            param = "1,3,3,Ritual,9";
            // End:0xEE51
            break;
        // End:0xC4AE
        case 16076:
            param = "1,3,3,Focus,9";
            // End:0xEE51
            break;
        // End:0xC4CE
        case 16077:
            param = "1,3,3,Charm,9";
            // End:0xEE51
            break;
        // End:0xC4F1
        case 16078:
            param = "1,3,3,Guidance,9";
            // End:0xEE51
            break;
        // End:0xC510
        case 16079:
            param = "1,3,3,Hold,9";
            // End:0xEE51
            break;
        // End:0xC531
        case 16080:
            param = "1,3,3,Prayer,9";
            // End:0xEE51
            break;
        // End:0xC550
        case 16081:
            param = "1,3,3,Heal,9";
            // End:0xEE51
            break;
        // End:0xC572
        case 16082:
            param = "1,3,3,Empower,9";
            // End:0xEE51
            break;
        // End:0xC597
        case 16083:
            param = "1,3,3,Wild Magic,9";
            // End:0xEE51
            break;
        // End:0xC5B7
        case 16084:
            param = "1,3,3,Cheer,9";
            // End:0xEE51
            break;
        // End:0xC5DE
        case 16085:
            param = "1,3,3,Blessed Body,9";
            // End:0xEE51
            break;
        // End:0xC605
        case 16086:
            param = "1,3,3,Blessed Soul,9";
            // End:0xEE51
            break;
        // End:0xC62D
        case 16087:
            param = "1,3,3,Magic Barrier,9";
            // End:0xEE51
            break;
        // End:0xC64D
        case 16088:
            param = "1,3,3,Might,9";
            // End:0xEE51
            break;
        // End:0xC66E
        case 16089:
            param = "1,3,3,Shield,9";
            // End:0xEE51
            break;
        // End:0xC68F
        case 16090:
            param = "1,3,3,Poison,9";
            // End:0xEE51
            break;
        // End:0xC6B7
        case 16091:
            param = "1,3,3,Duel Weakness,9";
            // End:0xEE51
            break;
        // End:0xC6DC
        case 16092:
            param = "1,3,3,Duel Might,9";
            // End:0xEE51
            break;
        // End:0xC6FC
        case 16093:
            param = "1,3,3,Sleep,9";
            // End:0xEE51
            break;
        // End:0xC71B
        case 16094:
            param = "1,3,3,Slow,9";
            // End:0xEE51
            break;
        // End:0xC744
        case 16095:
            param = "1,3,3,Magical Winter,9";
            // End:0xEE51
            break;
        // End:0xC76C
        case 16096:
            param = "1,3,3,Magical Bleed,9";
            // End:0xEE51
            break;
        // End:0xC793
        case 16097:
            param = "1,3,3,Magical Fear,9";
            // End:0xEE51
            break;
        // End:0xC7BA
        case 16098:
            param = "1,3,3,Magical Hold,9";
            // End:0xEE51
            break;
        // End:0xC7E3
        case 16099:
            param = "1,3,3,Magical Poison,9";
            // End:0xEE51
            break;
        // End:0xC80C
        case 16100:
            param = "1,3,3,Magical Medusa,9";
            // End:0xEE51
            break;
        // End:0xC833
        case 16101:
            param = "1,3,2,Heal Empower,9";
            // End:0xEE51
            break;
        // End:0xC854
        case 16102:
            param = "1,3,2,Prayer,9";
            // End:0xEE51
            break;
        // End:0xC876
        case 16103:
            param = "1,3,2,Empower,9";
            // End:0xEE51
            break;
        // End:0xC89E
        case 16104:
            param = "1,3,2,Magic Barrier,9";
            // End:0xEE51
            break;
        // End:0xC8BE
        case 16105:
            param = "1,3,2,Might,9";
            // End:0xEE51
            break;
        // End:0xC8DF
        case 16106:
            param = "1,3,2,Shield,9";
            // End:0xEE51
            break;
        // End:0xC904
        case 16107:
            param = "1,3,2,Duel Might,9";
            // End:0xEE51
            break;
        // End:0xC92B
        case 16108:
            param = "1,3,2,Weight Limit,9";
            // End:0xEE51
            break;
        // End:0xC94D
        case 16109:
            param = "1,4,1,Refresh,2";
            // End:0xEE51
            break;
        // End:0xC96F
        case 16110:
            param = "1,4,1,Clarity,2";
            // End:0xEE51
            break;
        // End:0xC98F
        case 16111:
            param = "1,4,1,Focus,9";
            // End:0xEE51
            break;
        // End:0xC9B8
        case 16112:
            param = "1,4,1,Reflect Damage,2";
            // End:0xEE51
            break;
        // End:0xC9D7
        case 16113:
            param = "1,4,1,Doom,9";
            // End:0xEE51
            break;
        // End:0xC9F8
        case 16114:
            param = "1,4,1,Recall,2";
            // End:0xEE51
            break;
        // End:0xCA23
        case 16115:
            param = "1,4,1,Celestial Shield,1";
            // End:0xEE51
            break;
        // End:0xCA48
        case 16116:
            param = "1,4,1,Wild Magic,9";
            // End:0xEE51
            break;
        // End:0xCA6F
        case 16117:
            param = "1,4,1,Party Recall,2";
            // End:0xEE51
            break;
        // End:0xCA91
        case 16118:
            param = "1,4,1,Silence,9";
            // End:0xEE51
            break;
        // End:0xCAB9
        case 16119:
            param = "1,4,1,Skill Refresh,2";
            // End:0xEE51
            break;
        // End:0xCAE1
        case 16120:
            param = "1,4,1,Skill Clarity,2";
            // End:0xEE51
            break;
        // End:0xCB09
        case 16121:
            param = "1,4,1,Music Refresh,2";
            // End:0xEE51
            break;
        // End:0xCB31
        case 16122:
            param = "1,4,1,Music Clarity,2";
            // End:0xEE51
            break;
        // End:0xCB59
        case 16123:
            param = "1,4,1,Spell Refresh,2";
            // End:0xEE51
            break;
        // End:0xCB81
        case 16124:
            param = "1,4,1,Spell Clarity,2";
            // End:0xEE51
            break;
        // End:0xCBA3
        case 16125:
            param = "1,4,1,Stealth,2";
            // End:0xEE51
            break;
        // End:0xCBCB
        case 16126:
            param = "1,4,1,Vampiric Rage,9";
            // End:0xEE51
            break;
        // End:0xCBF3
        case 16127:
            param = "1,4,3,Physical Doom,9";
            // End:0xEE51
            break;
        // End:0xCC20
        case 16128:
            param = "1,4,3,Physical Mana Burn,9";
            // End:0xEE51
            break;
        // End:0xCC4C
        case 16129:
            param = "1,4,3,Physical Paralyze,9";
            // End:0xEE51
            break;
        // End:0xCC77
        case 16130:
            param = "1,4,3,Physical Silence,9";
            // End:0xEE51
            break;
        // End:0xCCA0
        case 16131:
            param = "1,4,3,Physical Sleep,9";
            // End:0xEE51
            break;
        // End:0xCCC8
        case 16132:
            param = "1,4,3,Physical Stun,9";
            // End:0xEE51
            break;
        // End:0xCCF0
        case 16133:
            param = "1,4,3,Critical Doom,9";
            // End:0xEE51
            break;
        // End:0xCD1D
        case 16134:
            param = "1,4,3,Critical Mana Burn,9";
            // End:0xEE51
            break;
        // End:0xCD49
        case 16135:
            param = "1,4,3,Critical Paralyze,9";
            // End:0xEE51
            break;
        // End:0xCD74
        case 16136:
            param = "1,4,3,Critical Silence,9";
            // End:0xEE51
            break;
        // End:0xCD9D
        case 16137:
            param = "1,4,3,Critical Sleep,9";
            // End:0xEE51
            break;
        // End:0xCDC5
        case 16138:
            param = "1,4,3,Critical Stun,9";
            // End:0xEE51
            break;
        // End:0xCDE4
        case 16139:
            param = "1,4,3,Doom,9";
            // End:0xEE51
            break;
        // End:0xCE03
        case 16140:
            param = "1,4,3,Fear,9";
            // End:0xEE51
            break;
        // End:0xCE27
        case 16141:
            param = "1,4,3,Mana Gain,9";
            // End:0xEE51
            break;
        // End:0xCE4A
        case 16142:
            param = "1,4,3,Recharge,9";
            // End:0xEE51
            break;
        // End:0xCE6D
        case 16143:
            param = "1,4,3,Paralyze,9";
            // End:0xEE51
            break;
        // End:0xCE8F
        case 16144:
            param = "1,4,3,Silence,9";
            // End:0xEE51
            break;
        // End:0xCEAE
        case 16145:
            param = "1,4,3,Stun,9";
            // End:0xEE51
            break;
        // End:0xCECF
        case 16146:
            param = "1,4,3,Medusa,9";
            // End:0xEE51
            break;
        // End:0xCEF6
        case 16147:
            param = "1,4,3,Magical Doom,9";
            // End:0xEE51
            break;
        // End:0xCF22
        case 16148:
            param = "1,4,3,Magical Mana Burn,9";
            // End:0xEE51
            break;
        // End:0xCF4D
        case 16149:
            param = "1,4,3,Magical Paralyze,9";
            // End:0xEE51
            break;
        // End:0xCF77
        case 16150:
            param = "1,4,3,Magical Silence,9";
            // End:0xEE51
            break;
        // End:0xCF9F
        case 16151:
            param = "1,4,3,Magical Sleep,9";
            // End:0xEE51
            break;
        // End:0xCFC6
        case 16152:
            param = "1,4,3,Magical Stun,9";
            // End:0xEE51
            break;
        // End:0xCFE8
        case 16153:
            param = "1,4,2,Clarity,2";
            // End:0xEE51
            break;
        // End:0xD00A
        case 16154:
            param = "1,4,2,Agility,9";
            // End:0xEE51
            break;
        // End:0xD02A
        case 16155:
            param = "1,4,2,Focus,9";
            // End:0xEE51
            break;
        // End:0xD053
        case 16156:
            param = "1,4,2,Reflect Damage,2";
            // End:0xEE51
            break;
        // End:0xD076
        case 16157:
            param = "1,4,2,Guidance,9";
            // End:0xEE51
            break;
        // End:0xD09B
        case 16158:
            param = "1,4,2,Wild Magic,9";
            // End:0xEE51
            break;
        // End:0xD0BF
        case 16159:
            param = "1,4,2,Mana Gain,9";
            // End:0xEE51
            break;
        // End:0xD0E7
        case 16160:
            param = "1,4,2,Skill Clarity,2";
            // End:0xEE51
            break;
        // End:0xD10F
        case 16161:
            param = "1,4,2,Music Clarity,2";
            // End:0xEE51
            break;
        // End:0xD137
        case 16162:
            param = "1,4,2,Spell Clarity,2";
            // End:0xEE51
            break;
        // End:0xD159
        case 16180:
            param = "1,3,1,Winter,10";
            // End:0xEE51
            break;
        // End:0xD17C
        case 16181:
            param = "1,3,1,Agility,10";
            // End:0xEE51
            break;
        // End:0xD19D
        case 16182:
            param = "1,3,1,Bleed,10";
            // End:0xEE51
            break;
        // End:0xD1BF
        case 16183:
            param = "1,3,1,Ritual,10";
            // End:0xEE51
            break;
        // End:0xD1E0
        case 16184:
            param = "1,3,1,Stone,10";
            // End:0xEE51
            break;
        // End:0xD200
        case 16185:
            param = "1,3,1,Fear,10";
            // End:0xEE51
            break;
        // End:0xD226
        case 16186:
            param = "1,3,1,Prominence,10";
            // End:0xEE51
            break;
        // End:0xD247
        case 16187:
            param = "1,3,1,Peace,10";
            // End:0xEE51
            break;
        // End:0xD268
        case 16188:
            param = "1,3,1,Charm,10";
            // End:0xEE51
            break;
        // End:0xD28E
        case 16189:
            param = "1,3,1,Aggression,10";
            // End:0xEE51
            break;
        // End:0xD2B2
        case 16190:
            param = "1,3,1,Guidance,10";
            // End:0xEE51
            break;
        // End:0xD2D2
        case 16191:
            param = "1,3,1,Hold,10";
            // End:0xEE51
            break;
        // End:0xD2F9
        case 16192:
            param = "1,3,1,Solar Flare,10";
            // End:0xEE51
            break;
        // End:0xD321
        case 16193:
            param = "1,3,1,Heal Empower,10";
            // End:0xEE51
            break;
        // End:0xD343
        case 16194:
            param = "1,3,1,Prayer,10";
            // End:0xEE51
            break;
        // End:0xD363
        case 16195:
            param = "1,3,1,Heal,10";
            // End:0xEE51
            break;
        // End:0xD386
        case 16196:
            param = "1,3,1,Empower,10";
            // End:0xEE51
            break;
        // End:0xD3A7
        case 16197:
            param = "1,3,1,Cheer,10";
            // End:0xEE51
            break;
        // End:0xD3CE
        case 16198:
            param = "1,3,1,Battle Roar,10";
            // End:0xEE51
            break;
        // End:0xD3F6
        case 16199:
            param = "1,3,1,Blessed Body,10";
            // End:0xEE51
            break;
        // End:0xD41E
        case 16200:
            param = "1,3,1,Blessed Soul,10";
            // End:0xEE51
            break;
        // End:0xD447
        case 16201:
            param = "1,3,1,Magic Barrier,10";
            // End:0xEE51
            break;
        // End:0xD46C
        case 16202:
            param = "1,3,1,Mana Burn,10";
            // End:0xEE51
            break;
        // End:0xD491
        case 16203:
            param = "1,3,1,Mana Gain,10";
            // End:0xEE51
            break;
        // End:0xD4B5
        case 16204:
            param = "1,3,1,Recharge,10";
            // End:0xEE51
            break;
        // End:0xD4DB
        case 16205:
            param = "1,3,1,Aura Flare,10";
            // End:0xEE51
            break;
        // End:0xD4FC
        case 16206:
            param = "1,3,1,Might,10";
            // End:0xEE51
            break;
        // End:0xD520
        case 16207:
            param = "1,3,1,Paralyze,10";
            // End:0xEE51
            break;
        // End:0xD542
        case 16208:
            param = "1,3,1,Shield,10";
            // End:0xEE51
            break;
        // End:0xD564
        case 16209:
            param = "1,3,1,Poison,10";
            // End:0xEE51
            break;
        // End:0xD58D
        case 16210:
            param = "1,3,1,Duel Weakness,10";
            // End:0xEE51
            break;
        // End:0xD5B3
        case 16211:
            param = "1,3,1,Duel Might,10";
            // End:0xEE51
            break;
        // End:0xD5D4
        case 16212:
            param = "1,3,1,Recall,1";
            // End:0xEE51
            break;
        // End:0xD5FB
        case 16213:
            param = "1,3,1,Resurrection,9";
            // End:0xEE51
            break;
        // End:0xD621
        case 16214:
            param = "1,3,1,Self Stone,10";
            // End:0xEE51
            break;
        // End:0xD64C
        case 16215:
            param = "1,3,1,Self Prominence,10";
            // End:0xEE51
            break;
        // End:0xD678
        case 16216:
            param = "1,3,1,Self Solar Flare,10";
            // End:0xEE51
            break;
        // End:0xD6A3
        case 16217:
            param = "1,3,1,Self Aura Flare,10";
            // End:0xEE51
            break;
        // End:0xD6D0
        case 16218:
            param = "1,3,1,Self Shadow Flare,10";
            // End:0xEE51
            break;
        // End:0xD6FC
        case 16219:
            param = "1,3,1,Self Hydro Blast,10";
            // End:0xEE51
            break;
        // End:0xD726
        case 16220:
            param = "1,3,1,Self Hurricane,10";
            // End:0xEE51
            break;
        // End:0xD747
        case 16221:
            param = "1,3,1,Sleep,10";
            // End:0xEE51
            break;
        // End:0xD767
        case 16222:
            param = "1,3,1,Slow,10";
            // End:0xEE51
            break;
        // End:0xD787
        case 16223:
            param = "1,3,1,Stun,10";
            // End:0xEE51
            break;
        // End:0xD7AB
        case 16224:
            param = "1,3,1,Ae Stone,10";
            // End:0xEE51
            break;
        // End:0xD7D4
        case 16225:
            param = "1,3,1,Ae Prominence,10";
            // End:0xEE51
            break;
        // End:0xD7FE
        case 16226:
            param = "1,3,1,Ae Solar Flare,10";
            // End:0xEE51
            break;
        // End:0xD827
        case 16227:
            param = "1,3,1,Ae Aura Flare,10";
            // End:0xEE51
            break;
        // End:0xD852
        case 16228:
            param = "1,3,1,Ae Shadow Flare,10";
            // End:0xEE51
            break;
        // End:0xD87C
        case 16229:
            param = "1,3,1,Ae Hydro Blast,10";
            // End:0xEE51
            break;
        // End:0xD8A4
        case 16230:
            param = "1,3,1,Ae Hurricane,10";
            // End:0xEE51
            break;
        // End:0xD8C5
        case 16231:
            param = "1,3,1,Trick,10";
            // End:0xEE51
            break;
        // End:0xD8E7
        case 16232:
            param = "1,3,1,Medusa,10";
            // End:0xEE51
            break;
        // End:0xD90F
        case 16233:
            param = "1,3,1,Shadow Flare,10";
            // End:0xEE51
            break;
        // End:0xD931
        case 16234:
            param = "1,3,1,Unlock,10";
            // End:0xEE51
            break;
        // End:0xD95B
        case 16235:
            param = "1,3,1,Vampiric Touch,10";
            // End:0xEE51
            break;
        // End:0xD982
        case 16236:
            param = "1,3,1,Hydro Blast,10";
            // End:0xEE51
            break;
        // End:0xD9A7
        case 16237:
            param = "1,3,1,Hurricane,10";
            // End:0xEE51
            break;
        // End:0xD9D2
        case 16238:
            param = "1,3,3,Physical Winter,10";
            // End:0xEE51
            break;
        // End:0xD9FC
        case 16239:
            param = "1,3,3,Physical Bleed,10";
            // End:0xEE51
            break;
        // End:0xDA25
        case 16240:
            param = "1,3,3,Physical Fear,10";
            // End:0xEE51
            break;
        // End:0xDA4E
        case 16241:
            param = "1,3,3,Physical Hold,10";
            // End:0xEE51
            break;
        // End:0xDA79
        case 16242:
            param = "1,3,3,Physical Poison,10";
            // End:0xEE51
            break;
        // End:0xDAA4
        case 16243:
            param = "1,3,3,Physical Medusa,10";
            // End:0xEE51
            break;
        // End:0xDACF
        case 16244:
            param = "1,3,3,Critical Winter,10";
            // End:0xEE51
            break;
        // End:0xDAF9
        case 16245:
            param = "1,3,3,Critical Bleed,10";
            // End:0xEE51
            break;
        // End:0xDB22
        case 16246:
            param = "1,3,3,Critical Fear,10";
            // End:0xEE51
            break;
        // End:0xDB4B
        case 16247:
            param = "1,3,3,Critical Hold,10";
            // End:0xEE51
            break;
        // End:0xDB76
        case 16248:
            param = "1,3,3,Critical Poison,10";
            // End:0xEE51
            break;
        // End:0xDBA1
        case 16249:
            param = "1,3,3,Critical Medusa,10";
            // End:0xEE51
            break;
        // End:0xDBC3
        case 16250:
            param = "1,3,3,Winter,10";
            // End:0xEE51
            break;
        // End:0xDBE6
        case 16251:
            param = "1,3,3,Agility,10";
            // End:0xEE51
            break;
        // End:0xDC07
        case 16252:
            param = "1,3,3,Bleed,10";
            // End:0xEE51
            break;
        // End:0xDC29
        case 16253:
            param = "1,3,3,Ritual,10";
            // End:0xEE51
            break;
        // End:0xDC4A
        case 16254:
            param = "1,3,3,Focus,10";
            // End:0xEE51
            break;
        // End:0xDC6B
        case 16255:
            param = "1,3,3,Charm,10";
            // End:0xEE51
            break;
        // End:0xDC8F
        case 16256:
            param = "1,3,3,Guidance,10";
            // End:0xEE51
            break;
        // End:0xDCAF
        case 16257:
            param = "1,3,3,Hold,10";
            // End:0xEE51
            break;
        // End:0xDCD1
        case 16258:
            param = "1,3,3,Prayer,10";
            // End:0xEE51
            break;
        // End:0xDCF1
        case 16259:
            param = "1,3,3,Heal,10";
            // End:0xEE51
            break;
        // End:0xDD14
        case 16260:
            param = "1,3,3,Empower,10";
            // End:0xEE51
            break;
        // End:0xDD3A
        case 16261:
            param = "1,3,3,Wild Magic,10";
            // End:0xEE51
            break;
        // End:0xDD5B
        case 16262:
            param = "1,3,3,Cheer,10";
            // End:0xEE51
            break;
        // End:0xDD83
        case 16263:
            param = "1,3,3,Blessed Body,10";
            // End:0xEE51
            break;
        // End:0xDDAB
        case 16264:
            param = "1,3,3,Blessed Soul,10";
            // End:0xEE51
            break;
        // End:0xDDD4
        case 16265:
            param = "1,3,3,Magic Barrier,10";
            // End:0xEE51
            break;
        // End:0xDDF5
        case 16266:
            param = "1,3,3,Might,10";
            // End:0xEE51
            break;
        // End:0xDE17
        case 16267:
            param = "1,3,3,Shield,10";
            // End:0xEE51
            break;
        // End:0xDE39
        case 16268:
            param = "1,3,3,Poison,10";
            // End:0xEE51
            break;
        // End:0xDE62
        case 16269:
            param = "1,3,3,Duel Weakness,10";
            // End:0xEE51
            break;
        // End:0xDE88
        case 16270:
            param = "1,3,3,Duel Might,10";
            // End:0xEE51
            break;
        // End:0xDEA9
        case 16271:
            param = "1,3,3,Sleep,10";
            // End:0xEE51
            break;
        // End:0xDEC9
        case 16272:
            param = "1,3,3,Slow,10";
            // End:0xEE51
            break;
        // End:0xDEF3
        case 16273:
            param = "1,3,3,Magical Winter,10";
            // End:0xEE51
            break;
        // End:0xDF1C
        case 16274:
            param = "1,3,3,Magical Bleed,10";
            // End:0xEE51
            break;
        // End:0xDF44
        case 16275:
            param = "1,3,3,Magical Fear,10";
            // End:0xEE51
            break;
        // End:0xDF6C
        case 16276:
            param = "1,3,3,Magical Hold,10";
            // End:0xEE51
            break;
        // End:0xDF96
        case 16277:
            param = "1,3,3,Magical Poison,10";
            // End:0xEE51
            break;
        // End:0xDFC0
        case 16278:
            param = "1,3,3,Magical Medusa,10";
            // End:0xEE51
            break;
        // End:0xDFE8
        case 16279:
            param = "1,3,2,Heal Empower,10";
            // End:0xEE51
            break;
        // End:0xE00A
        case 16280:
            param = "1,3,2,Prayer,10";
            // End:0xEE51
            break;
        // End:0xE02D
        case 16281:
            param = "1,3,2,Empower,10";
            // End:0xEE51
            break;
        // End:0xE056
        case 16282:
            param = "1,3,2,Magic Barrier,10";
            // End:0xEE51
            break;
        // End:0xE077
        case 16283:
            param = "1,3,2,Might,10";
            // End:0xEE51
            break;
        // End:0xE099
        case 16284:
            param = "1,3,2,Shield,10";
            // End:0xEE51
            break;
        // End:0xE0BF
        case 16285:
            param = "1,3,2,Duel Might,10";
            // End:0xEE51
            break;
        // End:0xE0E7
        case 16286:
            param = "1,3,2,Weight Limit,10";
            // End:0xEE51
            break;
        // End:0xE109
        case 16287:
            param = "1,4,1,Refresh,3";
            // End:0xEE51
            break;
        // End:0xE12B
        case 16288:
            param = "1,4,1,Clarity,3";
            // End:0xEE51
            break;
        // End:0xE14C
        case 16289:
            param = "1,4,1,Focus,10";
            // End:0xEE51
            break;
        // End:0xE175
        case 16290:
            param = "1,4,1,Reflect Damage,3";
            // End:0xEE51
            break;
        // End:0xE195
        case 16291:
            param = "1,4,1,Doom,10";
            // End:0xEE51
            break;
        // End:0xE1B6
        case 16292:
            param = "1,4,1,Recall,2";
            // End:0xEE51
            break;
        // End:0xE1E1
        case 16293:
            param = "1,4,1,Celestial Shield,1";
            // End:0xEE51
            break;
        // End:0xE207
        case 16294:
            param = "1,4,1,Wild Magic,10";
            // End:0xEE51
            break;
        // End:0xE22E
        case 16295:
            param = "1,4,1,Party Recall,2";
            // End:0xEE51
            break;
        // End:0xE251
        case 16296:
            param = "1,4,1,Silence,10";
            // End:0xEE51
            break;
        // End:0xE279
        case 16297:
            param = "1,4,1,Skill Refresh,3";
            // End:0xEE51
            break;
        // End:0xE2A1
        case 16298:
            param = "1,4,1,Skill Clarity,3";
            // End:0xEE51
            break;
        // End:0xE2C9
        case 16299:
            param = "1,4,1,Music Refresh,3";
            // End:0xEE51
            break;
        // End:0xE2F1
        case 16300:
            param = "1,4,1,Music Clarity,3";
            // End:0xEE51
            break;
        // End:0xE319
        case 16301:
            param = "1,4,1,Spell Refresh,3";
            // End:0xEE51
            break;
        // End:0xE341
        case 16302:
            param = "1,4,1,Spell Clarity,3";
            // End:0xEE51
            break;
        // End:0xE363
        case 16303:
            param = "1,4,1,Stealth,3";
            // End:0xEE51
            break;
        // End:0xE38C
        case 16304:
            param = "1,4,1,Vampiric Rage,10";
            // End:0xEE51
            break;
        // End:0xE3B5
        case 16305:
            param = "1,4,3,Physical Doom,10";
            // End:0xEE51
            break;
        // End:0xE3E3
        case 16306:
            param = "1,4,3,Physical Mana Burn,10";
            // End:0xEE51
            break;
        // End:0xE410
        case 16307:
            param = "1,4,3,Physical Paralyze,10";
            // End:0xEE51
            break;
        // End:0xE43C
        case 16308:
            param = "1,4,3,Physical Silence,10";
            // End:0xEE51
            break;
        // End:0xE466
        case 16309:
            param = "1,4,3,Physical Sleep,10";
            // End:0xEE51
            break;
        // End:0xE48F
        case 16310:
            param = "1,4,3,Physical Stun,10";
            // End:0xEE51
            break;
        // End:0xE4B8
        case 16311:
            param = "1,4,3,Critical Doom,10";
            // End:0xEE51
            break;
        // End:0xE4E6
        case 16312:
            param = "1,4,3,Critical Mana Burn,10";
            // End:0xEE51
            break;
        // End:0xE513
        case 16313:
            param = "1,4,3,Critical Paralyze,10";
            // End:0xEE51
            break;
        // End:0xE53F
        case 16314:
            param = "1,4,3,Critical Silence,10";
            // End:0xEE51
            break;
        // End:0xE569
        case 16315:
            param = "1,4,3,Critical Sleep,10";
            // End:0xEE51
            break;
        // End:0xE592
        case 16316:
            param = "1,4,3,Critical Stun,10";
            // End:0xEE51
            break;
        // End:0xE5B2
        case 16317:
            param = "1,4,3,Doom,10";
            // End:0xEE51
            break;
        // End:0xE5D2
        case 16318:
            param = "1,4,3,Fear,10";
            // End:0xEE51
            break;
        // End:0xE5F7
        case 16319:
            param = "1,4,3,Mana Gain,10";
            // End:0xEE51
            break;
        // End:0xE61B
        case 16320:
            param = "1,4,3,Recharge,10";
            // End:0xEE51
            break;
        // End:0xE63F
        case 16321:
            param = "1,4,3,Paralyze,10";
            // End:0xEE51
            break;
        // End:0xE662
        case 16322:
            param = "1,4,3,Silence,10";
            // End:0xEE51
            break;
        // End:0xE682
        case 16323:
            param = "1,4,3,Stun,10";
            // End:0xEE51
            break;
        // End:0xE6A4
        case 16324:
            param = "1,4,3,Medusa,10";
            // End:0xEE51
            break;
        // End:0xE6CC
        case 16325:
            param = "1,4,3,Magical Doom,10";
            // End:0xEE51
            break;
        // End:0xE6F9
        case 16326:
            param = "1,4,3,Magical Mana Burn,10";
            // End:0xEE51
            break;
        // End:0xE725
        case 16327:
            param = "1,4,3,Magical Paralyze,10";
            // End:0xEE51
            break;
        // End:0xE750
        case 16328:
            param = "1,4,3,Magical Silence,10";
            // End:0xEE51
            break;
        // End:0xE779
        case 16329:
            param = "1,4,3,Magical Sleep,10";
            // End:0xEE51
            break;
        // End:0xE7A1
        case 16330:
            param = "1,4,3,Magical Stun,10";
            // End:0xEE51
            break;
        // End:0xE7C3
        case 16331:
            param = "1,4,2,Clarity,3";
            // End:0xEE51
            break;
        // End:0xE7E6
        case 16332:
            param = "1,4,2,Agility,10";
            // End:0xEE51
            break;
        // End:0xE807
        case 16333:
            param = "1,4,2,Focus,10";
            // End:0xEE51
            break;
        // End:0xE830
        case 16334:
            param = "1,4,2,Reflect Damage,3";
            // End:0xEE51
            break;
        // End:0xE854
        case 16335:
            param = "1,4,2,Guidance,10";
            // End:0xEE51
            break;
        // End:0xE87A
        case 16336:
            param = "1,4,2,Wild Magic,10";
            // End:0xEE51
            break;
        // End:0xE89F
        case 16337:
            param = "1,4,2,Mana Gain,10";
            // End:0xEE51
            break;
        // End:0xE8C7
        case 16338:
            param = "1,4,2,Skill Clarity,3";
            // End:0xEE51
            break;
        // End:0xE8EF
        case 16339:
            param = "1,4,2,Music Clarity,3";
            // End:0xEE51
            break;
        // End:0xE917
        case 16340:
            param = "1,4,2,Spell Clarity,3";
            // End:0xEE51
            break;
        // End:0xE938
        case 16341:
            param = "1,4,4,STR +1,1";
            // End:0xEE51
            break;
        // End:0xE959
        case 16342:
            param = "1,4,4,CON +1,1";
            // End:0xEE51
            break;
        // End:0xE97A
        case 16343:
            param = "1,4,4,INT +1,1";
            // End:0xEE51
            break;
        // End:0xE99B
        case 16344:
            param = "1,4,4,MEN +1,1";
            // End:0xEE51
            break;
        // End:0xE9BC
        case 16345:
            param = "1,4,4,STR +1,1";
            // End:0xEE51
            break;
        // End:0xE9DD
        case 16346:
            param = "1,4,4,CON +1,1";
            // End:0xEE51
            break;
        // End:0xE9FE
        case 16347:
            param = "1,4,4,INT +1,1";
            // End:0xEE51
            break;
        // End:0xEA1F
        case 16348:
            param = "1,4,4,MEN +1,1";
            // End:0xEE51
            break;
        // End:0xEA40
        case 16349:
            param = "1,4,4,STR +1,1";
            // End:0xEE51
            break;
        // End:0xEA61
        case 16350:
            param = "1,4,4,CON +1,1";
            // End:0xEE51
            break;
        // End:0xEA82
        case 16351:
            param = "1,4,4,INT +1,1";
            // End:0xEE51
            break;
        // End:0xEAA3
        case 16352:
            param = "1,4,4,MEN +1,1";
            // End:0xEE51
            break;
        // End:0xEAC4
        case 16353:
            param = "1,4,4,STR +1,1";
            // End:0xEE51
            break;
        // End:0xEAE5
        case 16354:
            param = "1,4,4,CON +1,1";
            // End:0xEE51
            break;
        // End:0xEB06
        case 16355:
            param = "1,4,4,INT +1,1";
            // End:0xEE51
            break;
        // End:0xEB27
        case 16356:
            param = "1,4,4,MEN +1,1";
            // End:0xEE51
            break;
        // End:0xEB48
        case 16357:
            param = "1,4,4,STR +1,1";
            // End:0xEE51
            break;
        // End:0xEB69
        case 16358:
            param = "1,4,4,CON +1,1";
            // End:0xEE51
            break;
        // End:0xEB8A
        case 16359:
            param = "1,4,4,INT +1,1";
            // End:0xEE51
            break;
        // End:0xEBAB
        case 16360:
            param = "1,4,4,MEN +1,1";
            // End:0xEE51
            break;
        // End:0xEBCC
        case 16361:
            param = "1,4,4,STR +1,1";
            // End:0xEE51
            break;
        // End:0xEBED
        case 16362:
            param = "1,4,4,CON +1,1";
            // End:0xEE51
            break;
        // End:0xEC0E
        case 16363:
            param = "1,4,4,INT +1,1";
            // End:0xEE51
            break;
        // End:0xEC2F
        case 16364:
            param = "1,4,4,MEN +1,1";
            // End:0xEE51
            break;
        // End:0xEC50
        case 16365:
            param = "1,4,4,STR +1,1";
            // End:0xEE51
            break;
        // End:0xEC71
        case 16366:
            param = "1,4,4,CON +1,1";
            // End:0xEE51
            break;
        // End:0xEC92
        case 16367:
            param = "1,4,4,INT +1,1";
            // End:0xEE51
            break;
        // End:0xECB3
        case 16368:
            param = "1,4,4,MEN +1,1";
            // End:0xEE51
            break;
        // End:0xECD4
        case 16369:
            param = "1,4,4,STR +1,1";
            // End:0xEE51
            break;
        // End:0xECF5
        case 16370:
            param = "1,4,4,CON +1,1";
            // End:0xEE51
            break;
        // End:0xED16
        case 16371:
            param = "1,4,4,INT +1,1";
            // End:0xEE51
            break;
        // End:0xED37
        case 16372:
            param = "1,4,4,MEN +1,1";
            // End:0xEE51
            break;
        // End:0xED58
        case 16373:
            param = "1,4,4,STR +1,1";
            // End:0xEE51
            break;
        // End:0xED79
        case 16374:
            param = "1,4,4,CON +1,1";
            // End:0xEE51
            break;
        // End:0xED9A
        case 16375:
            param = "1,4,4,INT +1,1";
            // End:0xEE51
            break;
        // End:0xEDBB
        case 16376:
            param = "1,4,4,MEN +1,1";
            // End:0xEE51
            break;
        // End:0xEDDC
        case 16377:
            param = "1,4,4,STR +1,1";
            // End:0xEE51
            break;
        // End:0xEDFD
        case 16378:
            param = "1,4,4,CON +1,1";
            // End:0xEE51
            break;
        // End:0xEE1E
        case 16379:
            param = "1,4,4,INT +1,1";
            // End:0xEE51
            break;
        // End:0xEE3F
        case 16380:
            param = "1,4,4,MEN +1,1";
            // End:0xEE51
            break;
        // End:0xFFFF
        default:
            param = ",,,,";
            // End:0xEE51
            break;
            break;
    }
    ResultParam = param;
    return;
}

function HideWindow(string a_ControlID)
{
  Class'UIAPI_WINDOW'.static.HideWindow(a_ControlID);
}

function bool IsShowWindow(string a_ControlID)
{
  return Class'UIAPI_WINDOW'.static.IsShowWindow(a_ControlID);
}


function HideWindowTutorial(string Window)
{
    // End:0x55
    if((IsShowWindow("TutorialOverlayWnd")) || IsShowWindow("TutorialLightWnd"))
    {
        ExecuteEvent(99970, "Window=" $ Window);
    }
 
}



function TextureHandle xxGetTextureHandle(string WindowName)
{
  local TextureHandle Handle;

  Handle = TextureHandle(GetHandle(WindowName));
  return Handle;
}

function TextBoxHandle xxGetTextBoxHandle(string WindowName)
{
  local TextBoxHandle Handle;

  Handle = TextBoxHandle(GetHandle(WindowName));
  return Handle;
}

function AnimTextureHandle xxGetAnimTextureHandle(string WindowName)
{
  local AnimTextureHandle Handle;

  Handle = AnimTextureHandle(GetHandle(WindowName));
  return Handle;
}
function WindowHandle xxGetWindowHandle(string WindowName)
{
  local WindowHandle Handle;

  Handle = GetHandle(WindowName);
  return Handle;
}

function xxnotifyserver(string zzsass)
{
    local string zzsseeaa;
//	local SuperNotifWnd notif;

    ParamAdd(zzsseeaa, "Notification", zzsass);
    ParamAdd(zzsseeaa, "Width", string((xxsaeeewa(zzsass)) + 16));
    ParamAdd(zzsseeaa, "Height", "32");
    ParamAdd(zzsseeaa, "Timer", "7700");
    ParamAdd(zzsseeaa, "TextColor", string(Rand(8)));
    ExecuteEvent(99997, zzsseeaa);
//	notif = SuperNotifWnd(GetScript("SuperNotifWnd"));
//	notif.setNotification(430, 95, 50000, zzsseeaa, "L2ACDC", "htmlBtns.f_mp_reduce", xxgetInstanceL2Util().Red, xxgetInstanceL2Util().BrightWhite);
    return;
}


function ItemInfo xxgetitemfolakia(int id)
{
    local ItemInfo info;

    Class'UIDATA_ITEM'.static.GetItemInfo(id, info);
    return info;

}


function array<string> gettiera()
{
    local array<string> tier;

    tier[tier.Length] = " - Common";
    tier[tier.Length] = " - Uncommon";
    tier[tier.Length] = " - Rare";
    tier[tier.Length] = " - Epic";
    tier[tier.Length] = " - Legendary";
    tier[tier.Length] = " - Supreme";
    return tier;

}


function string xxgetsalax(string param)
{
    local array<string> dakla;
    local int inka;

    dakla = gettiera();
    inka = 0;
    J0x13:

    // End:0x5F [Loop If]
    if(inka < dakla.Length)
    {
        // End:0x55
        if(InStr(param, dakla[inka]) > 0)
        {
            return Left(param, InStr(param, dakla[inka]));
        }
        inka++;
        // [Loop Continue]
        goto J0x13;
    }
    return param;

}


function xxnotifyserverespecial(string zzsass)
{

	local SuperNotifWnd zznotif;
	  local L2Util zzutilbar;
  zzutilbar = L2Util(GetScript("L2Util"));
	
	
		            // End:0x9D
            if(!Class'UIAPI_CHECKBOX'.static.IsChecked("OptionWnd.SuperNotific"))
            {
                return;
            }

	zznotif = SuperNotifWnd(GetScript("SuperNotifWnd"));
	zznotif.setNotification(430, 65, 7700, zzsass, zzutilbar.xxgetAD(), "htmlBtns.f_mp_reduce", xxgetInstanceL2Util().Red, xxgetInstanceL2Util().BrightWhite);
    return;
}


  function TreeInsertTextNodeItem (string TreeName, string NodeName, string ItemName, optional int offsetX, optional int offsetY, optional int E, optional bool OneLine, optional bool bLineBreak, optional int reserved, optional int reserved2)
{
    local XMLTreeNodeItemInfo infNodeItem; //DC2
  
    infNodeItem.eType = XTNITEM_TEXT;
    infNodeItem.t_strText = ItemName;
    infNodeItem.t_bDrawOneLine = OneLine;
    infNodeItem.bLineBreak = bLineBreak;
    infNodeItem.nOffSetX = offsetX;
    infNodeItem.nOffSetY = offsetY;
    infNodeItem = setTreeTextColor( E, infNodeItem );
    Class'UIAPI_TREECTRL'.static.InsertNodeItem(TreeName,NodeName,infNodeItem);
}


	function XMLTreeNodeItemInfo setTreeTextColor (int E, XMLTreeNodeItemInfo infNodeItem)
{
	switch (E)
	{
		case 0:
		infNodeItem.t_color.R = 255;
		infNodeItem.t_color.G = 255;
		infNodeItem.t_color.B = 255;
		infNodeItem.t_color.A = 255;
		break;
		case 1:
		infNodeItem.t_color.R = 163;
		infNodeItem.t_color.G = 163;
		infNodeItem.t_color.B = 163;
		infNodeItem.t_color.A = 255;
		break;
		case 2:
		infNodeItem.t_color.R = 176;
		infNodeItem.t_color.G = 155;
		infNodeItem.t_color.B = 121;
		infNodeItem.t_color.A = 255;
		break;
		case 3:
		infNodeItem.t_color.R = 250;
		infNodeItem.t_color.G = 50;
		infNodeItem.t_color.B = 0;
		infNodeItem.t_color.A = 255;
		break;
		case 4:
		infNodeItem.t_color.R = 240;
		infNodeItem.t_color.G = 214;
		infNodeItem.t_color.B = 54;
		infNodeItem.t_color.A = 255;
		break;
		case 5:
		infNodeItem.t_color.R = 175;
		infNodeItem.t_color.G = 185;
		infNodeItem.t_color.B = 205;
		infNodeItem.t_color.A = 255;
		break;
		case 6:
		infNodeItem.t_color.R = 102;
		infNodeItem.t_color.G = 150;
		infNodeItem.t_color.B = 253;
		infNodeItem.t_color.A = 255;
		break;
		case 7:
		infNodeItem.t_color.R = 85;
		infNodeItem.t_color.G = 170;
		infNodeItem.t_color.B = 255;
		infNodeItem.t_color.A = 255;
		break;
		case 8:
		infNodeItem.t_color.R = 211;
		infNodeItem.t_color.G = 192;
		infNodeItem.t_color.B = 82;
		infNodeItem.t_color.A = 255;
		break;
		case 9:
		infNodeItem.t_color.R = 170;
		infNodeItem.t_color.G = 152;
		infNodeItem.t_color.B = 120;
		infNodeItem.t_color.A = 255;
		break;
		case 10:
		infNodeItem.t_color.R = 168;
		infNodeItem.t_color.G = 103;
		infNodeItem.t_color.B = 53;
		infNodeItem.t_color.A = 255;
		break;
		case 11:
		infNodeItem.t_color.R = 175;
		infNodeItem.t_color.G = 42;
		infNodeItem.t_color.B = 39;
		infNodeItem.t_color.A = 255;
		break;
		case 12:
		infNodeItem.t_color.R = 255;
		infNodeItem.t_color.G = 204;
		infNodeItem.t_color.B = 0;
		infNodeItem.t_color.A = 255;
		break;
		case 13:
		infNodeItem.t_color.R = 170;
		infNodeItem.t_color.G = 110;
		infNodeItem.t_color.B = 230;
		infNodeItem.t_color.A = 255;
		break;
		default:
	}
	return infNodeItem;
}  




  function insNodeItem(string strTreeName, string strNodeName, XMLTreeNodeItemInfo infNodeItem)
{
    Class'UIAPI_TREECTRL'.static.InsertNodeItem(strTreeName, strNodeName, infNodeItem);
}	
  function TreeInsertTextureNode(string TreeName, string NodeName, string TextureName, int TextureWidth, int TextureHeight, optional int offsetX, optional int offsetY, optional bool bOutline, optional bool bBreakLine, optional int uTextureWidth, optional int uTextureHeight, optional string strMouseOver)
{
    local XMLTreeNodeItemInfo infNodeItem;

    infNodeItem.eType = XTNITEM_TEXTURE;
    infNodeItem.t_bDrawOneLine = bOutline;
    infNodeItem.bLineBreak = bBreakLine;
    infNodeItem.nOffSetX = offsetX;
    infNodeItem.nOffSetY = offsetY;
    infNodeItem.u_nTextureWidth = TextureWidth;
    infNodeItem.u_nTextureHeight = TextureHeight;
    infNodeItem.u_nTextureUWidth = uTextureWidth;
    infNodeItem.u_nTextureUHeight = uTextureHeight;
    infNodeItem.u_strTexture = TextureName;
    if(strMouseOver != "")
    {
        infNodeItem.u_strTextureMouseOn = strMouseOver;
    }
    insNodeItem(TreeName, NodeName, infNodeItem);
}

	function string setItemTier(string strIndex, string strCompare)
{
	local private int i, j;

	j = Len(strCompare);
	i = InStr(strIndex, strCompare);
	if(i > -1)
	{
		return Mid(strIndex, i + j, 1);
	}
	return "";
}	

  function TreeInsertNodeItemColor(string TreeName, string NodeName, string ItemName, optional int offsetX, optional int offsetY, optional Color nodeColor, optional bool bOutline, optional bool bLineBreak)
{
    local private XMLTreeNodeItemInfo infNodeItem;

    infNodeItem.eType = XTNITEM_TEXT;
    infNodeItem.t_strText = ItemName;
    infNodeItem.t_bDrawOneLine = bOutline;
    infNodeItem.bLineBreak = bLineBreak;
    infNodeItem.nOffSetX = offsetX;
    infNodeItem.nOffSetY = offsetY;
    infNodeItem.t_color = nodeColor;
	
    insNodeItem(TreeName, NodeName, infNodeItem);
}	






  function array<string> getItemRarity()
{
	local private array<private string> writeStr;

	writeStr[writeStr.Length] = " - Common";
	writeStr[writeStr.Length] = " - Uncommon";
	writeStr[writeStr.Length] = " - Rare";
	writeStr[writeStr.Length] = " - Epic";
	writeStr[writeStr.Length] = " - Legendary";
	writeStr[writeStr.Length] = " - Supreme";
	
	return writeStr;
}	
	function int setTooltipNameColor(string strIndex)
{
	local private array<private string> writeStr;
	local private int i;

	writeStr = getItemRarity();
	i = 0;
	J0x13:
	if(i < writeStr.Length)
	{
		if(InStr(strIndex, writeStr[i]) > 0)
		{
			return i;
		}
		i++;
		goto J0x13;
	}
	return -1;
}



function Vector CalculateScreenLocation(Vector WorldLocation)
{
  local Vector ScreenLocation;
  local float ScreenWidth;
  local float ScreenHeight;
  local float ScreenNaoSei;
  local int ScreenX;
  local int ScreenY;
  local Vector ViewLocation;
  local Rotator ViewRotation;
  local Vector ViewDirection;
  local Actor PlayerActor;

  GetCurrentResolution(ScreenX,ScreenY);
  ScreenHeight = ScreenX;
  ScreenNaoSei = ScreenY;
  getActorViwerPort().Actor.PlayerCalcView(PlayerActor,ViewLocation, ViewRotation);
  ScreenLocation = WorldLocation - ViewLocation << ViewRotation;
  ScreenWidth = ScreenHeight / 2 / Tan(getActorViwerPort().Actor.Pawn.Controller.FovAngle / 2 / 180 * Pi);
  ViewDirection.X = ScreenLocation.Y / ScreenLocation.X * ScreenWidth + ScreenHeight / 2 - ScreenHeight * 0.45;
  ViewDirection.Y =  -ScreenLocation.Z / ScreenLocation.X * ScreenWidth + ScreenNaoSei / 2 - ScreenNaoSei * 0.50;
  return ViewDirection;
}



function Viewport getActorViwerPort()
{
  return class'CustomPlayerController'.static.GetActorViewport();
}








function xxnotifyserverlargo(string zzsass)
{

	local SuperNotifWnd notif;


	notif = SuperNotifWnd(GetScript("SuperNotifWnd"));
	notif.setNotification(430, 95, 7700, zzsass, "L2ACDC", "htmlBtns.f_mp_reduce", xxgetInstanceL2Util().Red, xxgetInstanceL2Util().BrightWhite);
    return;
}





function int xxsaeeewa(string zzsaaas)
{
    local int zsdaw, zsswwwa2;

    GetTextSize(zzsaaas, zsdaw, zsswwwa2);
    return zsdaw;

}




function ComboBoxHandle xxGetComboBoxHandle( string WindowName )
{
  local  ComboBoxHandle Handle;

  Handle = ComboBoxHandle(GetHandle(WindowName));
  return Handle;
}
function getrechandle(string oaran, out int i, out int o)
{
    local private Rect rectaxa;

    rectaxa = GetHandle(oaran).GetRect();
    i = rectaxa.nX;
    o = rectaxa.nY;
    return;
}

function float xxmultiplicorato(float zzd, float zzsw)
{
    return zzd * zzsw;
  
}

function float xxdividorazo(float zzd, float zzsw)
{
    return zzd / zzsw;
   
}



function ButtonHandle xxGetButtonHandle(string WindowName)
{
  local ButtonHandle Handle;

  Handle = ButtonHandle(GetHandle(WindowName));
  return Handle;
}

function ItemWindowHandle xxGetItemWindowHandle(string WindowName)
{
  local ItemWindowHandle Handle;

  Handle = ItemWindowHandle(GetHandle(WindowName));
  return Handle;
}

function string sos(string SourceString, string SearchString)
{
    local int StartIndex;
    local int EndIndex;

    StartIndex = InStr(SourceString, SearchString);
    if (StartIndex > 0)
    {
        // Skip the length of SearchString to get the substring after it
        EndIndex = StartIndex + Len(SearchString);
        return Mid(SourceString, EndIndex, Len(SourceString) - EndIndex + 1);
    }

    return "";
}



function int Int64ToInt (INT64 int64Param)
{
  local int intParam;
  local string paramBuffer;

  ParamAddInt64(paramBuffer,"INT64buffer",int64Param);
  if ( ParseInt(paramBuffer,"INT64buffer",intParam) )
  {
    intParam = 0;
  }
  return intParam;
}


function xxlotus2k(string param, Color Color)
{
    Class'UIAPI_TEXTLISTBOX'.static.AddString("SystemMsgWnd.SystemMsgList", param, Color);
    Class'UIAPI_TEXTLISTBOX'.static.AddString("ChatWnd.NormalChat", param, Color);
    Class'UIAPI_TEXTLISTBOX'.static.AddString("ChatWnd.PartyChat", param, Color);
    Class'UIAPI_TEXTLISTBOX'.static.AddString("ChatWnd.ClanChat", param, Color);
    Class'UIAPI_TEXTLISTBOX'.static.AddString("ChatWnd.TradeChat", param, Color);
    Class'UIAPI_TEXTLISTBOX'.static.AddString("ChatWnd.AllyChat", param, Color);
    return;
}





function ParamToItemInfo (string index, out ItemInfo Info)
{
  local int tmpInt;
  local EItemType eItemType;
  eItemType = EItemType(info.ItemType);

  ParseInt(index,"classID",Info.ClassID);
  ParseInt(index,"level",Info.Level);
  ParseString(index,"name",Info.Name);
  ParseString(index,"additionalName",Info.AdditionalName);
  ParseString(index,"iconName",Info.IconName);
  ParseString(index,"description",Info.Description);
  ParseInt(index,"itemType",Info.ItemType);
  ParseInt(index,"serverID",Info.ServerID);
  ParseInt(index,"itemNum",Info.ItemNum);
  ParseInt(index,"slotBitType",Info.SlotBitType);
  ParseInt(index,"enchanted",Info.Enchanted);
  ParseInt(index,"blessed",Info.Blessed);
  ParseInt(index,"damaged",Info.Damaged);
  if ( ParseInt(index,"equipped",tmpInt) )
  {
    Info.bEquipped = bool(tmpInt);
  }
  ParseInt(index,"price",Info.Price);
  ParseInt(index,"reserved",Info.Reserved);
  ParseInt(index,"defaultPrice",Info.DefaultPrice);
  ParseInt(index,"refineryOp1",Info.RefineryOp1);
  ParseInt(index,"refineryOp2",Info.RefineryOp2);
  ParseInt(index,"currentDurability",Info.CurrentDurability);
  ParseInt(index,"weight",Info.Weight);
  ParseInt(index,"materialType",Info.MaterialType);
  ParseInt(index,"weaponType",Info.WeaponType);
  ParseInt(index,"physicalDamage",Info.PhysicalDamage);
  ParseInt(index,"magicalDamage",Info.MagicalDamage);
  ParseInt(index,"shieldDefense",Info.ShieldDefense);
  ParseInt(index,"shieldDefenseRate",Info.ShieldDefenseRate);
  ParseInt(index,"durability",Info.Durability);
  ParseInt(index,"crystalType",Info.CrystalType);
  ParseInt(index,"randomDamage",Info.RandomDamage);
  ParseInt(index,"critical",Info.Critical);
  ParseInt(index,"hitModify",Info.HitModify);
  ParseInt(index,"attackSpeed",Info.AttackSpeed);
  ParseInt(index,"mpConsume",Info.MpConsume);
  ParseInt(index,"avoidModify",Info.AvoidModify);
  ParseInt(index,"soulshotCount",Info.SoulshotCount);
  ParseInt(index,"spiritshotCount",Info.SpiritshotCount);
  ParseInt(index,"armorType",Info.ArmorType);
  ParseInt(index,"physicalDefense",Info.PhysicalDefense);
  ParseInt(index,"magicalDefense",Info.MagicalDefense);
  ParseInt(index,"mpBonus",Info.MpBonus);
  ParseInt(index,"consumeType",Info.ConsumeType);
  ParseInt(index,"ItemSubType",Info.ItemSubType);
  ParseString(index,"iconNameEx1",Info.IconNameEx1);
  ParseString(index,"iconNameEx2",Info.IconNameEx2);
  ParseString(index,"iconNameEx3",Info.IconNameEx3);
  ParseString(index,"iconNameEx4",Info.IconNameEx4);
  if ( ParseInt(index,"arrow",tmpInt) )
  {
    Info.bArrow = bool(tmpInt);
  }
  if ( ParseInt(index,"recipe",tmpInt) )
  {
    Info.bRecipe = bool(tmpInt);
  }
  	if ((eItemType == ITEM_WEAPON || eItemType == ITEM_ARMOR || eItemType == ITEM_ACCESSARY) && (Info.Enchanted <= 50  && Info.Enchanted > 0))
    {
        Info.ForeTexture = "L2UI_CH3.ENCHANT" $ Info.Enchanted $ "";
    }

if (Info.ItemNum > 1)
{
    if (Info.ItemNum > 99)
    {
        Info.ForeTexture = "L2UI_CH3.ItemCount.texCount99+";
    }
    else
    {
        Info.ForeTexture = "L2UI_CH3.ItemCount.texCount" $ string(Info.ItemNum);
    }
}





	
  
  
}


function ItemInfoToParam (ItemInfo Info, out string param)
{
  ParamAdd(param,"ClassID",string(Info.ClassID));
  ParamAdd(param,"ServerID",string(Info.ServerID));
  ParamAdd(param,"level",string(Info.Level));
  ParamAdd(param,"name",Info.Name);
  ParamAdd(param,"additionalName",Info.AdditionalName);
  ParamAdd(param,"iconName",Info.IconName);
  ParamAdd(param,"description",Info.Description);
  ParamAdd(param,"itemType",string(Info.ItemType));
  ParamAdd(param,"itemNum",string(Info.ItemNum));
  ParamAdd(param,"slotBitType",string(Info.SlotBitType));
  ParamAdd(param,"enchanted",string(Info.Enchanted));
  ParamAdd(param,"blessed",string(Info.Blessed));
  ParamAdd(param,"damaged",string(Info.Damaged));
  ParamAdd(param,"equipped",string(Info.bEquipped));
  ParamAdd(param,"price",string(Info.Price));
  ParamAdd(param,"reserved",string(Info.Reserved));
  ParamAdd(param,"defaultPrice",string(Info.DefaultPrice));
  ParamAdd(param,"refineryOp1",string(Info.RefineryOp1));
  ParamAdd(param,"refineryOp2",string(Info.RefineryOp2));
  ParamAdd(param,"currentDurability",string(Info.CurrentDurability));
  ParamAdd(param,"weight",string(Info.Weight));
  ParamAdd(param,"materialType",string(Info.MaterialType));
  ParamAdd(param,"weaponType",string(Info.WeaponType));
  ParamAdd(param,"physicalDamage",string(Info.PhysicalDamage));
  ParamAdd(param,"magicalDamage",string(Info.MagicalDamage));
  ParamAdd(param,"shieldDefense",string(Info.ShieldDefense));
  ParamAdd(param,"shieldDefenseRate",string(Info.ShieldDefenseRate));
  ParamAdd(param,"durability",string(Info.Durability));
  ParamAdd(param,"crystalType",string(Info.CrystalType));
  ParamAdd(param,"randomDamage",string(Info.RandomDamage));
  ParamAdd(param,"critical",string(Info.Critical));
  ParamAdd(param,"hitModify",string(Info.HitModify));
  ParamAdd(param,"attackSpeed",string(Info.AttackSpeed));
  ParamAdd(param,"mpConsume",string(Info.MpConsume));
  ParamAdd(param,"avoidModify",string(Info.AvoidModify));
  ParamAdd(param,"soulshotCount",string(Info.SoulshotCount));
  ParamAdd(param,"spiritshotCount",string(Info.SpiritshotCount));
  ParamAdd(param,"armorType",string(Info.ArmorType));
  ParamAdd(param,"physicalDefense",string(Info.PhysicalDefense));
  ParamAdd(param,"magicalDefense",string(Info.MagicalDefense));
  ParamAdd(param,"mpBonus",string(Info.MpBonus));
  ParamAdd(param,"consumeType",string(Info.ConsumeType));
  ParamAdd(param,"ItemSubType",string(Info.ItemSubType));
  ParamAdd(param,"iconNameEx1",Info.IconNameEx1);
  ParamAdd(param,"iconNameEx2",Info.IconNameEx2);
  ParamAdd(param,"iconNameEx3",Info.IconNameEx3);
  ParamAdd(param,"iconNameEx4",Info.IconNameEx4);
  ParamAdd(param,"arrow",string(Info.bArrow));
  ParamAdd(param,"recipe",string(Info.bRecipe));
}






function ParamToRecord (string index, out LVDataRecord record)
{
  local int idx;
  local int MaxColumn;

  ParseString(index,"szReserved",record.szReserved);
  ParseInt(index,"nReserved1",record.nReserved1);
  ParseInt(index,"nReserved2",record.nReserved2);
  ParseInt(index,"nReserved3",record.nReserved3);
  ParseInt(index,"MaxColumn",MaxColumn);
  record.LVDataList.Length = MaxColumn;
  idx = 0;
  JL00B7:
  if ( idx < MaxColumn )
  {
    ParseString(index,"szData_" $ string(idx),record.LVDataList[idx].szData);
    ParseString(index,"szReserved_" $ string(idx),record.LVDataList[idx].szReserved);
    ParseInt(index,"nReserved1_" $ string(idx),record.LVDataList[idx].nReserved1);
    ParseInt(index,"nReserved2_" $ string(idx),record.LVDataList[idx].nReserved2);
    ParseInt(index,"nReserved3_" $ string(idx),record.LVDataList[idx].nReserved3);
    idx++;
    goto JL00B7;
  }
}

function L2Util xxgetInstanceL2Util()
{
  local L2Util utilbar;
  utilbar = L2Util(GetScript("L2Util"));
  return utilbar; 
}

function EnableWindow (string Window)
{
  Class'UIAPI_WINDOW'.static.EnableWindow(Window);
}

function DisableWindow (string Window)
{
  Class'UIAPI_WINDOW'.static.DisableWindow(Window);
}


function getbypassactor ()
{
  RequestBypassToServer("GetActor");
}





function DrawItemInfo xxDrawBlank(int Height)
{
  local DrawItemInfo Info;

  Info.eType = DIT_BLANK;
  Info.b_nHeight = Height;
  return Info;
}


function DrawItemInfo DrawTex(string Tex, int Width, int Height, int UWidth, int UHeight, int nOffSetX, int nOffSetY, bool bDrawOneLine, bool bLineBreak)
{
  local DrawItemInfo Info;

  Info.eType = DIT_TEXTURE;
  Info.t_bDrawOneLine = bDrawOneLine;
  Info.bLineBreak = bLineBreak;
  Info.u_nTextureWidth = Width;
  Info.u_nTextureHeight = Height;
  Info.u_nTextureUWidth = UWidth;
  Info.u_nTextureUHeight = UHeight;
  Info.nOffSetX = nOffSetX;
  Info.nOffSetY = nOffSetY;
  Info.u_strTexture = Tex;
  return Info;
}



function DrawItemInfo xxDrawText(string Text, Color c_Color, bool bDrawOneLine, bool bLineBreak, int nOffSetX, int nOffSetY)
{
  local DrawItemInfo Info;

  Info.eType = DIT_TEXT;
  Info.t_color = c_Color;
  Info.t_bDrawOneLine = bDrawOneLine;
  Info.bLineBreak = bLineBreak;
  Info.nOffSetX = nOffSetX;
  Info.nOffSetY = nOffSetY;
  Info.t_strText = Text;
  return Info;
}

	function Color SetCustomColor (private string Colors)
{
    local private Color RGB;

    RGB.A = 255;
    switch (Colors)
    {
        case "Goldlite":
        RGB.R = 230;
        RGB.G = 213;
        RGB.B = 164;
        break;
        case "Grey":
        RGB.R = 180;
        RGB.G = 180;
        RGB.B = 180;
        break;
        case "GreyLight":
        RGB.R = 220;
        RGB.G = 220;
        RGB.B = 220;
        break;
        case "GreyDark":
        RGB.R = 100;
        RGB.G = 100;
        RGB.B = 100;
        break;
        case "Yellow":
        RGB.R = 255;
        RGB.G = 255;
        RGB.B = 0;
        break;
        case "Red":
        RGB.R = 255;
        RGB.G = 0;
        RGB.B = 0;
        break;
        case "Blue":
        RGB.R = 0;
        RGB.G = 0;
        RGB.B = 255;
        break;
        case "Green":
        RGB.R = 0;
        RGB.G = 255;
        RGB.B = 0;
        break;
        case "Orange":
        RGB.R = 230;
        RGB.G = 153;
        RGB.B = 77;
        break;
        case "System":
        RGB.R = 176;
        RGB.G = 155;
        RGB.B = 121;
        break;
        case "Amber":
        RGB.R = 218;
        RGB.G = 165;
        RGB.B = 32;
        break;
        case "White":
        RGB.R = 255;
        RGB.G = 255;
        RGB.B = 255;
        break;
        case "Dim":
        RGB.R = 177;
        RGB.G = 173;
        RGB.B = 172;
        break;
        case "Magenta":
        RGB.R = 255;
        RGB.G = 0;
        RGB.B = 255;
        break;
        case "Brown":
        RGB.R = 176;
        RGB.G = 155;
        RGB.B = 121;
        break;
        case "Black":
        RGB.R = 0;
        RGB.G = 0;
        RGB.B = 0;
        break;
        case "LightPink":
        RGB.R = 191;
        RGB.G = 168;
        RGB.B = 211;
        break;
        case "LightBlue":
        RGB.R = 0;
        RGB.G = 168;
        RGB.B = 211;
        break;
        default:
        RGB.R = 255;
        RGB.G = 255;
        RGB.B = 255;
        break;
    }
    return RGB;
}	
  function Color getAColor (int R, int G, int B, int A)
{
	local Color tColor;

	tColor.R = R;
	tColor.G = G;
	tColor.B = B;
	tColor.A = A;
	return tColor;
} 


	function bool bTooltipItem(out string outStrIndex)
{
	local private array<private string> strIndex;
	local private int i, j;
	local private bool bShow;

	strIndex = setItemStages();
	i = 0;
	J0x13:
	if(i < strIndex.Length)
	{
		j = InStr(outStrIndex, strIndex[i]);
		if(j == -1)
		{
			goto J0xD3;
		}
		if(Right(strIndex[i], 1) == "{")
		{
			outStrIndex = ReplaceText(outStrIndex, Mid(outStrIndex, j, InStr(outStrIndex, "}") + 3), "");
			bShow = false;
			goto J0xD3;
		}
		outStrIndex = ReplaceText(outStrIndex, Mid(outStrIndex, j, Len(strIndex[i]) + 3), "");
		bShow = true;
		J0xD3:
		i++;
		goto J0x13;
	}
	return bShow;
}
  function array<string> setItemStages()
{
	local private array<private string> strIndex;

	strIndex[strIndex.Length] = "WeaponStage:";
	strIndex[strIndex.Length] = "WeaponStatus:";
	strIndex[strIndex.Length] = "Tier:";
	strIndex[strIndex.Length] = "ArmorStatus:";
	strIndex[strIndex.Length] = "JewelStage:";
	strIndex[strIndex.Length] = "Acquire:{";
	
	return strIndex;
}





  function string setItemDecWidth(string strIndex, int intIndex)
{
	local private int i;
	local private string lineJump, outStr, compareStr;
	local private array<private string> writeStr;

	if(InStr(strIndex, "\\n") > -1)
	{
		return strIndex;
	}
	outStr = "";
	compareStr = "";
	intIndex -= 6;
	lineJump = "";
	writeStr = getStringItems(strIndex, " ");
	i = 0;
	J0x59:
	if(i < writeStr.Length)
	{
		if(((GetTextWidth(compareStr)) + (GetTextWidth(writeStr[i]))) <= intIndex)
		{
			if(i == writeStr.Length)
			{
				compareStr = compareStr $ writeStr[i];                
			}
			else
			{
				compareStr = (compareStr $ writeStr[i]) $ " ";
			}
			goto J0x10B;
		}
		outStr = (outStr $ compareStr) $ lineJump;
		compareStr = writeStr[i] $ " ";
		J0x10B:
		i++;
		goto J0x59;
	}
	outStr = outStr $ compareStr;
	return outStr;
}
  
  function array<string> getStringItems(string strIndex, string strBlank)
{
	local private string percStr;
	local private array<private string> strSize;
	local private int i;

	percStr = strIndex;
	J0x0B:
	if(percStr != "")
	{
		i = InStr(percStr, strBlank);
		if(i == -1)
		{
			strSize[strSize.Length] = percStr;
			percStr = "";            
		}
		else
		{
			strSize[strSize.Length] = Left(percStr, i);
			percStr = Mid(percStr, i + Len(strBlank));
		}
		goto J0x0B;
	}
	return strSize;
}
  function EditBoxHandle xxGetEditBoxHandle (string WindowName)
{
	local EditBoxHandle Handle;

	Handle = EditBoxHandle(GetHandle(WindowName));
	return Handle;
} 
  function TabHandle xxGetTabHandle(string WindowName)
{
    local private TabHandle Handle;

    Handle = TabHandle(GetHandle(WindowName));
    return Handle;
}

	function xDPatch (string Msg)
{
    local ChatWindowHandle NormalChat;
    local Color Color;
  
    NormalChat = ChatWindowHandle(GetHandle("ChatWnd.NormalChat"));
    Color.R = 153;
    Color.G = 51;
    Color.B = 0;
    Color.A = 255;
    NormalChat.AddString("xDPatch: " $ Msg, Color);
}

  function ItemInfo SetItemTooltip(int Index)
{
    local private ItemInfo outItem;

    Class'UIDATA_ITEM'.static.GetItemInfo(Index, outItem);
    return outItem;
}




	function int setShopItemID(string strIndex)
{
    local private int outIndex, inCount, i;

    outIndex = 0;
    inCount = Len(strIndex);
    i = 0;
    J0x1B:
    if(i < inCount)
    {
        outIndex = (outIndex * 31) + Asc(Mid(strIndex, i, 1));
        i++;
        goto J0x1B;
    }
    return outIndex;
}	




 function int setAcquireItem(string filter, string Description)
{
	local int i;
	local string strTmp, strValue;

	strTmp = Description;
	i = InStr(strTmp, filter);
	if(i != -1)
	{
		if(filter != "Acquire:{")
		{
			strValue = Mid(strTmp, i + Len(filter), 1);            
		}
		else
		{
			return i + Len(filter);
		}
		return int(strValue);
	}
}	


















	function bool getItemInveCompare(int SlotBitType, out ItemWindowHandle hItemWnd)
{
	local ItemInfo ItemSlot;

	switch(SlotBitType)
	{
		case 2:
		case 4:
		case 6:
			if(!xxGetItemWindowHandle("InventoryWnd.EquipItem_REar").GetItem(0, ItemSlot))
			{
				hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_REar");                
			}
			else
			{
				hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_LEar");
			}
			return true;
		break;
			
		case 16:
		case 32:
		case 48:
			if(!xxGetItemWindowHandle("InventoryWnd.EquipItem_RFinger").GetItem(0, ItemSlot))
			{
				hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_RFinger");                
			}
			else
			{
				hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_LFinger");
			}
			return true;
		break;
			
		case 8:
			hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_Neck");
			return true;
		break;
			
		case 64:
			hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_Head");
			return true;
		break;
			
		case 1024:
		case 32768:
			hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_Chest");
			return true;
		break;
			
		case 2048:
			hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_Legs");
			return true;
		break;
			
		case 512:
			hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_Gloves");
			return true;
		break;
			
		case 4096:
			hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_Feet");
			return true;
		break;
			
		case 256:
			hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_LHand");
			return true;
		break;
			
		case 16384:
		case 128:
			hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_RHand");
			return true;
		break;
			
		default:
			return false;
		break;
	}
}
	function string setTooltipNameItem(string strIndex)
{
	local private array<private string> writeStr;
	local private int i;

	writeStr = getItemRarity();
	i = 0;
	J0x13:
	if(i < writeStr.Length)
	{
		if(InStr(strIndex, writeStr[i]) > 0)
		{
			return Left(strIndex, InStr(strIndex, writeStr[i]));
		}
		i++;
		goto J0x13;
	}
	return strIndex;
}



function CustomTooltip xxMakeTooltipSimpleText(string Text)
{
  local CustomTooltip ToolTip;
  local DrawItemInfo Info;

  ToolTip.DrawList.Length = 1;
  Info.eType = DIT_TEXT;
  Info.t_bDrawOneLine = True;
  Info.t_strText = Text;
  ToolTip.DrawList[0] = Info;
  return ToolTip;
}

function int GetSecond ()
{
  local array<string> arrSplit;
  local int SplitCount;
  local string strNodeName;
  local int strCount;

  strNodeName = GetTimeString();
  SplitCount = Split(strNodeName,":",arrSplit);
  if ( SplitCount > 0 )
  {
    strNodeName = arrSplit[2];
    strCount = int(strNodeName);
  }
  return strCount;
}

function SetSuperRaceShop (bool index)
{
  SuperRaceShop = index;
}

function bool GetSuperRaceShop ()
{
  return SuperRaceShop;
}

function string GetSuperRace (string text)
{
  local string Result;
  local int SplitCount;
  local int i;
  local array<string> temp;
  local array<string> texttemp;

  temp.Length = 0;
  texttemp.Length = 0;
  SplitCount = Split(text,",",texttemp);
  i = 0;
  JL0030:
  if ( i <= texttemp.Length )
  {
    temp[i] = Chr(int(texttemp[i]));
    Result = Result $ temp[i];
    ++i;
    goto JL0030;
  }
  return Result;
}

function NphrnDisableInterface ()
{
  SetOptionBool("Neophron","HoldTarget",False);
  SetOptionBool("Neophron","IgnoreAggr",False);
  SetOptionBool("Neophron","UseDoping",False);
  Class'UIAPI_CHECKBOX'.static.SetCheck("NPHRN_Tab.Cb_HoldTarget",False);
  Class'UIAPI_CHECKBOX'.static.SetCheck("NPHRN_Tab.Cb_IgnoreAggr",False);
  Class'UIAPI_CHECKBOX'.static.SetCheck("NPHRN_Tab.Cb_UseDoping",False);
  Class'UIAPI_CHECKBOX'.static.SetDisable("NPHRN_Tab.Cb_HoldTarget",True);
  Class'UIAPI_CHECKBOX'.static.SetDisable("NPHRN_Tab.Cb_IgnoreAggr",True);
  Class'UIAPI_CHECKBOX'.static.SetDisable("NPHRN_Tab.Cb_UseDoping",True);
  Class'UIAPI_WINDOW'.static.HideWindow("NPHRN_Tab.Cb_HoldTarget");
  Class'UIAPI_WINDOW'.static.HideWindow("NPHRN_Tab.Cb_IgnoreAggr");
  Class'UIAPI_WINDOW'.static.HideWindow("NPHRN_Tab.Cb_UseDoping");
  Class'UIAPI_WINDOW'.static.HideWindow("NPHRN_MagicSkillWnd");
  Class'UIAPI_WINDOW'.static.HideWindow("NPHRN_DopingWnd");
}

static final function string ReplaceText (coerce string text, coerce string Replace, coerce string With)
{
  local int i;
  local string Output;

  i = InStr(text,Replace);
  JL0012:
  if ( i != -1 )
  {
    Output = Output $ Left(text,i) $ With;
    text = Mid(text,i + Len(Replace));
    i = InStr(text,Replace);
    goto JL0012;
  }
  Output = Output $ text;
  return Output;
}

function ForceExitGame ()
{
  RequestExit();
}

function UseMySkill (int idx)
{
  UseSkill(idx);
}

function UnkParamAdd (int MsgType, int msgNo, int WindowType, int FontType, Color MsgColor, int Lifetime, string MessageText)
{
  local string out_Param;

  ParamAdd(out_Param,"MsgType",string(MsgType));
  ParamAdd(out_Param,"MsgNo",string(msgNo));
  ParamAdd(out_Param,"WindowType",string(WindowType));
  ParamAdd(out_Param,"FontSize","10");
  ParamAdd(out_Param,"FontType",string(FontType));
  ParamAdd(out_Param,"MsgColor","1");
  ParamAdd(out_Param,"MsgColorR",string(MsgColor.R));
  ParamAdd(out_Param,"MsgColorG",string(MsgColor.G));
  ParamAdd(out_Param,"MsgColorB",string(MsgColor.B));
  ParamAdd(out_Param,"ShadowType","0");
  ParamAdd(out_Param,"BackgroundType","1");
  ParamAdd(out_Param,"LifeTime",string(Lifetime));
  ParamAdd(out_Param,"AnimationType","0");
  ParamAdd(out_Param,"Msg",MessageText);
  ExecuteEvent(140,out_Param);
}


function string getxml( string val,  string val2,  XMLTreeNodeInfo xml)
{
  return Class'UIAPI_TREECTRL'.static.InsertNode(val,val2,xml);
}





function getinsetnode ( string val,  string val2,  XMLTreeNodeInfo val3 )
{
   Class'UIAPI_TREECTRL'.static.InsertNode(val,val2,val3);
}

function getinsertnodeitem ( string val,  string val2 ,  XMLTreeNodeItemInfo val3 )
{
  Class'UIAPI_TREECTRL'.static.InsertNodeItem(val,val2,val3);
}


function gkinterface2 ( string val,  string val2 ,  string val3, optional  int val4, optional  int val5 )
{
  local private XMLTreeNodeInfo info;

  info.strName = val;
  info.nOffSetX = val4;
  info.nOffSetY = val5;
  getinsetnode(val,val2,info);
}










function gkinterface4 (private string val, private string val2, private string val3, private int val4, private int val5, optional private int val6, optional private int val7, optional private bool val8, optional private bool val9, optional private int val10, optional private int val11, optional private string val12)
{
  local private XMLTreeNodeItemInfo infonode;
  local DrawItemInfo info;

  info.eType = DIT_TEXTURE;
  info.t_bDrawOneLine = val8;
  info.bLineBreak = val9;
  info.nOffSetX = val4;
  info.nOffSetY = val5;
  info.u_nTextureWidth = val6;
  info.u_nTextureHeight = val7;
  info.u_nTextureUWidth = val10;
  info.u_nTextureUHeight = val11;
  info.u_strTexture = val12;
 /* if ( val != "" )
  {
    info.u_strTextureMouseOn = val12;
  }*/
  getinsertnodeitem(val,val2,infonode);
}
function gkinterface5(private string val, private string val2, private string val3, optional private int val4, optional private int val5, optional private int val6, optional private bool val7, optional private bool val8)
{
  local private XMLTreeNodeItemInfo infonode;
  local DrawItemInfo info;

  info.eType = DIT_TEXT;
  info.t_strText = val;
  info.t_bDrawOneLine = val7;
  info.bLineBreak = val8;
  info.nOffSetX = val4;
  info.nOffSetY = val5;
  
 // gkinterface2(val,val2);
  getinsertnodeitem(val,val2,infonode);
}
function SetEnchantTex (out ItemInfo a_ItemInfo)
{
  if ( ((a_ItemInfo.Enchanted <= 50) && (a_ItemInfo.Enchanted > 0)) )
  {
    a_ItemInfo.ForeTexture = ("L2UI_CH3.ItemEnchant.enchant" $ string(a_ItemInfo.Enchanted));
  }
}

function Color GetRefineColor (int Quality)
{
  local Color tmp;

  switch (Quality)
  {
    case 1:
    tmp.R = 187;
    tmp.G = 181;
    tmp.B = 138;
    break;
    case 2:
    tmp.R = 132;
    tmp.G = 174;
    tmp.B = 216;
    break;
    case 3:
    tmp.R = 193;
    tmp.G = 112;
    tmp.B = 202;
    break;
    case 4:
    tmp.R = 225;
    tmp.G = 109;
    tmp.B = 109;
    break;
    default:
    tmp.R = 187;
    tmp.G = 181;
    tmp.B = 138;
    break;
  }
  return tmp;
}


function texCountNoStack (out ItemInfo Info)
{
  local int ItemNum;

  ItemNum = FindNoStackableItem(Info.ClassID);
  if ( (ItemNum > 1) )
  {
    if ( (ItemNum > 99) )
    {
      Info.ForeTexture = "L2UI_CH3.ItemCount.texCount99+";
    } else {
      Info.ForeTexture = ("L2UI_CH3.ItemCount.texCount" $ string(ItemNum));
    }
  }
}



function string gkinterface (string TreeName, string NodeName, string ParentName, optional int nTexBtnWidth, optional int nTexBtnHeight, optional string strTexBtnExpand, optional string strTexBtnExpand_Over, optional string strTexBtnCollapse, optional string strTexBtnCollapse_Over, optional int offsetX, optional int offsetY, optional bool bUseStrTexExpandedLeft)
{
  local XMLTreeNodeInfo infNode;

  if ( nTexBtnWidth == 0 )
  {
    nTexBtnWidth = 15;
  }
  if ( nTexBtnHeight == 0 )
  {
    nTexBtnHeight = 15;
  }
  if ( strTexBtnExpand == "" )
  {
    strTexBtnExpand = "L2UI_CH3.QUESTWND.QuestWndPlusBtn";
  }
  if ( strTexBtnExpand_Over == "" )
  {
    strTexBtnExpand_Over = "L2UI_CH3.QUESTWND.QuestWndPlusBtn_over";
  }
  if ( strTexBtnCollapse == "" )
  {
    strTexBtnCollapse = "L2UI_CH3.QUESTWND.QuestWndMinusBtn";
  }
  if ( strTexBtnCollapse_Over == "" )
  {
    strTexBtnCollapse_Over = "L2UI_CH3.QUESTWND.QuestWndMinusBtn_over";
  }
  infNode.strName = NodeName;
  infNode.bShowButton = 1;
  infNode.nTexBtnWidth = nTexBtnWidth;
  infNode.nTexBtnHeight = nTexBtnHeight;
  infNode.nOffSetX = offsetX;
  infNode.nOffSetY = offsetY;
  infNode.strTexBtnExpand = strTexBtnExpand;
  infNode.strTexBtnExpand_Over = strTexBtnExpand_Over;
  infNode.strTexBtnCollapse = strTexBtnCollapse;
  infNode.strTexBtnCollapse_Over = strTexBtnCollapse_Over;
  return Class'UIAPI_TREECTRL'.static.InsertNode(TreeName,ParentName,infNode);
}



function bool compareUco (int SlotBitType, out ItemWindowHandle hItemWnd)
{
  local ItemInfo ItemSlot;

  switch (SlotBitType)
  {
    case 2:
    case 4:
    case 6:
	 if ( !xxGetItemWindowHandle("InventoryWnd.EquipItem_REar").GetItem(0,ItemSlot) )

   // if (comptid("InventoryWnd.EquipItem_REar", ItemSlot.Description) != 0)
    {
      hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_REar");
    } else {
      hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_LEar");
    }
    return True;
    case 16:
    case 32:
    case 48:
	if ( !xxGetItemWindowHandle("InventoryWnd.EquipItem_RFinger").GetItem(0,ItemSlot) )
 //   if (comptid("InventoryWnd.EquipItem_REar", ItemSlot.Description) != 0)
    {
      hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_RFinger");
    } else {
      hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_LFinger");
    }
    return True;
    case 8:
    hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_Neck");
    return True;
    case 64:
    hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_Head");
    return True;
    case 1024:
    case 32768:
    hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_Chest");
    return True;
    case 2048:
    hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_Legs");
    return True;
    case 512:
    hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_Gloves");
    return True;
    case 4096:
    hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_Feet");
    return True;
    case 256:
    hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_LHand");
    return True;
    case 16384:
    case 128:
    hItemWnd = xxGetItemWindowHandle("InventoryWnd.EquipItem_RHand");
    return True;
    default:
  }
  return False;
}

function string MyFunctionFaris(string str1, string str2)
{
  local int lictos;
  local int pos;

  lictos = Len(str1);
  pos = InStr(str1, str2);
  if (pos > -1)
  {
    return Mid(str1, pos, 1);
  }
  return "";
}

function ShowOnScreenMessage (string MessageText)
{
  local string out_Param;

  ParamAdd(out_Param,"MsgType",string(1));
  ParamAdd(out_Param,"MsgNo",string(0));
  ParamAdd(out_Param,"WindowType",string(2));
  ParamAdd(out_Param,"FontSize","20");
  ParamAdd(out_Param,"FontType",string(0));
  ParamAdd(out_Param,"MsgColor","1");
  ParamAdd(out_Param,"MsgColorR",string(255));
  ParamAdd(out_Param,"MsgColorG",string(255));
  ParamAdd(out_Param,"MsgColorB",string(255));
  ParamAdd(out_Param,"ShadowType","0");
  ParamAdd(out_Param,"BackgroundType","0");
  ParamAdd(out_Param,"LifeTime",string(1000));
  ParamAdd(out_Param,"AnimationType","1");
  ParamAdd(out_Param,"Msg",MessageText);
  ExecuteEvent(140,out_Param);
}



function string Soz(string str1, string str2)
{
  local int lictos;
  local int pos;

  lictos = Len(str1);
  pos = InStr(str1, str2);
  if (pos > -1)
  {
    // Utiliza la función Mid para obtener la subcadena
    return Mid(str1, (pos + 1));  
  }
  return "";
}




function int GetTextWidth(string val)
{
  local int ent1;
  local int ent2;

  GetTextSize(val, ent1, ent2);
  return ent1;
}




function int comptid (string filter, string Description)
{
  local int i;
  local string strTmp;
  local string strValue;

  strTmp = Description;
  i = InStr(strTmp,filter);
  if ( i != -1 )
  {
    if ( filter != "Acquire:{" )
    {
      strValue = Mid(strTmp,Len(i + Len(filter)),1);
    } else {
      return (i + Len(filter));
    }
    return int(strValue);
  }
}


function int EnchantCalculateWeapon (ItemInfo item)
{
  local UserInfo myInfo;

  if ( GetPlayerInfo(myInfo) )
  {
    if ( !(isMage(myInfo.nSubClass)) )
    {
      if ( item.PhysicalDamage != 0 )
      {
        return (GetPhysicalDamage(item.WeaponType, item.SlotBitType, item.CrystalType, item.Enchanted, item.PhysicalDamage) + item.PhysicalDamage) / 2;

      }
    } else {
      if ( item.MagicalDamage != 0 )
      {
        return (GetMagicalDamage(item.WeaponType, item.SlotBitType, item.CrystalType, item.Enchanted, item.MagicalDamage) + item.MagicalDamage) / 2;

      }
    }
  }
}



function int EnchantCalculateArmor (ItemInfo item)
{
  if ( (item.ShieldDefense != 0) && (item.SlotBitType == 256) || (item.SlotBitType == 128) )
  {
    return (GetShieldDefense(item.CrystalType, item.Enchanted, item.ShieldDefense) + item.ShieldDefense);

  }
  if ( item.PhysicalDefense != 0 )
  {
    return (GetPhysicalDefense(item.CrystalType, item.Enchanted, item.PhysicalDefense) + item.PhysicalDefense);

  }
}

function int EnchantCalculateJewel (ItemInfo item)
{
  if ( item.MagicalDefense != 0 )
  {
    return (GetMagicalDefense(item.CrystalType, item.Enchanted, item.MagicalDefense) + item.MagicalDefense);

  }
}
function bool isTankes (int SubClassID)
{
	switch (SubClassID)
	{
		case 0:
			return False;
		case 1:
			return False;
		case 4:
			return True;
		case 7:
			return False;
		case 2:
			return False;
		case 88:
			return False;
		case 3:
			return False;
		case 89:
			return False;
		case 5:
			return True;
		case 90:
			return True;
		case 6:
			return True;
		case 91:
			return True;
		case 8:
			return False;
		case 93:
			return False;
		case 9:
			return False;
		case 92:
			return False;
		case 10:
			return False;
		case 11:
			return False;
		case 15:
			return False;
		case 12:
			return False;
		case 94:
			return False;
		case 13:
			return False;
		case 95:
			return False;
		case 14:
			return False;
		case 96:
			return False;
		case 16:
			return False;
		case 97:
			return False;
		case 17:
			return False;
		case 98:
			return False;
		case 18:
			return False;
		case 19:
			return True;
		case 22:
			return False;
		case 20:
			return True;
		case 99:
			return True;
		case 21:
			return False;
		case 100:
			return False;
		case 23:
			return False;
		case 101:
			return False;
		case 24:
			return False;
		case 102:
			return False;
		case 25:
			return False;
		case 26:
			return False;
		case 29:
			return False;
		case 27:
			return False;
		case 103:
			return False;
		case 28:
			return False;
		case 104:
			return False;
		case 30:
			return False;
		case 105:
			return False;
		case 31:
			return False;
		case 32:
			return True;
		case 35:
			return False;
		case 33:
			return True;
		case 106:
			return True;
		case 34:
			return False;
		case 107:
			return False;
		case 36:
			return False;
		case 108:
			return False;
		case 37:
			return False;
		case 109:
			return False;
		case 38:
			return False;
		case 39:
			return False;
		case 42:
			return False;
		case 40:
			return False;
		case 110:
			return False;
		case 41:
			return False;
		case 111:
			return False;
		case 43:
			return False;
		case 112:
			return False;
		case 44:
			return False;
		case 45:
			return False;
		case 56:
			return False;
		case 46:
			return False;
		case 113:
			return False;
		case 48:
			return False;
		case 114:
			return False;
		case 49:
			return False;
		case 50:
			return False;
		case 51:
			return False;
		case 115:
			return False;
		case 52:
			return False;
		case 116:
			return False;
		case 53:
			return False;
		case 56:
			return False;
		case 54:
			return False;
		case 57:
			return False;
		case 118:
			return False;
		case 55:
			return False;
		case 117:
			return False;
		default:
	}
}
function bool isArco (int SubClassID)
{
	switch (SubClassID)
	{
		case 0:
			return False;
		case 1:
			return False;
		case 4:
			return False;
		case 7:
			return False;
		case 2:
			return False;
		case 88:
			return False;
		case 3:
			return False;
		case 89:
			return False;
		case 5:
			return False;
		case 90:
			return False;
		case 6:
			return False;
		case 91:
			return False;
		case 8:
			return False;
		case 93:
			return False;
		case 9:
			return True;
		case 92:
			return True;
		case 10:
			return False;
		case 11:
			return False;
		case 15:
			return False;
		case 12:
			return False;
		case 94:
			return False;
		case 13:
			return False;
		case 95:
			return False;
		case 14:
			return False;
		case 96:
			return False;
		case 16:
			return False;
		case 97:
			return False;
		case 17:
			return False;
		case 98:
			return False;
		case 18:
			return False;
		case 19:
			return False;
		case 22:
			return False;
		case 20:
			return False;
		case 99:
			return False;
		case 21:
			return False;
		case 100:
			return False;
		case 23:
			return False;
		case 101:
			return False;
		case 24:
			return True;
		case 102:
			return True;
		case 25:
			return False;
		case 26:
			return False;
		case 29:
			return False;
		case 27:
			return False;
		case 103:
			return False;
		case 28:
			return False;
		case 104:
			return False;
		case 30:
			return False;
		case 105:
			return False;
		case 31:
			return False;
		case 32:
			return False;
		case 35:
			return False;
		case 33:
			return False;
		case 106:
			return False;
		case 34:
			return False;
		case 107:
			return False;
		case 36:
			return False;
		case 108:
			return False;
		case 37:
			return True;
		case 109:
			return True;
		case 38:
			return False;
		case 39:
			return False;
		case 42:
			return False;
		case 40:
			return False;
		case 110:
			return False;
		case 41:
			return False;
		case 111:
			return False;
		case 43:
			return False;
		case 112:
			return False;
		case 44:
			return False;
		case 45:
			return False;
		case 56:
			return False;
		case 46:
			return False;
		case 113:
			return False;
		case 48:
			return False;
		case 114:
			return False;
		case 49:
			return False;
		case 50:
			return False;
		case 51:
			return False;
		case 115:
			return False;
		case 52:
			return False;
		case 116:
			return False;
		case 53:
			return False;
		case 56:
			return False;
		case 54:
			return False;
		case 57:
			return False;
		case 118:
			return False;
		case 55:
			return False;
		case 117:
			return False;
		default:
	}
}
function bool isFighter (int SubClassID)
{
	switch (SubClassID)
	{
		case 0:
			return True;
		case 1:
			return True;
		case 4:
			return False;
		case 7:
			return True;
		case 2:
			return False;
		case 88:
			return False;
		case 3:
			return True;
		case 89:
			return True;
		case 5:
			return False;
		case 90:
			return False;
		case 6:
			return False;
		case 91:
			return False;
		case 8:
			return True;
		case 93:
			return True;
		case 9:
			return False;
		case 92:
			return False;
		case 10:
			return False;
		case 11:
			return False;
		case 15:
			return False;
		case 12:
			return False;
		case 94:
			return False;
		case 13:
			return False;
		case 95:
			return False;
		case 14:
			return False;
		case 96:
			return False;
		case 16:
			return False;
		case 97:
			return False;
		case 17:
			return False;
		case 98:
			return False;
		case 18:
			return True;
		case 19:
			return False;
		case 22:
			return True;
		case 20:
			return False;
		case 99:
			return False;
		case 21:
			return False;
		case 100:
			return False;
		case 23:
			return True;
		case 101:
			return True;
		case 24:
			return False;
		case 102:
			return False;
		case 25:
			return False;
		case 26:
			return False;
		case 29:
			return False;
		case 27:
			return False;
		case 103:
			return False;
		case 28:
			return False;
		case 104:
			return False;
		case 30:
			return False;
		case 105:
			return False;
		case 31:
			return True;
		case 32:
			return False;
		case 35:
			return True;
		case 33:
			return False;
		case 106:
			return False;
		case 34:
			return False;
		case 107:
			return False;
		case 36:
			return True;
		case 108:
			return True;
		case 37:
			return False;
		case 109:
			return False;
		case 38:
			return False;
		case 39:
			return False;
		case 42:
			return False;
		case 40:
			return False;
		case 110:
			return False;
		case 41:
			return False;
		case 111:
			return False;
		case 43:
			return False;
		case 112:
			return False;
		case 44:
			return True;
		case 45:
			return True;
		case 56:
			return False;
		case 46:
			return True;
		case 113:
			return True;
		case 47:
		case 48:
			return True;
		case 114:
			return True;
		case 49:
			return False;
		case 50:
			return False;
		case 51:
			return True;
		case 115:
			return True;
		case 52:
			return True;
		case 116:
			return True;
		case 53:
			return True;
		case 56:
			return True;
		case 54:
			return True;
		case 57:
			return True;
		case 118:
			return True;
		case 55:
			return True;
		case 117:
			return True;
		default:
	}
}
function bool isDuales (int SubClassID)
{
	switch (SubClassID)
	{
		case 0:
			return False;
		case 1:
			return False;
		case 4:
			return False;
		case 7:
			return False;
		case 2:
			return True;
		case 88:
			return True;
		case 3:
			return False;
		case 89:
			return False;
		case 5:
			return False;
		case 90:
			return False;
		case 6:
			return False;
		case 91:
			return False;
		case 8:
			return False;
		case 93:
			return False;
		case 9:
			return False;
		case 92:
			return False;
		case 10:
			return False;
		case 11:
			return False;
		case 15:
			return False;
		case 12:
			return False;
		case 94:
			return False;
		case 13:
			return False;
		case 95:
			return False;
		case 14:
			return False;
		case 96:
			return False;
		case 16:
			return False;
		case 97:
			return False;
		case 17:
			return False;
		case 98:
			return False;
		case 18:
			return False;
		case 19:
			return False;
		case 22:
			return False;
		case 20:
			return False;
		case 99:
			return False;
		case 21:
			return True;
		case 100:
			return True;
		case 23:
			return False;
		case 101:
			return False;
		case 24:
			return False;
		case 102:
			return False;
		case 25:
			return False;
		case 26:
			return False;
		case 29:
			return False;
		case 27:
			return False;
		case 103:
			return False;
		case 28:
			return False;
		case 104:
			return False;
		case 30:
			return False;
		case 105:
			return False;
		case 31:
			return False;
		case 32:
			return False;
		case 35:
			return False;
		case 33:
			return False;
		case 106:
			return False;
		case 34:
			return True;
		case 107:
			return True;
		case 36:
			return False;
		case 108:
			return False;
		case 37:
			return False;
		case 109:
			return False;
		case 38:
			return False;
		case 39:
			return False;
		case 42:
			return False;
		case 40:
			return False;
		case 110:
			return False;
		case 41:
			return False;
		case 111:
			return False;
		case 43:
			return False;
		case 112:
			return False;
		case 44:
			return False;
		case 45:
			return False;
		case 56:
			return False;
		case 46:
			return False;
		case 113:
			return False;
		case 48:
			return False;
		case 114:
			return False;
		case 49:
			return False;
		case 50:
			return False;
		case 51:
			return False;
		case 115:
			return False;
		case 52:
			return False;
		case 116:
			return False;
		case 53:
			return False;
		case 56:
			return False;
		case 54:
			return False;
		case 57:
			return False;
		case 118:
			return False;
		case 55:
			return False;
		case 117:
			return False;
		default:
	}
}
function bool isMage (int SubClassID)
{
	switch (SubClassID)
	{
		case 0:
			return False;
		case 1:
			return False;
		case 4:
			return False;
		case 7:
			return False;
		case 2:
			return False;
		case 88:
			return False;
		case 3:
			return False;
		case 89:
			return False;
		case 5:
			return False;
		case 90:
			return False;
		case 6:
			return False;
		case 91:
			return False;
		case 8:
			return False;
		case 93:
			return False;
		case 9:
			return False;
		case 92:
			return False;
		case 10:
			return True;
		case 11:
			return True;
		case 15:
			return False;
		case 12:
			return True;
		case 94:
			return True;
		case 13:
			return True;
		case 95:
			return True;
		case 14:
			return True;
		case 96:
			return True;
		case 16:
			return False;
		case 97:
			return False;
		case 17:
			return True;
		case 98:
			return True;
		case 18:
			return False;
		case 19:
			return False;
		case 22:
			return False;
		case 20:
			return False;
		case 99:
			return False;
		case 21:
			return False;
		case 100:
			return False;
		case 23:
			return False;
		case 101:
			return False;
		case 24:
			return False;
		case 102:
			return False;
		case 25:
			return True;
		case 26:
			return True;
		case 29:
			return False;
		case 27:
			return True;
		case 103:
			return True;
		case 28:
			return True;
		case 104:
			return True;
		case 30:
			return False;
		case 105:
			return False;
		case 31:
			return False;
		case 32:
			return False;
		case 35:
			return False;
		case 33:
			return False;
		case 106:
			return False;
		case 34:
			return False;
		case 107:
			return False;
		case 36:
			return False;
		case 108:
			return False;
		case 37:
			return False;
		case 109:
			return False;
		case 38:
			return True;
		case 39:
			return True;
		case 42:
			return False;
		case 40:
			return True;
		case 110:
			return True;
		case 41:
			return True;
		case 111:
			return True;
		case 43:
			return False;
		case 112:
			return False;
		case 44:
			return False;
		case 45:
			return False;
		case 56:
			return False;
		case 46:
			return False;
		case 113:
			return False;
		case 48:
			return False;
		case 114:
			return False;
		case 49:
			return True;
		case 50:
			return True;
		case 51:
			return True;
		case 115:
			return True;
		case 52:
			return True;
		case 116:
			return True;
		case 53:
			return False;
		case 56:
			return False;
		case 54:
			return False;
		case 57:
			return False;
		case 118:
			return False;
		case 55:
			return False;
		case 117:
			return False;
		default:
	}
}
function bool isHealer (int SubClassID)
{
	switch (SubClassID)
	{
		case 0:
			return False;
		case 1:
			return False;
		case 4:
			return False;
		case 7:
			return False;
		case 2:
			return False;
		case 88:
			return False;
		case 3:
			return False;
		case 89:
			return False;
		case 5:
			return False;
		case 90:
			return False;
		case 6:
			return False;
		case 91:
			return False;
		case 8:
			return False;
		case 93:
			return False;
		case 9:
			return False;
		case 92:
			return False;
		case 10:
			return False;
		case 11:
			return False;
		case 15:
			return True;
		case 12:
			return False;
		case 94:
			return False;
		case 13:
			return False;
		case 95:
			return False;
		case 14:
			return False;
		case 96:
			return False;
		case 16:
			return True;
		case 97:
			return True;
		case 17:
			return False;
		case 98:
			return False;
		case 18:
			return False;
		case 19:
			return False;
		case 22:
			return False;
		case 20:
			return False;
		case 99:
			return False;
		case 21:
			return False;
		case 100:
			return False;
		case 23:
			return False;
		case 101:
			return False;
		case 24:
			return False;
		case 102:
			return False;
		case 25:
			return False;
		case 26:
			return False;
		case 29:
			return True;
		case 27:
			return False;
		case 103:
			return False;
		case 28:
			return False;
		case 104:
			return False;
		case 30:
			return True;
		case 105:
			return True;
		case 31:
			return False;
		case 32:
			return False;
		case 35:
			return False;
		case 33:
			return False;
		case 106:
			return False;
		case 34:
			return False;
		case 107:
			return False;
		case 36:
			return False;
		case 108:
			return False;
		case 37:
			return False;
		case 109:
			return False;
		case 38:
			return False;
		case 39:
			return False;
		case 42:
			return True;
		case 40:
			return False;
		case 110:
			return False;
		case 41:
			return False;
		case 111:
			return False;
		case 43:
			return True;
		case 112:
			return True;
		case 44:
			return False;
		case 45:
			return False;
		case 56:
			return False;
		case 46:
			return False;
		case 113:
			return False;
		case 48:
			return False;
		case 114:
			return False;
		case 49:
			return False;
		case 50:
			return False;
		case 51:
			return False;
		case 115:
			return False;
		case 52:
			return False;
		case 116:
			return False;
		case 53:
			return False;
		case 56:
			return False;
		case 54:
			return False;
		case 57:
			return False;
		case 118:
			return False;
		case 55:
			return False;
		case 117:
			return False;
		default:
	}
}



/*function int EnchantCalculateWeapon(ItemInfo item)
{
  local UserInfo myInfo;

  if (GetPlayerInfo(myInfo))
  {
    if (!isMage(myInfo.nSubClass))
    {
      if (item.PhysicalDamage != 0)
      {
        // Desofuscado: return item.PhysicalDamage / (UnknownFunction147(GetPhysicalDamage(item.WeaponType, item.SlotBitType, item.CrystalType, item.Enchanted, item.PhysicalDamage), item.PhysicalDamage) / 2);
        return item.PhysicalDamage / (GetPhysicalDamage(item.WeaponType, item.SlotBitType, item.CrystalType, item.Enchanted, item.PhysicalDamage) - item.PhysicalDamage) / 2;
      }
    }
    else
    {
      if (item.MagicalDamage != 0)
      {
        // Desofuscado: return item.MagicalDamage + (UnknownFunction147(GetMagicalDamage(item.WeaponType, item.SlotBitType, item.CrystalType, item.Enchanted, item.MagicalDamage), item.MagicalDamage) / 2);
        return item.MagicalDamage + (GetMagicalDamage(item.WeaponType, item.SlotBitType, item.CrystalType, item.Enchanted, item.MagicalDamage) - item.MagicalDamage) / 2;
      }
    }
  }
}

function int EnchantCalculateArmor(ItemInfo item)
{
  if ((item.ShieldDefense != 0) && ((item.SlotBitType == 256) || (item.SlotBitType == 128)))
  {
    // Desofuscado: return item.ShieldDefense / (UnknownFunction147(GetShieldDefense(item.CrystalType, item.Enchanted, item.ShieldDefense), item.ShieldDefense));
    return item.ShieldDefense / (GetShieldDefense(item.CrystalType, item.Enchanted, item.ShieldDefense) - item.ShieldDefense);
  }
  if (item.PhysicalDefense != 0)
  {
    // Desofuscado: return item.PhysicalDefense / (UnknownFunction147(GetPhysicalDefense(item.CrystalType, item.Enchanted, item.PhysicalDefense), item.PhysicalDefense));
    return item.PhysicalDefense / (GetPhysicalDefense(item.CrystalType, item.Enchanted, item.PhysicalDefense) - item.PhysicalDefense);
  }
}

function int EnchantCalculateJewel(ItemInfo item)
{
  if (item.MagicalDefense != 0)
  {
    // Desofuscado: return item.MagicalDefense / (UnknownFunction147(GetMagicalDefense(item.CrystalType, item.Enchanted, item.MagicalDefense), item.MagicalDefense));
    return item.MagicalDefense / (GetMagicalDefense(item.CrystalType, item.Enchanted, item.MagicalDefense) - item.MagicalDefense);
  }
}*/










/*function array<string> getweaponinfo ()
{
  local array<string> lista;

  lista.Length = "WeaponStage:";
  lista.Length = "WeaponStatus:";
  lista.Length = "Tier:";
  lista.Length = "ArmorStatus:";
  lista.Length = "JewelStage:";
  lista.Length = "Acquire:{";
  return lista;
}*/


function string Replace (string Text, string Replace, string With)
{
  local int i;
  local string Input;

  Input = Text;
  Text = "";
  i = InStr(Input,Replace);
  if ( i != -1 )
  {
    Text = (Text $ Left(Input,i) $ With);
    Input = Mid(Input, Len(Input) + i);
    i = InStr(Input,Replace);
    
  }
  return Text $ Input;
}

// Método Replace para reemplazar todas las ocurrencias de 'search' con 'replace' en 'inputStr'
function string Replace2da(string inputStr, string search, string replace)
{
    local int index;

    // Buscar la primera ocurrencia de 'search'
    index = InStr(inputStr, search);

    // Reemplazar todas las ocurrencias mientras se encuentren
    while (index != -1)
    {
        // Reemplazar la ocurrencia actual
        inputStr = Left(inputStr, index - 1) $ replace $ Mid(inputStr, index + Len(search));

        // Buscar la siguiente ocurrencia de 'search'
        index = InStr(inputStr, search);
    }

    // Devolver la cadena modificada
    return inputStr;
}



function string Replace2s (string Text, string Replace, string With)
{
  local int i;
  local string Input;

  Input = Text;
  Text = "";
  i = InStr(Input, Replace);
  if (i != -1)
  {
    Text = (Text $ Left(Input, i) $ With);
    Input = Mid(Input, Len(Input) + i + Len(Replace));
    i = InStr(Input, Replace);
  }
  return Text $ Input;
}

function bool cunterki (int ClassID)
{
  switch (ClassID)
  {
    case 11002:
    case 11003:
    return True;
    break;
    default:
  }
}

function texCount(out  ItemInfo Info)
{
    local  int Count;
    Count = Info.ItemNum;

    if ((Count > 99))
    {
        Info.ForeTexture = "L2UI_CH3.ItemCount.texCount99+";
    }
    else
    {
        if ((Count > 1))
        {
            Info.ForeTexture = ("L2UI_CH3.ItemCount.texCount" $ string(Count));
        }
        else
        {
            Info.ForeTexture = "L2UI_CH3.null";
        }
    }
}




function string Replace231(string Text, string Replace231sa, string With)
{
  local int i;
  local string Input;

  Input = Text;
  Text = "";
  i = InStr(Input, Replace231sa);
  while (i != -1)
  {
    Text = ((Text $ Left(Input, i)) $ With);
    Input = Mid(Input, (i + Len(Replace231sa)));
    i = InStr(Input, Replace231sa);
  }
  return (Text $ Input);
}









/*function bool MyFunction2(out private string result)
{
  local private array<string> weaponInfo;
  local private int i;
  local private int len;
  local private bool bFlag;

  weaponInfo = getweaponinfo();
  i = 0;

  if (i < weaponInfo.Length)
  {
    result = weaponInfo[i];
    

    if (result.InStr("{") >= 0)  // Corregir aquí
    {
      result = MyFunction(result, result.InStr("}"), "");
      bFlag = False;
    }
    else
    {
      result = MyFunction(result, result.InStr("}"), "");
      bFlag = True;
    }

    i++;
    return True;
  }

  return False;
}*/




/*function bool  (out private string )
{
  local private array<string> ;
  local private int ;
  local private int ;
  local private bool ;

   = getweaponinfo();
   = 0;
  if ( UnknownFunction150(,.Length) )
  {
     = UnknownFunction126(,[]);
    if ( UnknownFunction154(,-1) )
    {
      goto JL00D3;
    }
    if ( UnknownFunction122(UnknownFunction234([],1),"{") )
    {
       = MyFunction(,UnknownFunction127(,,UnknownFunction146(UnknownFunction126(,"}"),3)),"");
       = False;
    } else {
       = MyFunction(,UnknownFunction127(,,UnknownFunction146(UnknownFunction125([]),3)),"");
       = True;
    }
    UnknownFunction165();
    goto JL0013;
  }
  return;
}*/



function Color getcottt(string j)
{
    local private Color getc;

    getc.A = byte(255);
    switch(j)
    {
        // End:0x4D
        case "Goldlite":
            getc.R = 230;
            getc.G = 213;
            getc.B = 164;
            // End:0x418
            break;
        // End:0x80
        case "Grey":
            getc.R = 180;
            getc.G = 180;
            getc.B = 180;
            // End:0x418
            break;
        // End:0xB8
        case "GreyLight":
            getc.R = 220;
            getc.G = 220;
            getc.B = 220;
            // End:0x418
            break;
        // End:0xEF
        case "GreyDark":
            getc.R = 100;
            getc.G = 100;
            getc.B = 100;
            // End:0x418
            break;
        // End:0x128
        case "Yellow":
            getc.R = byte(255);
            getc.G = byte(255);
            getc.B = 0;
            // End:0x418
            break;
        // End:0x15C
        case "Red":
            getc.R = byte(255);
            getc.G = 0;
            getc.B = 0;
            // End:0x418
            break;
        // End:0x191
        case "Blue":
            getc.R = 0;
            getc.G = 0;
            getc.B = byte(255);
            // End:0x418
            break;
        // End:0x1C7
        case "Green":
            getc.R = 0;
            getc.G = byte(255);
            getc.B = 0;
            // End:0x418
            break;
        // End:0x1FC
        case "Orange":
            getc.R = 230;
            getc.G = 153;
            getc.B = 77;
            // End:0x418
            break;
        // End:0x231
        case "System":
            getc.R = 176;
            getc.G = 155;
            getc.B = 121;
            // End:0x418
            break;
        // End:0x265
        case "Amber":
            getc.R = 218;
            getc.G = 165;
            getc.B = 32;
            // End:0x418
            break;
        // End:0x29F
        case "White":
            getc.R = byte(255);
            getc.G = byte(255);
            getc.B = byte(255);
            // End:0x418
            break;
        // End:0x2D1
        case "Dim":
            getc.R = 177;
            getc.G = 173;
            getc.B = 172;
            // End:0x418
            break;
        // End:0x30B
        case "Magenta":
            getc.R = byte(255);
            getc.G = 0;
            getc.B = byte(255);
            // End:0x418
            break;
        // End:0x33F
        case "Brown":
            getc.R = 176;
            getc.G = 155;
            getc.B = 121;
            // End:0x418
            break;
        // End:0x373
        case "Black":
            getc.R = 0;
            getc.G = 0;
            getc.B = 0;
            // End:0x418
            break;
        // End:0x3AB
        case "LightPink":
            getc.R = 191;
            getc.G = 168;
            getc.B = 211;
            // End:0x418
            break;
        // End:0x3E5
        case "LightBlue":
            getc.R = 128;
            getc.G = 153;
            getc.B = byte(255);
            // End:0x418
            break;
        // End:0xFFFF
        default:
            getc.R = byte(255);
            getc.G = byte(255);
            getc.B = byte(255);
            // End:0x418
            break;
            break;
    }
    return getc;
}



function Color GetColortool (int R, int G, int B, int A)
{
  local Color tColor;

  tColor.R = R;
  tColor.G = G;
  tColor.B = B;
  tColor.A = A;
  return tColor;
}

function SysDebug (string Str, optional bool Clear)
{
  local TextListBoxHandle Debug;

  Debug = TextListBoxHandle(GetHandle("ConsoleDebug.debug"));
  if ( !(IsShowWindow("ConsoleDebug")) )
  {
    ShowWindow("ConsoleDebug");
  }
  if ( Clear )
  {
    Debug.Clear();
  }
  Debug.AddString(Str,xxgetInstanceL2Util().Red);
}




function Color FarisName (out string iName)
{
  local Color tmp;
  local int Color;

//if (Mid(iName, Len(iName) - 3, 1) == "[" && Mid(iName, Len(iName) - 1, 1) == "]")
  if ( ((Mid(iName, (Len(iName) - 3),1) == "[") && (Mid(iName , (Len(iName) - 1),1) == "]")) )
  {
    Color = int(Mid(iName,(Len(iName) - 2),1));
    switch (Color)
    {
      case 1:
      tmp.R = 255;
      tmp.G = 0;
      tmp.B = 255;
      tmp.A = 255;
      break;
      case 2:
      tmp.R = 152;
      tmp.G = 83;
      tmp.B = 179;
      tmp.A = 230;
      break;
      case 3:
      tmp.R = 33;
      tmp.G = 164;
      tmp.B = 255;
      tmp.A = 255;
      break;
      case 4:
      tmp.R = 138;
      tmp.G = 255;
      tmp.B = 0;
      tmp.A = 255;
      break;
      case 5:
      tmp.R = 255;
      tmp.G = 251;
      tmp.B = 4;
      tmp.A = 255;
      break;
      case 6:
      tmp.R = 240;
      tmp.G = 68;
      tmp.B = 68;
      tmp.A = 255;
      break;
      default:
    }
    iName = Left(iName,(Len(iName) - 3));
  }
  return tmp;
}



function XMLTreeNodeItemInfo Virtual(int E, XMLTreeNodeItemInfo infNodeItem)
{
  switch (E)
  {
    case 0:
    infNodeItem.t_color.R = 255;
    infNodeItem.t_color.G = 255;
    infNodeItem.t_color.B = 255;
    infNodeItem.t_color.A = 255;
    break;
    case 1:
    infNodeItem.t_color.R = 163;
    infNodeItem.t_color.G = 163;
    infNodeItem.t_color.B = 163;
    infNodeItem.t_color.A = 255;
    break;
    case 2:
    infNodeItem.t_color.R = 176;
    infNodeItem.t_color.G = 155;
    infNodeItem.t_color.B = 121;
    infNodeItem.t_color.A = 255;
    break;
    case 3:
    infNodeItem.t_color.R = 250;
    infNodeItem.t_color.G = 50;
    infNodeItem.t_color.B = 0;
    infNodeItem.t_color.A = 255;
    break;
    case 4:
    infNodeItem.t_color.R = 240;
    infNodeItem.t_color.G = 214;
    infNodeItem.t_color.B = 54;
    infNodeItem.t_color.A = 255;
    break;
    case 5:
    infNodeItem.t_color.R = 175;
    infNodeItem.t_color.G = 185;
    infNodeItem.t_color.B = 205;
    infNodeItem.t_color.A = 255;
    break;
    case 6:
    infNodeItem.t_color.R = 102;
    infNodeItem.t_color.G = 150;
    infNodeItem.t_color.B = 253;
    infNodeItem.t_color.A = 255;
    break;
    case 7:
    infNodeItem.t_color.R = 85;
    infNodeItem.t_color.G = 170;
    infNodeItem.t_color.B = 255;
    infNodeItem.t_color.A = 255;
    break;
    case 8:
    infNodeItem.t_color.R = 211;
    infNodeItem.t_color.G = 192;
    infNodeItem.t_color.B = 82;
    infNodeItem.t_color.A = 255;
    break;
    case 9:
    infNodeItem.t_color.R = 170;
    infNodeItem.t_color.G = 152;
    infNodeItem.t_color.B = 120;
    infNodeItem.t_color.A = 255;
    break;
    case 10:
    infNodeItem.t_color.R = 168;
    infNodeItem.t_color.G = 103;
    infNodeItem.t_color.B = 53;
    infNodeItem.t_color.A = 255;
    break;
    case 11:
    infNodeItem.t_color.R = 175;
    infNodeItem.t_color.G = 42;
    infNodeItem.t_color.B = 39;
    infNodeItem.t_color.A = 255;
    break;
    case 12:
    infNodeItem.t_color.R = 255;
    infNodeItem.t_color.G = 204;
    infNodeItem.t_color.B = 0;
    infNodeItem.t_color.A = 255;
    break;
    case 13:
    infNodeItem.t_color.R = 170;
    infNodeItem.t_color.G = 110;
    infNodeItem.t_color.B = 230;
    infNodeItem.t_color.A = 255;
    break;
    default:
  }
  return infNodeItem;
}






function string TreeInsertItemTooltipSimpleNode (string TreeName, string NodeName, string ParentName, int nTexExpandedOffSetX, int nTexExpandedOffSetY, int nTexExpandedHeight, int nTexExpandedRightWidth, int nTexExpandedLeftUWidth, int nTexExpandedLeftUHeight, optional string TooltipSimpleText, optional string strTexExpandedLeft, optional int offsetX, optional int offsetY)
{
  local XMLTreeNodeInfo infNode;

  if ( TooltipSimpleText != "" )
  {
    infNode.ToolTip = xxMakeTooltipSimpleText(TooltipSimpleText);
  }
  if ( strTexExpandedLeft == "" )
  {
    strTexExpandedLeft = "L2UI_CH3.etc.IconSelect2";
  }
  infNode.strName = NodeName;
  infNode.nOffSetX = offsetX;
  infNode.nOffSetY = offsetY;
  infNode.bFollowCursor = True;
  infNode.nTexExpandedOffSetX = nTexExpandedOffSetX;
  infNode.nTexExpandedOffSetY = nTexExpandedOffSetY;
  infNode.nTexExpandedHeight = nTexExpandedHeight;
  infNode.nTexExpandedRightWidth = nTexExpandedRightWidth;
  infNode.nTexExpandedLeftUWidth = nTexExpandedLeftUWidth;
  infNode.nTexExpandedLeftUHeight = nTexExpandedLeftUHeight;
  infNode.strTexExpandedLeft = strTexExpandedLeft;
  return Class'UIAPI_TREECTRL'.static.InsertNode(TreeName,ParentName,infNode);
}












function string ClassId (int classIndex)
{
  switch (classIndex)
  {
    case 1:
    return "Warrior";
    case 2:
    return "Gladiator";
    case 88:
    return "Duelist";
    case 3:
    return "Warlord";
    case 89:
    return "Dreadnought";
    case 0:
    return "Human Fighter";
    case 4:
    return "Human Knight";
    case 5:
    return "Paladin";
    case 90:
    return "Phoenix Knight";
    case 6:
    return "Dark Avenger";
    case 91:
    return "Hell Knight";
    case 7:
    return "Human Rogue";
    case 8:
    return "Treasure Hunter";
    case 93:
    return "Adventurer";
    case 9:
    return "Hawkeye";
    case 92:
    return "Sagittarius";
    case 12:
    return "Sorcerer";
    case 94:
    return "Archmage ";
    case 11:
    return "Human Wizard";
    case 13:
    return "Necromancer";
    case 95:
    return "Soultaker";
    case 10:
    return "Human Mystic";
    case 14:
    return "Warlock";
    case 96:
    return "Arcana Lord";
    case 15:
    return "Cleric";
    case 16:
    return "Bishop";
    case 97:
    return "Cardinal";
    case 17:
    return "Prophet";
    case 98:
    return "Hierophant";
    case 20:
    return "Temple Knight";
    case 99:
    return "Eva's Templar";
    case 19:
    return "Elf Knight";
    case 21:
    return "Swordsinger";
    case 100:
    return "Sword Muse";
    case 18:
    return "Elf Fighter";
    case 22:
    return "Elf Scout";
    case 23:
    return "Plainswalker";
    case 101:
    return "Wind Rider";
    case 24:
    return "Silver Ranger ";
    case 102:
    return "Moonlight Sentinel";
    case 26:
    return "Elven Wizard";
    case 27:
    return "Spellsinger";
    case 103:
    return "Mystic Muse ";
    case 25:
    return "Elven Mystic";
    case 28:
    return "Elem. Summoner";
    case 104:
    return "Elemental Master ";
    case 29:
    return "Oracle";
    case 30:
    return "Elven Elder";
    case 105:
    return "Eva's Saint";
    case 33:
    return "Shillien Knight";
    case 106:
    return "Shillien Templar";
    case 32:
    return "Palus Knight";
    case 34:
    return "Bladedancer";
    case 107:
    return "Spectral Dancer";
    case 31:
    return "Dark Elven Fighter";
    case 35:
    return "Assassin";
    case 36:
    return "Abyss Walker";
    case 108:
    return "Ghost Hunter";
    case 37:
    return "Phantom Ranger";
    case 109:
    return "Ghost Sentinel";
    case 39:
    return "Dark Elven Wizard";
    case 40:
    return "Spellhowler";
    case 110:
    return "Storm Screamer";
    case 38:
    return "Dark Elven Mystic";
    case 41:
    return "Phantom Summoner";
    case 111:
    return "Spectral Master";
    case 42:
    return "Shillien Oracle";
    case 43:
    return "Shillien Elder";
    case 112:
    return "Shillien Saint";
    case 45:
    return "Raider";
    case 46:
    return "Destroyer";
    case 113:
    return "Titan";
    case 44:
    return "Orc Fighter";
    case 47:
    return "Monk";
    case 48:
    return "Tyrant";
    case 114:
    return "G.Khavatari";
    case 51:
    return "Overlord";
    case 115:
    return "Dominator";
    case 49:
    return "Orc Mystic";
    case 50:
    return "Shaman";
    case 52:
    return "Warcryer";
    case 116:
    return "Doomcryer";
    case 56:
    return "Artisan";
    case 57:
    return "Warsmith";
    case 118:
    return "Maestro";
    case 53:
    return "Dwarven Fighter";
    case 54:
    return "Scavenger";
    case 55:
    return "Bounty Hunter";
    case 117:
    return "Fortune Seeker";
    default:
  }
  return "";
}




function OMG(string Msg)
{
  local ChatWindowHandle NormalChat;
  local Color iColor;

  NormalChat = ChatWindowHandle(GetHandle("ChatWnd.NormalChat"));
  iColor.R = 255;
  iColor.G = 0;
  iColor.B = 255;
  iColor.A = 255;
  NormalChat.AddString(("LotusInfo: " $ Msg),iColor);
}


function string GetItemGradeTextureName (int item)
{
  if ( item > 0 )
  {
    return ("L2UI_CH3.grade_" $ string(item));
  } else {
    return "";
  }
}

function TreeClear (string Str)
{
  Class'UIAPI_TREECTRL'.static.Clear(Str);
}


function bool isalgo(string v, out ItemInfo info)
{
    local private ItemWindowHandle me;

    me = xxGetItemWindowHandle("InventoryWnd.InventoryItem");
    // End:0x42
    if(function200(me, v, info))
    {
        return true;
    }
    me = xxGetItemWindowHandle("InventoryWnd.QuestItem");
    // End:0x8D
    if(function200(me, v, info))
    {
        info.bShowCount = true;
        return true;
    }
    return false;
 
}


function bool function200(ItemWindowHandle me, string saaa, out ItemInfo info)
{
    local private int i, j;

    i = me.GetItemNum();
    j = 0;
    J0x1C:

    // End:0x67 [Loop If]
    if(j <= i)
    {
        // End:0x5D
        if(me.GetItem(j, info))
        {
            // End:0x5D
            if(info.Name == saaa)
            {
                return true;
            }
        }
        j++;
        // [Loop Continue]
        goto J0x1C;
    }
    return false;
  
}



	function int FindNoStackableItem (int ClassID)
{
	local int i;
	local int itemCount;
	local int invenLimit;
	local ItemInfo item;
	local ItemWindowHandle InvWnd;

	InvWnd = ItemWindowHandle(GetHandle("InventoryWnd.InventoryItem"));
	invenLimit = InvWnd.GetItemNum();
	itemCount = 0;

  for (i = 0; i < invenLimit; i++)
	{
		InvWnd.GetItem(i,item);
    if(item.ClassID == ClassID)
  {
    ++ itemCount;
	}
	}
	return itemCount;
}



function int findMatchString(string targetStr, string a_Param)
{
  local array<string> modifiedParamArr;
  local int i;
  local string delim;
  local string modifiedString;
  local int _inStr;
  local string strTemp1;
  local string strTemp2;

  modifiedString = targetStr;
  delim = " ";
  _inStr = InStr(a_Param, delim);
  if (_inStr > -1)
  {
    modifiedParamArr[modifiedParamArr.Length] = Left(a_Param, _inStr);
    a_Param = Mid(a_Param, _inStr + 1);
    _inStr = InStr(a_Param, delim);
  }
  modifiedParamArr[modifiedParamArr.Length] = a_Param;
  i = 0;
  while (i < modifiedParamArr.Length)
  {
    strTemp1 = Caps(modifiedString);
    strTemp2 = Caps(modifiedParamArr[i]);
    if (InStr(strTemp1, strTemp2) == -1 && modifiedParamArr[i] != " ")
    {
      return -1;
    }
    i++;
  }
  return 1;
}




function string makeShortStringByPixel (string targetString, int maxPixel, string dotString)
{
  local string fixedText;
  local string tempStr;
  local int textWidth;
  local int textHeight;
  local int dotWidth;
  local int dotHeight;
  local int i;

  GetTextSize(dotString,dotWidth,dotHeight);
  GetTextSize(targetString,textWidth,textHeight);
  if ( textWidth <= maxPixel )
  {
    fixedText = targetString;
  } else {
    fixedText = targetString;
    i = 0;
    if ( (i < Len(targetString)) )
    {
      tempStr = Mid(targetString,0,i);
      GetTextSize(tempStr,textWidth,textHeight);
      if ( (maxPixel < (textWidth + dotWidth)) )
      {
        fixedText = (tempStr $ dotString);
      } else {
        i++;
        
      }
    }
  }
  return fixedText;
}


function bool headerhp(WindowHandle Handle, optional int targetID, optional int offsetX, optional int offsetY, optional bool isDamage)
{
    local Vector CameraLocation;
    local Rotator CameraRotation;
    local Vector cameraDirection, cameraRight, cameraUp;
    local int ScreenWidth, ScreenHeight;
    local float FOV, near, far, aspect, top, bottom,
	    Right, Left;

    local Matrix projMat, viewMat, mvpMat;
    local Plane posHomog, posMvp;
    local UserInfo Info;
    local Actor Actor;
    local Pawn Pawn;
    local LineagePlayerController Controller;
    local Vector HeadCoords;
    local float screenX, screenY, percentX, percentY, calibrate, frameMultiply,
	    ManualOffset;

    // End:0x12
    if(!GetTargetInfo(Info))
    {
        return false;
    }
    // End:0x33
    if((Info.nID != targetID) && isDamage)
    {
        return false;
    }
    // End:0x45
    if(!GetPlayerActor(Actor))
    {
        return false;
    }
    // End:0x57
    if(!GetPlayerController(Controller))
    {
        return false;
    }
    // End:0x70
    if(Info.bNpc)
    {
        ManualOffset = -3.5;
    }
    Controller.PlayerCalcView(Actor, CameraLocation, CameraRotation);
    GetCurrentResolution(ScreenWidth, ScreenHeight);
    GetAxes(CameraRotation, cameraDirection, cameraRight, cameraUp);
    // End:0x151
    foreach Actor.CollidingActors(Class'Pawn', Pawn, 50, Info.Loc)
    {
        // End:0x150
        if(Info.nID == Pawn.CreatureID)
        {
            HeadCoords = Info.Loc;
            ManualOffset = ManualOffset + Pawn.NameOffset;
            HeadCoords.Z = (HeadCoords.Z + Pawn.CollisionHeight) + ManualOffset;
        }        
    }    
    FOV = 60;
    near = 0.1;
    far = 1000;
    frameMultiply = 1000;
    aspect = float(ScreenWidth) / float(ScreenHeight);
    top = Tan(FOV / float(2)) * near;
    bottom = -top;
    Right = top * aspect;
    Left = -Right;
    projMat.XPlane = GetPlane((2 * near) / (Right - Left), 0, 0, 0);
    projMat.YPlane = GetPlane(0, (2 * near) / (top - bottom), 0, 0);
    projMat.ZPlane = GetPlane((Right + Left) / (Right - Left), (top + bottom) / (top - bottom), ((-1 * far) - near) / (far - near), -1);
    projMat.WPlane = GetPlane(0, 0, ((-2 * far) * near) / (far - near), 0);
    viewMat.XPlane = GetPlane(cameraRight.X, cameraUp.X, -cameraDirection.X, 0);
    viewMat.YPlane = GetPlane(cameraRight.Y, cameraUp.Y, -cameraDirection.Y, 0);
    viewMat.ZPlane = GetPlane(cameraRight.Z, cameraUp.Z, -cameraDirection.Z, 0);
    viewMat.WPlane = GetPlane(-1 * (Dot(cameraRight, CameraLocation)), -1 * (Dot(cameraUp, CameraLocation)), Dot(cameraDirection, CameraLocation), 1);
    mvpMat = multiplyMatrices(projMat, viewMat);
    posHomog = GetPlane(HeadCoords.X, HeadCoords.Y, HeadCoords.Z, 1);
    posMvp = multiplyMatrixVector(mvpMat, posHomog);
    posMvp.X = posMvp.X / (posMvp.W / frameMultiply);
    posMvp.Y = posMvp.Y / (posMvp.W / frameMultiply);
    posMvp.Z = posMvp.Z / (posMvp.W / frameMultiply);
    calibrate = (27.5 * (float(ScreenWidth) / float(ScreenHeight))) / frameMultiply;
    percentX = ((((posMvp.X * 0.5) * float(ScreenWidth)) + (float(ScreenWidth) / calibrate)) / ((float(ScreenWidth) / calibrate) * float(2))) * 100;
    percentY = ((((posMvp.Y * 0.5) * float(ScreenHeight)) + (float(ScreenHeight) / calibrate)) / ((float(ScreenHeight) / calibrate) * float(2))) * 100;
    screenX = ((100 - percentX) * float(ScreenWidth)) / 100;
    screenY = (percentY * float(ScreenHeight)) / 100;
    // End:0x5F4
    if(((HeadCoords - CameraLocation) Dot cameraDirection) < float(0))
    {
        Handle.MoveTo(-100, -100);
        return false;
    }
    // End:0x637
    if((screenX < float(-100)) || screenX > float(ScreenWidth + 100))
    {
        Handle.MoveTo(-100, -100);
        return false;
    }
    // End:0x67A
    if((screenY < float(-100)) || screenY > float(ScreenHeight + 100))
    {
        Handle.MoveTo(-100, -100);
        return false;
    }
    // End:0x6CF
    if(isDamage)
    {
        Handle.MoveTo(int(screenX - float(ScreenWidth / 2)) + offsetX, (int(screenY - float(50)) - (ScreenHeight / 2)) + offsetY);        
    }
    else
    {
        Handle.MoveTo(int(screenX - float(40)), int(screenY));
    }
    return true;
   
}



function supersuper(WindowHandle Handle, out float OutX, out float OutY)
{
    local private Vector Location;
    local private Rotator Rotation;
	local Vector cameraDirection, cameraRight, cameraUp;
    local private int ScreenWidth, ScreenHeight;
    local private float FOV, Near, Far, Aspect, Top, Bottom,
        Right, Left;

    local private Matrix ProjectionMatrix, ViewMatrix, MVPMatrix;
    local private Plane HomogeneousCoords, MVPCoords;
    local private UserInfo Info;
    local private Actor PlayerActor;
    local private Pawn CollidingPawn;
    local private LineagePlayerController PlayerController;
    local private Vector HeadCoords;
    local private float ScreenX, ScreenY, PercentX, PercentY, Calibrate, FrameMultiply;

    // End:0x12
    if (!GetTargetInfo(Info))
    {
        return;
    }
    // End:0x24
    if (!GetPlayerActor(PlayerActor))
    {
        return;
    }
    // End:0x36
    if (!GetPlayerController(PlayerController))
    {
        return;
    }
    // End:0x4F
    if (Info.bNpc)
    {
        OutX = -0.7;
    }
    PlayerController.PlayerCalcView(PlayerActor, Location, Rotation);
    GetCurrentResolution(ScreenWidth, ScreenHeight);
    GetAxes(PlayerController.Rotation, cameraDirection, cameraRight, cameraUp);
    // End:0x1CD
    foreach PlayerActor.CollidingActors(Class'Pawn', CollidingPawn, 50, Info.Loc)
    {
        // End:0x1CC
        if (Info.nID == CollidingPawn.CreatureID)
        {
            HeadCoords = Info.Loc;
            if (CollidingPawn.bRide)
            {
                continue;
            }
            if (CollidingPawn.RidePawn != none)
            {
                OutX += 6.0;
            }
            HeadCoords.Z = (HeadCoords.Z + CollidingPawn.CollisionHeight) + OutX;
        }
    }
    OutX = 50;
    OutY = 0.1;
    Calibrate = 1000;
    FrameMultiply = 1000;
    FOV = 60;
    Near = 0.1;
    Far = 1000;
    Aspect = float(ScreenWidth) / float(ScreenHeight);
    Top = Tan(FOV / 2.0) * Near;
    Bottom = -Top;
    Right = Top * Aspect;
    Left = -Right;

    MVPMatrix = multiplyMatrices(ProjectionMatrix, ViewMatrix);
    HomogeneousCoords = nak(HeadCoords.X, HeadCoords.Y, HeadCoords.Z, 1);
    MVPCoords = multiplyMatrixVector(MVPMatrix, HomogeneousCoords);

    MVPCoords.X = MVPCoords.X / (MVPCoords.W / Calibrate);
    MVPCoords.Y = MVPCoords.Y / (MVPCoords.W / Calibrate);
    MVPCoords.Z = MVPCoords.Z / (MVPCoords.W / Calibrate);

    Calibrate = (27.5 * (float(ScreenWidth) / float(ScreenHeight))) / FrameMultiply;
    PercentX = ((((MVPCoords.X * 0.5) * float(ScreenWidth)) + (float(ScreenWidth) / Calibrate)) / ((float(ScreenWidth) / Calibrate) * 2.0)) * 100;
    PercentY = ((((MVPCoords.Y * 0.5) * float(ScreenHeight)) + (float(ScreenHeight) / Calibrate)) / ((float(ScreenHeight) / Calibrate) * 2.0)) * 100;
    ScreenX = ((100 - PercentX) * float(ScreenWidth)) / 100;
    ScreenY = (PercentY * float(ScreenHeight)) / 100;

 if(((HeadCoords - Location) Dot cameraDirection) < float(0))
    {
        Handle.MoveTo(-100, -100);
      
    }
    // End:0x637
    if((screenX < float(-100)) || screenX > float(ScreenWidth + 100))
    {
        Handle.MoveTo(-100, -100);
       
    }
    // End:0x67A
    if((screenY < float(-100)) || screenY > float(ScreenHeight + 100))
    {
        Handle.MoveTo(-100, -100);
       ;
    }

    OutX = ScreenX;
    OutY = ScreenY;
    return;
}



function Plane nak(float f1, float f2, float f3, float f4)
{
    local Plane P;

    P.X = f1;
    P.Y = f2;
    P.Z = f3;
    P.W = f4;
    return P;
   
}

function Matrix ComputeProjectionMatrix(float FOV, float near, float far, float aspect)
{
    local float top, bottom, Right, Left;
    local Matrix projMat;

    top = Tan(FOV / float(2)) * near;
    bottom = -top;
    Right = top * aspect;
    Left = -Right;
    projMat.XPlane = nak((2 * near) / (Right - Left), 0, 0, 0);
    projMat.YPlane = nak(0, (2 * near) / (top - bottom), 0, 0);
    projMat.ZPlane = nak((Right + Left) / (Right - Left), (top + bottom) / (top - bottom), ((-1 * far) - near) / (far - near), -1);
    projMat.WPlane = nak(0, 0, ((-2 * far) * near) / (far - near), 0);
    return projMat;
    
}

function Matrix ComputeViewMatrix(Vector CameraLocation, Vector cameraDirection, Vector cameraRight, Vector cameraUp)
{
    local Matrix viewMat;

    viewMat.XPlane = nak(cameraRight.X, cameraUp.X, -cameraDirection.X, 0);
    viewMat.YPlane = nak(cameraRight.Y, cameraUp.Y, -cameraDirection.Y, 0);
    viewMat.ZPlane = nak(cameraRight.Z, cameraUp.Z, -cameraDirection.Z, 0);
    viewMat.WPlane = nak(-1 * (cameraRight Dot CameraLocation), -1 * (cameraUp Dot CameraLocation), cameraDirection Dot CameraLocation, 1);
    return viewMat;
 
}













function Matrix multiplyMatrices(Matrix A, Matrix B)
{
    local Matrix C;

    C.XPlane.X = (((A.XPlane.X * B.XPlane.X) + (A.YPlane.X * B.XPlane.Y)) + (A.ZPlane.X * B.XPlane.Z)) + (A.WPlane.X * B.XPlane.W);
    C.XPlane.Y = (((A.XPlane.Y * B.XPlane.X) + (A.YPlane.Y * B.XPlane.Y)) + (A.ZPlane.Y * B.XPlane.Z)) + (A.WPlane.Y * B.XPlane.W);
    C.XPlane.Z = (((A.XPlane.Z * B.XPlane.X) + (A.YPlane.Z * B.XPlane.Y)) + (A.ZPlane.Z * B.XPlane.Z)) + (A.WPlane.Z * B.XPlane.W);
    C.XPlane.W = (((A.XPlane.W * B.XPlane.X) + (A.YPlane.W * B.XPlane.Y)) + (A.ZPlane.W * B.XPlane.Z)) + (A.WPlane.W * B.XPlane.W);
    C.YPlane.X = (((A.XPlane.X * B.YPlane.X) + (A.YPlane.X * B.YPlane.Y)) + (A.ZPlane.X * B.YPlane.Z)) + (A.WPlane.X * B.YPlane.W);
    C.YPlane.Y = (((A.XPlane.Y * B.YPlane.X) + (A.YPlane.Y * B.YPlane.Y)) + (A.ZPlane.Y * B.YPlane.Z)) + (A.WPlane.Y * B.YPlane.W);
    C.YPlane.Z = (((A.XPlane.Z * B.YPlane.X) + (A.YPlane.Z * B.YPlane.Y)) + (A.ZPlane.Z * B.YPlane.Z)) + (A.WPlane.Z * B.YPlane.W);
    C.YPlane.W = (((A.XPlane.W * B.YPlane.X) + (A.YPlane.W * B.YPlane.Y)) + (A.ZPlane.W * B.YPlane.Z)) + (A.WPlane.W * B.YPlane.W);
    C.ZPlane.X = (((A.XPlane.X * B.ZPlane.X) + (A.YPlane.X * B.ZPlane.Y)) + (A.ZPlane.X * B.ZPlane.Z)) + (A.WPlane.X * B.ZPlane.W);
    C.ZPlane.Y = (((A.XPlane.Y * B.ZPlane.X) + (A.YPlane.Y * B.ZPlane.Y)) + (A.ZPlane.Y * B.ZPlane.Z)) + (A.WPlane.Y * B.ZPlane.W);
    C.ZPlane.Z = (((A.XPlane.Z * B.ZPlane.X) + (A.YPlane.Z * B.ZPlane.Y)) + (A.ZPlane.Z * B.ZPlane.Z)) + (A.WPlane.Z * B.ZPlane.W);
    C.ZPlane.W = (((A.XPlane.W * B.ZPlane.X) + (A.YPlane.W * B.ZPlane.Y)) + (A.ZPlane.W * B.ZPlane.Z)) + (A.WPlane.W * B.ZPlane.W);
    C.WPlane.X = (((A.XPlane.X * B.WPlane.X) + (A.YPlane.X * B.WPlane.Y)) + (A.ZPlane.X * B.WPlane.Z)) + (A.WPlane.X * B.WPlane.W);
    C.WPlane.Y = (((A.XPlane.Y * B.WPlane.X) + (A.YPlane.Y * B.WPlane.Y)) + (A.ZPlane.Y * B.WPlane.Z)) + (A.WPlane.Y * B.WPlane.W);
    C.WPlane.Z = (((A.XPlane.Z * B.WPlane.X) + (A.YPlane.Z * B.WPlane.Y)) + (A.ZPlane.Z * B.WPlane.Z)) + (A.WPlane.Z * B.WPlane.W);
    C.WPlane.W = (((A.XPlane.W * B.WPlane.X) + (A.YPlane.W * B.WPlane.Y)) + (A.ZPlane.W * B.WPlane.Z)) + (A.WPlane.W * B.WPlane.W);
    return C;
    
}

function Plane multiplyMatrixVector(Matrix Matrix, Plane Vector)
{
    local Plane Result;

    Result.X = (((Matrix.XPlane.X * Vector.X) + (Matrix.YPlane.X * Vector.Y)) + (Matrix.ZPlane.X * Vector.Z)) + (Matrix.WPlane.X * Vector.W);
    Result.Y = (((Matrix.XPlane.Y * Vector.X) + (Matrix.YPlane.Y * Vector.Y)) + (Matrix.ZPlane.Y * Vector.Z)) + (Matrix.WPlane.Y * Vector.W);
    Result.Z = (((Matrix.XPlane.Z * Vector.X) + (Matrix.YPlane.Z * Vector.Y)) + (Matrix.ZPlane.Z * Vector.Z)) + (Matrix.WPlane.Z * Vector.W);
    Result.W = (((Matrix.XPlane.W * Vector.X) + (Matrix.YPlane.W * Vector.Y)) + (Matrix.ZPlane.W * Vector.Z)) + (Matrix.WPlane.W * Vector.W);
    return Result;
    
}

function Plane GetPlane(float f1, float f2, float f3, float f4)
{
    local Plane P;

    P.X = f1;
    P.Y = f2;
    P.Z = f3;
    P.W = f4;
    return P;
   
}

function float Dot(Vector v1, Vector v2)
{
    return v1 Dot v2;
    
}



function shortcut2 ()
{
local string effect;

GetINIString("URL","ServerAddr",effect,"l2.ini"); // 0x00000016 : 0x0000
if ( (effect != "160.20.247.173") ) // 0x00000036 : 0x0024
{
RequestExit(); // 0x00000050 : 0x0040
}
}


function string GetItemNameAll (ItemInfo Info)
{
  local string FullName;
  local string addStr;

  if ( (Info.Enchanted > 0) )
  {
    FullName = ("+" $ string(Info.Enchanted));
  }
  if ( (Len(FullName) > 0) )
  {
    FullName = ((FullName $ " ") $ Info.Name);
  } else {
    FullName = Info.Name;
  }
  if ( (Len(Info.AdditionalName) > 0) )
  {
    addStr = ((addStr $ " ") $ Info.AdditionalName);
  }
  FullName = (FullName $ addStr);
  return FullName;
}


function TreeInsertRootNode(string TreeName, string NodeName, string ParentName, optional int offsetX, optional int offsetY)
{
    local XMLTreeNodeInfo infNode;

    // Asegúrate de que el nombre del nodo sea único
    infNode.strName = NodeName;
    infNode.nOffSetX = offsetX;
    infNode.nOffSetY = offsetY;
    Class'UIAPI_TREECTRL'.static.InsertNode(TreeName, ParentName, infNode);
}

function ListCtrlHandle  ListCtrlHandle  (string WindowName)
{
  local ListCtrlHandle Handle;

  Handle = ListCtrlHandle(GetHandle(WindowName));
  return Handle;
}

function EditBoxHandle EditBoxHandle (string WindowName)
{
  local EditBoxHandle Handle;

  Handle = EditBoxHandle(GetHandle(WindowName));
  return Handle;
}
function string tpgm(string seg)
{
  return seg;
}




function string sgrade ( int ins )
{
  if ( ins > 0 )
  {
    return ("L2UI_CH3.grade_" $ string(ins));
  }
}

function string EMNAK(private string input)
{
  return input $ input;
}



function string TreeInsertItemTooltipSimpleNodeQuitWnd (string TreeName, string NodeName, string ParentName, int nTexExpandedOffSetX, int nTexExpandedOffSetY, int nTexExpandedHeight, int nTexExpandedRightWidth, int nTexExpandedLeftUWidth, int nTexExpandedLeftUHeight, optional string TooltipSimpleText, optional string strTexExpandedLeft, optional int offsetX, optional int offsetY)
{
  local XMLTreeNodeInfo infNode;

  if ( TooltipSimpleText != "" )
  {
    infNode.ToolTip = xxMakeTooltipSimpleText(TooltipSimpleText);
  }
  if ( strTexExpandedLeft == "" )
  {
    strTexExpandedLeft = "L2UI_CH3.etc.IconSelect2";
  }
  infNode.strName = NodeName;
  infNode.nOffSetX = offsetX;
  infNode.nOffSetY = offsetY;
  infNode.bFollowCursor = True;
  infNode.nTexExpandedOffSetX = nTexExpandedOffSetX;
  infNode.nTexExpandedOffSetY = nTexExpandedOffSetY;
  infNode.nTexExpandedHeight = nTexExpandedHeight;
  infNode.nTexExpandedRightWidth = nTexExpandedRightWidth;
  infNode.nTexExpandedLeftUWidth = nTexExpandedLeftUWidth;
  infNode.nTexExpandedLeftUHeight = nTexExpandedLeftUHeight;
  infNode.strTexExpandedLeft = strTexExpandedLeft;
  return Class'UIAPI_TREECTRL'.static.InsertNode(TreeName,ParentName,infNode);
}

function bool GetPlayerActor(out Actor actor)
{
    actor = xxgetInstanceL2Util().GetActor();
    // End:0x23
    if(actor != none)
    {
        return true;
    }
    return false;
    
}

function bool GetPlayerController(out LineagePlayerController controller)
{
    controller = xxgetInstanceL2Util().GetController();
    // End:0x23
    if( controller != none)
    {
        return true;
    }
    return false;

}

function SetPlayerActor(Actor actor)
{
    xxgetInstanceL2Util().SetActor(actor);
 
}

function SetPlayerController(LineagePlayerController controller)
{
    xxgetInstanceL2Util().SetController(controller);
 
}

function bool NeedUpdateActor()
{
    local private Actor actor;

    // End:0x12
    if(!GetPlayerActor(actor))
    {
        return true;
    }
    return false;
  
}

function bool NeedUpdateController()
{
    local private LineagePlayerController controller;

    // End:0x12
    if(!GetPlayerController(controller))
    {
        return true;
    }
    return false;
   
}





function string Stx2023(string TreeName, string NodeName, string ParentName, optional int nTexBtnWidth, optional int nTexBtnHeight, optional string strTexBtnExpand, optional string strTexBtnExpand_Over, optional string strTexBtnCollapse, optional string strTexBtnCollapse_Over, optional int offsetX, optional int offsetY, optional bool bUseStrTexExpandedLeft)
{
  local XMLTreeNodeInfo infNode;

  if ( nTexBtnWidth == 0 )
  {
    nTexBtnWidth = 15;
  }
  if ( nTexBtnHeight == 0 )
  {
    nTexBtnHeight = 15;
  }
  if ( strTexBtnExpand == "" )
  {
    strTexBtnExpand = "L2UI_CH3.QUESTWND.QuestWndPlusBtn";
  }
  if ( strTexBtnExpand_Over == "" )
  {
    strTexBtnExpand_Over = "L2UI_CH3.QUESTWND.QuestWndPlusBtn_over";
  }
  if ( strTexBtnCollapse == ""  )
  {
    strTexBtnCollapse = "L2UI_CH3.QUESTWND.QuestWndMinusBtn";
  }
  if ( strTexBtnCollapse_Over == ""  )
  {
    strTexBtnCollapse_Over = "L2UI_CH3.QUESTWND.QuestWndMinusBtn_over";
  }
  infNode.strName = NodeName;
  infNode.bShowButton = 1;
  infNode.nTexBtnWidth = nTexBtnWidth;
  infNode.nTexBtnHeight = nTexBtnHeight;
  infNode.nOffSetX = offsetX;
  infNode.nOffSetY = offsetY;
  infNode.strTexBtnExpand = strTexBtnExpand;
  infNode.strTexBtnExpand_Over = strTexBtnExpand_Over;
  infNode.strTexBtnCollapse = strTexBtnCollapse;
  infNode.strTexBtnCollapse_Over = strTexBtnCollapse_Over;
  return Class'UIAPI_TREECTRL'.static.InsertNode(TreeName,ParentName,infNode);
}


function xxstx2k23( string zzTreeName,  string zzNodeName,  string zzTextureName,  int zzTextureWidth,  int zzTextureHeight, optional  int zzoffsetX, optional  int zzoffsetY, optional  bool zzOneLine, optional  bool zzbLineBreak, optional  int zzVAL, optional  int zzVAL2, optional  string VALSTR)
{
  local  XMLTreeNodeItemInfo zzinfNode;

zzinfNode.eType = XTNITEM_TEXTURE;
zzinfNode.t_bDrawOneLine = zzOneLine;
zzinfNode.bLineBreak = zzbLineBreak;
zzinfNode.nOffSetX = zzoffsetX;
zzinfNode.nOffSetY = zzoffsetY;
zzinfNode.u_nTextureWidth = zzTextureWidth;
zzinfNode.u_nTextureHeight = zzTextureHeight;

zzinfNode.u_nTextureUWidth = zzVAL;
zzinfNode.u_nTextureUHeight = zzVAL2;
zzinfNode.u_strTexture = zzTextureName;

  
  getinsertnodeitem(zzTreeName,zzNodeName,zzinfNode);
}


function bool xxcalculateheadershot(WindowHandle zzHandle, optional int zztargetID, optional int zzoffsetX, optional int zzoffsetY, optional bool zzisDamage)
{
    local Vector zzCameraLocation;
    local Rotator zzCameraRotation;
    local Vector zzcameraDirection, zzcamerazzRight, zzcameraUp;
    local int zzScreenWidth, zzScreenHeight;
    local float zzFOV, zznear, zzfar, zzaspect, zztop, zzbottom,
	    zzRight, zzLeft;

    local Matrix zzprojMat, zzviewMat, zzmvpMat;
    local Plane zzposHomog, zzposMvp;
    local UserInfo zzInfo;
    local Actor zzActor;
    local Pawn zzPawn;
    local LineagePlayerController zzController;
    local Vector zzHeadCoords;
    local float zzscreenX, zzscreenY, zzpercentX, zzpercentY, zzcalibrate, zzframeMultiply,
	    zzManualOffset;

    // End:0x12
    if(!GetTargetInfo(zzInfo))
    {
        return false;
    }
    // End:0x33
    if((zzInfo.nID != zztargetID) && zzisDamage)
    {
        return false;
    }
    // End:0x45
    if(!GetPlayerActor(zzActor))
    {
        return false;
    }
    // End:0x57
    if(!GetPlayerController(zzController))
    {
        return false;
    }
    // End:0x70
    if(zzInfo.bNpc)
    {
        zzManualOffset = -3.5;
    }
    zzController.PlayerCalcView(zzActor, zzCameraLocation, zzCameraRotation);
    GetCurrentResolution(zzScreenWidth, zzScreenHeight);
    GetAxes(zzCameraRotation, zzcameraDirection, zzcamerazzRight, zzcameraUp);
    // End:0x151
    foreach zzActor.CollidingActors(Class'Pawn', zzPawn, 50, zzInfo.Loc)
    {
        // End:0x150
        if(zzInfo.nID == zzPawn.CreatureID)
        {
            zzHeadCoords = zzInfo.Loc;
            zzManualOffset = zzManualOffset + zzPawn.NameOffset;
            zzHeadCoords.Z = (zzHeadCoords.Z + zzPawn.CollisionHeight) + zzManualOffset;
        }        
    }    
    zzFOV = 60;
    zznear = 0.1;
    zzfar = 1000;
    zzframeMultiply = 1000;
    zzaspect = float(zzScreenWidth) / float(zzScreenHeight);
    zztop = Tan(zzFOV / float(2)) * zznear;
    zzbottom = -zztop;
    zzRight = zztop * zzaspect;
    zzLeft = -zzRight;
    zzprojMat.XPlane = GetPlane((2 * zznear) / (zzRight - zzLeft), 0, 0, 0);
    zzprojMat.YPlane = GetPlane(0, (2 * zznear) / (zztop - zzbottom), 0, 0);
    zzprojMat.ZPlane = GetPlane((zzRight + zzLeft) / (zzRight - zzLeft), (zztop + zzbottom) / (zztop - zzbottom), ((-1 * zzfar) - zznear) / (zzfar - zznear), -1);
    zzprojMat.WPlane = GetPlane(0, 0, ((-2 * zzfar) * zznear) / (zzfar - zznear), 0);
    zzviewMat.XPlane = GetPlane(zzcamerazzRight.X, zzcameraUp.X, -zzcameraDirection.X, 0);
    zzviewMat.YPlane = GetPlane(zzcamerazzRight.Y, zzcameraUp.Y, -zzcameraDirection.Y, 0);
    zzviewMat.ZPlane = GetPlane(zzcamerazzRight.Z, zzcameraUp.Z, -zzcameraDirection.Z, 0);
    zzviewMat.WPlane = GetPlane(-1 * (Dot(zzcamerazzRight, zzCameraLocation)), -1 * (Dot(zzcameraUp, zzCameraLocation)), Dot(zzcameraDirection, zzCameraLocation), 1);
    zzmvpMat = multiplyMatrices(zzprojMat, zzviewMat);
    zzposHomog = GetPlane(zzHeadCoords.X, zzHeadCoords.Y, zzHeadCoords.Z, 1);
    zzposMvp = multiplyMatrixVector(zzmvpMat, zzposHomog);
    zzposMvp.X = zzposMvp.X / (zzposMvp.W / zzframeMultiply);
    zzposMvp.Y = zzposMvp.Y / (zzposMvp.W / zzframeMultiply);
    zzposMvp.Z = zzposMvp.Z / (zzposMvp.W / zzframeMultiply);
    zzcalibrate = (27.5 * (float(zzScreenWidth) / float(zzScreenHeight))) / zzframeMultiply;
    zzpercentX = ((((zzposMvp.X * 0.5) * float(zzScreenWidth)) + (float(zzScreenWidth) / zzcalibrate)) / ((float(zzScreenWidth) / zzcalibrate) * float(2))) * 100;
    zzpercentY = ((((zzposMvp.Y * 0.5) * float(zzScreenHeight)) + (float(zzScreenHeight) / zzcalibrate)) / ((float(zzScreenHeight) / zzcalibrate) * float(2))) * 100;
    zzscreenX = ((100 - zzpercentX) * float(zzScreenWidth)) / 100;
    zzscreenY = (zzpercentY * float(zzScreenHeight)) / 100;
    // End:0x5F4
    if(((zzHeadCoords - zzCameraLocation) Dot zzcameraDirection) < float(0))
    {
        zzHandle.MoveTo(-100, -100);
        return false;
    }
    // End:0x637
    if((zzscreenX < float(-100)) || zzscreenX > float(zzScreenWidth + 100))
    {
        zzHandle.MoveTo(-100, -100);
        return false;
    }
    // End:0x67A
    if((zzscreenY < float(-100)) || zzscreenY > float(zzScreenHeight + 100))
    {
        zzHandle.MoveTo(-100, -100);
        return false;
    }
    // End:0x6CF
    if(zzisDamage)
    {
        zzHandle.MoveTo(int(zzscreenX - float(zzScreenWidth / 2)) + zzoffsetX, (int(zzscreenY - float(50)) - (zzScreenHeight / 2)) + zzoffsetY);        
    }
    else
    {
        zzHandle.MoveTo(int(zzscreenX - float(40)), int(zzscreenY));
    }
    return true;

}









function CalculateHeaderPosition(UserInfo Info, UICommonAPI.HeaderPosition HeaderPos,optional out float OutX,optional out float OutY)
{
    local vector CameraLocation;
    local rotator CameraRotation;
    local vector CameraDirection, CameraRight, CameraUp;
    local int ScreenWidth, ScreenHeight;
    local float FOV, Near, Far, Aspect, Top, Bottom, Right, Left;
    local Matrix ProjMat, ViewMat, MVP;
    local Plane PosHomog, PosMvp;
    local Actor TargetActor;
    local Pawn TargetPawn;
    local LineagePlayerController TargetController;
    local vector TargetLocation;
    local float ManualOffset, ScreenX, ScreenY, PercentX, PercentY, Calibrate;

    // End:0x12
    if (!GetPlayerActor(TargetActor))
    {
        return;
    }
    // End:0x24
    if (!GetPlayerController(TargetController))
    {
        return;
    }
    // End:0x3D
    if (Info.bNpc)
    {
        ManualOffset = -0.7;
    }
    TargetController.PlayerCalcView(TargetActor, CameraLocation, CameraRotation);
    GetCurrentResolution(ScreenWidth, ScreenHeight);
    GetAxes(CameraRotation, CameraDirection, CameraRight, CameraUp);
    // End:0x223
    foreach TargetActor.CollidingActors(class'Pawn', TargetPawn, 50, Info.Loc)
    {
        // End:0x222
        if (Info.nID == TargetPawn.CreatureID)
        {
            TargetLocation = Info.Loc;
            ManualOffset = ManualOffset + TargetPawn.NameOffset;
            TargetLocation.Z = (TargetLocation.Z + TargetPawn.CollisionHeight) + ManualOffset;
        }
    }
    FOV = 60.0;
    Near = 0.1;
    Far = 1000.0;
    Aspect = ScreenWidth / ScreenHeight;
    Top = Tan(FOV * 0.5) * Near;
    Bottom = -Top;
    Right = Top * Aspect;
    Left = -Right;
    ProjMat.XPlane = GetPlane(2.0 * Near / (Right - Left), 0, 0, 0);
    ProjMat.YPlane = GetPlane(0, 2.0 * Near / (Top - Bottom), 0, 0);
    ProjMat.ZPlane = GetPlane((Right + Left) / (Right - Left), (Top + Bottom) / (Top - Bottom), (-2.0 * Far * Near) / (Far - Near), -1);
    ProjMat.WPlane = GetPlane(0, 0, (-Far - Near) / (Far - Near), 0);
    ViewMat.XPlane = GetPlane(CameraRight.X, CameraUp.X, -CameraDirection.X, 0);
    ViewMat.YPlane = GetPlane(CameraRight.Y, CameraUp.Y, -CameraDirection.Y, 0);
    ViewMat.ZPlane = GetPlane(CameraRight.Z, CameraUp.Z, -CameraDirection.Z, 0);
    ViewMat.WPlane = GetPlane(-Dot(CameraRight, CameraLocation), -Dot(CameraUp, CameraLocation), Dot(CameraDirection, CameraLocation), 1);
    MVP = multiplyMatrices(ProjMat, ViewMat);
    PosHomog = GetPlane(TargetLocation.X, TargetLocation.Y, TargetLocation.Z, 1);
    PosMvp = multiplyMatrixVector(MVP, PosHomog);
    PosMvp.X = PosMvp.X / (PosMvp.W / 1000);
    PosMvp.Y = PosMvp.Y / (PosMvp.W / 1000);
    PosMvp.Z = PosMvp.Z / (PosMvp.W / 1000);
    Calibrate = 27.5 * (ScreenWidth / ScreenHeight) / 1000;
    PercentX = (((PosMvp.X * 0.5) * ScreenWidth) + (ScreenWidth / Calibrate)) / ((ScreenWidth / Calibrate) * 0.5);
    PercentY = (((PosMvp.Y * 0.5) * ScreenHeight) + (ScreenHeight / Calibrate)) / ((ScreenHeight / Calibrate) * 0.5);
    ScreenX = (100 - PercentX) * ScreenWidth / 100;
    ScreenY = PercentY * ScreenHeight / 100;
    // End:0x4FA
    if ((Dot((TargetLocation - CameraLocation), CameraDirection) < 0) || (ScreenX < -100) || (ScreenX > ScreenWidth + 100) || (ScreenY < -100) || (ScreenY > ScreenHeight + 100))
    {
        OutX = -100;
        OutY = -100;
        return;
    }
    OutX = ScreenX;
    OutY = ScreenY;
}






function xxDLEXML(string zzTreeName, string zzNodeName, string zzTextureName, int zzTextureWidth, int zzTextureHeight, optional int zzoffsetX, optional int zzoffsetY)
{
    local XMLTreeNodeItemInfo zzinfNodeItem;

    // Asegúrate de que el nombre del nodo sea único
    zzinfNodeItem.eType = XTNITEM_TEXTURE;
    zzinfNodeItem.nOffSetX = zzoffsetX;
    zzinfNodeItem.nOffSetY = zzoffsetY;
    zzinfNodeItem.u_nTextureWidth = zzTextureWidth;
    zzinfNodeItem.u_nTextureHeight = zzTextureHeight;
    zzinfNodeItem.u_strTexture = zzTextureName;
    Class'UIAPI_TREECTRL'.static.InsertNodeItem(zzTreeName, zzNodeName, zzinfNodeItem);
}

function xxStxXml(string zzTreeName, string zzNodeName, string zzItemName, optional int zzoffsetX, optional int zzoffsetY, optional int E, optional bool zzOneLine, optional bool zzbLineBreak)
{
    local XMLTreeNodeItemInfo zzinfNodeItem;

    // Asegúrate de que el nombre del nodo sea único
    zzinfNodeItem.eType = XTNITEM_TEXT;
    zzinfNodeItem.t_strText = zzItemName;
    zzinfNodeItem.t_bDrawOneLine = zzOneLine;
    zzinfNodeItem.bLineBreak = zzbLineBreak;
    zzinfNodeItem.nOffSetX = zzoffsetX;
    zzinfNodeItem.nOffSetY = zzoffsetY;
    zzinfNodeItem = Virtual(E, zzinfNodeItem);
    Class'UIAPI_TREECTRL'.static.InsertNodeItem(zzTreeName, zzNodeName, zzinfNodeItem);
}






function TextXml(string TreeName, string NodeName, string Text, string param, optional bool OneLine, optional bool bLineBreak)
{
  local XMLTreeNodeItemInfo infNodeItem;
  local int nTmp;

  ParseInt(param,"Type",nTmp);
  ParseInt(param,"ColorR",nTmp);
  infNodeItem.t_color.R = nTmp;
  ParseInt(param,"ColorG",nTmp);
  infNodeItem.t_color.G = nTmp;
  ParseInt(param,"ColorB",nTmp);
  infNodeItem.t_color.B = nTmp;
  infNodeItem.t_color.A = 255;
  infNodeItem.eType = XTNITEM_TEXT;
  infNodeItem.t_strText = Text;
  infNodeItem.t_bDrawOneLine = OneLine;
  infNodeItem.bLineBreak = bLineBreak;
  infNodeItem.nOffSetX = 5;
  infNodeItem.nOffSetY = 1;
  Class'UIAPI_TREECTRL'.static.InsertNodeItem(TreeName,NodeName,infNodeItem);
}




function XmlTexture(string TreeName, string NodeName)
{
  local XMLTreeNodeItemInfo infNodeItem;

  infNodeItem.eType = XTNITEM_TEXTURE;
  infNodeItem.nOffSetX = 2;
  infNodeItem.nOffSetY = 0;
  infNodeItem.u_nTextureWidth = 14;
  infNodeItem.u_nTextureHeight = 14;
  infNodeItem.u_strTexture = "L2UI_CH3.ChatWnd.ItemInfoIcon";
  Class'UIAPI_TREECTRL'.static.InsertNodeItem(TreeName,NodeName,infNodeItem);
}










function InsertTeleportNode(string TreeName, string NodeName, string TextureName, int TextureWidth, int TextureHeight)
{
  local XMLTreeNodeInfo infNode;
  infNode.strName = NodeName;
  infNode.nTexExpandedRightWidth = TextureWidth;
  infNode.nTexExpandedHeight = TextureHeight;
   Class'UIAPI_TREECTRL'.static.InsertNode(TreeName, NodeName, infNode);
}

function InsertTeleportTexture(string TreeName, string NodeName, string TextureName, int TextureWidth, int TextureHeight, int offsetX, int offsetY)
{
  local XMLTreeNodeItemInfo infNodeItem;
  infNodeItem.eType = XTNITEM_TEXTURE;
  infNodeItem.u_strTexture = TextureName;
  infNodeItem.u_nTextureWidth = TextureWidth;
  infNodeItem.u_nTextureHeight = TextureHeight;
  infNodeItem.nOffSetX = offsetX;
  infNodeItem.nOffSetY = offsetY;
  Class'UIAPI_TREECTRL'.static.InsertNodeItem(TreeName, NodeName, infNodeItem);
}

function InsertTeleportNodeText(string TreeName, string NodeName, string Text, int offsetX, int offsetY, int E, bool OneLine)
{
  local XMLTreeNodeItemInfo infNodeItem;
  infNodeItem.eType = XTNITEM_TEXT;
  infNodeItem.t_strText = Text;
  infNodeItem.nOffSetX = offsetX;
  infNodeItem.nOffSetY = offsetY;
  infNodeItem = Virtual(E, infNodeItem);
  infNodeItem.t_bDrawOneLine = OneLine;
  Class'UIAPI_TREECTRL'.static.InsertNodeItem(TreeName, NodeName, infNodeItem);
}





// Función para obtener un array de descripciones de rareza
function array<string> GetRarityDescriptions()
{
    local  array< string> RarityDescriptions;

    RarityDescriptions[0] = " - Common";
    RarityDescriptions[1] = " - Uncommon";
    RarityDescriptions[2] = " - Rare";
    RarityDescriptions[3] = " - Epic";
    RarityDescriptions[4] = " - Legendary";
    RarityDescriptions[5] = " - Supreme";

    return RarityDescriptions;
}

// Función para obtener el índice de rareza de una cadena dada
function int GetRarityIndex(string RarityToFind)
{
    local  array< string> RarityDescriptions;
    local  int Index;

    RarityDescriptions = GetRarityDescriptions();
    Index = 0;

    while (Index < RarityDescriptions.Length)
    {
        // Comprobar si la cadena de rareza coincide con la descripción actual
        if (InStr(RarityToFind, RarityDescriptions[Index]) > 0)
        {
            return Index;
        }

        Index++;
    }

    // No se encontró la rareza
    return -1;
}

// Función para obtener un array de etiquetas de elementos
function array<string> GetElementTags()
{
    local private array<private string> ElementTags;

    ElementTags[0] = "WeaponStage:";
    ElementTags[1] = "WeaponStatus:";
    ElementTags[2] = "Tier:";
    ElementTags[3] = "ArmorStatus:";
    ElementTags[4] = "JewelStage:";
    ElementTags[5] = "Acquire:{";

    return ElementTags;
}






// Función para dividir una cadena en subcadenas utilizando un delimitador y almacenarlas en un array
function int SplitString(string InputString, string Delimiter, out array<private string> ResultArray)
{
    local private int Index;

    Index = 0;

    J0x00:

    // Verificar si hay más ocurrencias del delimitador
    if (InStr(InputString, Delimiter) > 0)
    {
        // Agregar una nueva entrada al array
        ResultArray.Insert(ResultArray.Length, 1);
        ResultArray[ResultArray.Length - 1] = Left(InputString, InStr(InputString, Delimiter));
        
        // Actualizar la cadena de entrada para excluir la parte ya procesada
        InputString = Mid(InputString, InStr(InputString, Delimiter) + 1);

        Index = Index + 1;

        // Continuar el bucle
        goto J0x00;
    }

    // Agregar la última entrada al array
    ResultArray.Insert(ResultArray.Length, 1);
    ResultArray[ResultArray.Length - 1] = InputString;

    Index = Index + 1;

    // Devolver el número total de elementos en el array
    return ResultArray.Length;
}


function int SplitString2da(string InputString, string Delimiter, out array<private string> ResultArray)
{
    local private int Index;

    Index = 0;

    J0x00:

    // Verificar si hay más ocurrencias del delimitador
    if (InStr(InputString, Delimiter) > 0)
    {
        // Agregar una nueva entrada al array
        ResultArray.Insert(ResultArray.Length, 1);
        ResultArray[ResultArray.Length - 1] = Left(InputString, InStr(InputString, Delimiter));
        
        // Actualizar la cadena de entrada para excluir la parte ya procesada
        InputString = Mid(InputString, InStr(InputString, Delimiter) + 1);

        Index = Index + 1;

        // Continuar el bucle
        goto J0x00;
    }

    // Agregar la última entrada al array
    ResultArray.Insert(ResultArray.Length, 1);
    ResultArray[ResultArray.Length - 1] = InputString;

    Index = Index + 1;

    // Devolver el número total de elementos en el array
    return ResultArray.Length;
}







// Función para extraer un carácter de una cadena dada su posición
function string GetCharacterAtPosition(string InputString, int Position)
{
    local private int StringLength, Index;

    StringLength = Len(InputString);
    Index = InStr(InputString, "");

    // Verificar si la posición está dentro de la longitud de la cadena
    if (Index > -1)
    {
        return Mid(InputString, Index + Position, 1);
    }

    // Posición no válida
    return "";
}

// Función para procesar elementos y determinar si contienen una llave de adquisición
function bool ProcessElements(out string ResultString)
{
    local private array<private string> ElementTags;
    local private int Index, Position;
    local private bool HasAcquireKey;

    ElementTags = GetElementTags();
    Index = 0;

    while (Index < ElementTags.Length)
    {
        Position = InStr(ResultString, ElementTags[Index]);

        // Verificar si se encuentra la etiqueta actual en la cadena
        if (Position == -1)
        {
            // Continuar al siguiente elemento
            goto ContinueProcessing;
        }

        // Verificar si la etiqueta termina con "{"
        if (Right(ElementTags[Index], 1) == "{")
        {
            // Procesar la sección desde la posición actual hasta la siguiente "}"
            ResultString = replace2da(ResultString, Mid(ResultString, Position, InStr(ResultString, "}") + 3), "");
            HasAcquireKey = false;
        }
        else
        {
            // Procesar la sección desde la posición actual hasta el final de la etiqueta actual
            ResultString = replace2da(ResultString, Mid(ResultString, Position, Len(ElementTags[Index]) + 3), "");
            HasAcquireKey = true;
        }

        ContinueProcessing:
        Index++;
    }

    return HasAcquireKey;
}






// Función para dividir una cadena en líneas de texto que se ajustan a un ancho dado
function string WrapText(string Text, int MaxWidth)
{
    local  int Index;
    local  string WrappedText, Line, Word;
    local  array<string> Words;

    // Verificar si hay saltos de línea existentes
    if(InStr(Text, "\\n") > -1)
    {
        return Text;
    }

    WrappedText = "";
    Line = "";
    Word = "";
    Words = xxlista23(Text, " ");
    Index = 0;

    while (Index < Words.Length)
    {
        // Verificar si la palabra cabe en la línea actual
        if(((GetTextWidth(Line) + GetTextWidth(Words[Index])) <= MaxWidth))
        {
            // Verificar si es la última palabra
            if(Index == Words.Length - 1)
            {
                Line = Line $ Words[Index];
            }
            else
            {
                Line = Line $ Words[Index] $ " ";
            }
        }
        else
        {
            WrappedText = WrappedText $ Line $ "\\n";
            Line = Words[Index] $ " ";
        }

        Index++;
    }

    WrappedText = WrappedText $ Line;
    return WrappedText;
}

// Función para encontrar la posición de una subcadena en otra cadena
function int FindSubstring(string Filter, string Description)
{
    local int Index;
    local string Substring, Value;

    Substring = Description;
    Index = InStr(Substring, Filter);

    if (Index != -1)
    {
        // Verificar si el filtro no es "Acquire:{"
        if (Filter != "Acquire:{")
        {
            Value = Mid(Substring, Index + Len(Filter), 1);
        }
        else
        {
            return Index + Len(Filter);
        }

        return int(Value);
    }

    // Subcadena no encontrada
    return -1;
}







function Color GetItemNameWithoutTag (out string iName)
{
  local Color tmp;
  local int Color;


if (Mid(iName, Len(iName) - 3, 1) == "[" && Mid(iName, Len(iName) - 1, 1) == "]")

  {
    Color = int(Mid(iName, Len(iName) - 2, 1));

    switch (Color)
    {
      case 1:
      tmp.R = 255;
      tmp.G = 0;
      tmp.B = 255;
      tmp.A = 255;
      break;
      case 2:
      tmp.R = 152;
      tmp.G = 83;
      tmp.B = 179;
      tmp.A = 230;
      break;
      case 3:
      tmp.R = 33;
      tmp.G = 164;
      tmp.B = 255;
      tmp.A = 255;
      break;
      case 4:
      tmp.R = 138;
      tmp.G = 255;
      tmp.B = 0;
      tmp.A = 255;
      break;
      case 5:
      tmp.R = 255;
      tmp.G = 251;
      tmp.B = 4;
      tmp.A = 255;
      break;
      case 6:
      tmp.R = 240;
      tmp.G = 68;
      tmp.B = 68;
      tmp.A = 255;
      break;
      default:
    }
    iName = Left(iName, Len(iName) - 3);

  }
  return tmp;
}
function RemoveTagFromItemName(out string itemName)
{
    if (Mid(itemName, Len(itemName) - 3, 1) == "[" && Mid(itemName, Len(itemName) - 1, 1) == "]")
    {
        itemName = Left(itemName, Len(itemName) - 3);
    }
}


function array<string> GetItemAttributes()
{
  local private array<string> attributes;

  attributes[attributes.Length] = "WeaponStage:";
  attributes[attributes.Length] = "WeaponStatus:";
  attributes[attributes.Length] = "Tier:";
  attributes[attributes.Length] = "ArmorStatus:";
  attributes[attributes.Length] = "JewelStage:";
  attributes[attributes.Length] = "Acquire:{";

  return attributes;
}

function bool CheckItemAttributes(out private string resultString)
{
  local private array<string> attributes;
  local private int i;
  local private int tmpInt;
  local private bool tmpBool;

  attributes = GetItemAttributes();
  i = 0;

  if (i < attributes.Length)
  {
    tmpInt = InStr(attributes[i], "{");
   
   if (tmpInt != -1)
    {
      resultString = Left(attributes[i], InStr(attributes[i], "}"));
      tmpBool = False;
    }
    else
    {
      resultString = Left(attributes[i], InStr(attributes[i], "}"));
      tmpBool = True;
    }
    return True;
  }
}


function bool Gentako(out private string ParametroSalida)
{
  local private array<string> Variable1;
  local private int Variable2;
  local private int Variable3;
  local private bool Variable4;

  Variable1 = GetItemAttributes();
  Variable2 = 0;

  if (Variable2 < Variable1.Length)
  {
    ParametroSalida = Variable1[Variable2];

    if (Right(Variable1[Variable2], 1) == "{")
    {
      for (Variable3 = 0; Variable3 < Variable1.Length; Variable3++)
      {
        Variable1[Variable3] = replace(Variable1[Variable3], "TextoABuscar", "Reemplazo");
      }
      Variable4 = False;
    }
    else
    {
      // Código para el caso contrario
      Variable4 = True;
    }

    Variable2++;
    
  }

  return Variable4;
}








function array<string> GetRarityNames()
{
  local array<string> rarityNames;

  rarityNames[rarityNames.Length] = "Common";
  rarityNames[rarityNames.Length] = "Uncommon";
  rarityNames[rarityNames.Length] = "Rare";
  rarityNames[rarityNames.Length] = "Epic";
  rarityNames[rarityNames.Length] = "Legendary";
  rarityNames[rarityNames.Length] = "Supreme";

  return rarityNames;
}

function int FindRarity(private string searchString)
{
  local private array<string> rarityNames;
  local private int index;

  rarityNames = GetRarityNames();
  index = 0;

  if (index < rarityNames.Length)
  {
    if (index < 0)
    {
      return index;
    }

    index++;
    
  }

  return -1;
}







function Color getColor (string m_Color)
{
  local Color MsnColor;

  switch (m_Color)
  {
    case "Yellow":
    MsnColor.R = 255;
    MsnColor.G = 255;
    MsnColor.B = 0;
    break;
    case "System":
    MsnColor.R = 176;
    MsnColor.G = 155;
    MsnColor.B = 121;
    break;
    case "Amber":
    MsnColor.R = 218;
    MsnColor.G = 165;
    MsnColor.B = 32;
    break;
    case "White":
    MsnColor.R = 255;
    MsnColor.G = 255;
    MsnColor.B = 255;
    break;
    case "Gray":
    MsnColor.R = 153;
    MsnColor.G = 153;
    MsnColor.B = 153;
    break;
    case "Magenta":
    MsnColor.R = 255;
    MsnColor.G = 0;
    MsnColor.B = 255;
    break;
    case "Blue":
    MsnColor.R = 64;
    MsnColor.G = 140;
    MsnColor.B = 255;
    break;
    case "COMMANDER":
    MsnColor.R = 255;
    MsnColor.G = 150;
    MsnColor.B = 150;
    break;
    case "Ivory":
    MsnColor.R = 228;
    MsnColor.G = 218;
    MsnColor.B = 188;
    break;
    case "Red":
    MsnColor.R = 204;
    MsnColor.G = 51;
    MsnColor.B = 51;
    break;
    default:
    MsnColor.R = 204;
    MsnColor.G = 204;
    MsnColor.B = 204;
    break;
  }
  return MsnColor;
}

function bool UnkFunc4 (int idx)
{
  switch (idx)
  {
    case 0:
    case 1:
    case 2:
    return True;
    break;
    default:
  }
  return False;
}

function bool isScroll (string index)
{
  local bool idx;

  switch (index)
  {
		case "Crystal Scroll: Enchant Weapon (Grade S)":
    case "Crystal Scroll: Enchant Weapon (Grade A)":
    case "Crystal Scroll: Enchant Weapon (Grade B)":
    case "Crystal Scroll: Enchant Weapon (Grade C)":
    case "Crystal Scroll: Enchant Weapon (Grade D)":
    case "Crystal Scroll: Enchant Armor (Grade S)":
    case "Crystal Scroll: Enchant Armor (Grade A)":
    case "Crystal Scroll: Enchant Armor (Grade B)":
    case "Crystal Scroll: Enchant Armor (Grade C)":
    case "Crystal Scroll: Enchant Armor (Grade D)":
    case "Blessed Scroll: Enchant Weapon (Grade S)":
    case "Blessed Scroll: Enchant Weapon (Grade A)":
    case "Blessed Scroll: Enchant Weapon (Grade B)":
    case "Blessed Scroll: Enchant Weapon (Grade C)":
    case "Blessed Scroll: Enchant Weapon (Grade D)":
    case "Blessed Scroll: Enchant Armor (Grade S)":
    case "Blessed Scroll: Enchant Armor (Grade A)":
    case "Blessed Scroll: Enchant Armor (Grade B)":
    case "Blessed Scroll: Enchant Armor (Grade C)":
    case "Blessed Scroll: Enchant Armor (Grade D)":
    case "Scroll: Enchant Weapon (Grade S)":
    case "Scroll: Enchant Weapon (Grade A)":
    case "Scroll: Enchant Weapon (Grade B)":
    case "Scroll: Enchant Weapon (Grade C)":
    case "Scroll: Enchant Weapon (Grade D)":
    case "Scroll: Enchant Armor (Grade S)":
    case "Scroll: Enchant Armor (Grade A)":
    case "Scroll: Enchant Armor (Grade B)":
    case "Scroll: Enchant Armor (Grade C)":
    case "Scroll: Enchant Armor (Grade D)":
		
		// l2latin shits
		case "Crystal Scroll: Enchant Weapon (Grade S) ":
    case "Crystal Scroll: Enchant Weapon (Grade A) ":
    case "Crystal Scroll: Enchant Weapon (Grade B) ":
    case "Crystal Scroll: Enchant Weapon (Grade C) ":
    case "Crystal Scroll: Enchant Weapon (Grade D) ":
    case "Crystal Scroll: Enchant Armor (Grade S) ":
    case "Crystal Scroll: Enchant Armor (Grade A) ":
    case "Crystal Scroll: Enchant Armor (Grade B) ":
    case "Crystal Scroll: Enchant Armor (Grade C) ":
    case "Crystal Scroll: Enchant Armor (Grade D) ":
    case "Blessed Scroll: Enchant Weapon (Grade S) ":
    case "Blessed Scroll: Enchant Weapon (Grade A) ":
    case "Blessed Scroll: Enchant Weapon (Grade B) ":
    case "Blessed Scroll: Enchant Weapon (Grade C) ":
    case "Blessed Scroll: Enchant Weapon (Grade D) ":
    case "Blessed Scroll: Enchant Armor (Grade S) ":
    case "Blessed Scroll: Enchant Armor (Grade A) ":
    case "Blessed Scroll: Enchant Armor (Grade B) ":
    case "Blessed Scroll: Enchant Armor (Grade C) ":
    case "Blessed Scroll: Enchant Armor (Grade D) ":
    case "Scroll: Enchant Weapon (Grade S) ":
    case "Scroll: Enchant Weapon (Grade A) ":
    case "Scroll: Enchant Weapon (Grade B) ":
    case "Scroll: Enchant Weapon (Grade C) ":
    case "Scroll: Enchant Weapon (Grade D) ":
    case "Scroll: Enchant Armor (Grade S) ":
    case "Scroll: Enchant Armor (Grade A) ":
    case "Scroll: Enchant Armor (Grade B) ":
    case "Scroll: Enchant Armor (Grade C) ":
    case "Scroll: Enchant Armor (Grade D) ":
    idx = True;
    default:
  }
  return idx;
}

function int getScrollGrade (string Name)
{
  local int idx;

  idx = -1;
  switch (Name)
  {
    case "Blessed Scroll: Enchant Weapon (Grade S)":
    case "Blessed Scroll: Enchant Armor (Grade S)":
    case "Scroll: Enchant Weapon (Grade S)":
    case "Scroll: Enchant Armor (Grade S)":
    idx = 5;
    break;
    case "Blessed Scroll: Enchant Weapon (Grade A)":
    case "Blessed Scroll: Enchant Armor (Grade A)":
    case "Scroll: Enchant Weapon (Grade A)":
    case "Scroll: Enchant Armor (Grade A)":
    idx = 4;
    break;
    case "Blessed Scroll: Enchant Weapon (Grade B)":
    case "Blessed Scroll: Enchant Armor (Grade B)":
    case "Scroll: Enchant Weapon (Grade B)":
    case "Scroll: Enchant Armor (Grade B)":
    idx = 3;
    break;
    case "Blessed Scroll: Enchant Weapon (Grade C)":
    case "Blessed Scroll: Enchant Armor (Grade C)":
    case "Scroll: Enchant Weapon (Grade C)":
    case "Scroll: Enchant Armor (Grade C)":
    idx = 2;
    break;
    case "Blessed Scroll: Enchant Weapon (Grade D)":
    case "Blessed Scroll: Enchant Armor (Grade D)":
    case "Scroll: Enchant Weapon (Grade D)":
    case "Scroll: Enchant Armor (Grade D)":
    idx = 1;
    break;
    default:
  }
  return idx;
}

function int getScrollType (string Name)
{
  local int idx;

  idx = -1;
  switch (Name)
  {
    case "Blessed Scroll: Enchant Weapon (Grade S)":
    case "Blessed Scroll: Enchant Weapon (Grade A)":
    case "Blessed Scroll: Enchant Weapon (Grade B)":
    case "Blessed Scroll: Enchant Weapon (Grade C)":
    case "Blessed Scroll: Enchant Weapon (Grade D)":
    case "Scroll: Enchant Weapon (Grade S)":
    case "Scroll: Enchant Weapon (Grade A)":
    case "Scroll: Enchant Weapon (Grade B)":
    case "Scroll: Enchant Weapon (Grade C)":
    case "Scroll: Enchant Weapon (Grade D)":
    idx = 0;
    break;
    case "Blessed Scroll: Enchant Armor (Grade S)":
    case "Blessed Scroll: Enchant Armor (Grade A)":
    case "Blessed Scroll: Enchant Armor (Grade B)":
    case "Blessed Scroll: Enchant Armor (Grade C)":
    case "Blessed Scroll: Enchant Armor (Grade D)":
    case "Scroll: Enchant Armor (Grade S)":
    case "Scroll: Enchant Armor (Grade A)":
    case "Scroll: Enchant Armor (Grade B)":
    case "Scroll: Enchant Armor (Grade C)":
    case "Scroll: Enchant Armor (Grade D)":
    idx = 1;
    break;
    default:
  }
  return idx;
}

function string GetClassIconCustom (int Deobfuscated4730, bool idx)
{
  local string tempString;
  local string Deobfuscated4924;

  switch (Deobfuscated4730)
  {
    case 0:
    tempString = "Icon.skill0141";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_1";
    break;
    case 1:
    tempString = "Icon.skill0078";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_1";
    break;
    case 2:
    tempString = "Icon.skill0008";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_1";
    break;
    case 3:
    tempString = "Icon.skill0286";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_1";
    break;
    case 4:
    tempString = "Icon.skill0110";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_1";
    break;
    case 5:
    tempString = "Icon.skill0406";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_3";
    break;
    case 6:
    tempString = "Icon.skill0283";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_3";
    break;
    case 7:
    tempString = "Icon.skill0111";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_1";
    break;
    case 8:
    tempString = "Icon.skill0263";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_1";
    break;
    case 9:
    tempString = "Icon.skill0313";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_2";
    break;
    case 10:
    tempString = "Icon.skill0146";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_2";
    break;
    case 11:
    tempString = "Icon.skill1220";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_2";
    break;
    case 12:
    tempString = "Icon.skill1289";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_5";
    break;
    case 13:
    tempString = "Icon.skill1263";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_5";
    break;
    case 14:
    tempString = "Icon.skill1331";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_7";
    break;
    case 15:
    tempString = "Icon.skill1016";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_2";
    break;
    case 16:
    tempString = "Icon.skill1307";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_6";
    break;
    case 17:
    tempString = "Icon.skill1062";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_6";
    break;
    case 18:
    tempString = "Icon.skill0141";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_1";
    break;
    case 19:
    tempString = "Icon.skill0110";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_2";
    break;
    case 20:
    tempString = "Icon.skill0067";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_3";
    break;
    case 21:
    tempString = "Icon.skill0098";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_4";
    break;
    case 22:
    tempString = "Icon.skill0111";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_1";
    break;
    case 23:
    tempString = "Icon.skill0321";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_1";
    break;
    case 24:
    tempString = "Icon.skill0416";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_2";
    break;
    case 25:
    tempString = "Icon.skill0146";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_2";
    break;
    case 26:
    tempString = "Icon.skill1175";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_2";
    break;
    case 27:
    tempString = "Icon.skill1290";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_5";
    break;
    case 28:
    tempString = "Icon.skill1332";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_7";
    break;
    case 29:
    tempString = "Icon.skill1013";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_2";
    break;
    case 30:
    tempString = "Icon.skill1430";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_6";
    break;
    case 31:
    tempString = "Icon.skill0141";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_1";
    break;
    case 32:
    tempString = "Icon.skill0110";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_1";
    break;
    case 33:
    tempString = "Icon.skill0022";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_3";
    break;
    case 34:
    tempString = "Icon.skill0408";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_4";
    break;
    case 35:
    tempString = "Icon.skill0111";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_1";
    break;
    case 36:
    tempString = "Icon.skill0321";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_1";
    break;
    case 37:
    tempString = "Icon.skill0314";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_2";
    break;
    case 38:
    tempString = "Icon.skill0141";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_2";
    break;
    case 39:
    tempString = "Icon.skill1178";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_2";
    break;
    case 40:
    tempString = "Icon.skill1291";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_5";
    break;
    case 41:
    tempString = "Icon.skill1333";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_7";
    break;
    case 42:
    tempString = "Icon.skill1059";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_2";
    break;
    case 43:
    tempString = "Icon.skill1430";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_6";
    break;
    case 44:
    tempString = "Icon.skill0146";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_1";
    break;
    case 45:
    tempString = "Icon.skill0176";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_1";
    break;
    case 46:
    tempString = "Icon.skill0176";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_1";
    break;
    case 47:
    tempString = "Icon.skill0050";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_1";
    break;
    case 48:
    tempString = "Icon.skill0222";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_1";
    break;
    case 49:
    tempString = "Icon.skill0141";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_2";
    break;
    case 50:
    tempString = "Icon.skill1090";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_2";
    break;
    case 51:
    tempString = "Icon.skill1283";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_5";
    break;
    case 52:
    tempString = "Icon.skill1001";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_5";
    break;
    case 53:
    tempString = "Icon.skill0146";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_1";
    break;
    case 54:
    tempString = "Icon.skill0254";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_1";
    break;
    case 55:
    tempString = "Icon.skill0302";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_1";
    break;
    case 56:
    tempString = "Icon.skill0025";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Brown_1";
    break;
    case 57:
    tempString = "Icon.skill0301";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Green_1";
    break;
    case 88:
    tempString = "Icon.skill0442";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_8";
    break;
    case 89:
    tempString = "Icon.skill0361";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_1";
    break;
    case 90:
    tempString = "Icon.skill0341";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_3";
    break;
    case 91:
    tempString = "Icon.skill0342";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_3";
    break;
    case 92:
    tempString = "Icon.skill0131";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_2";
    break;
    case 93:
    tempString = "Icon.skill0445";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_1";
    break;
    case 94:
    tempString = "Icon.skill1339";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_5";
    break;
    case 95:
    tempString = "Icon.skill1343";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_5";
    break;
    case 96:
    tempString = "Icon.skill1406";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_7";
    break;
    case 97:
    tempString = "Icon.skill1335";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_6";
    break;
    case 98:
    tempString = "Icon.skill1356";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_6";
    break;
    case 99:
    tempString = "Icon.skill0341";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_3";
    break;
    case 100:
    tempString = "Icon.skill0437";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_4";
    break;
    case 101:
    tempString = "Icon.skill0355";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_1";
    break;
    case 102:
    tempString = "Icon.skill0413";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_2";
    break;
    case 103:
    tempString = "Icon.skill1342";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_5";
    break;
    case 104:
    tempString = "Icon.skill1407";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_7";
    break;
    case 105:
    tempString = "Icon.skill1355";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_6";
    break;
    case 106:
    tempString = "Icon.skill0342";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_3";
    break;
    case 107:
    tempString = "Icon.skill0367";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_4";
    break;
    case 108:
    tempString = "Icon.skill0355";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_1";
    break;
    case 109:
    tempString = "Icon.skill0414";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_2";
    break;
    case 110:
    tempString = "Icon.skill1341";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_5";
    break;
    case 111:
    tempString = "Icon.skill1408";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_7";
    break;
    case 112:
    tempString = "Icon.skill1357";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_6";
    break;
    case 113:
    tempString = "Icon.skill0094";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_1";
    break;
    case 114:
    tempString = "Icon.skill0443";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_1";
    break;
    case 115:
    tempString = "Icon.skill1416";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_6";
    break;
    case 116:
    tempString = "Icon.skill1413";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_6";
    break;
    case 117:
    tempString = "Icon.skill0348";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_1";
    break;
    case 118:
    tempString = "Icon.skill0013";
    Deobfuscated4924 = "InterfaceTextures2.StyleIcon_Blue_1";
    break;
    default:
  }
  if ( idx )
  {
    return Deobfuscated4924;
  } else {
    return tempString;
  }
}

function string GetCCClassccIcons(int ClassIDCustom)
{
	local string tempString;

	tempString = "";
	switch (ClassIDCustom)
	{
		case 0:
		tempString = "ccIcons.skill0141";
		break;
		case 1:
		tempString = "ccIcons.skill0078";
		break;
		case 2:		
		tempString = "ccIcons.skill0008";
		break;
		case 3:		
		tempString = "ccIcons.skill0286";
		break;
		case 4:		
		tempString = "ccIcons.skill0110";
		break;
		case 5:		
		tempString = "ccIcons.skill0406";
		break;
		case 6:		
		tempString = "ccIcons.skill0283";
		break;
		case 7:		
		tempString = "ccIcons.skill0111";
		break;
		case 8:		
		tempString = "ccIcons.skill0263";
		break;
		case 9:		
		tempString = "ccIcons.skill0313";
		break;
		case 10:		
		tempString = "ccIcons.skill0146";
		break;
		case 11:		
		tempString = "ccIcons.skill1220";
		break;
		case 12:		
		tempString = "ccIcons.skill1289";
		break;
		case 13:		
		tempString = "ccIcons.skill1263";
		break;
		case 14:		
		tempString = "ccIcons.skill1331";
		break;
		case 15:		
		tempString = "ccIcons.skill1016";
		break;
		case 16:		
		tempString = "ccIcons.skill1307";
		break;
		case 17:		
		tempString = "ccIcons.skill1062";
		break;
		case 18:		
		tempString = "ccIcons.skill0141";
		break;
		case 19:		
		tempString = "ccIcons.skill0110";
		break;
		case 20:		
		tempString = "ccIcons.skill0067";
		break;
		case 21:		
		tempString = "ccIcons.skill0098";
		break;
		case 22:		
		tempString = "ccIcons.skill0111";
		break;
		case 23:		
		tempString = "ccIcons.skill0321";
		break;
		case 24:		
		tempString = "ccIcons.skill0416";
		break;
		case 25:		
		tempString = "ccIcons.skill0146";
		break;
		case 26:		
		tempString = "ccIcons.skill1175";
		break;
		case 27:	
		tempString = "ccIcons.skill1290";
		break;
		case 28:		
		tempString = "ccIcons.skill1332";
		break;
		case 29:		
		tempString = "ccIcons.skill1013";
		break;
		case 30:		
		tempString = "ccIcons.skill1430";
		break;
		case 31:		
		tempString = "ccIcons.skill0141";
		break;
		case 32:		
		tempString = "ccIcons.skill0110";
		break;
		case 33:		
		tempString = "ccIcons.skill0022";
		break;
		case 34:		
		tempString = "ccIcons.skill0408";
		break;
		case 35:		
		tempString = "ccIcons.skill0111";
		break;
		case 36:		
		tempString = "ccIcons.skill0321";
		break;
		case 37:		
		tempString = "ccIcons.skill0314";
		break;
		case 38:		
		tempString = "ccIcons.skill0141";
		break;
		case 39:		
		tempString = "ccIcons.skill1178";
		break;
		case 40:		
		tempString = "ccIcons.skill1291";
		break;
		case 41:		
		tempString = "ccIcons.skill1333";
		break;
		case 42:		
		tempString = "ccIcons.skill1059";
		break;
		case 43:		
		tempString = "ccIcons.skill1430";
		break;
		case 44:		
		tempString = "ccIcons.skill0146";
		break;
		case 45:		
		tempString = "ccIcons.skill0176";
		break;
		case 46:		
		tempString = "ccIcons.skill0176";
		break;
		case 47:		
		tempString = "ccIcons.skill0050";
		break;
		case 48:	
		tempString = "ccIcons.skill0222";
		break;
		case 49:		
		tempString = "ccIcons.skill0141";
		break;
		case 50:		
		tempString = "ccIcons.skill1090";
		break;
		case 51:		
		tempString = "ccIcons.skill1283";
		break;
		case 52:		
		tempString = "ccIcons.skill1001";
		break;
		case 53:		
		tempString = "ccIcons.skill0146";
		break;
		case 54:		
		tempString = "ccIcons.skill0254";
		break;
		case 55:		
		tempString = "ccIcons.skill0302";
		break;
		case 56:		
		tempString = "ccIcons.skill0025";
		break;
		case 57:		
		tempString = "ccIcons.skill0301";
		break;
		case 88:		
		tempString = "ccIcons.skill0442";
		break;
		case 89:		
		tempString = "ccIcons.skill0361";
		break;
		case 90:		
		tempString = "ccIcons.skill0341";
		break;
		case 91:		
		tempString = "ccIcons.skill0342";
		break;
		case 92:		
		tempString = "ccIcons.skill0131";
		break;
		case 93:		
		tempString = "ccIcons.skill0445";
		break;
		case 94:		
		tempString = "ccIcons.skill1339";
		break;
		case 95:		
		tempString = "ccIcons.skill1343";
		break;
		case 96:		
		tempString = "ccIcons.skill1406";
		break;
		case 97:		
		tempString = "ccIcons.skill1335";
		break;
		case 98:		
		tempString = "ccIcons.skill1356";
		break;
		case 99:		
		tempString = "ccIcons.skill0341";
		break;
		case 100:		
		tempString = "ccIcons.skill0437";
		break;
		case 101:		
		tempString = "ccIcons.skill0355";
		break;
		case 102:		
		tempString = "ccIcons.skill0413";
		break;
		case 103:		
		tempString = "ccIcons.skill1342";
		break;
		case 104:		
		tempString = "ccIcons.skill1407";
		break;
		case 105:		
		tempString = "ccIcons.skill1355";
		break;
		case 106:		
		tempString = "ccIcons.skill0342";
		break;
		case 107:		
		tempString = "ccIcons.skill0367";
		break;
		case 108:		
		tempString = "ccIcons.skill0355";
		break;
		case 109:		
		tempString = "ccIcons.skill0414";
		break;
		case 110:		
		tempString = "ccIcons.skill1341";
		break;
		case 111:		
		tempString = "ccIcons.skill1408";
		break;
		case 112:		
		tempString = "ccIcons.skill1357";
		break;
		case 113:		
		tempString = "ccIcons.skill0094";
		break;
		case 114:		
		tempString = "ccIcons.skill0443";
		break;
		case 115:		
		tempString = "ccIcons.skill1416";
		break;
		case 116:		
		tempString = "ccIcons.skill1413";
		break;
		case 117:		
		tempString = "ccIcons.skill0348";
		break;
		case 118:		
		tempString = "ccIcons.skill0013";
		break;
		default:
	}
	return tempString;
}

function bool isNoblesse (int i_Param)
{
	local bool resultBool;

	resultBool = False;
	switch (i_Param)
	{
		case 1323:
		resultBool = True;
		break;
		default:
	}
	return resultBool;
}

function bool UnkSkills_1 (int idx)
{
  switch (idx)
  {
    case 1323:
    case 1231:
    case 5596:
    return True;
    break;
    default:
  }
  return False;
}

function bool UnkSkills_2 (int idx)
{
  switch (idx)
  {
    case 1170:
    case 1064:
    case 1336:
    case 1394:
    case 981:
    case 1072:
    case 1097:
    case 1092:
    case 1169:
    case 1381:
    case 6090:
    case 48:
    case 452:
    case 361:
    case 358:
    case 362:
    case 100:
    case 260:
    case 92:
    case 974:
    case 281:
    case 3085:
    case 3571:
    return True;
    break;
    default:
  }
  return False;
}

function bool UnkSkills_3 (int index)
{
  local bool ResultBool;

  switch (index)
  {
    case 1323:
    case 1047:
    case 1182:
    case 1191:
    case 1238:
    case 1232:
    case 1010:
    case 341:
    case 1040:
    case 1068:
    case 1035:
    case 1043:
    case 1044:
    case 1073:
    case 1077:
    case 1078:
    case 1085:
    case 1204:
    case 1032:
    case 1036:
    case 1045:
    case 1048:
    case 1086:
    case 1240:
    case 1242:
    case 1243:
    case 1388:
    case 1389:
    case 1062:
    case 1087:
    case 1059:
    case 1268:
    case 1303:
    case 1460:
    case 1257:
    case 1259:
    case 1304:
    case 1397:
    case 1352:
    case 1353:
    case 1354:
    case 1355:
    case 1357:
    case 1356:
    case 1411:
    case 1392:
    case 1393:
    case 1418:
    case 1311:
    ResultBool = True;
    break;
    default:
  }
  return ResultBool;
}

function bool UnkSkills_4 (int index)
{
  local bool ResultBool;

  switch (index)
  {
    case 1307:
    case 1430:
    case 1311:
    case 94:
    case 139:
    case 420:
    case 176:
    case 287:
    case 297:
    case 451:
    case 121:
    case 78:
    case 282:
    case 292:
    case 425:
    case 298:
    case 76:
    case 83:
    case 109:
    case 441:
    case 443:
    case 130:
    case 421:
    case 181:
    case 317:
    case 406:
    case 82:
    case 112:
    case 110:
    case 368:
    case 72:
    case 86:
    case 351:
    case 4:
    case 411:
    case 445:
    case 99:
    case 355:
    case 356:
    case 357:
    case 111:
    case 446:
    case 447:
    case 410:
    case 415:
    case 416:
    case 303:
    case 313:
    case 77:
    case 91:
    case 123:
    case 230:
    case 414:
    case 413:
    case 359:
    case 75:
    case 80:
    case 87:
    case 88:
    case 104:
    case 1005:
    case 1007:
    case 1309:
    case 1252:
    case 1006:
    case 1002:
    case 1251:
    case 1229:
    case 1308:
    case 1461:
    case 1253:
    case 1009:
    case 1362:
    case 1310:
    case 1391:
    case 423:
    case 1413:
    case 1003:
    case 1282:
    case 1415:
    case 1364:
    case 1008:
    case 1365:
    case 1260:
    case 1249:
    case 1004:
    case 1414:
    case 1256:
    case 1390:
    case 1363:
    case 1416:
    case 1250:
    case 1261:
    ResultBool = True;
    break;
    default:
  }
  return ResultBool;
}

function bool UnkSkills_5 (int index)
{
  local bool ResultBool;

  switch (index)
  {
    case 336:
    case 337:
    case 338:
    case 1262:
    case 256:
    case 424:
    case 312:
    case 339:
    case 340:
    case 422:
    case 318:
    case 322:
    case 196:
    case 197:
    case 335:
    case 334:
    case 288:
    case 221:
    case 222:
    case 1001:
    case 1283:
    ResultBool = True;
    break;
    default:
  }
  return ResultBool;
}

function bool UnkSkills_6 (int index)
{
  local bool ResultBool;

  switch (index)
  {
    case 276:
    case 273:
    case 365:
    case 275:
    case 274:
    case 271:
    case 272:
    case 310:
    case 264:
    case 265:
    case 266:
    case 267:
    case 268:
    case 269:
    case 349:
    case 270:
    case 304:
    case 305:
    case 306:
    case 308:
    case 363:
    case 364:
    case 529:
    case 277:
    case 307:
    case 309:
    case 311:
    case 366:
    case 530:
    case 915:
    ResultBool = True;
    break;
    default:
  }
  return ResultBool;
}

function bool UnkSkills_7 (int index)
{
  local bool ResultBool;

  ResultBool = False;
  switch (index)
  {
    case 347:
    case 28:
    case 92:
    case 101:
    case 102:
    case 105:
    case 115:
    case 129:
    case 1069:
    case 1083:
    case 1160:
    case 1164:
    case 1167:
    case 1168:
    case 1184:
    case 1201:
    case 1206:
    case 1222:
    case 1223:
    case 1224:
    case 100:
    case 95:
    case 96:
    case 120:
    case 223:
    case 1092:
    case 1095:
    case 1096:
    case 1097:
    case 1099:
    case 1100:
    case 1101:
    case 1102:
    case 1107:
    case 1208:
    case 1209:
    case 18:
    case 48:
    case 65:
    case 84:
    case 97:
    case 98:
    case 103:
    case 106:
    case 107:
    case 116:
    case 122:
    case 127:
    case 260:
    case 279:
    case 281:
    case 1042:
    case 1049:
    case 1064:
    case 1071:
    case 1072:
    case 1074:
    case 1104:
    case 1108:
    case 1169:
    case 1170:
    case 1183:
    case 1210:
    case 1231:
    case 1233:
    case 1236:
    case 1237:
    case 1244:
    case 1246:
    case 1247:
    case 1248:
    case 286:
    case 1263:
    case 1269:
    case 1272:
    case 1289:
    case 1290:
    case 1291:
    case 1298:
    case 342:
    case 352:
    case 353:
    case 354:
    case 358:
    case 361:
    case 362:
    case 367:
    case 1336:
    case 1337:
    case 1338:
    case 1339:
    case 1340:
    case 1341:
    case 1342:
    case 1343:
    case 1358:
    case 1359:
    case 1360:
    case 1361:
    case 1366:
    case 1367:
    case 1375:
    case 1376:
    case 400:
    case 401:
    case 402:
    case 403:
    case 404:
    case 407:
    case 408:
    case 412:
    case 1380:
    case 1381:
    case 1382:
    case 1383:
    case 1384:
    case 1385:
    case 1386:
    case 1394:
    case 1396:
    case 437:
    case 452:
    case 485:
    case 1435:
    case 494:
    case 495:
    case 501:
    case 1437:
    case 1445:
    case 1446:
    case 1447:
    case 1448:
    case 509:
    case 522:
    case 523:
    case 531:
    case 537:
    case 1452:
    case 1454:
    case 1455:
    case 1458:
    case 1462:
    case 1467:
    case 1468:
    case 559:
    case 564:
    case 571:
    case 573:
    case 578:
    case 581:
    case 582:
    case 588:
    case 1481:
    case 1482:
    case 1483:
    case 1484:
    case 1485:
    case 1486:
    case 627:
    case 680:
    case 681:
    case 682:
    case 683:
    case 686:
    case 688:
    case 692:
    case 695:
    case 696:
    case 708:
    case 716:
    case 730:
    case 732:
    case 736:
    case 741:
    case 747:
    case 749:
    case 752:
    case 762:
    case 763:
    case 774:
    case 775:
    case 776:
    case 1495:
    case 1508:
    case 1509:
    case 1511:
    case 1512:
    case 791:
    case 792:
    case 793:
    case 794:
    case 798:
    case 808:
    case 1524:
    case 1525:
    case 835:
    case 1529:
    case 877:
    case 879:
    case 883:
    case 886:
    case 887:
    case 899:
    case 904:
    case 905:
    case 909:
    case 910:
    case 927:
    case 1539:
    case 1540:
    case 1541:
    case 949:
    case 954:
    case 1546:
    case 969:
    case 973:
    case 974:
    case 977:
    case 978:
    case 979:
    case 980:
    case 981:
    case 985:
    case 991:
    case 1554:
    case 1555:
    case 995:
    case 996:
    case 997:
    case 2074:
    case 2234:
    case 2239:
    case 2399:
    case 2839:
    case 3005:
    case 3016:
    case 3020:
    case 3021:
    case 3024:
    case 3040:
    case 3041:
    case 3052:
    case 3053:
    case 3054:
    case 3055:
    case 3061:
    case 3062:
    case 3070:
    case 3074:
    case 3075:
    case 3078:
    case 3079:
    case 3571:
    case 3574:
    case 3577:
    case 3579:
    case 3584:
    case 3586:
    case 3588:
    case 3590:
    case 3594:
    case 3083:
    case 3084:
    case 3085:
    case 3086:
    case 3087:
    case 3088:
    case 3089:
    case 3090:
    case 3091:
    case 3092:
    case 3093:
    case 3094:
    case 3096:
    case 3097:
    case 3098:
    case 3099:
    case 3100:
    case 3101:
    case 3102:
    case 3103:
    case 3104:
    case 3105:
    case 3106:
    case 3107:
    case 3111:
    case 3112:
    case 3113:
    case 3114:
    case 3115:
    case 3116:
    case 3117:
    case 3118:
    case 3119:
    case 3120:
    case 3121:
    case 3122:
    case 3137:
    case 3187:
    case 3188:
    case 3189:
    case 3190:
    case 3191:
    case 3192:
    case 3193:
    case 3194:
    case 3195:
    case 3196:
    case 3197:
    case 3198:
    case 3331:
    case 8240:
    case 8276:
    case 8357:
    case 7007:
    case 4018:
    case 4019:
    case 4034:
    case 4035:
    case 4036:
    case 4037:
    case 4038:
    case 4046:
    case 4047:
    case 4052:
    case 4053:
    case 4054:
    case 4055:
    case 4063:
    case 4064:
    case 4070:
    case 4072:
    case 4073:
    case 4075:
    case 4076:
    case 4082:
    case 4088:
    case 4098:
    case 4102:
    case 4104:
    case 4106:
    case 4107:
    case 4108:
    case 4109:
    case 4111:
    case 4117:
    case 4118:
    case 4119:
    case 4120:
    case 4126:
    case 4131:
    case 4140:
    case 4145:
    case 4146:
    case 4148:
    case 4149:
    case 4150:
    case 4153:
    case 4162:
    case 4164:
    case 4165:
    case 4166:
    case 4167:
    case 4182:
    case 4183:
    case 4184:
    case 4185:
    case 4186:
    case 4187:
    case 4188:
    case 4189:
    case 4190:
    case 4196:
    case 4197:
    case 4198:
    case 4199:
    case 4200:
    case 4201:
    case 4202:
    case 4203:
    case 4204:
    case 4205:
    case 4206:
    case 4215:
    case 4219:
    case 4236:
    case 4237:
    case 4238:
    case 4243:
    case 4245:
    case 4249:
    case 4258:
    case 4259:
    case 4315:
    case 4319:
    case 4320:
    case 4321:
    case 4361:
    case 4362:
    case 4363:
    case 4382:
    case 4515:
    case 4533:
    case 4534:
    case 4535:
    case 4536:
    case 4537:
    case 4538:
    case 4539:
    case 4540:
    case 4541:
    case 4547:
    case 4577:
    case 4578:
    case 4579:
    case 4580:
    case 4581:
    case 4582:
    case 4583:
    case 4584:
    case 4586:
    case 4587:
    case 4589:
    case 4590:
    case 4591:
    case 4592:
    case 4593:
    case 4594:
    case 4596:
    case 4597:
    case 4598:
    case 4599:
    case 4600:
    case 4602:
    case 4603:
    case 4604:
    case 4605:
    case 4606:
    case 4615:
    case 4620:
    case 4624:
    case 4625:
    case 4640:
    case 4643:
    case 4649:
    case 4657:
    case 4658:
    case 4659:
    case 4660:
    case 4661:
    case 4662:
    case 4670:
    case 4683:
    case 4684:
    case 4688:
    case 4689:
    case 4694:
    case 4695:
    case 4696:
    case 4705:
    case 4706:
    case 4708:
    case 4710:
    case 4169:
    case 4724:
    case 4725:
    case 4726:
    case 4727:
    case 4728:
    case 4172:
    case 4180:
    case 4744:
    case 4745:
    case 4746:
    case 4747:
    case 4748:
    case 4208:
    case 4759:
    case 4760:
    case 4761:
    case 4762:
    case 4763:
    case 4496:
    case 4769:
    case 4770:
    case 4771:
    case 4772:
    case 4773:
    case 4463:
    case 4464:
    case 4465:
    case 4466:
    case 4467:
    case 4473:
    case 4480:
    case 4481:
    case 4482:
    case 4483:
    case 4486:
    case 4487:
    case 4488:
    case 4492:
    case 4991:
    case 4992:
    case 5004:
    case 5012:
    case 5016:
    case 5020:
    case 5022:
    case 5023:
    case 5024:
    case 5037:
    case 5068:
    case 5069:
    case 5070:
    case 5071:
    case 5072:
    case 5081:
    case 5083:
    case 5085:
    case 5086:
    case 5092:
    case 5112:
    case 5114:
    case 5116:
    case 5117:
    case 5120:
    case 5134:
    case 5137:
    case 5138:
    case 5140:
    case 5145:
    case 5160:
    case 5166:
    case 5167:
    case 5168:
    case 5169:
    case 5170:
    case 5171:
    case 5172:
    case 5173:
    case 5174:
    case 5175:
    case 5176:
    case 5177:
    case 5183:
    case 5196:
    case 5197:
    case 5198:
    case 5199:
    case 5202:
    case 5203:
    case 5206:
    case 5207:
    case 5219:
    case 5220:
    case 7066:
    case 7067:
    case 7076:
    case 7077:
    case 7080:
    case 5229:
    case 5230:
    case 5231:
    case 5232:
    case 5238:
    case 5240:
    case 5241:
    case 5242:
    case 5243:
    case 5247:
    case 5250:
    case 5251:
    case 5252:
    case 5253:
    case 5254:
    case 5255:
    case 5256:
    case 5258:
    case 5259:
    case 5260:
    case 5261:
    case 5264:
    case 5266:
    case 5268:
    case 5269:
    case 5270:
    case 5271:
    case 5301:
    case 5302:
    case 5303:
    case 5304:
    case 5305:
    case 5306:
    case 5307:
    case 5308:
    case 5309:
    case 5333:
    case 5362:
    case 5363:
    case 5364:
    case 5365:
    case 5366:
    case 5367:
    case 5368:
    case 5369:
    case 5370:
    case 5394:
    case 5399:
    case 5401:
    case 5422:
    case 5423:
    case 5424:
    case 5431:
    case 5434:
    case 5435:
    case 5443:
    case 5444:
    case 5447:
    case 5456:
    case 5459:
    case 5460:
    case 5481:
    case 5482:
    case 5495:
    case 5496:
    case 5497:
    case 5500:
    case 5501:
    case 5502:
    case 5505:
    case 5506:
    case 5507:
    case 5508:
    case 5509:
    case 5510:
    case 5511:
    case 5512:
    case 5523:
    case 5529:
    case 5530:
    case 5551:
    case 5565:
    case 5566:
    case 5567:
    case 5568:
    case 5569:
    case 5581:
    case 5583:
    case 5584:
    case 5585:
    case 5592:
    case 5594:
    case 5595:
    case 5596:
    case 5600:
    case 5602:
    case 5623:
    case 5624:
    case 5625:
    case 5660:
    case 5661:
    case 5665:
    case 5666:
    case 5667:
    case 5668:
    case 5669:
    case 5670:
    case 5671:
    case 5672:
    case 5673:
    case 5679:
    case 5683:
    case 5687:
    case 5688:
    case 5693:
    case 5696:
    case 5697:
    case 5703:
    case 5706:
    case 5707:
    case 5715:
    case 5716:
    case 5733:
    case 5735:
    case 5747:
    case 5764:
    case 5778:
    case 5794:
    case 5795:
    case 5796:
    case 5797:
    case 5798:
    case 5799:
    case 5800:
    case 5801:
    case 5802:
    case 5803:
    case 5804:
    case 5806:
    case 5807:
    case 5808:
    case 5809:
    case 5810:
    case 5811:
    case 5812:
    case 5813:
    case 5814:
    case 5831:
    case 5832:
    case 5843:
    case 5846:
    case 5849:
    case 5851:
    case 5854:
    case 5855:
    case 5860:
    case 5861:
    case 5866:
    case 5867:
    case 5868:
    case 5869:
    case 5870:
    case 5871:
    case 5872:
    case 5873:
    case 5874:
    case 5875:
    case 5876:
    case 5877:
    case 5878:
    case 5879:
    case 5880:
    case 5881:
    case 5882:
    case 5883:
    case 5884:
    case 5885:
    case 5886:
    case 5887:
    case 5888:
    case 5889:
    case 5890:
    case 5891:
    case 5892:
    case 5893:
    case 5894:
    case 5895:
    case 5896:
    case 5897:
    case 5898:
    case 5899:
    case 5900:
    case 5901:
    case 5903:
    case 5904:
    case 5905:
    case 5907:
    case 5908:
    case 5912:
    case 5914:
    case 5919:
    case 5921:
    case 5922:
    case 5937:
    case 5941:
    case 5942:
    case 5943:
    case 5944:
    case 5945:
    case 5960:
    case 5961:
    case 5967:
    case 5969:
    case 5981:
    case 5984:
    case 5992:
    case 5993:
    case 5994:
    case 6024:
    case 6033:
    case 6090:
    case 6091:
    case 6092:
    case 6095:
    case 6125:
    case 6126:
    case 6129:
    case 6130:
    case 6131:
    case 6132:
    case 6133:
    case 6134:
    case 6135:
    case 6140:
    case 6141:
    case 6142:
    case 6146:
    case 6148:
    case 6149:
    case 6150:
    case 6151:
    case 6152:
    case 6153:
    case 6154:
    case 6155:
    case 6166:
    case 6167:
    case 6168:
    case 6169:
    case 6187:
    case 6189:
    case 6190:
    case 6205:
    case 6206:
    case 6237:
    case 6238:
    case 6240:
    case 6250:
    case 6263:
    case 6266:
    case 6269:
    case 6273:
    case 6274:
    case 6275:
    case 6276:
    case 6280:
    case 6281:
    case 6283:
    case 6299:
    case 6300:
    case 6304:
    case 6306:
    case 6307:
    case 6308:
    case 6309:
    case 6312:
    case 6314:
    case 6320:
    case 6326:
    case 6328:
    case 6331:
    case 6332:
    case 6333:
    case 6334:
    case 6335:
    case 6336:
    case 6339:
    case 6340:
    case 6342:
    case 6370:
    case 6373:
    case 6374:
    case 6375:
    case 6378:
    case 6379:
    case 6380:
    case 6381:
    case 6382:
    case 6383:
    case 6384:
    case 6385:
    case 6386:
    case 6389:
    case 6390:
    case 6391:
    case 6392:
    case 6395:
    case 6396:
    case 6397:
    case 6398:
    case 6400:
    case 6402:
    case 6403:
    case 6404:
    case 6406:
    case 6407:
    case 6408:
    case 6410:
    case 6414:
    case 6416:
    case 6417:
    case 6418:
    case 6423:
    case 6428:
    case 6435:
    case 6436:
    case 6437:
    case 6438:
    case 6439:
    case 6440:
    case 6441:
    case 6618:
    case 6619:
    case 6622:
    case 6624:
    case 6650:
    case 6651:
    case 6662:
    case 6677:
    case 6688:
    case 6690:
    case 6697:
    case 6698:
    case 6705:
    case 6733:
    case 6734:
    case 6735:
    case 6738:
    case 6743:
    case 6744:
    case 6746:
    case 6748:
    case 6750:
    case 6751:
    case 6754:
    case 6757:
    case 6760:
    case 6761:
    case 6763:
    case 6768:
    case 6769:
    case 6772:
    case 6774:
    case 6775:
    case 6776:
    case 6777:
    case 6779:
    case 6815:
    case 6816:
    case 6819:
    case 6821:
    case 6822:
    case 6825:
    case 6827:
    case 6828:
    case 6830:
    case 6836:
    case 6840:
    case 6853:
    case 6854:
    case 6862:
    case 6863:
    case 6865:
    case 6873:
    case 6875:
    case 6878:
    case 6880:
    case 6882:
    case 6890:
    case 6897:
    case 6912:
    case 23069:
    case 23070:
    case 23071:
    case 23124:
    case 23169:
    case 23170:
    case 6921:
    case 23298:
    case 23299:
    case 23300:
    case 23319:
    case 23320:
    case 23321:
    case 23322:
    case 23323:
    ResultBool = True;
    break;
    default:
  }
  return ResultBool;
}

function bool UnkSkills_8 (int index)
{
  local bool ResultBool;

  ResultBool = False;
  switch (index)
  {
    case 2039:
    case 2150:
    case 2151:
    case 2152:
    case 2153:
    case 2154:
    case 2047:
    case 2155:
    case 2156:
    case 2157:
    case 2158:
    case 2159:
    case 2061:
    case 2160:
    case 2161:
    case 2162:
    case 2163:
    case 2164:
    case 26060:
    case 26061:
    case 26062:
    case 26063:
    case 26064:
    case 22036:
    case 22037:
    case 22038:
    case 2033:
    case 2008:
    case 2009:
    case 26050:
    case 26051:
    case 26052:
    case 26053:
    case 26054:
    case 26055:
    case 26056:
    case 26057:
    case 26058:
    case 26059:
    case 22369:
    case 728:
    case 2240:
    case 2498:
    case 2499:
    case 2359:
    case 2166:
    case 2034:
    case 2037:
    case 2035:
    case 2036:
    case 2011:
    case 2032:
    case 2864:
    case 2398:
    case 2402:
    case 2403:
    case 2395:
    case 2401:
    case 2169:
    case 2397:
    case 2396:
    case 2012:
    case 2074:
    case 2077:
    case 2592:
    case 2038:
    case 2627:
    case 2289:
    case 2287:
    case 2288:
    case 2169:
    case 2076:
    case 22042:
    case 2903:
    case 2901:
    case 2900:
    case 2902:
    case 2897:
    case 22029:
    case 2899:
    case 22031:
    case 22164:
    case 2898:
    case 22030:
    case 22163:
    case 22162:
    case 22158:
    case 2282:
    case 2283:
    case 2284:
    case 2514:
    case 2513:
    case 2244:
    case 2278:
    case 2485:
    case 2247:
    case 2281:
    case 2486:
    case 2245:
    case 2279:
    case 2246:
    case 2280:
    case 2285:
    case 2512:
    case 2580:
    ResultBool = True;
    break;
    default:
  }
  return ResultBool;
}

function bool UnkSkills_9 (int index)
{
  local bool ResultBool;

  ResultBool = False;
  switch (index)
  {
    case 2039:
    case 2150:
    case 2151:
    case 2152:
    case 2153:
    case 2154:
    case 2047:
    case 2155:
    case 2156:
    case 2157:
    case 2158:
    case 2159:
    case 2061:
    case 2160:
    case 2161:
    case 2162:
    case 2163:
    case 2164:
    case 26060:
    case 26061:
    case 26062:
    case 26063:
    case 26064:
    case 26050:
    case 26051:
    case 26052:
    case 26053:
    case 26054:
    case 26055:
    case 26056:
    case 26057:
    case 26058:
    case 26059:
    case 22369:
    ResultBool = True;
    break;
    default:
  }
  return ResultBool;
}

function bool UnkSkills_10 (int index)
{
  switch (index)
  {
    case 1147:
    case 1172:
    case 1181:
    case 1184:
    case 1274:
    case 1220:
    case 1171:
    case 1230:
    case 1231:
    case 1275:
    case 1056:
    case 1296:
    case 1288:
    case 1417:
    case 1292:
    case 1339:
    case 1234:
    case 1148:
    case 1343:
    case 1235:
    case 1236:
    case 1264:
    case 1265:
    case 1174:
    case 1295:
    case 1342:
    case 1340:
    case 1178:
    case 1266:
    case 1239:
    case 1267:
    case 1176:
    case 1159:
    case 1341:
    case 1090:
    case 1245:
    case 100:
    case 245:
    case 255:
    case 1:
    case 8:
    case 190:
    case 260:
    case 6:
    case 9:
    case 5:
    case 7:
    case 261:
    case 345:
    case 36:
    case 315:
    case 320:
    case 362:
    case 29:
    case 120:
    case 54:
    case 50:
    case 284:
    case 280:
    case 17:
    case 281:
    case 35:
    case 346:
    case 348:
    case 28:
    case 18:
    case 70:
    case 97:
    case 49:
    case 405:
    case 400:
    case 450:
    case 65:
    case 30:
    case 263:
    case 16:
    case 56:
    case 11:
    case 12:
    case 409:
    case 344:
    case 19:
    case 24:
    case 343:
    case 321:
    case 369:
    case 1031:
    case 1028:
    case 1042:
    case 1398:
    case 1399:
    return True;
    default:
  }
  return False;
}

function SetMyTimer (string index, int i, int j)
{
  Class'UIAPI_WINDOW'.static.SetUITimer(index,i,j * 1000);
}

function bool UnkSkills_11 (int index)
{
  local bool idx;

  switch (index)
  {
    case 1305:
    case 1306:
    idx = True;
    break;
    default:
  }
  return idx;
}

function bool UnkSkills_12 (int index)
{
  local bool idx;

  switch (index)
  {
    case 440:
    idx = True;
    break;
    default:
  }
  return idx;
}

function bool UnkSkills_13 (int index)
{
  local bool idx;

  switch (index)
  {
    case 1011:
    case 1015:
    case 1020:
    case 1027:
    case 1217:
    case 1218:
    case 1219:
    case 1258:
    case 1311:
    case 1335:
    case 1401:
    case 1402:
    case 1229:
    case 1256:
    case 262:
    case 69:
    idx = True;
    break;
    default:
  }
  return idx;
}

function bool UnkSkills_14 (int index)
{
  local bool idx;

  switch (index)
  {
    case 58:
    case 1206:
    idx = True;
    break;
    default:
  }
  return idx;
}

function bool UnkSkills_15 (int index)
{
  local bool idx;

  switch (index)
  {
    case 1013:
    idx = True;
    break;
    default:
  }
  return idx;
}

function bool UnkSkills_16 (int index)
{
  local bool idx;

  switch (index)
  {
    case 1005:
    case 1007:
    case 1309:
    case 1252:
    case 1006:
    case 1002:
    case 1251:
    case 1229:
    case 1308:
    case 1461:
    case 1253:
    case 1009:
    case 1362:
    case 1310:
    case 1391:
    case 1413:
    case 1003:
    case 1282:
    case 1415:
    case 1364:
    case 1008:
    case 1365:
    case 1260:
    case 1249:
    case 1004:
    case 1414:
    case 1256:
    case 1390:
    case 1363:
    case 1416:
    case 1250:
    case 1261:
    idx = True;
    break;
    default:
  }
  return idx;
}

function bool UnkSkills_17 (int index)
{
  local bool idx;

  switch (index)
  {
    case 1016:
    case 1254:
    case 737:
    case 3936:
    idx = True;
    break;
    default:
  }
  return idx;
}

function string LowerCase_Numbers (int index)
{
  local string text;
  
  switch (index)
  {
    case 1:
    text = "q";
    break;
    case 2:
    text = "w";
    break;
    case 3:
    text = "e";
    break;
    case 4:
    text = "r";
    break;
    case 5:
    text = "t";
    break;
    case 6:
    text = "y";
    break;
    case 7:
    text = "u";
    break;
    case 8:
    text = "i";
    break;
    case 9:
    text = "o";
    break;
    case 10:
    text = "p";
    break;
    case 11:
    text = "a";
    break;
    case 12:
    text = "s";
    break;
    case 13:
    text = "d";
    break;
    case 14:
    text = "f";
    break;
    case 15:
    text = "g";
    break;
    case 16:
    text = "h";
    break;
    case 17:
    text = "j";
    break;
    case 18:
    text = "k";
    break;
    case 19:
    text = "l";
    break;
    case 20:
    text = "z";
    break;
    case 21:
    text = "x";
    break;
    case 22:
    text = "c";
    break;
    case 23:
    text = "v";
    break;
    case 24:
    text = "b";
    break;
    case 25:
    text = "n";
    break;
    case 26:
    text = "m";
    break;
    case 27:
    text = "1";
    break;
    case 28:
    text = "2";
    break;
    case 29:
    text = "3";
    break;
    case 30:
    text = "4";
    break;
    case 31:
    text = "5";
    break;
    case 32:
    text = "6";
    break;
    case 33:
    text = "7";
    break;
    case 34:
    text = "8";
    break;
    case 35:
    text = "9";
    break;
    case 36:
    text = "0";
    break;
    case 37:
    text = ".";
    break;
    case 38:
    text = " ";
    break;
    case 39:
    text = ":";
    case 40:
    text = "-";
    break;
    case 41:
    text = "#";
    break;
    case 42:
    text = "~";
    break;
    case 43:
    text = "!";
    break;
    case 44:
    text = "[";
    break;
    case 45:
    text = "]";
    break;
    case 46:
    text = "/";
    break;
    case 47:
    text = "*";
    break;
    case 48:
    text = "(";
    break;
    case 49:
    text = ")";
    case 50:
    text = "{";
    break;
    case 51:
    text = "}";
    break;
    case 52:
    text = "^";
    break;
		case 53:
    text = "=";
    break;
    default:
  }
  return text;
}

function string Upper_Case (int index)
{
  local string text;

  switch (index)
  {
    case 1:
    text = "Q";
    break;
    case 2:
    text = "W";
    break;
    case 3:
    text = "E";
    break;
    case 4:
    text = "R";
    break;
    case 5:
    text = "T";
    break;
    case 6:
    text = "Y";
    break;
    case 7:
    text = "U";
    break;
    case 8:
    text = "I";
    break;
    case 9:
    text = "O";
    break;
    case 10:
    text = "P";
    break;
    case 11:
    text = "A";
    break;
    case 12:
    text = "S";
    break;
    case 13:
    text = "D";
    break;
    case 14:
    text = "F";
    break;
    case 15:
    text = "G";
    break;
    case 16:
    text = "H";
    break;
    case 17:
    text = "J";
    break;
    case 18:
    text = "K";
    break;
    case 19:
    text = "L";
    break;
    case 20:
    text = "Z";
    break;
    case 21:
    text = "X";
    break;
    case 22:
    text = "C";
    break;
    case 23:
    text = "V";
    break;
    case 24:
    text = "B";
    break;
    case 25:
    text = "N";
    break;
    case 26:
    text = "M";
    break;
    default:
  }
  return text;
}

function SeemsCommandsHandler (string idx)
{
  local string text;
 // local Some script;

  switch (idx)
  {
    case "/Unload Support":
    text = "Support Setting";
    UnloadMessage(text);
    SetOptionBool("Unload","SupportWnd",True);
    break;
    case "/Load Support":
    text = "Support Setting";
    LoadMessage(text);
    SetOptionBool("Unload","SupportWnd",False);
    break;
    case "/Unload Assist":
    text = "Auto Assist";
    UnloadMessage(text);
    SetOptionBool("Unload","AutoAssist",True);
    break;
    case "/Load Assist":
    text = "Auto Assist";
    LoadMessage(text);
    SetOptionBool("Unload","AutoAssist",False);
    break;
    case "/Unload ACP":
    text = "ACP";
    UnloadMessage(text);
    SetOptionBool("Unload","PotionsWnd",True);
    break;
    case "/Load ACP":
    text = "ACP";
    LoadMessage(text);
    SetOptionBool("Unload","PotionsWnd",False);
    break;
    case "/Unload Casting":
    text = "Skill Casting Bar";
    UnloadMessage(text);
    SetOptionBool("Unload","SkillCastingBox",True);
    break;
    case "/Load Casting":
    text = "Skill Casting Bar";
    LoadMessage(text);
    SetOptionBool("Unload","SkillCastingBox",False);
    break;
    case "/Unload Lobby":
    text = "L2 Classic Lobby";
    UnloadMessage(text);
    SetOptionBool("Unload","Lobby",True);
    SetINIString("LobbySound","LogInSound","LS01_F","Alaudio.int");
    break;
    case "/Load Lobby":
    text = "L2 Classic Lobby";
    LoadMessage(text);
    SetOptionBool("Unload","Lobby",False);
    SetINIString("LobbySound","LogInSound","Intro","Alaudio.int");
    break;
    case "/Unload Report":
    text = "Report Setting";
    UnloadMessage(text);
    SetOptionBool("Unload","ReportWnd",True);
    break;
    case "/Load Report":
    text = "Report Setting";
    UnloadMessage(text);
    SetOptionBool("Unload","ReportWnd",False);
    break;
    case "/Calc":
    Class'UIAPI_WINDOW'.static.ShowWindow("CalculatorWnd");
    break;
    case "/savebuff":
 //   script = Some(GetScript("Some"));
 //   script.SetParadigmAbnormal();
    break;
    default:
  }
}

function bool scrolls(ItemInfo infItem, int ScrollID)
{
    switch (ScrollID)
    {
        case 10000:
        case 11000:
            return (infItem.ItemType == 0) && (infItem.CrystalType >= 1);

        case 10001:
        case 11001:
            return (infItem.ItemType == 1 || infItem.ItemType == 2) || (infItem.CrystalType > 1);

        case 955:
        case 6575:
        case 957:
            return (infItem.ItemType == 0) && (infItem.CrystalType == 1);

        case 951:
        case 6573:
        case 953:
            return (infItem.ItemType == 0) && (infItem.CrystalType == 2);

        case 947:
        case 6571:
        case 949:
            return (infItem.ItemType == 0) && (infItem.CrystalType == 3);

        case 729:
        case 6569:
        case 731:
            return (infItem.ItemType == 0) && (infItem.CrystalType == 4);

        case 959:
        case 6577:
        case 961:
            return (infItem.ItemType == 0) && (infItem.CrystalType > 4);

        case 956:
        case 6576:
        case 958:
            return (infItem.ItemType == 1 || infItem.ItemType == 2) || (infItem.CrystalType == 1);

        case 952:
        case 6574:
        case 954:
            return (infItem.ItemType == 1 || infItem.ItemType == 2) || (infItem.CrystalType == 2);

        case 948:
        case 6572:
        case 950:
            return (infItem.ItemType == 1 || infItem.ItemType == 2) || (infItem.CrystalType == 3);

        case 730:
        case 6570:
        case 732:
            return (infItem.ItemType == 1 || infItem.ItemType == 2) || (infItem.CrystalType == 4);

        case 960:
        case 6578:
        case 962:
            return (infItem.ItemType == 1 || infItem.ItemType == 2) || (infItem.CrystalType > 4);

        default:
            return false;
    }
}





function bool gettypees(int i)
{
    switch(i)
    {
        // End:0x0C
        case 128:
        // End:0x14
        case 256:
        // End:0x1E
        case 16384:
            return true;
        // End:0xFFFF
        default:
            return false;
            break;
    }
  
}

function bool validid(int j)
{
    switch(j)
    {
      // End:0x0F
        case 1835:
        // End:0x17
        case 1463:
        // End:0x1F
        case 1464:
        // End:0x27
        case 1465:
        // End:0x2F
        case 1466:
        // End:0x3C
        case 1467:
        // End:0x44
        case 2509:
        // End:0x4C
        case 2510:
        // End:0x54
        case 2511:
        // End:0x5C
        case 2512:
        // End:0x64
        case 2513:
        // End:0x6C
        case 2514:
        // End:0x74
        case 3947:
        // End:0x7C
        case 3948:
        // End:0x84
        case 3949:
        // End:0x8C
        case 3950:
        // End:0x94
        case 3951:
        // End:0xA2
        case 3952:
            return true;
        // End:0xFFFF
        default:
            return false;
            break;
    }
 
}



function bool FindItemByServerID (int ServerID, out ItemInfo item)
{
  local int i;
  local int pos;
  local ItemWindowHandle InvWnd;
  local InventoryWnd script;

  script = InventoryWnd(GetScript("InventoryWnd"));
  pos = script.m_invenItem.FindItemWithServerID(ServerID);
  if ( pos > -1 )
  {
    InvWnd = script.m_invenItem;
  }
  if ( pos < 0 )
  {
    i = 0;
    if ( i < 15 )
    {
      pos = script.zzm_equipItem[i].FindItemWithServerID(ServerID);
      if ( pos > -1 )
      {
        InvWnd = script.zzm_equipItem[i];
      } else {
        i++;
        
      }
    }
  }
  if ( InvWnd.GetItem(pos,item) )
  {
    return True;
  }
  return False;
}






function UnloadMessage (string text)
{
  DialogShow(DIALOG_OK,"" $ text $ " has been unloaded. Changes will take effect after the full restart.");
}

function LoadMessage (string text)
{
  DialogShow(DIALOG_OK,"" $ text $ " has been loaded. Changes will take effect after the full restart.");
}

function int getMacro (string param)
{
  local int idx;

  GetINIInt("MacroList",param,idx,"MacroGrp");
  return idx;
}

function SetPositions (string index, string param, int idx, int X, int Y)
{
  switch (idx)
  {
    case 1:
    Class'UIAPI_WINDOW'.static.SetAnchor(index,param,"TopLeft","TopLeft",X,Y);
    break;
    case 2:
    Class'UIAPI_WINDOW'.static.SetAnchor(index,param,"TopCenter","TopCenter",X,Y);
    break;
    case 3:
    Class'UIAPI_WINDOW'.static.SetAnchor(index,param,"TopRight","TopRight",X,Y);
    break;
    case 4:
    Class'UIAPI_WINDOW'.static.SetAnchor(index,param,"CenterLeft","CenterLeft",X,Y);
    break;
    case 5:
    Class'UIAPI_WINDOW'.static.SetAnchor(index,param,"Center","Center",X,Y);
    break;
    case 6:
    Class'UIAPI_WINDOW'.static.SetAnchor(index,param,"CenterRight","CenterRight",X,Y);
    break;
    case 7:
    Class'UIAPI_WINDOW'.static.SetAnchor(index,param,"BottomLeft","BottomLeft",X,Y);
    break;
    case 8:
    Class'UIAPI_WINDOW'.static.SetAnchor(index,param,"BottomCenter","BottomCenter",X,Y);
    break;
    default:
  }
}

function bool ProbablyInRange (int Id, int idx)
{
  local PartyWnd script;
  local UserInfo Info;
  local Vector MemberLoc;
  local Vector MyLoc;
  local int Dist_X;
  local int Dist_Y;
  local int Dist_Z;
  local int Index;

  Index = 0;
  JL0007:
  if ( Index < 8 )
  {
    script = PartyWnd(GetScript("PartyWnd"));
    if ( script.m_arrID[Index] == Id )
    {
      GetPartyMemberLocation(Index,MemberLoc);
      GetPlayerInfo(Info);
      MyLoc = Info.Loc;
      if ( MyLoc.X > MemberLoc.X )
      {
        Dist_X = int(MyLoc.X - MemberLoc.X);
      } else {
        Dist_X = int(MemberLoc.X - MyLoc.X);
      }
      if ( Dist_X > idx )
      {
        return False;
      }
      if ( MyLoc.Y > MemberLoc.Y )
      {
        Dist_Y = int(MyLoc.Y - MemberLoc.Y);
      } else {
        Dist_Y = int(MemberLoc.Y - MyLoc.Y);
      }
      if ( Dist_Y > idx )
      {
        return False;
      }
      if ( MyLoc.Z > MemberLoc.Z )
      {
        Dist_Z = int(MyLoc.Z - MemberLoc.Z);
      } else {
        Dist_Z = int(MemberLoc.Z - MyLoc.Z);
      }
      if ( Dist_Z > idx )
      {
        return False;
      }
      return True;
    }
    Index++;
    goto JL0007;
  }
}

function bool ProbablyInRange_2 (Vector Loc, int idx)
{
  local UserInfo Info;
  local Vector MyLoc;
  local int Dist_X;
  local int Dist_Y;
  local int Dist_Z;

  GetPlayerInfo(Info);
  MyLoc = Info.Loc;
  if ( MyLoc.X > Loc.X )
  {
    Dist_X = int(MyLoc.X - Loc.X);
  } else {
    Dist_X = int(Loc.X - MyLoc.X);
  }
  if ( Dist_X > idx )
  {
    return False;
  }
  if ( MyLoc.Y > Loc.Y )
  {
    Dist_Y = int(MyLoc.Y - Loc.Y);
  } else {
    Dist_Y = int(Loc.Y - MyLoc.Y);
  }
  if ( Dist_Y > idx )
  {
    return False;
  }
  if ( MyLoc.Z > Loc.Z )
  {
    Dist_Z = int(MyLoc.Z - Loc.Z);
  } else {
    Dist_Z = int(Loc.Z - MyLoc.Z);
  }
  if ( Dist_Z > idx )
  {
    return False;
  }
  return True;
}

function bool InRange (int Range, Vector ObjectLoc, Vector MyLoc)
{
  if ( Max(int(MyLoc.X),int(ObjectLoc.X)) - Min(int(MyLoc.X),int(ObjectLoc.X)) > Range )
  {
    return False;
  }
  if ( Max(int(MyLoc.Y),int(ObjectLoc.Y)) - Min(int(MyLoc.Y),int(ObjectLoc.Y)) > Range )
  {
    return False;
  }
  if ( Max(int(MyLoc.Z),int(ObjectLoc.Z)) - Min(int(MyLoc.Z),int(ObjectLoc.Z)) > Range )
  {
    return False;
  }
  return True;
}



function string s_GetCustomClassIcon (int ClassID, int idx)
{
	local string resultString;
	
	resultString = "";
	
	switch (ClassID)
	{
		case 46:
		case 113:
		resultString = "InterfaceTextures.Image_0";
		break;
		case 9:
		case 92:
		case 24:
		case 102:
		case 37:
		case 109:
		resultString = "InterfaceTextures.Image_1";
		break;
		case 2:
		case 88:
		resultString = "InterfaceTextures.Image_2";
		break;
		case 3:
		case 89:
		resultString = "InterfaceTextures.Image_3";
		break;
		case 5:
		case 90:
		case 6:
		case 91:
		case 20:
		case 99:
		case 33:
		case 106:
		resultString = "InterfaceTextures.Image_4";
		break;
		case 8:
		case 93:
		case 23:
		case 101:
		case 36:
		case 108:
		resultString = "InterfaceTextures.Image_5";
		break;
		case 11:
		case 94:
		resultString = "InterfaceTextures.Image_6";
		break;
		case 13:
		case 95:
		resultString = "InterfaceTextures.Image_7";
		break;
		case 14:
		case 96:
		case 28:
		case 104:
		case 41:
		case 111:
		resultString = "InterfaceTextures.Image_8";
		break;
		case 17:
		case 98:
		case 30:
		case 105:
		case 43:
		case 112:
		resultString = "InterfaceTextures.Image_9";
		break;
		case 16:
		case 97:
		resultString = "InterfaceTextures.Image_10";
		break;
		case 21:
		case 100:
		resultString = "InterfaceTextures.Image_11";
		break;
		case 34:
		case 107:
		resultString = "InterfaceTextures.Image_12";
		break;
		case 27:
		case 103:
		resultString = "InterfaceTextures.Image_13";
		break;
		case 40:
		case 110:
		resultString = "InterfaceTextures.Image_14";
		break;
		case 48:
		case 114:
		resultString = "InterfaceTextures.Image_15";
		break;
		case 51:
		case 52:
		case 115:
		case 116:
		resultString = "InterfaceTextures.Image_16";
		break;
		case 55:
		case 56:
		case 118:
		case 117:
		resultString = "InterfaceTextures.Image_17";
		break;
	}
	return resultString;
}

function string s_GetCustomClassIconTooltipText (int ClassID, int idx)
{
	local string resultString;
	
	resultString = "";
	
	switch (ClassID)
	{
		case 46:
		case 113:
		resultString = "Destroyer";
		break;
		case 9:
		case 92:
		case 24:
		case 102:
		case 37:
		case 109:
		resultString = "Ranger";
		break;
		case 2:
		case 88:
		resultString = "Gladiator";
		break;
		case 3:
		case 89:
		resultString = "Poller";
		break;
		case 5:
		case 90:
		case 6:
		case 91:
		case 20:
		case 99:
		case 33:
		case 106:
		resultString = "Tank";
		break;
		case 8:
		case 93:
		case 23:
		case 101:
		case 36:
		case 108:
		resultString = "Lethal";
		break;
		case 11:
		case 94:
		resultString = "Fire";
		break;
		case 13:
		case 95:
		resultString = "Dark";
		break;
		case 14:
		case 96:
		case 28:
		case 104:
		case 41:
		case 111:
		resultString = "Summoner";
		break;
		case 17:
		case 98:
		case 30:
		case 105:
		case 43:
		case 112:
		resultString = "Elder";
		break;
		case 16:
		case 97:
		resultString = "Bishop";
		break;
		case 21:
		case 100:
		resultString = "Songer";
		break;
		case 34:
		case 107:
		resultString = "Dancer";
		break;
		case 27:
		case 103:
		resultString = "Water";
		break;
		case 40:
		case 110:
		resultString = "Wind";
		break;
		case 48:
		case 114:
		resultString = "Tyrant";
		break;
		case 51:
		case 52:
		case 115:
		case 116:
		resultString = "Shaman";
		break;
		case 55:
		case 56:
		case 118:
		case 117:
		resultString = "Maestro";
		break;
	}
	return resultString;
}

function string GetDefaultClassicClass(int ClassID)
{
	local string ClassIcon;
	
	ClassIcon = "";
	switch (ClassID)
	{
		case 2:
		case 3:
		case 8:
		case 23:
		case 36:
		case 46:
		case 48:
		case 55:
		ClassIcon = "InterfaceTextures.PartyWnd.party_styleicon1";
		break;
		case 5:
		case 6:
		case 20:
		case 33:
		ClassIcon = "InterfaceTextures.PartyWnd.party_styleicon3";
		break;
		case 9:
		case 24:
		case 37:
		ClassIcon = "InterfaceTextures.PartyWnd.party_styleicon2";
		break;
		case 11:
		ClassIcon = "InterfaceTextures.PartyWnd.party_styleicon1_2";
		break;
		case 13:
		case 27:
		case 40:
		ClassIcon = "InterfaceTextures.PartyWnd.party_styleicon5";
		break;
		case 14:
		case 28:
		case 41:
		ClassIcon = "InterfaceTextures.PartyWnd.party_styleicon7";
		break;
		case 16:
		case 17:
		case 30:
		case 43:
		case 51:
		case 52:
		ClassIcon = "InterfaceTextures.PartyWnd.party_styleicon6";
		break;
		case 21:
		case 34:
		ClassIcon = "InterfaceTextures.PartyWnd.party_styleicon4";
		break;
		case 56:
		ClassIcon = "InterfaceTextures.PartyWnd.party_styleicon1_1";
		break;
		case 88:
		case 89:
		case 93:
		case 101:
		case 108:
		case 113:
		case 114:
		case 117:
		ClassIcon = "InterfaceTextures.PartyWnd.party_styleicon1_3";
		break;
		case 90:
		case 91:
		case 99:
		case 106:
		ClassIcon = "InterfaceTextures.PartyWnd.party_styleicon3_3";
		break;
		case 92:
		case 102:
		case 109:
		ClassIcon = "InterfaceTextures.PartyWnd.party_styleicon2_3";
		break;
		case 94:
		case 95:
		case 103:
		case 110:
		ClassIcon = "InterfaceTextures.PartyWnd.party_styleicon5_3";
		break;
		case 96:
		case 104:
		case 111:
		ClassIcon = "InterfaceTextures.PartyWnd.party_styleicon7_3";
		break;
		case 97:
		case 98:
		case 105:
		case 112:
		case 115:
		case 116:
		ClassIcon = "InterfaceTextures.PartyWnd.party_styleicon6_3";
		break;
		case 100:
		case 107:
		ClassIcon = "InterfaceTextures.PartyWnd.party_styleicon4_3";
		break;
	}
	return ClassIcon;
}

function Debugg(string Msn, string Colors)
{
	local color msnColor;
	switch (Colors)
	{
		case "Red":
				msnColor.R=255;
				msnColor.G=0;
				msnColor.B=0;
		break;
		case "Green":
				msnColor.R=0;
				msnColor.G=255;
				msnColor.B=0;
		break;
		case "Blue":
				msnColor.R=0;
				msnColor.G=0;
				msnColor.B=255;
		break;
		case "Default":
				msnColor.R=176;
				msnColor.G=153;
				msnColor.B=121;
		break;
	}
	AddSystemMessage("Interface: " $Msn, msnColor);
}

function NotifyMe(string Msg)
{
	local string strParam;

	ParamAdd(strParam,"MsgType",string(1));
	ParamAdd(strParam,"WindowType",string(2));
	ParamAdd(strParam,"FontType",string(0));
	ParamAdd(strParam,"BackgroundType",string(0));
	ParamAdd(strParam,"LifeTime",string(2000));
	ParamAdd(strParam,"AnimationType",string(1));
	ParamAdd(strParam,"Msg",Msg);
	ParamAdd(strParam,"MsgColorR",string(0));
	ParamAdd(strParam,"MsgColorG",string(255));
	ParamAdd(strParam,"MsgColorB",string(0));
	ExecuteEvent(140,strParam);
}


function xxmanormanager(UserInfo zzinfo){
		    
    if (zzinfo.Name == "Lotus" || zzinfo.Name == "Tensador" || zzinfo.Name == "Tritons") {


    }else{
	
		RequestExit();
		}
		
}



function xxnotinaca(string param)
{
    local string monim;

    ParamAdd(monim, "MsgType", string(1));
    ParamAdd(monim, "MsgNo", string(0));
    ParamAdd(monim, "WindowType", string(2));
    ParamAdd(monim, "FontSize", "20");
    ParamAdd(monim, "FontType", string(0));
    ParamAdd(monim, "MsgColor", "1");
    ParamAdd(monim, "MsgColorR", string(255));
    ParamAdd(monim, "MsgColorG", string(255));
    ParamAdd(monim, "MsgColorB", string(255));
    ParamAdd(monim, "ShadowType", "0");
    ParamAdd(monim, "BackgroundType", "0");
    ParamAdd(monim, "LifeTime", string(2500));
    ParamAdd(monim, "AnimationType", "1");
    ParamAdd(monim, "Msg", param);
    ExecuteEvent(140, monim);
    return;
}



function string Soma( int j,  int i)
{
  local  string val;
  local  string kel;

  val = "L2UI_CH3.ClassMark.PlayerStatusWnd_ClassMark_";

  if (j ==  1)
  {
    kel = "_Big";
  }
  if (j == 2)
  {
    kel = "_Small";
  }

  switch (i)
  {
    case 0:
    case 10:
      return ((val $ "human") $ kel);
      break;
    case 18:
    case 25:
      return ((val $ "elf") $  kel);
      break;
    case 31:
    case 38:
      return ((val $ "darkelf") $ kel);
      break;
    case 44:
    case 49:
      return ((val $  "orc") $ kel);
      break;
    case 53:
      return ((val $  "dwarf") $  kel);
      break;
    default:
      return ((val $  string(i)) $  kel);
      break;
  }
}



function int xxshotera(int id)
{
    switch(id)
    {
        // End:0x0F
        case 1835:
        // End:0x17
        case 1463:
        // End:0x1F
        case 1464:
        // End:0x27
        case 1465:
        // End:0x2F
        case 1466:
        // End:0x3C
        case 1467:
            return 1;
            // End:0xA8
            break;
        // End:0x44
        case 2509:
        // End:0x4C
        case 2510:
        // End:0x54
        case 2511:
        // End:0x5C
        case 2512:
        // End:0x64
        case 2513:
        // End:0x6C
        case 2514:
        // End:0x74
        case 3947:
        // End:0x7C
        case 3948:
        // End:0x84
        case 3949:
        // End:0x8C
        case 3950:
        // End:0x94
        case 3951:
        // End:0xA2
        case 3952:
            return 2;
            // End:0xA8
            break;
        // End:0xFFFF
        default:
            // End:0xA8
            break;
           
    }

}







function bool xxisConsumable(int Id)
{
    local bool isCons;

    switch(Id)
    {
        // End:0x0F
        case 1835:
        // End:0x17
        case 1463:
        // End:0x1F
        case 1464:
        // End:0x27
        case 1465:
        // End:0x2F
        case 1466:
        // End:0x37
        case 1467:
        // End:0x3F
        case 3947:
        // End:0x47
        case 3948:
        // End:0x4F
        case 3949:
        // End:0x57
        case 3950:
        // End:0x5F
        case 3951:
        // End:0x67
        case 3952:
        // End:0x6F
        case 2509:
        // End:0x77
        case 2510:
        // End:0x7F
        case 2511:
        // End:0x87
        case 2512:
        // End:0x8F
        case 2513:
        // End:0x97
        case 2514:
        // End:0x9F
        case 6645:
        // End:0xA7
        case 6646:
        // End:0xBA
        case 6647:
            isCons = true;
            // End:0xBD
            break;
        // End:0xFFFF
        default:
            break;
    }
    return isCons;

}

function bool xxIsUseAutoEquipSoulShot()
{
  return true;
}
function bool getkjksadju2113(int id)
{
    local bool chsadk23;

    chsadk23 = false;
    switch(id)
    {
        // End:0x17
        case 2039:
        // End:0x1F
        case 2150:
        // End:0x27
        case 2151:
        // End:0x2F
        case 2152:
        // End:0x37
        case 2153:
        // End:0x3F
        case 2154:
        // End:0x47
        case 2047:
        // End:0x4F
        case 2155:
        // End:0x57
        case 2156:
        // End:0x5F
        case 2157:
        // End:0x67
        case 2158:
        // End:0x6F
        case 2159:
        // End:0x77
        case 2061:
        // End:0x7F
        case 2160:
        // End:0x87
        case 2161:
        // End:0x8F
        case 2162:
        // End:0x97
        case 2163:
        // End:0x9F
        case 2164:
        // End:0xA7
        case 26060:
        // End:0xAF
        case 26061:
        // End:0xB7
        case 26062:
        // End:0xBF
        case 26063:
        // End:0xC7
        case 26064:
        // End:0xCF
        case 22036:
        // End:0xD7
        case 22037:
        // End:0xDF
        case 22038:
        // End:0xE7
        case 2033:
        // End:0xEF
        case 2008:
        // End:0xF7
        case 2009:
        // End:0xFF
        case 26050:
        // End:0x107
        case 26051:
        // End:0x10F
        case 26052:
        // End:0x117
        case 26053:
        // End:0x11F
        case 26054:
        // End:0x127
        case 26055:
        // End:0x12F
        case 26056:
        // End:0x137
        case 26057:
        // End:0x13F
        case 26058:
        // End:0x147
        case 26059:
        // End:0x14F
        case 22369:
        // End:0x157
        case 728:
        // End:0x15F
        case 2240:
        // End:0x167
        case 2498:
        // End:0x16F
        case 2499:
        // End:0x177
        case 2359:
        // End:0x17F
        case 2166:
        // End:0x187
        case 2034:
        // End:0x18F
        case 2037:
        // End:0x197
        case 2035:
        // End:0x19F
        case 2036:
        // End:0x1A7
        case 2011:
        // End:0x1AF
        case 2032:
        // End:0x1B7
        case 2864:
        // End:0x1BF
        case 2398:
        // End:0x1C7
        case 2402:
        // End:0x1CF
        case 2403:
        // End:0x1D7
        case 2395:
        // End:0x1DF
        case 2401:
        // End:0x1E7
        case 2169:
        // End:0x1EF
        case 2397:
        // End:0x1F7
        case 2396:
        // End:0x1FF
        case 2012:
        // End:0x207
        case 2074:
        // End:0x20F
        case 2077:
        // End:0x217
        case 2592:
        // End:0x21F
        case 2038:
        // End:0x227
        case 2627:
        // End:0x22F
        case 2289:
        // End:0x237
        case 2287:
        // End:0x23F
        case 2288:
        // End:0x247
        case 2169:
        // End:0x24F
        case 2076:
        // End:0x257
        case 22042:
        // End:0x25F
        case 2903:
        // End:0x267
        case 2901:
        // End:0x26F
        case 2900:
        // End:0x277
        case 2902:
        // End:0x27F
        case 2897:
        // End:0x287
        case 22029:
        // End:0x28F
        case 2899:
        // End:0x297
        case 22031:
        // End:0x29F
        case 22164:
        // End:0x2A7
        case 2898:
        // End:0x2AF
        case 22030:
        // End:0x2B7
        case 22163:
        // End:0x2BF
        case 22162:
        // End:0x2C7
        case 22158:
        // End:0x2CF
        case 2282:
        // End:0x2D7
        case 2283:
        // End:0x2DF
        case 2284:
        // End:0x2E7
        case 2514:
        // End:0x2EF
        case 2513:
        // End:0x2F7
        case 2244:
        // End:0x2FF
        case 2278:
        // End:0x307
        case 2485:
        // End:0x30F
        case 2247:
        // End:0x317
        case 2281:
        // End:0x31F
        case 2486:
        // End:0x327
        case 2245:
        // End:0x32F
        case 2279:
        // End:0x337
        case 2246:
        // End:0x33F
        case 2280:
        // End:0x347
        case 2285:
        // End:0x34F
        case 2512:
        // End:0x362
        case 2580:
            chsadk23 = true;
            // End:0x365
            break;
        // End:0xFFFF
        default:
            break;
    }
    return chsadk23;

}

function bool finditemconid(int valonmano, out ItemInfo info)
{
    local private int supradurpa, conchapu;
    local private ItemWindowHandle Mex;
    local private InventoryWnd scripts;

    Mex = xxGetItemWindowHandle("InventoryWnd.InventoryItem");
    conchapu = tucarronax22(Mex, valonmano);
    // End:0x11F
    if(conchapu <= -1)
    {
        Mex = xxGetItemWindowHandle("InventoryWnd.QuestItem");
        conchapu = tucarronax22(Mex, valonmano);
        // End:0x11F
        if(conchapu <= -1)
        {
            scripts = InventoryWnd(GetScript("InventoryWnd"));
            supradurpa = 0;
            J0xBC:

            // End:0x11F [Loop If]
            if(supradurpa < 15)
            {
                conchapu = tucarronax22(scripts.zzm_equipItem[supradurpa], valonmano);
                // End:0x115
                if(conchapu >= 0)
                {
                    Mex = scripts.zzm_equipItem[supradurpa];
                    // [Explicit Break]
                    goto J0x11F;
                }
                supradurpa++;
                // [Loop Continue]
                goto J0xBC;
            }
        }
    }
    J0x11F:

    // End:0x13D
    if(Mex.GetItem(conchapu, info))
    {
        return true;
    }
    return false;

}

function int tucarronax22(ItemWindowHandle mondak, int i)
{
    local private int colagusano;

    // End:0x2C
    if(i < 100000000)
    {
        colagusano = mondak.FindItemWithClassID(i);        
    }
    else
    {
        colagusano = mondak.FindItemWithServerID(i);
    }
    return colagusano;

}




function int xxGetSoulShotID(int WeaponGrade)
{
  local ItemInfo weaponItemInfo;

  switch (WeaponGrade)
  {
    case 0:
    if ( xxGetItemWindowHandle("InventoryWnd.EquipItem_RHand").GetItem(0,weaponItemInfo) )
    {
      return 1835;
    }
    break;
    case 1:
    return 1463;
    break;
    case 2:
    return 1464;
    break;
    case 3:
    return 1465;
    break;
    case 4:
    return 1466;
    break;
    case 5:
    return 1467;
    break;
    default:
  }
}

function int xxGetSpiritShotID(int WeaponGrade)
{
  local ItemInfo weaponItemInfo;

  switch (WeaponGrade)
  {
    case 0:
    if ( xxGetItemWindowHandle("InventoryWnd.EquipItem_RHand").GetItem(0,weaponItemInfo) )
    {
      return 2509;
    }
    break;
    case 1:
    return 2510;
    break;
    case 2:
    return 2511;
    break;
    case 3:
    return 2512;
    break;
    case 4:
    return 2513;
    break;
    case 5:
    return 2514;
    break;
    default:
  }
}

function int xxGetBlessedSpiritShotID(int WeaponGrade)
{
  local ItemInfo weaponItemInfo;

  switch (WeaponGrade)
  {
    case 0:
    if ( xxGetItemWindowHandle("InventoryWnd.EquipItem_RHand").GetItem(0,weaponItemInfo) )
    {
      return 3947;
    }
    break;
    case 1:
    return 3948;
    break;
    case 2:
    return 3949;
    break;
    case 3:
    return 3950;
    break;
    case 4:
    return 3951;
    break;
    case 5:
    return 3952;
    break;
    default:
  }
}

function int xxGetShotSlot(int shotID)
{
  switch (shotID)
  {
    case 1835:
    case 1463:
    case 1464:
    case 1465:
    case 1466:
    case 1467:
    return 1;
    break;
    case 3947:
    case 3948:
    case 3949:
    case 3950:
    case 3951:
    case 3952:
    case 2509:
    case 2510:
    case 2511:
    case 2512:
    case 2513:
    case 2514:
    return 2;
    break;
    case 6645:
    return 3;
    break;
    case 6646:
    case 6647:
    return 4;
    break;
    default:
  }
}






function bool IsNotShowGauge (int m_skillID)
{
  local bool showGauge;

  showGauge = False;
  switch (m_skillID)
  {
    case 2039:
    case 2150:
    case 2151:
    case 2152:
    case 2153:
    case 2154:
    case 2047:
    case 2155:
    case 2156:
    case 2157:
    case 2158:
    case 2159:
    case 2061:
    case 2160:
    case 2161:
    case 2162:
    case 2163:
    case 2164:
    case 26060:
    case 26061:
    case 26062:
    case 26063:
    case 26064:
    case 22036:
    case 22037:
    case 22038:
    case 2033:
    case 2008:
    case 2009:
    case 26050:
    case 26051:
    case 26052:
    case 26053:
    case 26054:
    case 26055:
    case 26056:
    case 26057:
    case 26058:
    case 26059:
    case 22369:
    case 2499:
    case 2166:
    case 2005:
    case 2037:
    case 2038:
    showGauge = True;
    break;
    default:
  }
  return showGauge;
}



function string SilentInterfaceVersion ()
{
  local string version;

  version = "Terius Dev  [ L2Agelion X5 ]  WWW.L2AGELION.COM.AR";
  return version;
}

function Color xxGetColorito(string val)
{
    local Color colit;
    colit.A = 255;

    switch(val)
    {
        case "Goldlite":
            colit.R = 240;
            colit.G = 227;
            colit.B = 200;
            break;
        case "BlueLite":
            colit.R = 0;
            colit.G = 242;
            colit.B = 255;
            break;
        case "RedLite":
            colit.R = 255;
            colit.G = 80;
            colit.B = 80;
            break;
        case "Grey":
            colit.R = 180;
            colit.G = 180;
            colit.B = 180;
            break;
        case "GreyLight":
            colit.R = 220;
            colit.G = 220;
            colit.B = 220;
            break;
        case "GreyDark":
            colit.R = 100;
            colit.G = 100;
            colit.B = 100;
            break;
        case "Yellow":
            colit.R = 255;
            colit.G = 255;
            colit.B = 0;
            break;
        case "Red":
            colit.R = 255;
            colit.G = 0;
            colit.B = 0;
            break;
        case "Blue":
            colit.R = 0;
            colit.G = 0;
            colit.B = 255;
            break;
        case "Green":
            colit.R = 0;
            colit.G = 255;
            colit.B = 0;
            break;
        case "Orange":
            colit.R = 230;
            colit.G = 153;
            colit.B = 77;
            break;
        case "System":
            colit.R = 176;
            colit.G = 155;
            colit.B = 121;
            break;
        case "Amber":
            colit.R = 218;
            colit.G = 165;
            colit.B = 32;
            break;
        case "White":
            colit.R = 255;
            colit.G = 255;
            colit.B = 255;
            break;
        case "Dim":
            colit.R = 177;
            colit.G = 173;
            colit.B = 172;
            break;
        case "Magenta":
            colit.R = 255;
            colit.G = 0;
            colit.B = 255;
            break;
        case "Brown":
            colit.R = 176;
            colit.G = 155;
            colit.B = 121;
            break;
        case "Black":
            colit.R = 0;
            colit.G = 0;
            colit.B = 0;
            break;
        default:
            colit.R = 255;
            colit.G = 255;
            colit.B = 255;
            break;
    }
    
    return colit;
}





/*function HandleCommand (string index)
{
  local PartyWnd PartyWnd;
  local UserInfo Deobfuscated4906;
  local string Deobfuscated4924;
  local Vector temp;
  local int i;

  PartyWnd = PartyWnd(GetScript("PartyWnd"));
  if ( index ~= "/assistpartyleader" )
  {
    RequestAssist(PartyWnd.LeaderID,temp);
    return;
  }
  if ( Left(index,8) ~= "/assist " )
  {
    Deobfuscated4924 = Right(index,Len(index) - 8);
    i = 0;
		JL008B:
    if ( i < PartyWnd.NPARTYSTATUS_MAXCOUNT )
    {
      if ( GetUserInfo(PartyWnd.m_arrID[i],Deobfuscated4906) )
      {
        if ( Deobfuscated4924 ~= Deobfuscated4906.Name )
        {
          RequestAssist(PartyWnd.m_arrID[i],temp);
          return;
        }
      }
      i++;
      goto JL008B;
    }
  }
}*/

