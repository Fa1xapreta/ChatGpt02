//================================================================================
// TeleportLoadingWnd.
//================================================================================

class TeleportLoadingWnd extends UICommonAPI;

var WindowHandle zzMe;
var TextureHandle t_BG;
const DELAY_FADE= 3000;
const DELAY_HIDE= 200;
const TIMER_HIDE= 8001;
const TIMER_FADE= 8000;
const H_SIZE= 1080;
const W_SIZE= 1920;

function OnLoad ()
{

  RegisterEvent(2900);
  RegisterEvent(99981);
  zzMe = GetHandle("TeleportLoadingWnd");
 // t_BG = TextureHandle(GetHandle("TeleportLoadingWnd.ReviewTex"));
  CheckResolution();
  zzMe.SetAlpha(0);
}

function OnEvent (int zzEventID, string zza_Param)
{

  switch (zzEventID)
  {
    case 99981:
    HandleShowLoading(zza_Param);           
    break;
    case 2900:
    CheckResolution();
    break;
    default:
  }
}

function OnTimer (int zzTimerID)
{
  switch (zzTimerID)
  {
    case 8000:
    zzMe.KillTimer(8000);
    zzMe.SetAlpha(0,0.2);
    zzMe.SetTimer(8001,200);
    break;
    case 8001:
    zzMe.KillTimer(8001);
    zzMe.HideWindow();
    break;
    default:
  }
}

function HandleShowLoading(string zza_Param)
{
  local string zzt_TextureBG;

  ParseString(zza_Param,"texture",zzt_TextureBG);
  zzMe.SetAlpha(255,0.2);
  zzMe.ShowWindow();
  zzMe.SetFocus();
  zzMe.SetTimer(8000,3000);
  
}



function CheckResolution ()
{
  local int zzCurrentMaxWidth;
  local int zzCurrentMaxHeight;

  GetCurrentResolution(zzCurrentMaxWidth,zzCurrentMaxHeight);
  SetTextureSize(zzCurrentMaxWidth,zzCurrentMaxHeight);
}

function SetTextureSize (int zztextureWidth, int zztextureHeight)
{
  local float zzscreenAspectRatio;
  local float zzvideoAspectRatio;
  local int zzCurrentMaxWidth;
  local int zzCurrentMaxHeight;

  GetCurrentResolution(zzCurrentMaxWidth,zzCurrentMaxHeight);
  t_BG.SetAnchor("TeleportLoadingWnd","CenterCenter","CenterCenter",0,0);
  zzscreenAspectRatio = (zzCurrentMaxWidth / zzCurrentMaxHeight);
  zzvideoAspectRatio = (1920 / 1080);
if (GetAbs(zzvideoAspectRatio - zzscreenAspectRatio) > 0)
  {
    if ( zzscreenAspectRatio > zzvideoAspectRatio )
    {
      zztextureWidth = zzCurrentMaxWidth;
      zztextureHeight = int((zztextureWidth / zzvideoAspectRatio));
    } else {
      zztextureHeight = zzCurrentMaxHeight;
      zztextureWidth = int((zztextureHeight * zzvideoAspectRatio));
    }
  } else {
    zztextureWidth = zzCurrentMaxWidth;
    zztextureHeight = zzCurrentMaxHeight;
  }
  t_BG.SetWindowSize(zztextureWidth,zztextureHeight);
}

function float GetAbs(float zzNum)
{
    if (zzNum < 0)
    {
        return -zzNum;
    }
    return zzNum;
}

