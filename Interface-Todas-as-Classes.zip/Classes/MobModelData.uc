class MobModelData extends Object;
struct ModelEntry { var int NPCID; var string MeshPath; var string SkinPaths; var float Radius; var float Height; };
var array<ModelEntry> Models;
static function bool Lookup(int npcID,out string meshPath,out string skinPaths,out float radius,out float height) { local int lo,hi,mid; hi=default.Models.Length-1; while(lo<=hi) { mid=(lo+hi)/2; if(default.Models[mid].NPCID==npcID) { meshPath=default.Models[mid].MeshPath;skinPaths=default.Models[mid].SkinPaths;radius=default.Models[mid].Radius;height=default.Models[mid].Height;return true;} if(default.Models[mid].NPCID<npcID)lo=mid+1;else hi=mid-1;}return false;}
