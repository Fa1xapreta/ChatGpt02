class PCCafeEventWnd extends UICommonAPI;

var string BuffWndCategoryData[6];
var string BuffWndPresetData[6];

var int BuffWndCategoryNext[6];
var int BuffWndPresetNext[6];

var int zzm_TotalPoint;
var int zzm_AddPoint;
var int zzm_PeriodType;
var int zzm_RemainTime;
var int zzm_PointType;
var int CommonSkullCount;
var int CommonSkullTicks;
var bool CommonSkullActive;

var ExpBarWnd zzbarscript;
var WindowHandle zzHelpButton;
var KillLogWnd zzKillLog;

function OnLoad()
{
    RegisterEvent(EV_PCCafePointInfo);
    RegisterEvent(140);

    zzbarscript = ExpBarWnd(GetScript("ExpBarWnd"));
    zzHelpButton = GetHandle("PCCafeEventWnd.HelpButton");
InitCommonKillSkull();
}

function OnClickButton(string a_ButtonID)
{
    switch(a_ButtonID)
    {
        case "HelpButton":
            OnClickHelpButton();
            break;
    }
}

function OnEvent(int a_EventID, string a_Param)
{
    switch(a_EventID)
    {
        case EV_PCCafePointInfo:
            HandlePCCafePointInfo(a_Param);
            break;

        case 140:
            HandleStringEvent(a_Param);
            break;
    }
}

function HandleStringEvent(string a_Param)
{
    local int cEvent;

    ParseInt(a_Param, "CustomEvent", cEvent);

if(cEvent == 88547)
{
    ShowCommonKillSkull();
    return;
}

    if(cEvent == 88546)
    {
        zzKillLog = KillLogWnd(GetScript("KillLogWnd"));

        if(zzKillLog != None)
        {
            zzKillLog.HandleKill(a_Param);
        }
    }
    else if(cEvent == 88554)
    {
        if(PvpRankWnd(GetScript("PvpRankWnd")) != None)
        {
            PvpRankWnd(GetScript("PvpRankWnd")).HandleRankEvent(a_Param);
        }
    }
    else if(cEvent > 0)
    {
        a_Param = Mid(a_Param, InStr(a_Param, "CustomEvent"));
        ExecuteEvent(cEvent, a_Param);
    }
    else
    {
        ExecuteEvent(99996, a_Param);
    }

    return;
}

function OnClickHelpButton()
{
}

function HandlePCCafePointInfo(string zza_Param)
{
    local ToolTip zzscript;

    zzscript = ToolTip(GetScript("ToolTip"));

    ParseInt(zza_Param, "TotalPoint", zzm_TotalPoint);
    ParseInt(zza_Param, "AddPoint", zzm_AddPoint);
    ParseInt(zza_Param, "PeriodType", zzm_PeriodType);
    ParseInt(zza_Param, "RemainTime", zzm_RemainTime);
    ParseInt(zza_Param, "PointType", zzm_PointType);

    // Frame exclusivo da AutoHunting.
if (zzm_RemainTime == 99982)
{
    return;
}

     if(HandlePlayerModePacket())
    {
        return;
    }


    if(HandleBuffWndPacket())
    {
        return;
    }

    switch(zzm_RemainTime)
    {
        case 0:
        case 1:
            xxsynnak(zzm_AddPoint, zzm_RemainTime);
            break;

        case 99981:
            ExecuteEvent(99981);
            break;

        case 154786:
            ExecuteEvent(154786);
            break;

        case 154787:
            ExecuteEvent(154787);
            break;

        case 154788:
            xxlcoin(zzm_AddPoint);
            break;

        case 154789:
            xxtimepve(zzm_AddPoint);
            break;

        case 154790:
            xxtimepvp(zzm_AddPoint);
            break;

        case 154791:
            xxtimesolo(zzm_AddPoint);
            break;

        case 154792:
            xxtimelairpvp(zzm_AddPoint);
            break;

        case 1013:
        case 1014:
        case 1015:
        case 1016:
            xxtimeinstance(zzm_AddPoint, zzm_RemainTime);
            break;

        case 155789:
            xxbypasexit(zzm_AddPoint);
            break;

        case 155790:
            ExecuteEvent(155790);
            break;

        case 98715:
            xxHideOrionChiets();
            break;

        case 99562:
            zzscript.isadmin = true;
            break;

        case 99563:
            zzscript.isadmin = false;
            break;

        default:
            break;
    }

    Refresh();
}

function xxHideOrionChiets()
{
    HideWindow("AutoHunting");
    ExecuteEvent(99872);
    ExecuteEvent(98716);
    return;
}

function xxsynnak(int zzid, int zzenable)
{
    local string zzparam;

    ParamAdd(zzparam, "ShotID", string(zzid));
    ParamAdd(zzparam, "bEnable", string(zzenable));

    ExecuteEvent(44467, zzparam);
    return;
}

function xxlcoin(int zzid)
{
    local string zzparam;

    ParamAdd(zzparam, "LcoinCount", string(zzid));
    ExecuteEvent(154788, zzparam);
    return;
}

function xxtimepve(int zzid)
{
    local string zzparam;

    ParamAdd(zzparam, "TimePvE", string(zzid));
    ExecuteEvent(154789, zzparam);
}

function xxtimepvp(int zzid)
{
    local string zzparam;

    ParamAdd(zzparam, "TimePvP", string(zzid));
    ExecuteEvent(154790, zzparam);
    return;
}

function xxtimesolo(int zzid)
{
    local string zzparam;

    ParamAdd(zzparam, "TimeSolo", string(zzid));
    ExecuteEvent(154791, zzparam);
    return;
}

function xxtimelairpvp(int zzid)
{
    local string zzparam;

    ParamAdd(zzparam, "TimeLairPvP", string(zzid));
    ExecuteEvent(154792, zzparam);
    return;
}

function xxtimeinstance(int zzid, int zzinstanceid)
{
    local string zzparam;

    ParamAdd(zzparam, "TimeInstance", string(zzid));
    ParamAdd(zzparam, "InstanceId", string(zzinstanceid));

    ExecuteEvent(156750, zzparam);
}

function xxbypasexit(int zzid)
{
    local string zzparam;

    ParamAdd(zzparam, "Bypass", string(zzid));
    ExecuteEvent(155789, zzparam);
    return;
}

function bool IsPCCafeEventOpened()
{
    if(0 < zzm_PeriodType)
    {
        return true;
    }

    return false;
}

function OnEnterState(name a_PreStateName)
{
    InitCommonKillSkull();
    Refresh();
}

function Refresh()
{
    local Color zzTextColor;
    local string zzAddPointText;

    if(IsPCCafeEventOpened())
    {
        zzHelpButton.SetTooltipCustomType(
            xxSetTooltip(GetHelpButtonTooltipText())
        );

        class'UIAPI_TEXTBOX'.static.SetText(
            "PCCafeEventWnd.PointTextBox",
            MakeCostString(string(zzm_TotalPoint))
        );

        class'UIAPI_WINDOW'.static.SetAlpha(
            "PCCafeEventWnd.PointAddTextBox",
            0
        );

        class'UIAPI_TEXTBOX'.static.SetText(
            "ExpBarWnd.textCountPCBANG",
            MakeCostString(string(zzm_TotalPoint))
        );

        if(0 != zzm_AddPoint)
        {
            if(0 < zzm_AddPoint)
            {
                zzAddPointText = "+"
                    $ MakeCostString(string(zzm_AddPoint));
            }
            else
            {
                zzAddPointText = MakeCostString(
                    string(zzm_AddPoint)
                );
            }

            class'UIAPI_TEXTBOX'.static.SetText(
                "PCCafeEventWnd.PointAddTextBox",
                zzAddPointText
            );

            switch(zzm_PointType)
            {
                case 0:
                    zzTextColor.R = 255;
                    zzTextColor.G = 255;
                    zzTextColor.B = 0;
                    break;

                case 1:
                    zzTextColor.R = 0;
                    zzTextColor.G = 255;
                    zzTextColor.B = 255;
                    break;

                case 2:
                    zzTextColor.R = 255;
                    zzTextColor.G = 0;
                    zzTextColor.B = 0;
                    break;
            }

            class'UIAPI_TEXTBOX'.static.SetTextColor(
                "PCCafeEventWnd.PointAddTextBox",
                zzTextColor
            );

            class'UIAPI_WINDOW'.static.SetAnchor(
                "PCCafeEventWnd.PointAddTextBox",
                "PCCafeEventWnd",
                "TopRight",
                "TopRight",
                -5,
                41
            );

            class'UIAPI_WINDOW'.static.ClearAnchor(
                "PCCafeEventWnd.PointAddTextBox"
            );

            class'UIAPI_WINDOW'.static.Move(
                "PCCafeEventWnd.PointAddTextBox",
                0,
                -18,
                1.f
            );

            class'UIAPI_WINDOW'.static.SetAlpha(
                "PCCafeEventWnd.PointAddTextBox",
                255
            );

            class'UIAPI_WINDOW'.static.SetAlpha(
                "PCCafeEventWnd.PointAddTextBox",
                0,
                0.8f
            );

            zzm_AddPoint = 0;
        }
    }
    else
    {
        HideWindow("PCCafeEventWnd");
    }
}

function string GetHelpButtonTooltipText()
{
    local string zzTooltipSystemMsg;

    if(1 == zzm_PeriodType)
    {
        zzTooltipSystemMsg = GetSystemMessage(1705);
    }
    else if(2 == zzm_PeriodType)
    {
        zzTooltipSystemMsg = GetSystemMessage(1706);
    }
    else
    {
        return "";
    }

    return MakeFullSystemMsg(
        zzTooltipSystemMsg,
        string(zzm_RemainTime),
        ""
    );
}

function bool HandleBuffWndPacket()
{
    local int category, slot, classId;
    local int index, skillId, skillLevel;
    local string params;

    if(zzm_RemainTime == 99978)
    {
        ExecuteEvent(99978);
        return true;
    }

    if(zzm_RemainTime != 99970 && zzm_RemainTime != 99971)
    {
        return false;
    }

    index = zzm_PeriodType;
    skillId = zzm_AddPoint >> 8;
    skillLevel = zzm_AddPoint & 255;

    if(zzm_RemainTime == 99970)
    {
        category = zzm_TotalPoint;

        if(category < 0 || category > 5
            || index < 0 || index > 23)
        {
            return true;
        }

        if(index == 0)
        {
            BuffWndCategoryData[category] = "";
            BuffWndCategoryNext[category] = 0;

            ParamAdd(
                BuffWndCategoryData[category],
                "cat",
                string(category)
            );
        }

        if(index != BuffWndCategoryNext[category])
        {
            return true;
        }

        if(skillId > 0 && skillLevel > 0)
        {
            ParamAdd(
                BuffWndCategoryData[category],
                "id_" $ string(index),
                string(skillId)
            );

            ParamAdd(
                BuffWndCategoryData[category],
                "lvl_" $ string(index),
                string(skillLevel)
            );
        }

        BuffWndCategoryNext[category]++;

        if(zzm_PointType == 1)
        {
            ExecuteEvent(
                99980,
                BuffWndCategoryData[category]
            );
        }

        return true;
    }

    if(zzm_PointType == 2)
    {
        slot = zzm_TotalPoint;

        if(slot < 0 || slot > 5)
        {
            return true;
        }

        ParamAdd(params, "newPreset", "1");
        ParamAdd(params, "presetID", string(slot));

        ExecuteEvent(99979, params);
        return true;
    }

    slot = zzm_TotalPoint & 7;
    classId = zzm_TotalPoint / 8;

    if(slot < 0 || slot > 5
        || classId < 0
        || index < 0 || index > 39)
    {
        return true;
    }

    if(index == 0)
    {
        BuffWndPresetData[slot] = "";
        BuffWndPresetNext[slot] = 0;

        ParamAdd(
            BuffWndPresetData[slot],
            "newPreset",
            "0"
        );

        ParamAdd(
            BuffWndPresetData[slot],
            "presetID",
            string(slot)
        );

        ParamAdd(
            BuffWndPresetData[slot],
            "PresetName",
            "Lista" $ string(slot + 1)
        );

        ParamAdd(
            BuffWndPresetData[slot],
            "UserClass",
            string(classId)
        );
    }

    if(index != BuffWndPresetNext[slot])
    {
        return true;
    }

    if(skillId > 0 && skillLevel > 0)
    {
        ParamAdd(
            BuffWndPresetData[slot],
            "id_" $ string(index),
            string(skillId)
        );

        ParamAdd(
            BuffWndPresetData[slot],
            "lvl_" $ string(index),
            string(skillLevel)
        );
    }

    BuffWndPresetNext[slot]++;

    if(zzm_PointType == 1)
    {
        ExecuteEvent(
            99979,
            BuffWndPresetData[slot]
        );
    }

    return true;
}

function CustomTooltip xxSetTooltip(string zzText)
{
    local CustomTooltip zzTooltip;
    local DrawItemInfo zzinfo;

    zzTooltip.MinimumWidth = 144;
    zzTooltip.DrawList.Length = 1;

    zzinfo.eType = DIT_TEXT;
    zzinfo.t_bDrawOneLine = true;

    zzinfo.t_color.R = 178;
    zzinfo.t_color.G = 190;
    zzinfo.t_color.B = 207;
    zzinfo.t_color.A = 255;

    zzinfo.t_strText = zzText;
    zzTooltip.DrawList[0] = zzinfo;

    return zzTooltip;
}

function bool HandlePlayerModePacket()
{
    local string Params;

    if(zzm_RemainTime != 28650)
    {
        return false;
    }

    if(zzm_TotalPoint < 0 || zzm_TotalPoint > 2)
    {
        return true;
    }

    ParamAdd(Params, "Mode", string(zzm_TotalPoint));
    ParamAdd(Params, "Result", string(zzm_AddPoint));

    ExecuteEvent(28650, Params);

    return true;
}

function InitCommonKillSkull()
{
    CommonSkullCount = 0;
    CommonSkullTicks = 0;
    CommonSkullActive = false;

    HideCommonKillSkull();

    class'NWindow.UIAPI_WINDOW'.static.KillUITimer(
        "PCCafeEventWnd",
        88547
    );

    class'NWindow.UIAPI_WINDOW'.static.SetUITimer(
        "PCCafeEventWnd",
        88547,
        50
    );
}

function HideCommonKillSkull()
{
    CommonSkullActive = false;
    CommonSkullTicks = 0;

    class'NWindow.UIAPI_WINDOW'.static.SetAlpha("PVPKill", 0);
    class'NWindow.UIAPI_WINDOW'.static.HideWindow("PVPKill");

    class'NWindow.UIAPI_TEXTBOX'.static.SetText(
        "PVPKill.PvpCountText",
        ""
    );

    class'NWindow.UIAPI_TEXTBOX'.static.SetText(
        "PVPKill.PKCountText",
        ""
    );
}

function ShowCommonKillSkull()
{
    local Color CountColor;

    if(GetUIState() != "GAMINGSTATE")
        return;

    // Reinicia a animacao, mantendo a contagem.
    HideCommonKillSkull();

CommonSkullCount++;

// Continua contando as kills, mesmo com a imagem desativada.
if(GetOptionBool("Lotus_Custom", "DisableKillMarker"))
    return;

CommonSkullActive = true;
CommonSkullTicks = 0;

    CountColor.R = 255;
    CountColor.G = 0;
    CountColor.B = 0;
    CountColor.A = 255;

    class'NWindow.UIAPI_TEXTBOX'.static.SetText(
        "PVPKill.PvpCountText",
        string(CommonSkullCount) $ " KILL"
    );

    class'NWindow.UIAPI_TEXTBOX'.static.SetTextColor(
        "PVPKill.PvpCountText",
        CountColor
    );

    // Contagem centralizada abaixo da caveira.
    class'NWindow.UIAPI_WINDOW'.static.SetAnchor(
        "PVPKill.PvpCountText",
        "PVPKill.PVPKillLogo",
        "BottomCenter",
        "TopCenter",
        0,
        8
    );

    class'NWindow.UIAPI_WINDOW'.static.ShowWindow("PVPKill");

    class'NWindow.UIAPI_WINDOW'.static.SetAnchor(
        "PVPKill",
        "",
        "TopCenter",
        "TopCenter",
        0,
        100
    );

    class'NWindow.UIAPI_WINDOW'.static.ClearAnchor("PVPKill");
    class'NWindow.UIAPI_WINDOW'.static.SetAlpha("PVPKill", 255);

    // Sobe suavemente durante um segundo.
    class'NWindow.UIAPI_WINDOW'.static.Move("PVPKill", 0,-18,1.0);
}

function OnTimer(int TimerID)
{
    local int SkullAlpha;

    if(TimerID != 88547)
        return;

    // Mantem a janela oculta enquanto nao houver uma kill.
  if(!CommonSkullActive|| GetOptionBool("Lotus_Custom", "DisableKillMarker")|| GetUIState() != "GAMINGSTATE")
    {
        HideCommonKillSkull();
        return;
    }

    CommonSkullTicks++;

  // 40 etapas de 50 ms = aproximadamente dois segundos.
if(CommonSkullTicks >= 40)
{
    HideCommonKillSkull();
    return;
}

SkullAlpha = 255 - ((CommonSkullTicks * 255) / 40);

class'NWindow.UIAPI_WINDOW'.static.SetAlpha("PVPKill",SkullAlpha);
}

