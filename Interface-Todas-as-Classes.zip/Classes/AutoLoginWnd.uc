class AutoLoginWnd extends UICommonAPI;

const DIALOG_ID_AUTO_LOGIN = 13122401;
const DIALOG_ID_AUTO_PASSWORD = 13122402;
const DIALOG_ID_AUTO_REQUEST = 13122403;
const DIALOG_ID_AUTO_DELETE = 13122404;
const DIALOG_ID_AUTO_ERROR = 13122405;
const DIALOG_ID_MAX_RECORD = 13122406;
const DIALOG_ID_AUTO_ERROR2 = 13122407;

const MAX_LENGTH = 16;
const MAX_RECORD = 28;

var WindowHandle me;
var ListCtrlHandle	listLogin;
var string login;
var string password;
var int statError;

function OnLoad()
{
	registerEvent(13122024); // кнопка вход в игру
	registerEvent(14122024); // загрузка из ini
	registerEvent(15122024); // добавить в список отображения
	registerEvent(16122024); // в .dll происходит перехват. и сюда обратно
	registerEvent(17122024); // удалить
	registerEvent(18122024); // сообщение
	
	registerEvent( EV_DialogOK );
	registerEvent( EV_DialogCancel );
	registerState("AutoLoginWnd", "LoginState" );
	
	me = GetHandle("AutoLoginWnd");
	listLogin = ListCtrlHandle(GetHandle("AutoLoginWnd.listLogin"));
	
	ExecuteEvent(14122024, "AutoLoginWnd=listLogin");
}
 
function ClearListLogin()
{
	listLogin.DeleteAllItem();
}

function ClearInput()
{
	login = "";
	password = "";
}

function OnEvent( int eventID, string param )
{
	local array<string> arrToken;
	local string message;
	local int messageID;
	switch( eventID )
	{
		case EV_DialogOK:
			HandleDialogOK();
		break;
		case EV_DialogCancel:
			HandleDialogCancel();
		break;
		case 14122024: // загрузка изи ini
			Split(param, "=", arrToken);
			AutoLoginInsert(arrToken[1], false);
		break;
		case 15122024: // добавить в список отображения
			Split(param, "=", arrToken);
			AutoLoginInsert(arrToken[1], true);
		break;
		case 18122024:
			if(ParseString(param, "login", message) && ParseInt(param, "messageID", messageID))
			{
				DialogSetID(DIALOG_ID_AUTO_ERROR2);
				DialogSetDefaultOK();
				DialogShow(DIALOG_Warning, MakeFullSystemMsg(GetSystemMessage(messageID), login, "")); // 153 u,$s1 занят. Пожалуйста, попробуйте еще раз через некоторое время.\0
			}
		break;
	};
}

function HandleDialogOK() // ОК
{
	local string message;
	
	if( DialogIsMine())
	{
		message = DialogGetString();
		switch(DialogGetID())
		{
			case DIALOG_ID_AUTO_LOGIN:
				login = message;
				if(CheckInString(login))
				{
					DialogInPassword();
				}
				else
				{
					statError = 1;
					DialogError();
				}
			break;
			case DIALOG_ID_AUTO_PASSWORD:
				password = message;
				if(CheckInString(password))
				{
					ExecuteEvent(16122024, login $ "=" $ password); // в .dll происходит перехват. // сохранить логин пароль
				}
				else
				{
					statError = 2;
					DialogError();
				}
			break;
			case DIALOG_ID_AUTO_DELETE:
				AutoLoginDeletet(true);
			break;
			case DIALOG_ID_AUTO_REQUEST:
				
			break;
			case DIALOG_ID_AUTO_ERROR:
				HandleDialogError();
			break;
		}
	}
}

function HandleDialogError()
{
	switch(statError)
	{
		case 1:
			DialogInLogin();
		break;
		case 2:
			DialogInPassword();
		break;
	}
}

function HandleDialogCancel() // Отмена
{
	if( DialogIsMine() )
	{
		switch(DialogGetID())
		{
			case DIALOG_ID_AUTO_LOGIN:
			case DIALOG_ID_AUTO_PASSWORD:
				ClearInput();
			break;
			case DIALOG_ID_AUTO_DELETE:
			break;
			case DIALOG_ID_AUTO_REQUEST:
			break;
		}
	}
}

function OnClickButton(string name ) //	"butAdd"	"butLogin"	"butDel"
{
	switch(name)
	{
		case "butAdd":
			DialogInLogin();
			break;
		case "butDel":
			AutoLoginDeletet(false);
			break;
		case "butLogin":
			OnDBClickListCtrlRecord("");
			break;
	}
}

function DialogInLogin() // ввод логина
{
	ClearInput();
	DialogSetID( DIALOG_ID_AUTO_LOGIN );
	DialogSetEditBoxMaxLength(MAX_LENGTH);
	DialogSetEditType("normal");
	DialogSetDefaultOK();
	DialogShow( DIALOG_OKCancelInput, MakeFullSystemMsg(GetSystemMessage(86), "", "" )); // 86 u,Введите ваш логин.
}

function DialogInPassword() // ввод пароля
{
	DialogSetID( DIALOG_ID_AUTO_PASSWORD );
	DialogSetEditBoxMaxLength(MAX_LENGTH);
	DialogSetEditType("password");
	DialogSetDefaultOK();	
	DialogShow( DIALOG_OKCancelInput, MakeFullSystemMsg(GetSystemMessage(87), "", "" )); // 87 u,Введите ваш пароль.
}

function bool CheckInString(string message)
{
	local int lenM;
	lenM = Len(message);
	if(lenM >= 3 && lenM <= MAX_LENGTH)
	{
		return true;
	}
	return false;
}

function DialogError()
{
	DialogSetID(DIALOG_ID_AUTO_ERROR);
	DialogSetDefaultOK();
	DialogShow(DIALOG_Warning, MakeFullSystemMsg(GetSystemMessage(786), "", "" )); // 786 u,Неверный синтаксис.
}

function AutoLoginInsert(string login, bool dialog)
{
	local LVDataRecord	record;
	
	ClearInput();
	
	if(listLogin.GetRecordCount() >= MAX_RECORD)
	{
		if(dialog)
		{
			DialogSetID(DIALOG_ID_MAX_RECORD);
			DialogSetDefaultOK();
			DialogShow(DIALOG_OK, MakeFullSystemMsg(GetSystemMessage(1369), "", "")); // 1369 u,Вы превысили максимум.
		}
		return;
	}

	Record.LVDataList.Length = 2;
	Record.LVDataList[0].szData = string(listLogin.GetRecordCount());
	Record.LVDataList[1].szData = login;
	listLogin.InsertRecord(record);
}

function AutoLoginDeletet(bool delete)
{
	local LVDataRecord	record;
	local int index;
	index = listLogin.GetSelectedIndex();
	if(index > -1)
	{
		if(delete)
		{	
			record = listLogin.GetRecord(index);
			ExecuteEvent(17122024, "login=" $ Record.LVDataList[1].szData);
			listLogin.DeleteRecord(index);
		}
		else
		{
			record = listLogin.GetRecord(index);
			DialogSetID(DIALOG_ID_AUTO_DELETE);
			DialogSetDefaultOK();
			DialogShow(DIALOG_OKCancel, MakeFullSystemMsg(GetSystemMessage(78), Record.LVDataList[1].szData , "" )); // 78 u,Вы хотите удалить $s1?
		}
	}
}

function OnDBClickListCtrlRecord( String name )
{
	local LVDataRecord	record;
	local int index;
	index = listLogin.GetSelectedIndex();
	if(index > -1)
	{
		record = listLogin.GetRecord(index);
		ExecuteEvent(13122024, "login=" $ Record.LVDataList[1].szData);
	}
}

function OnDefaultPosition()
{
	me.SetAnchor("", "TopLeft", "TopLeft", 100, 200);
	me.ClearAnchor();
}
