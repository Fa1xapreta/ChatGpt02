class MobInfoLauncherWnd extends UICommonAPI;
const LAUNCH_PANEL_TIMER = 6594;
const HELP_PULSE_TIMER = 6595;
var WindowHandle Me;
var bool LaunchQueued;
var ButtonHandle MileniumHelpButton;
var bool HelpPulseActive;
var bool HelpPulseBright;
function OnLoad()
{
 Me=GetHandle("MobInfoLauncherWnd");
 Me.SetDraggable(false);
 InitializeMileniumHelp();
 Me.SetAnchor("TargetStatusWnd","TopLeft","TopRight",0,5);
 RegisterEvent(EV_TargetUpdate);
 RegisterEvent(EV_TargetHideWindow);
 RegisterEvent(EV_GamingStateEnter);
 RegisterEvent(EV_GamingStateExit);
 Me.HideWindow();
}
function OnEvent(int eventID,string param)
{
 if(eventID==EV_GamingStateExit)
 {
  Me.KillTimer(LAUNCH_PANEL_TIMER);
  LaunchQueued=false;
 }
 if(eventID==EV_GamingStateExit || eventID==EV_TargetHideWindow)Me.HideWindow();
 else UpdateVisibility();
}
function UpdateVisibility()
{
 local UserInfo info;
 if(GetTargetInfo(info) && info.bNpc && !info.bPet)Me.ShowWindow();
 else Me.HideWindow();
}
function InitializeMileniumHelp()
{
 local CustomTooltip helpTooltip;
 local DrawItemInfo helpLine;
 MileniumHelpButton=ButtonHandle(GetHandle("MobInfoLauncherWnd.MobInfoButton"));
 helpTooltip=xxMakeTooltipSimpleText("Dados do Monstro");
 helpTooltip.MinimumWidth=260;
 helpTooltip.DrawList.Length=3;
 helpLine.eType=DIT_TEXT;
 helpLine.t_bDrawOneLine=false;
 helpLine.bLineBreak=true;
 helpLine.t_color.R=220;helpLine.t_color.G=220;helpLine.t_color.B=220;helpLine.t_color.A=255;
 helpLine.t_strText="Nivel, atributos, drop, spoil e quests.";
 helpTooltip.DrawList[1]=helpLine;
 helpLine.t_strText="Clique para ver os dados e a localizacao.";
 helpTooltip.DrawList[2]=helpLine;
 MileniumHelpButton.SetTooltipCustomType(helpTooltip);
 ApplyMileniumHelpPulse();
}
function ApplyMileniumHelpPulse()
{
 local string normalTexture;
 if(MileniumHelpButton==None)return;
 normalTexture="L2UI_CH3.InventoryWnd.Btn_Help";
 if(HelpPulseBright)normalTexture="L2UI_CH3.InventoryWnd.Btn_Help_over";
 MileniumHelpButton.SetTexture(normalTexture,"L2UI_CH3.InventoryWnd.Btn_Help_down","L2UI_CH3.InventoryWnd.Btn_Help_over");
}
function OnShow()
{
 if(Me==None)Me=GetHandle("MobInfoLauncherWnd");
 if(MileniumHelpButton==None)InitializeMileniumHelp();
 if(!HelpPulseActive)
 {
  HelpPulseActive=true;
  HelpPulseBright=false;
  ApplyMileniumHelpPulse();
  Me.SetTimer(HELP_PULSE_TIMER,600);
 }
}
function OnHide()
{
 Me.KillTimer(HELP_PULSE_TIMER);
 HelpPulseActive=false;
 HelpPulseBright=false;
 ApplyMileniumHelpPulse();
}
function MileniumLaunchMessage(string text)
{
 local Color messageColor;
 messageColor.R=255;messageColor.G=200;messageColor.B=80;messageColor.A=255;
 class'UIAPI_TEXTLISTBOX'.static.AddString("ChatWnd.NormalChat",text,messageColor);
}
function OnClickButton(string buttonID)
{
 if(Caps(buttonID)!="MOBINFOBUTTON")return;
 if(LaunchQueued)return;
 // Use the same native opening API as the user's other windows.
 ShowWindowWithFocus("MobInformerWnd");
 if(Me==None)Me=GetHandle("MobInfoLauncherWnd");
 LaunchQueued=true;
 Me.SetTimer(LAUNCH_PANEL_TIMER,100);
}
function OnTimer(int timerID)
{
 local MobInformerWnd panel;
 if(timerID==HELP_PULSE_TIMER)
 {
  if(!Me.IsShowWindow())
  {
   Me.KillTimer(HELP_PULSE_TIMER);
   HelpPulseActive=false;
   return;
  }
  HelpPulseBright=!HelpPulseBright;
  ApplyMileniumHelpPulse();
  return;
 }
 if(timerID!=LAUNCH_PANEL_TIMER)return;
 Me.KillTimer(LAUNCH_PANEL_TIMER);
 LaunchQueued=false;
 // Bind/call the script after the native window has had a chance to load.
 panel=MobInformerWnd(GetScript("MobInformerWnd"));
 if(panel==None)
 {
  MileniumLaunchMessage("[Monster Data MD2] Classe MobInformerWnd indisponivel na Interface.u.");
  return;
 }
 panel.OpenFromLauncher();
}

