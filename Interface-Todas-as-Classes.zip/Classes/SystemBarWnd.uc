class SystemBarWnd extends UICommonAPI;

var string m_WindowName;
var bool KillStatsInitialized;
var string KillStatsPlayerName;
var int LastPvpCount;
var int LastPkCount;
var int SessionPvpCount;
var int SessionPkCount;
var int CommonKillCount;

function OnLoad()
{
    RegisterEvent(180);
    RegisterEvent(2610);

    ResetKillState();
}

function OnEnterState(name a_PreStateName)
{
    ResetKillState();
    UpdatePlayerInfo();
    UpdateAdena();
}

function ResetKillState()
{
    KillStatsInitialized = false;
    KillStatsPlayerName = "";
    LastPvpCount = 0;
    LastPkCount = 0;
    SessionPvpCount = 0;
    SessionPkCount = 0;
    CommonKillCount = 0;

    HideKillSkull();
}

function OnEvent(int a_EventID, string a_Param)
{
    switch(a_EventID)
    {
        case 180:
            if(GetUIState() == "GAMINGSTATE")
            {
                UpdatePlayerInfo();
                UpdateAdena();
            }
            break;

        case 2610:
            UpdateAdena();
            break;
    }
}

function OnShow()
{
    UpdatePlayerInfo();
    UpdateAdena();
}

function UpdateAdena()
{
    class'NWindow.UIAPI_TEXTBOX'.static.SetText(
        m_WindowName $ ".AdenaText",
        MakeCostString(string(GetAdena()))
    );

    class'NWindow.UIAPI_TEXTBOX'.static.SetTooltipString(
        m_WindowName $ ".AdenaText",
        ConvertNumToText(string(GetAdena()))
    );
}

function UpdatePlayerInfo()
{
    local UserInfo Info;
    local Color TextColor;
    local float ExpPercent;

    GetPlayerInfo(Info);

    if(!KillStatsInitialized || KillStatsPlayerName != Info.Name)
    {
        LastPvpCount = Info.nDualCount;
        LastPkCount = Info.nPKCount;
        SessionPvpCount = 0;
        SessionPkCount = 0;
        CommonKillCount = 0;
        KillStatsPlayerName = Info.Name;
        KillStatsInitialized = true;
    }
    else
    {
        if(Info.nDualCount > LastPvpCount)
            SessionPvpCount += Info.nDualCount - LastPvpCount;

        if(Info.nPKCount > LastPkCount)
            SessionPkCount += Info.nPKCount - LastPkCount;

        LastPvpCount = Info.nDualCount;
        LastPkCount = Info.nPKCount;
    }

    TextColor.R = 255;
    TextColor.G = 255;
    TextColor.B = 255;
    TextColor.A = 255;

    class'NWindow.UIAPI_TEXTBOX'.static.SetText(
        m_WindowName $ ".PVPInfo",
        "PvP: " $ string(Info.nDualCount)
        $ " / PK: " $ string(Info.nPKCount)
    );

    class'NWindow.UIAPI_TEXTBOX'.static.SetTextColor(
        m_WindowName $ ".PVPInfo",
        TextColor
    );

    class'NWindow.UIAPI_TEXTBOX'.static.SetTooltipString(
        m_WindowName $ ".PVPInfo",
        "Total Kills after Logged:\\nPVP: "
        $ string(SessionPvpCount)
        $ "\\nPK: " $ string(SessionPkCount)
    );

    class'NWindow.UIAPI_STATUSBARCTRL'.static.SetPointExp(
        m_WindowName $ ".EXPBar",
        Info.nCurExp,
        Info.nLevel
    );

    ExpPercent =
        class'NWindow.UIDATA_PLAYER'.static.GetPlayerEXPRate() * 100.0;

    if(ExpPercent < 0)
        ExpPercent = 0;

    class'NWindow.UIAPI_TEXTBOX'.static.SetText(
        m_WindowName $ ".ExpText",
        string(ExpPercent) $ "% "
    );

    class'NWindow.UIAPI_TEXTBOX'.static.SetTooltipString(
        m_WindowName $ ".ExpText",
        string(ExpPercent) $ "% XP of Lv." $ string(Info.nLevel)
    );
}

function ShowKillSkull()
{
    local Color CountColor;

    UpdatePlayerInfo();
    CommonKillCount++;

    // Reinicia a animacao caso outra kill aconteca rapidamente.
    HideKillSkull();

    CountColor.R = 230;
    CountColor.G = 77;
    CountColor.B = 77;
    CountColor.A = 255;

    class'NWindow.UIAPI_TEXTBOX'.static.SetText(
        "PVPKill.PKCountText",
        ""
    );

    class'NWindow.UIAPI_TEXTBOX'.static.SetText(
        "PVPKill.PvpCountText",
        string(CommonKillCount)
    );

    class'NWindow.UIAPI_TEXTBOX'.static.SetTextColor(
        "PVPKill.PvpCountText",
        CountColor
    );

    class'NWindow.UIAPI_WINDOW'.static.SetAnchor(
        "PVPKill.PvpCountText",
        "PVPKill.PVPKillLogo",
        "BottomCenter",
        "TopCenter",
        0,
        -5
    );

    class'NWindow.UIAPI_WINDOW'.static.ShowWindow("PVPKill");

    class'NWindow.UIAPI_WINDOW'.static.SetAnchor(
        "PVPKill",
        "",
        "TopCenter",
        "TopCenter",
        0,
        100
    );

    class'NWindow.UIAPI_WINDOW'.static.ClearAnchor("PVPKill");
    class'NWindow.UIAPI_WINDOW'.static.SetAlpha("PVPKill", 255);
    class'NWindow.UIAPI_WINDOW'.static.Move("PVPKill", 0, -18, 1.0);
    class'NWindow.UIAPI_WINDOW'.static.SetAlpha("PVPKill", 0, 1.0);

    class'NWindow.UIAPI_WINDOW'.static.SetUITimer(
        m_WindowName,
        88547,
        1100
    );
}

function HideKillSkull()
{
    class'NWindow.UIAPI_WINDOW'.static.KillUITimer(
        m_WindowName,
        88547
    );

    class'NWindow.UIAPI_WINDOW'.static.SetAlpha("PVPKill", 0);
    class'NWindow.UIAPI_WINDOW'.static.HideWindow("PVPKill");
}

function OnTimer(int TimerID)
{
    if(TimerID == 88547)
        HideKillSkull();
}

function OnDefaultPosition()
{
    class'NWindow.UIAPI_WINDOW'.static.SetAnchor(
        m_WindowName,
        "",
        "BottomLeft",
        "BottomLeft",
        0,
        0
    );
}

function CustomTooltip SetTooltip(string Text)
{
    local CustomTooltip ToolTip;
    local DrawItemInfo Info;

    ToolTip.DrawList.Length = 1;
    Info.eType = DIT_TEXT;
    Info.t_strText = Text;
    ToolTip.DrawList[0] = Info;

    return ToolTip;
}

