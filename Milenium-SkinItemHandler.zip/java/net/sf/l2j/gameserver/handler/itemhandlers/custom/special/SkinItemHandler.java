/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.handler.itemhandlers.custom.special;

import net.sf.l2j.gameserver.datatables.custom.SkinTable;
import net.sf.l2j.gameserver.handler.IItemHandler;
import net.sf.l2j.gameserver.model.actor.L2Playable;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;

public final class SkinItemHandler implements IItemHandler
{
	@Override
	public void useItem(L2Playable playable, ItemInstance item, boolean forceUse)
	{
		if (!(playable instanceof L2PcInstance))
			return;

		final L2PcInstance player = (L2PcInstance) playable;
		if (player.isInOlympiadMode() || player.isOlympiadProtection())
		{
			player.sendMessage("Voce nao pode alterar a skin durante a Olimpiada.");
			return;
		}

		final int skinId = item.getItemId();
		if (!SkinTable.getInstance().getSkinId(skinId))
		{
			player.sendMessage("Esta skin ainda nao tem uma aparencia configurada.");
			return;
		}

		if (player.getActiveSkinId() == skinId)
		{
			player.setActiveSkinId(0);
			player.broadcastUserInfo();
			player.sendMessage("Skin desativada.");
			return;
		}

		if (player.getFakeArmorObjectId() != 0)
			player.removeFakeArmor();

		if (player.getActiveSkinId() != 0)
		{
			player.setActiveSkinId(0);
			player.broadcastUserInfo();
		}

		player.setActiveSkinId(skinId);
		player.broadcastUserInfo();
		player.sendMessage("Skin ativada.");
	}
}
