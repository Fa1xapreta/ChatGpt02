package net.sf.l2j.gameserver.handler.itemhandlers;

import net.sf.l2j.gameserver.datatables.custom.SkinTable;
import net.sf.l2j.gameserver.handler.IItemHandler;
import net.sf.l2j.gameserver.model.actor.L2Playable;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;

public class SkinItemHandler implements IItemHandler
{
	@Override
	public void useItem(L2Playable playable, ItemInstance item, boolean forceUse)
	{
		if (!(playable instanceof L2PcInstance))
			return;

		final L2PcInstance player = (L2PcInstance) playable;
		if (player.isInOlympiadMode()
			|| !SkinTable.getInstance().isModelArmorItem(item.getItemId()))
			return;

		if (!SkinTable.getInstance().getSkinId(item.getItemId()))
		{
			player.sendMessage("This skin is waiting for its client visuals.");
			return;
		}

		player.clearArmorSkinPreview();
		if (player.getActiveSkinId() == item.getItemId())
			player.setActiveSkinId(0);
		else
		{
			if (player.getFakeArmorObjectId() != 0)
				player.removeFakeArmor();
			player.setActiveSkinId(item.getItemId());
		}
		player.broadcastUserInfo();
		player.broadcastUserInfoHiden();
	}
}
