param([string]$Compiler = 'D:\Compilador\Interlude')

$ErrorActionPreference = 'Stop'
$compiler = (Resolve-Path -LiteralPath $Compiler).Path
$relativeSource = 'Interface\Classes\TimeZoneWnd.uc'
foreach ($file in @('System\UCC.exe', $relativeSource)) {
    if (!(Test-Path -LiteralPath (Join-Path $compiler $file) -PathType Leaf)) {
        throw "Arquivo ausente no compilador: $file"
    }
}
$stamp = [Guid]::NewGuid().ToString('N').Substring(0, 8)
$logs = New-Item -ItemType Directory -Path (Join-Path $PSScriptRoot "Resultado-$stamp")
$clone = Join-Path $env:TEMP "Milenium-UCC-AB-$stamp"
$null = New-Item -ItemType Directory -Path $clone
Write-Host "Copiando o compilador para $clone"
& robocopy.exe $compiler $clone /E /XJ /R:1 /W:1 /NFL /NDL /NJH /NJS /NP
if ($LASTEXITCODE -ge 8) { throw "Falha ao copiar o compilador: $LASTEXITCODE" }

$report = Join-Path $logs.FullName 'Resumo.txt'
$installed = (Get-FileHash -LiteralPath (Join-Path $compiler $relativeSource) -Algorithm SHA256).Hash
"TimeZoneWnd instalado SHA256=$installed" | Set-Content -LiteralPath $report -Encoding UTF8
Push-Location -LiteralPath (Join-Path $clone 'System')
try {
    foreach ($variant in @('A', 'B')) {
        $source = Join-Path $PSScriptRoot "$variant\TimeZoneWnd.uc"
        $hash = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
        Copy-Item -LiteralPath $source -Destination (Join-Path $clone $relativeSource) -Force
        if (Test-Path -LiteralPath 'Interface.u') {
            Move-Item -LiteralPath 'Interface.u' -Destination "Interface-antes-do-teste-$variant.u"
        }
        Write-Host "Compilando variante $variant"
        & cmd.exe /d /c 'echo N|UCC.exe make -NoBind -log=UCC-AB.log > UCC-AB-console.txt 2>&1'
        $code = $LASTEXITCODE
        $built = Test-Path -LiteralPath 'Interface.u' -PathType Leaf
        $last = Get-Content -LiteralPath 'UCC-AB-console.txt' | Where-Object { $_.Trim() } | Select-Object -Last 1
        "$variant ExitCode=$code GerouInterface=$built SHA256=$hash" | Add-Content -LiteralPath $report -Encoding UTF8
        "$variant UltimaLinha=$last" | Add-Content -LiteralPath $report -Encoding UTF8
        Move-Item -LiteralPath 'UCC-AB-console.txt' -Destination (Join-Path $logs.FullName "$variant-console.txt")
        if (Test-Path -LiteralPath 'UCC-AB.log') {
            Move-Item -LiteralPath 'UCC-AB.log' -Destination (Join-Path $logs.FullName "$variant-UCC.log")
        }
    }
} finally {
    Pop-Location
}
Get-Content -LiteralPath $report
Write-Host "Envie os arquivos da pasta $($logs.FullName)"
