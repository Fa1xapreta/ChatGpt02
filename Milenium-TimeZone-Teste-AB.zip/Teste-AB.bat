@echo off
setlocal
if not "%~1"=="" goto custom
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Teste-AB.ps1"
goto done
:custom
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Teste-AB.ps1" -Compiler "%~1"
:done
set "RESULT=%ERRORLEVEL%"
pause
exit /b %RESULT%
