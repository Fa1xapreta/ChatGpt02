# AutoFarm Offline para Milenium

Esta versão usa um gerenciador de sessão offline com a rotina de combate
do AutoHunting atual. O jogador configura skills, poções e contra-ataque
no painel que já usa. O botão **Farm offline** abre um menu de ativação
em HTML, sem exigir alteração do XDAT. O relógio no AutoHunting e a dica
do botão exibem a duração disponível para um ticket enquanto conectado.

## Arquivos e configuração

- `java/` contém o gerenciador novo e os arquivos de integração da base
  Milenium disponível. `Integracao-Java.patch` mostra exatamente os trechos
  para mesclar quando a cópia instalada tiver outras alterações.
- `Interface/Classes/AutoHunting.uc` parte da edição com o marcador animado
  de monstros já corrigido.
- `config/custom/OfflineFarm.properties` vem desativado. Configure o ID de
  um ticket já cadastrado na sua pack, a duração e os spots da sua geodata.
  Cada spot usa `X,Y,Z`. Separe vários spots com `|`.
- Relatórios ficam em `data/offlinefarm/reports/`. O core salva o personagem
  pela rotina de persistência existente. Esta implementação usa arquivos
  por personagem para os relatórios.

## Fluxo

1. Abra o AutoHunting pela sidebar, configure suas skills e vá a um spot
   autorizado. O modo offline verifica nível, zona, spot, disponibilidade
   por conta e por spot, ticket e o estado do personagem.
2. Abra **Farm offline** e selecione **Ativar e desconectar**. Um ticket
   vale uma sessão, com duração de 60 minutos por padrão. O prazo encerra
   também ao reconectar. Tempo não usado dessa sessão não vira saldo.
3. Se o personagem morrer, a sessão pode reanimá-lo no spot após o intervalo
   configurado, desde que ainda tenha prazo.
4. Ao selecionar o mesmo personagem, a integração encerra a sessão e
   devolve o personagem ao cliente. Ao entrar no mundo, abre o relatório
   com tempo, monstros abatidos, mortes, ganho líquido de XP/SP e itens
   que aumentaram no inventário.

A rotina offline usa as regras de drops e combate da Milenium. O limite
de drop e a lógica específica de stamina da pack modelo não foram portados.
O desligamento encerra as sessões e preserva os relatórios. As sessões
não são retomadas automaticamente após reiniciar o servidor.

## Validação

A base Java disponível no workspace foi compilada com ECJ. Ainda faltam
a compilação de AutoHunting.uc pelo UCC e o teste integrado no cliente/servidor.

Em homologação, configure um ticket existente, um spot e uma sessão de
1 minuto. Confira que uma tentativa sem ticket, fora do spot ou em combate
é recusada. Depois teste desconexão, skills, combate, retorno antes de
expirar, expiração com o cliente fechado e o relatório no login.
