/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.model.actor.instance;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.instancemanager.offlinefarm.OfflineFarm;
import net.sf.l2j.gameserver.model.actor.L2Attackable;
import net.sf.l2j.gameserver.model.actor.L2Character;
import net.sf.l2j.gameserver.model.actor.knownlist.MonsterKnownList;
import net.sf.l2j.gameserver.model.actor.template.NpcTemplate;
import net.sf.l2j.gameserver.model.entity.events.PartyZoneEvent.PartyZoneTask;
import net.sf.l2j.gameserver.model.entity.events.Tyrannosaurus.TyrannosaurusTask;
import net.sf.l2j.gameserver.model.holder.RewardHolder;
import net.sf.l2j.gameserver.util.MinionList;
import net.sf.l2j.util.Rnd;

/**
 * This class manages monsters.
 * <ul>
 * <li>L2MonsterInstance</li>
 * <li>L2RaidBossInstance</li>
 * <li>L2GrandBossInstance</li>
 * </ul>
 */
public class L2MonsterInstance extends L2Attackable
{
	private L2MonsterInstance _master;
	private MinionList _minionList;
	
	/**
	 * Constructor of L2MonsterInstance (use L2Character and L2NpcInstance constructor).
	 * <ul>
	 * <li>Call the L2Character constructor to set the _template of the L2MonsterInstance (copy skills from template to object and link _calculators to NPC_STD_CALCULATOR)</li>
	 * <li>Set the name of the L2MonsterInstance</li>
	 * <li>Create a RandomAnimation Task that will be launched after the calculated delay if the server allow it</li>
	 * </ul>
	 * @param objectId Identifier of the object to initialized
	 * @param template L2NpcTemplate to apply to the NPC
	 */
	public L2MonsterInstance(int objectId, NpcTemplate template)
	{
		super(objectId, template);
	}
	
	@Override
	public void initKnownList()
	{
		setKnownList(new MonsterKnownList(this));
	}
	
	@Override
	public final MonsterKnownList getKnownList()
	{
		return (MonsterKnownList) super.getKnownList();
	}
	
	@Override
	public boolean isAutoAttackable(L2Character attacker)
	{
		// FIXME: to test to allow monsters hit others monsters
		if (attacker instanceof L2MonsterInstance)
			return false;
		
		return true;
	}
	
	@Override
	public boolean isAggressive()
	{
		return (getAggroRange() > 0);
	}
	
	@Override
	public void onSpawn()
	{
		if (!isTeleporting())
		{
			if (_master != null)
			{
				setIsNoRndWalk(true);
				setIsRaidMinion(_master.isRaid());
				_master.getMinionList().onMinionSpawn(this);
			}
			// delete spawned minions before dynamic minions spawned by script
			else if (_minionList != null)
				getMinionList().deleteSpawnedMinions();
			
			startMaintenanceTask();
		}
		
		// dynamic script-based minions spawned here, after all preparations.
		super.onSpawn();
	}
	
	@Override
	public void onTeleported()
	{
		super.onTeleported();
		
		if (_minionList != null)
			getMinionList().onMasterTeleported();
	}
	
	/**
	 * Spawn minions.
	 */
	protected void startMaintenanceTask()
	{
		if (!getTemplate().getMinionData().isEmpty())
			getMinionList().spawnMinions();
	}
	
	@Override
	public boolean doDie(L2Character killer)
	{
		if (!super.doDie(killer))
			return false;
		
		if (killer != null)
		{
			final L2PcInstance player = killer.getActingPlayer();
			if (player != null)
			{
				if (!isRaid())
					OfflineFarm.getInstance().recordKill(player);
				if  (Config.MISSION_LIST_MONSTER.contains(getTemplate().getNpcId()) && Config.ACTIVE_MISSION_FARM)
				{				
					if (!player.checkMissions(player.getObjectId()))
						player.updateMissions();
					
					if (!(player.isFarmCompleted() || player.getFarmCont() >= Config.MISSION_FARM_COUNT))
						player.setFarmCont(player.getFarmCont() + 1);			               
				}
				
				if  (Config.MISSION_LIST_CHAMPION_MONSTER.contains(getTemplate().getNpcId()) && Config.ACTIVE_MISSION_CHAMPION)
				{				
					if (!player.checkMissions(player.getObjectId()))
						player.updateMissions();
					
					if (!(player.isChampionCompleted() || player.getChampionCont() >= Config.MISSION_CHAMPION_COUNT))
						player.setChampionCont(player.getChampionCont() + 1);			               
				}
				
				if (getNpcId() == Config.monsterId && PartyZoneTask.is_started())
				{
					for (RewardHolder reward : Config.PARTY_ZONE_REWARDS)
					{
						if (player.getParty() != null)
						{
							for (L2PcInstance member : player.getParty().getPartyMembers())
							{
								if (member.isInsideRadius(getX(), getY(), getZ(), Config.RADIUS_TO_PARTYZONE, false, false))
								{
									if (Rnd.get(1000000) <= reward.getRewardChance())
									{
										if (member.isVip())
										{
											member.addItem("Random Reward", reward.getRewardId(), Rnd.get(reward.getRewardMin(), reward.getRewardMax()) * Config.VIP_DROP_RATE, member, true);
										}
										else
										{
											member.addItem("item", reward.getRewardId(), Rnd.get(reward.getRewardMin(), reward.getRewardMax()), member, true);
										}
									}
								}
							}
						}
						else if (Rnd.get(1000000) <= reward.getRewardChance())
						{
							if (player.isVip())
							{
								player.addItem("Random Reward", reward.getRewardId(), Rnd.get(reward.getRewardMin(), reward.getRewardMax()) * Config.VIP_DROP_RATE, player, true);
							}
							else
							{
								player.addItem("item", reward.getRewardId(), Rnd.get(reward.getRewardMin(), reward.getRewardMax()), player, true);
							}
						}
					}
				}
				else if (getNpcId() == Config.LS_monsterId && TyrannosaurusTask.is_started())
				{
					for (RewardHolder reward : Config.LS_ZONE_REWARDS)
					{
						if (player.getParty() != null)
						{
							for (L2PcInstance member : player.getParty().getPartyMembers())
							{
								if (member.isInsideRadius(getX(), getY(), getZ(), Config.RADIUS_TO_LS, false, false))
								{
									if (Rnd.get(1000000) <= reward.getRewardChance())
									{
										if (member.isVip())
										{
											member.addItem("Random Reward", reward.getRewardId(), Rnd.get(reward.getRewardMin(), reward.getRewardMax()) * Config.VIP_DROP_RATE, member, true);
										}
										else
										{
											member.addItem("item", reward.getRewardId(), Rnd.get(reward.getRewardMin(), reward.getRewardMax()), member, true);
										}
									}
								}
							}
						}
						else if (Rnd.get(1000000) <= reward.getRewardChance())
						{
							if (player.isVip())
							{
								player.addItem("Random Reward", reward.getRewardId(), Rnd.get(reward.getRewardMin(), reward.getRewardMax()) * Config.VIP_DROP_RATE, player, true);
							}
							else
							{
								player.addItem("item", reward.getRewardId(), Rnd.get(reward.getRewardMin(), reward.getRewardMax()), player, true);
							}
						}
					}
				}
			}
		}
		
		if (_master != null)
			_master.getMinionList().onMinionDie(this, _master.getSpawn().getRespawnDelay() / 2);
		
		return true;
	}
	
	@Override
	public void deleteMe()
	{
		if (_minionList != null)
			getMinionList().onMasterDie(true);
		else if (_master != null)
			_master.getMinionList().onMinionDie(this, 0);
		
		super.deleteMe();
	}
	
	@Override
	public L2MonsterInstance getLeader()
	{
		return _master;
	}
	
	public void setLeader(L2MonsterInstance leader)
	{
		_master = leader;
	}
	
	public boolean hasMinions()
	{
		return _minionList != null;
	}
	
	public MinionList getMinionList()
	{
		if (_minionList == null)
			_minionList = new MinionList(this);
		
		return _minionList;
	}
}