from pathlib import Path
import hashlib
import json
import struct
import sys

def main():
    if len(sys.argv) != 2:
        raise SystemExit("Uso: python aplicar.py caminho/para/interface.u")
    source = Path(sys.argv[1])
    original = source.read_bytes()
    key = hashlib.sha256(original).hexdigest()
    here = Path(__file__).resolve().parent
    manifests = json.loads((here / "versoes.json").read_text(encoding="utf-8"))
    version = manifests.get(key)
    if version is None:
        raise SystemExit("Este interface.u nao corresponde a nenhuma das duas bases TimeZoneV2 deste patch.")
    result = bytearray(original)
    struct.pack_into("<I", result, 24, version["export_table"])
    result.extend((here / version["delta"]).read_bytes())
    if hashlib.sha256(result).hexdigest() != version["result"]:
        raise SystemExit("Falha na verificacao do patch. Nenhum arquivo foi gravado.")
    output = source.with_name("interface-timezone-v2-ajustado.u")
    with output.open("xb") as stream:
        stream.write(result)
    print("Arquivo gerado:", output)
    print("O interface.u original foi preservado.")

if __name__ == "__main__":
    main()
