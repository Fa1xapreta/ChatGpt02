@echo off
where py >nul 2>nul
if errorlevel 1 (
    python "%~dp0aplicar.py" "%~1"
) else (
    py -3 "%~dp0aplicar.py" "%~1"
)
pause
