@echo off
setlocal
cd /d "%~dp0System" || exit /b 1
if not exist "UCC.exe" (
  echo Coloque este BAT na pasta Interlude do compilador, ao lado da pasta System.
  exit /b 1
)
for %%I in (6060 6061 6062) do (
  if not exist "..\Interface\Textures\SBAbnormal\fx_m_t%%I.dds" (
    echo Arquivo faltando: ..\Interface\Textures\SBAbnormal\fx_m_t%%I.dds
    exit /b 1
  )
)
if exist "Interface.u" (
  copy /b /y "Interface.u" "Interface-antes-marcador.bak" >nul || exit /b 1
  del "Interface.u" || exit /b 1
)
UCC.exe make -NoBind
if errorlevel 1 goto failed
if not exist "Interface.u" goto failed
echo Compilado: "%CD%\Interface.u"
exit /b 0
:failed
if exist "Interface-antes-marcador.bak" copy /b /y "Interface-antes-marcador.bak" "Interface.u" >nul
echo A compilacao falhou. Consulte "%CD%\UCC.log".
exit /b 1
