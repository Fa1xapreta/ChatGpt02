// Port of Classic LineageEffect.a_u019_abno_target, preserving its five particle layers.
// Original DXT1 pixels; the shared twist_m02 mesh is provided by the Interlude client.
class AutoFarmTargetEffect extends Emitter;
var bool MarkerVisible;

#exec TEXTURE IMPORT NAME=fx_m_t6062 FILE="../Interface/Textures/SBAbnormal/fx_m_t6062.dds" GROUP=SBAbnormal MIPS=ON
#exec TEXTURE IMPORT NAME=fx_m_t6061 FILE="../Interface/Textures/SBAbnormal/fx_m_t6061.dds" GROUP=SBAbnormal MIPS=ON
#exec TEXTURE IMPORT NAME=fx_m_t6060 FILE="../Interface/Textures/SBAbnormal/fx_m_t6060.dds" GROUP=SBAbnormal MIPS=ON

static function bool IsValidOwner(Pawn character)
{
    return character!=None && !character.bDeleteMe;
}

// Native PHYS_Trailer follows Owner every engine frame, as the original
// Interlude skill emitters do. UI polling controls visibility only; it must
// never fight native movement by periodically assigning world positions.
function UpdateMarker(bool wanted)
{
 local Pawn character;
 local vector position;
 character=Pawn(Owner);
 if(!wanted || character==None || character.bDeleteMe)
 {
  if(MarkerVisible || !bHidden)
  {
   bHidden=True;SetDrawType(DT_None);SetDisabled(True);
   SetPhysics(PHYS_None);
  }
  MarkerVisible=False;
  return;
 }
 if(!MarkerVisible)
 {
  TrailerPrePivot.X=0.0;TrailerPrePivot.Y=0.0;
  TrailerPrePivot.Z=character.CollisionHeight+28.0;
  position=character.Location+TrailerPrePivot;
  SetLocation(position);
  SetPhysics(PHYS_Trailer);
  SetDisabled(False);SetDrawType(DT_Particle);bHidden=False;
  MarkerVisible=True;
 }
}

function ReleaseMarker()
{
 bHidden=True;SetDrawType(DT_None);SetDisabled(True);MarkerVisible=False;
 SetPhysics(PHYS_None);
 Kill();LifeSpan=0.1;Destroy();
}

defaultproperties
{
    Begin Object Class=SpriteEmitter Name=ClassicTargetLayer0
        Disabled=True
        UseDirectionAs=PTDU_Up
        ColorScale(0)=(RelativeTime=0.00000000,Color=(B=255,G=255,R=255,A=255))
        ColorScale(1)=(RelativeTime=1.00000000,Color=(B=255,G=255,R=255,A=255))
        ColorMultiplierRange=(X=(Min=1.00000000,Max=1.00000000),Y=(Min=0.47799999,Max=0.47799999),Z=(Min=0.39600000,Max=0.39600000))
        Opacity=0.80000001
        FadeOutStartTime=0.40000001
        FadeOut=True
        FadeInEndTime=0.20000000
        FadeIn=True
        MaxParticles=2
        Name="Sprite1"
        UniformSize=True
        StartSizeRange=(X=(Min=6.00000000,Max=6.00000000),Y=(Min=6.00000000,Max=6.00000000),Z=(Min=6.00000000,Max=6.00000000))
        InitialParticlesPerSecond=1000.00000000
        AutomaticInitialSpawning=False
        DrawStyle=PTDS_Brighten
        Texture=Texture'Interface.SBAbnormal.fx_m_t6061'
        LifetimeRange=(Min=1.00000000,Max=1.00000000)
        StartVelocityRange=(X=(Min=0.00000000,Max=0.00000000),Y=(Min=0.00000000,Max=0.00000000),Z=(Min=0.04000000,Max=0.04000000))
    End Object
    Emitters(0)=SpriteEmitter'Interface.AutoFarmTargetEffect.ClassicTargetLayer0'
    Begin Object Class=SpriteEmitter Name=ClassicTargetLayer1
        Disabled=True
        UseDirectionAs=PTDU_Up
        ColorScale(0)=(RelativeTime=0.00000000,Color=(B=255,G=255,R=255,A=255))
        ColorScale(1)=(RelativeTime=1.00000000,Color=(B=255,G=255,R=255,A=255))
        ColorMultiplierRange=(X=(Min=1.00000000,Max=1.00000000),Y=(Min=0.41299999,Max=0.41299999),Z=(Min=0.27500001,Max=0.27500001))
        Opacity=0.47000000
        FadeOutStartTime=0.31000000
        FadeOut=True
        FadeInEndTime=0.23000000
        FadeIn=True
        Name="Sprite2"
        SpinParticles=True
        UseSizeScale=True
        UseRegularSizeScale=False
        UniformSize=True
        SizeScale(0)=(RelativeTime=0.00000000,RelativeSize=0.60000002)
        SizeScale(1)=(RelativeTime=0.08000000,RelativeSize=0.89999998)
        SizeScale(2)=(RelativeTime=1.00000000,RelativeSize=1.20000005)
        StartSizeRange=(X=(Min=6.00000000,Max=6.00000000),Y=(Min=6.00000000,Max=6.00000000),Z=(Min=6.00000000,Max=6.00000000))
        InitialParticlesPerSecond=20.00000000
        AutomaticInitialSpawning=False
        DrawStyle=PTDS_Brighten
        Texture=Texture'Interface.SBAbnormal.fx_m_t6061'
        LifetimeRange=(Min=1.00000000,Max=1.00000000)
        StartVelocityRange=(X=(Min=0.00000000,Max=0.00000000),Y=(Min=0.00000000,Max=0.00000000),Z=(Min=0.04000000,Max=0.04000000))
    End Object
    Emitters(1)=SpriteEmitter'Interface.AutoFarmTargetEffect.ClassicTargetLayer1'
    Begin Object Class=SpriteEmitter Name=ClassicTargetLayer2
        Disabled=True
        UseDirectionAs=PTDU_Up
        ColorScale(0)=(RelativeTime=0.00000000,Color=(B=255,G=255,R=255,A=255))
        ColorScale(1)=(RelativeTime=1.00000000,Color=(B=255,G=255,R=255,A=255))
        ColorMultiplierRange=(X=(Min=1.00000000,Max=1.00000000),Y=(Min=0.51099998,Max=0.51099998),Z=(Min=0.41400000,Max=0.41400000))
        Opacity=0.30000001
        FadeOutStartTime=0.34999999
        FadeOut=True
        FadeInEndTime=0.20000000
        FadeIn=True
        MaxParticles=3
        Name="Bow"
        SpinCCWorCW=(X=0.00000000,Y=0.50000000,Z=0.50000000)
        SpinsPerSecondRange=(X=(Min=0.20000000,Max=0.20000000),Y=(Min=0.00000000,Max=0.00000000),Z=(Min=0.00000000,Max=0.00000000))
        StartSpinRange=(X=(Min=1.00000000,Max=1.00000000),Y=(Min=0.00000000,Max=0.00000000),Z=(Min=0.00000000,Max=0.00000000))
        UseRegularSizeScale=False
        UniformSize=True
        SizeScale(0)=(RelativeTime=0.00000000,RelativeSize=0.80000001)
        SizeScale(1)=(RelativeTime=0.31999999,RelativeSize=1.00000000)
        StartSizeRange=(X=(Min=6.00000000,Max=6.00000000),Y=(Min=6.00000000,Max=6.00000000),Z=(Min=6.00000000,Max=6.00000000))
        InitialParticlesPerSecond=1000.00000000
        AutomaticInitialSpawning=False
        Texture=Texture'Interface.SBAbnormal.fx_m_t6060'
        LifetimeRange=(Min=1.00000000,Max=1.00000000)
        StartVelocityRange=(X=(Min=0.00000000,Max=0.00000000),Y=(Min=0.00000000,Max=0.00000000),Z=(Min=0.04000000,Max=0.04000000))
    End Object
    Emitters(2)=SpriteEmitter'Interface.AutoFarmTargetEffect.ClassicTargetLayer2'
    Begin Object Class=MeshEmitter Name=ClassicTargetLayer3
        Disabled=True
        StaticMesh=StaticMesh'LineageEffectsStaticmeshes.etc.twist_m02'
        UseMeshBlendMode=False
        RenderTwoSided=True
        ColorScale(0)=(RelativeTime=0.00000000,Color=(B=255,G=255,R=255,A=255))
        ColorScale(1)=(RelativeTime=1.00000000,Color=(B=255,G=255,R=255,A=255))
        ColorMultiplierRange=(X=(Min=1.00000000,Max=1.00000000),Y=(Min=0.75000000,Max=0.75000000),Z=(Min=0.76999998,Max=0.76999998))
        Opacity=0.04000000
        FadeOutStartTime=0.40000001
        FadeOut=True
        FadeInEndTime=0.20000000
        FadeIn=True
        Name="Mesh"
        StartLocationOffset=(X=0.00000000,Y=0.00000000,Z=-4.50000000)
        SpinParticles=True
        SpinsPerSecondRange=(X=(Min=0.50000000,Max=0.50000000),Y=(Min=0.00000000,Max=0.00000000),Z=(Min=0.00000000,Max=0.00000000))
        StartSpinRange=(X=(Min=1.00000000,Max=1.00000000),Y=(Min=0.00000000,Max=0.00000000),Z=(Min=0.00000000,Max=0.00000000))
        UseSizeScale=True
        UseRegularSizeScale=False
        SizeScale(0)=(RelativeTime=0.00000000,RelativeSize=0.50000000)
        SizeScale(1)=(RelativeTime=0.20999999,RelativeSize=0.80000001)
        SizeScale(2)=(RelativeTime=1.00000000,RelativeSize=1.00000000)
        StartSizeRange=(X=(Min=0.01980000,Max=0.07080000),Y=(Min=0.01980000,Max=0.07080000),Z=(Min=0.01980000,Max=0.07080000))
        InitialParticlesPerSecond=10.00000000
        AutomaticInitialSpawning=False
        LifetimeRange=(Min=1.00000000,Max=1.00000000)
    End Object
    Emitters(3)=MeshEmitter'Interface.AutoFarmTargetEffect.ClassicTargetLayer3'
    Begin Object Class=SpriteEmitter Name=ClassicTargetLayer4
        Disabled=True
        UseDirectionAs=PTDU_Up
        ColorScale(0)=(RelativeTime=0.00000000,Color=(B=255,G=255,R=255,A=255))
        ColorScale(1)=(RelativeTime=1.00000000,Color=(B=255,G=255,R=255,A=255))
        Opacity=0.50000000
        FadeOutStartTime=0.54000002
        FadeOut=True
        FadeInEndTime=0.22000000
        FadeIn=True
        MaxParticles=5
        Name="Light"
        UniformSize=True
        StartSizeRange=(X=(Min=6.00000000,Max=6.00000000),Y=(Min=6.00000000,Max=6.00000000),Z=(Min=6.00000000,Max=6.00000000))
        InitialParticlesPerSecond=1000.00000000
        AutomaticInitialSpawning=False
        DrawStyle=PTDS_Brighten
        Texture=Texture'Interface.SBAbnormal.fx_m_t6062'
        TextureUSubdivisions=8
        TextureVSubdivisions=8
        BlendBetweenSubdivisions=True
        SubdivisionEnd=64
        LifetimeRange=(Min=1.00000000,Max=1.00000000)
        StartVelocityRange=(X=(Min=0.00000000,Max=0.00000000),Y=(Min=0.00000000,Max=0.00000000),Z=(Min=0.04000000,Max=0.04000000))
    End Object
    Emitters(4)=SpriteEmitter'Interface.AutoFarmTargetEffect.ClassicTargetLayer4'
    AutoDestroy=False
    AutoReset=False
    bNoDelete=False
    bStatic=False
    bStasis=False
    bAlwaysTick=False
    bTrailerPrePivot=True
    bTrailerSameRotation=False
    bTrailerAllowRotation=False
    bTrailerNoOwnerDestroy=False
    bHidden=True
    DrawType=DT_None
    RemoteRole=ROLE_None
    bCollideActors=False
    bCollideWorld=False
    bBlockActors=False
    bBlockPlayers=False
    bProjTarget=False
    Physics=PHYS_None
}
