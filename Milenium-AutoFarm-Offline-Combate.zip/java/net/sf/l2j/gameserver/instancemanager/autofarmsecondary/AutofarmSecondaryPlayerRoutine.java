package net.sf.l2j.gameserver.instancemanager.autofarmsecondary;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.ai.CtrlIntention;
import net.sf.l2j.gameserver.instancemanager.offlinefarm.OfflineFarm;
import net.sf.l2j.gameserver.geoengine.PathFinding;
import net.sf.l2j.gameserver.handler.IItemHandler;
import net.sf.l2j.gameserver.handler.ItemHandler;
import net.sf.l2j.gameserver.model.L2Object;
import net.sf.l2j.gameserver.model.L2Skill;
import net.sf.l2j.gameserver.model.L2WorldRegion;
import net.sf.l2j.gameserver.model.actor.L2Character;
import net.sf.l2j.gameserver.model.actor.L2Summon;
import net.sf.l2j.gameserver.model.actor.instance.L2ChestInstance;
import net.sf.l2j.gameserver.model.actor.instance.L2MonsterInstance;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.model.zone.ZoneId;
import net.sf.l2j.gameserver.network.serverpackets.ActionFailed;
import net.sf.l2j.gameserver.templates.skills.L2SkillType;
import net.sf.l2j.gameserver.util.Util;
import net.sf.l2j.util.Rnd;

public class AutofarmSecondaryPlayerRoutine
{
    private static final long CAST_STUCK_TIMEOUT = 15000L;

    private final L2PcInstance player;

    private volatile boolean stopped;
    private L2Character committedTarget;
    private long castingSince;

    public AutofarmSecondaryPlayerRoutine(L2PcInstance player)
    {
        this.player = player;
    }

    public void start()
    {
        AutofarmSecondaryManager.INSTANCE.startFarm(player);
    }

    public void stop()
    {
        AutofarmSecondaryManager.INSTANCE.stopFarm(player);
    }

    public void executeRoutine()
    {
        if (stopped || player == null)
            return;

        if (!player.isOnline())
        {
            AutofarmSecondaryManager.INSTANCE.onPlayerLogout(player);
            return;
        }

        if (!player.isSecondaryAutoFarm())
        {
            stop();
            return;
        }

        if (player.getLevel() < 20
            || player.isPveModeActive()
            || player.isInsideZone(ZoneId.PEACE)
            || player.isInsideZone(ZoneId.OLYMPIAD)
            || player.isDead()
            || player.isAlikeDead())
        {
            stop();
            return;
        }

        if (player.isNoBuffProtected()
            && player.getAllEffects().length <= 8)
        {
            player.sendMessage(
                "Voce nao possui buffs suficientes para usar o AutoFarm."
            );

            stop();
            return;
        }

        if (player.isCastingNow())
        {
            if (castingSince == 0L)
                castingSince = System.currentTimeMillis();

            if (System.currentTimeMillis() - castingSince
                >= CAST_STUCK_TIMEOUT)
            {
                resetStuckState();
                castingSince = 0L;
            }

            return;
        }

        castingSince = 0L;

        if (!player.isAttackingNow())
            calculatePotions();

        if (useSelfSkill())
            return;

        targetEligibleCreature();

        final L2Character target = getCurrentTarget();

        if (target == null || target.isDead())
            return;

        attackWithSummon(target);

        if (useAppropriateSpell())
            return;

        physicalAttack();
    }

    private boolean useSelfSkill()
    {
        for (Integer skillId :
            orderedSkills(player.getSecondaryAutoFarmSkills("self")))
        {
            final L2Skill skill = getConfiguredSkill(skillId);

            if (skill == null || player.getFirstEffect(skillId) != null)
                continue;

            if (useMagicSkill(skill, true))
                return true;
        }

        return false;
    }

    private boolean useAppropriateSpell()
    {
        final L2Skill healSkill = nextAvailableSkill(
            player.getSecondaryAutoFarmSkills("heal"),
            AutofarmSecondarySpellType.Heal
        );

        if (healSkill != null)
            return useMagicSkill(healSkill, true);

        final L2Skill chanceSkill = nextAvailableSkill(
            player.getSecondaryAutoFarmSkills("chance"),
            AutofarmSecondarySpellType.Chance
        );

        if (chanceSkill != null)
            return useMagicSkill(chanceSkill, false);

        final L2Skill attackSkill = nextAvailableSkill(
            player.getSecondaryAutoFarmSkills("attack"),
            AutofarmSecondarySpellType.Attack
        );

        if (attackSkill != null)
            return useMagicSkill(attackSkill, false);

        return false;
    }

    private boolean isFighterMode()
    {
        return "Fighter".equalsIgnoreCase(
            player.getSecondaryAutoFarmFarmType()
        );
    }

    private L2Skill nextAvailableSkill(
        List<Integer> skillIds,
        AutofarmSecondarySpellType spellType)
    {
        for (Integer skillId : orderedSkills(skillIds))
        {
            final L2Skill skill = getConfiguredSkill(skillId);

            if (skill == null)
                continue;

            if (skill.getSkillType() == L2SkillType.SIGNET
                || skill.getSkillType() == L2SkillType.SIGNET_CASTTIME)
            {
                continue;
            }

            if (!player.checkDoCastConditions(skill))
                continue;

            if (spellType == AutofarmSecondarySpellType.Chance)
            {
                final L2Character target = getCurrentTarget();

                if (target == null || target.getFirstEffect(skillId) != null)
                    continue;

                if (Rnd.get(100)
                    >= player.getSecondaryAutoFarmChancePercent())
                {
                    continue;
                }

                return skill;
            }

            if (spellType == AutofarmSecondarySpellType.Heal)
            {
                if (getHpPercentage()
                    > player.getSecondaryAutoFarmHealPercent())
                {
                    continue;
                }

                return skill;
            }

            return skill;
        }

        return null;
    }

    private L2Skill getConfiguredSkill(int skillId)
    {
        return player.getKnownSkill(skillId);
    }

    private List<Integer> orderedSkills(List<Integer> skillIds)
    {
        final List<Integer> ordered = new ArrayList<>(skillIds);

        if (player.isSecondaryAutoFarmRandomSkills())
            Collections.shuffle(ordered);

        return ordered;
    }

    private double getHpPercentage()
    {
        return player.getCurrentHp() * 100.0 / player.getMaxHp();
    }

    private double getMpPercentage()
    {
        return player.getCurrentMp() * 100.0 / player.getMaxMp();
    }

    private void calculatePotions()
    {
        if (getMpPercentage() < player.getSecondaryAutoFarmMpPercent())
            forceUseItem(728);
    }

    private void forceUseItem(int itemId)
    {
        final ItemInstance potion =
            player.getInventory().getItemByItemId(itemId);

        if (potion == null)
            return;

        final IItemHandler handler =
            ItemHandler.getInstance().getItemHandler(potion.getEtcItem());

        if (handler != null)
            handler.useItem(player, potion, false);
    }

    private boolean useMagicSkill(L2Skill skill, boolean forceOnSelf)
    {
        if (skill == null)
            return false;

        if (player.isDead()
            || player.isAlikeDead()
            || player.isCastingNow()
            || player.isOutOfControl())
        {
            return false;
        }

        if (skill.getSkillType() == L2SkillType.SIGNET
            || skill.getSkillType() == L2SkillType.SIGNET_CASTTIME)
        {
            return false;
        }

        if (skill.getSkillType() == L2SkillType.RECALL
            && !Config.KARMA_PLAYER_CAN_TELEPORT
            && player.getKarma() > 0)
        {
            return false;
        }

        if (skill.isToggle() && player.isMounted())
            return false;

        return castSpellWithAppropriateTarget(skill, forceOnSelf);
    }

    private boolean castSpellWithAppropriateTarget(
        L2Skill skill,
        boolean forceOnSelf)
    {
        if (!forceOnSelf)
        {
            player.useMagic(skill, false, false);
            return true;
        }

        final L2Object oldTarget = player.getTarget();

        try
        {
            player.setTarget(player);
            player.useMagic(skill, false, false);
            return true;
        }
        finally
        {
            player.setTarget(oldTarget);
        }
    }

    private void physicalAttack()
    {
        final L2Character target = getCurrentTarget();

        if (target == null)
            return;

        if (target.isDead()
            || !target.isVisible()
            || !target.isAutoAttackable(player))
        {
            clearTarget();
            return;
        }

        if (!PathFinding.getInstance().canSeeTarget(player, target))
        {
            if (player.isSecondaryAutoFarmRunCloseUp()
                && PathFinding.getInstance().canMoveToTarget(
                    player.getX(),
                    player.getY(),
                    player.getZ(),
                    target.getX(),
                    target.getY(),
                    target.getZ()))
            {
                player.getAI().setIntention(
                    CtrlIntention.FOLLOW,
                    target
                );
            }
            else
            {
                clearTarget();
            }

            return;
        }

        if ((!player.isMageClass() || isFighterMode() || OfflineFarm.getInstance().isDetachedSession(player))
            && !player.isCastingNow())
        {
            player.getAI().setIntention(
                CtrlIntention.ATTACK,
                target
            );

            player.onActionRequest();
        }
    }

    private void targetEligibleCreature()
    {
        final String targetMode =
            player.getSecondaryAutoFarmTargetMode();

        final boolean allowPlayers =
            "pvp".equalsIgnoreCase(targetMode)
            || "both".equalsIgnoreCase(targetMode);

        final boolean allowMonsters =
            !"pvp".equalsIgnoreCase(targetMode);

        if (allowPlayers)
        {
            final L2PcInstance attacker = getDefensivePlayerTarget();

            if (attacker != null)
            {
                setCommittedTarget(attacker);
                return;
            }
        }

        if (!allowMonsters)
        {
            clearTarget();
            return;
        }

        final List<L2MonsterInstance> targets = getKnownMonstersInRadius(
            player,
            player.getSecondaryAutoFarmRadius(),
            creature -> isValidFarmTarget(creature)
        );

        if (targets.isEmpty())
        {
            clearTarget();
            return;
        }

        final L2MonsterInstance assistedLeaderTarget =
            getPartyLeaderTarget(targets);

        if (assistedLeaderTarget != null)
        {
            setCommittedTarget(assistedLeaderTarget);
            return;
        }

        final L2MonsterInstance assistedMobTarget =
            getAssistMobTarget(targets);

        if (assistedMobTarget != null)
        {
            setCommittedTarget(assistedMobTarget);
            return;
        }

        if (committedTarget instanceof L2MonsterInstance
            && targets.contains(committedTarget))
        {
            player.setTarget(committedTarget);
            return;
        }

        final L2MonsterInstance closestTarget = targets.stream()
            .min((first, second) -> Double.compare(
                player.getDistanceSq(first),
                player.getDistanceSq(second)
            ))
            .orElse(null);

        if (closestTarget == null)
        {
            clearTarget();
            return;
        }

        setCommittedTarget(closestTarget);
    }

    private L2PcInstance getDefensivePlayerTarget()
    {
        return player.getAttackByList().stream()
            .filter(L2PcInstance.class::isInstance)
            .map(L2PcInstance.class::cast)
            .filter(this::isValidDefensivePlayerTarget)
            .min((first, second) -> Double.compare(
                player.getDistanceSq(first),
                player.getDistanceSq(second)
            ))
            .orElse(null);
    }

    private boolean isValidDefensivePlayerTarget(L2PcInstance target)
    {
        return target != null
            && target != player
            && target.isOnline()
            && !target.isDead()
            && !target.isAlikeDead()
            && target.isVisible()
            && Util.checkIfInRange(
                player.getSecondaryAutoFarmRadius(),
                player,
                target,
                true
            )
            && target.isAutoAttackable(player)
            && PathFinding.getInstance().canMoveToTarget(
                player.getX(),
                player.getY(),
                player.getZ(),
                target.getX(),
                target.getY(),
                target.getZ()
            )
            && isInsideStartLocation(target);
    }

    private boolean isValidFarmTarget(L2MonsterInstance creature)
    {
        return respectsOtherHunters(creature)
            && PathFinding.getInstance().canMoveToTarget(
                player.getX(),
                player.getY(),
                player.getZ(),
                creature.getX(),
                creature.getY(),
                creature.getZ()
            )
            && !player.ignoredMonsterContain(creature.getNpcId())
            && !creature.isAgathion()
            && !creature.isRaidMinion()
            && !creature.isRaid()
            && !creature.isDead()
            && !(creature instanceof L2ChestInstance)
            && isInsideStartLocation(creature);
    }

    private boolean respectsOtherHunters(L2MonsterInstance monster)
    {
        if (!player.isAntiKsProtected())
            return true;

        L2Character victim = monster.getMostHated();

        if (victim == null
            && monster.getTarget() instanceof L2Character)
        {
            victim = (L2Character) monster.getTarget();
        }

        final L2PcInstance owner =
            victim == null ? null : victim.getActingPlayer();

        return owner == null
            || owner == player
            || (player.getParty() != null
                && player.getParty() == owner.getParty());
    }

    private void attackWithSummon(L2Character target)
    {
        final L2Summon summon = player.getPet();

        if (!player.isSummonAttack()
            || summon == null
            || target == null
            || summon.isDead()
            || summon.isAlikeDead()
            || summon.isCastingNow()
            || !target.isAutoAttackable(summon)
            || !PathFinding.getInstance().canSeeTarget(summon, target))
        {
            return;
        }

        if (summon.getTarget() == target && summon.isAttackingNow())
            return;

        summon.setTarget(target);

        summon.getAI().setIntention(
            CtrlIntention.ATTACK,
            target
        );
    }

    L2PcInstance getPlayer()
    {
        return player;
    }

    private L2MonsterInstance getPartyLeaderTarget(
        List<L2MonsterInstance> targets)
    {
        if (!player.isSecondaryAutoFarmAssistLeader()
            || player.getParty() == null)
        {
            return null;
        }

        final L2PcInstance leader = player.getParty().getLeader();

        if (leader == null
            || leader == player
            || leader.isDead()
            || leader.isAlikeDead())
        {
            return null;
        }

        final L2Object leaderTarget = leader.getTarget();

        if (!(leaderTarget instanceof L2MonsterInstance))
            return null;

        final L2MonsterInstance monster =
            (L2MonsterInstance) leaderTarget;

        return targets.contains(monster) ? monster : null;
    }

    private L2MonsterInstance getAssistMobTarget(
        List<L2MonsterInstance> targets)
    {
        if (!player.isSecondaryAutoFarmAssistMobs())
            return null;

        return targets.stream()
            .filter(monster ->
                monster.containsTarget(player)
                || monster.getMostHated() == player)
            .min((first, second) -> Double.compare(
                player.getDistanceSq(first),
                player.getDistanceSq(second)
            ))
            .orElse(null);
    }

    private void setCommittedTarget(L2Character target)
    {
        committedTarget = target;
        player.setTarget(target);
    }

    private boolean isInsideStartLocation(L2Character creature)
    {
        if (!player.isSecondaryAutoFarmKeepLocation())
            return true;

        final long dx =
            creature.getX() - player.getSecondaryAutoFarmStartX();

        final long dy =
            creature.getY() - player.getSecondaryAutoFarmStartY();

        final long dz =
            creature.getZ() - player.getSecondaryAutoFarmStartZ();

        final long radius = player.getSecondaryAutoFarmRadius();

        return dx * dx + dy * dy + dz * dz <= radius * radius;
    }

    private static List<L2MonsterInstance> getKnownMonstersInRadius(
        L2PcInstance player,
        int radius,
        Function<L2MonsterInstance, Boolean> condition)
    {
        final L2WorldRegion region = player.getWorldRegion();

        if (region == null)
            return Collections.emptyList();

        final List<L2MonsterInstance> result = new ArrayList<>();

        for (L2WorldRegion surroundingRegion :
            region.getSurroundingRegions())
        {
            for (L2Object object :
                surroundingRegion.getVisibleObjects().values())
            {
                if (!(object instanceof L2MonsterInstance))
                    continue;

                if (!Util.checkIfInRange(radius, player, object, true))
                    continue;

                final L2MonsterInstance monster =
                    (L2MonsterInstance) object;

                if (!condition.apply(monster))
                    continue;

                result.add(monster);
            }
        }

        return result;
    }

    private L2MonsterInstance getMonsterTarget()
    {
        return player.getTarget() instanceof L2MonsterInstance
            ? (L2MonsterInstance) player.getTarget()
            : null;
    }

    private L2Character getCurrentTarget()
    {
        return player.getTarget() instanceof L2Character
            ? (L2Character) player.getTarget()
            : null;
    }

    private void clearTarget()
    {
        committedTarget = null;
        player.setTarget(null);

        player.getAI().setIntention(CtrlIntention.ACTIVE);
        player.sendPacket(ActionFailed.STATIC_PACKET);
    }

    private void resetStuckState()
    {
        committedTarget = null;

        player.abortCast();
        player.abortAttack();
        player.setTarget(null);

        player.getAI().setIntention(CtrlIntention.ACTIVE);
        player.sendPacket(ActionFailed.STATIC_PACKET);

        final L2Summon summon = player.getPet();

        if (summon != null)
        {
            summon.abortCast();
            summon.abortAttack();
            summon.setTarget(null);

            summon.getAI().setIntention(CtrlIntention.ACTIVE);
        }
    }

    public void reset()
    {
        stopped = true;
        castingSince = 0L;
        resetStuckState();
    }
}