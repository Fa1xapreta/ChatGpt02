package net.sf.l2j.gameserver.instancemanager.offlinefarm;

import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.l2j.gameserver.ThreadPoolManager;
import net.sf.l2j.gameserver.ai.CtrlIntention;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.geoengine.GeoData;
import net.sf.l2j.gameserver.geoengine.PathFinding;
import net.sf.l2j.gameserver.instancemanager.ZoneManager;
import net.sf.l2j.gameserver.model.Location;
import net.sf.l2j.gameserver.model.zone.L2ZoneType;
import net.sf.l2j.gameserver.model.zone.type.L2ChaoticFreeZone;
import net.sf.l2j.gameserver.model.zone.type.L2ChaoticSelfZone;
import net.sf.l2j.gameserver.model.zone.type.L2PartyFarmZone;
import net.sf.l2j.gameserver.model.zone.type.L2PeaceZone;
import net.sf.l2j.gameserver.model.zone.type.L2TownZone;
import net.sf.l2j.gameserver.instancemanager.autofarm.AutofarmManager;
import net.sf.l2j.gameserver.instancemanager.autofarmsecondary.AutofarmSecondaryManager;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.model.item.kind.Item;
import net.sf.l2j.gameserver.model.zone.ZoneId;
import net.sf.l2j.gameserver.network.L2GameClient;
import net.sf.l2j.gameserver.network.serverpackets.ExShowScreenMessage;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;

public final class OfflineFarm
{
    private static final Logger LOG = Logger.getLogger(OfflineFarm.class.getName());
    private static final Path REPORTS = Paths.get("data", "offlinefarm", "reports");
    private static final ZoneId[] FORBIDDEN = { ZoneId.PEACE, ZoneId.FLAG_AREA, ZoneId.FLAG_AREA_SELF, ZoneId.PARTY_FARM };
    private static final OfflineFarm INSTANCE = new OfflineFarm();

    private final Map<Integer, Session> sessions = new ConcurrentHashMap<>();
    private final Map<String, Session> accounts = new ConcurrentHashMap<>();
    private final boolean enabled;
    private volatile boolean shuttingDown;
    private final int ticketId, minutes, minLevel, maxLevel, maxSessions, respawnRadius, maxZ, respawnSeconds;

    private OfflineFarm()
    {
        final Properties p = new Properties();
        final Path config = Paths.get("config", "custom", "OfflineFarm.properties");
        if (Files.isRegularFile(config))
        {
            try (java.io.InputStream input = Files.newInputStream(config))
            {
                p.load(input);
            }
            catch (IOException e)
            {
                LOG.log(Level.WARNING, "Could not load OfflineFarm.properties.", e);
                p.clear();
            }
        }
        ticketId = number(p, "TicketItemId", 0, 0, Integer.MAX_VALUE);
        minutes = number(p, "MinutesPerTicket", 60, 1, 1440);
        minLevel = number(p, "MinLevel", 20, 1, 100);
        maxLevel = number(p, "MaxLevel", 100, minLevel, 100);
        maxSessions = number(p, "MaxSessions", 100, 1, 1000);
        respawnRadius = number(p, "RespawnRadius", 250, 32, 3000);
        maxZ = number(p, "MaxZDifference", 300, 1, 1500);
        respawnSeconds = number(p, "RespawnSeconds", 300, 1, 3600);
        enabled = Boolean.parseBoolean(p.getProperty("Enabled", "false").trim()) && ticketId > 0;
        if (enabled)
            ThreadPoolManager.getInstance().scheduleGeneralAtFixedRate(this::tick, 1000, 1000);
    }

    public static OfflineFarm getInstance()
    {
        return INSTANCE;
    }

    private static int number(Properties p, String key, int fallback, int min, int max)
    {
        try
        {
            return Math.max(min, Math.min(max, Integer.parseInt(p.getProperty(key, String.valueOf(fallback)).trim())));
        }
        catch (NumberFormatException e)
        {
            return fallback;
        }
    }

    public boolean handle(L2PcInstance player, String command)
    {
        if ("offlinefarm status".equals(command))
            sendStatus(player);
        else if ("offlinefarm menu".equals(command))
            showMenu(player);
        else if ("offlinefarm start".equals(command))
            start(player);
        else if ("offlinefarm disconnect".equals(command))
        {
            if (!disconnect(player))
                player.sendMessage("Offline Farm: nenhuma sessao ativa ou desconexao indisponivel.");
        }
        else if ("offlinefarm stop".equals(command))
            stopOnline(player);
        else
            return false;
        return true;
    }

    private void sendStatus(L2PcInstance player)
    {
        final Session session = sessions.get(player.getObjectId());
        final boolean active = session != null && session.running;
        final long seconds = active ? Math.max(0, (session.until - System.currentTimeMillis() + 999) / 1000) : 0;
        player.sendPacket(new ExShowScreenMessage("CustomEvent=OfflineFarmV2|" + (active ? "1|" : "0|")
            + seconds + "|" + (player.isVip() ? "1" : "0"), 1));
    }

    private void showMenu(L2PcInstance player)
    {
        sendStatus(player);
        final Session session = sessions.get(player.getObjectId());
        final StringBuilder body = new StringBuilder("<center><font color=LEVEL>AutoFarm Offline</font></center><br>");
        if (session != null && session.running)
        {
            body.append("Sessao ativa. Acompanhe o tempo no relogio do AutoHunting.<br>");
            body.append(button("Continuar e desconectar", "disconnect"));
            body.append(button("Encerrar sessao", "stop"));
        }
        else
        {
            final String denied = rejection(player);
            body.append("Custo: 1 ticket (ID ").append(ticketId).append(").<br1>Duracao: ").append(minutes)
                .append(" min por sessao.<br>Usa as opcoes do AutoFarm atual. Ative primeiro e, quando quiser sair, use Continuar e desconectar.<br>");
            if (denied != null)
                body.append("<font color=FF7777>").append(denied).append("</font>");
            else
                body.append(button("Ativar Offline Farm", "start"));
        }
        sendHtml(player, body.toString());
    }

    private static String button(String caption, String command)
    {
        return "<center><button value=\"" + caption + "\" action=\"bypass -h offlinefarm " + command
            + "\" width=160 height=25 back=\"L2UI_CH3.bigbutton2_down\" fore=\"L2UI_CH3.bigbutton2\"></center>";
    }

    private String rejection(L2PcInstance player)
    {
        if (!enabled || shuttingDown || ItemTable.getInstance().getTemplate(ticketId) == null)
            return "Offline Farm indispon\u00edvel.";
        if (!validLocation(player))
            return "Offline Farm bloqueado em zonas de paz, flag e Party Farm.";
        if (player.getLevel() < minLevel || player.getLevel() > maxLevel || player.isAlikeDead()
            || player.isInCombat() || player.getPvpFlag() != 0 || player.isCastingNow() || player.isAttackingNow()
            || player.isInParty() || player.isInStoreMode() || player.isInOlympiadMode() || player.inObserverMode()
            || player.isInDuel() || player.isInArenaEvent() || player.isInFunEvent() || player.isFishing()
            || player.isLocked() || player.isMounted() || player.isPveModeActive() || player.isSitting()
            || player.isTeleporting() || player.getKarma() != 0 || player.getVehicle() != null
            || player.isCursedWeaponEquipped() || player.isFestivalParticipant() || player.isProcessingRequest()
            || player.getActiveTradeList() != null || player.getAppearance().getInvisible() || player.isInvul())
            return "Saia de combate, grupos e eventos para ativar.";
        if (player.isNoBuffProtected() && player.getAllEffects().length <= 8)
            return "A prote\u00e7\u00e3o de buffs do seu AutoFarm est\u00e1 ativa e faltam buffs.";
        if (AutofarmManager.INSTANCE.isAutofarming(player) || AutofarmSecondaryManager.INSTANCE.isAutofarming(player))
            return "Desative o AutoFarm online antes de iniciar.";
        if (player.getInventory().getItemByItemId(ticketId) == null)
            return "Voc\u00ea precisa do ticket Offline Farm.";
        return null;
    }

    private static boolean validLocation(L2PcInstance player)
    {
        for (ZoneId zone : FORBIDDEN)
        {
            if (player.isInsideZone(zone))
                return false;
        }
        return true;
    }

    private static boolean validSpawnZone(int x, int y, int z)
    {
        for (L2ZoneType zone : ZoneManager.getInstance().getZones(x, y, z))
        {
            if (zone instanceof L2PeaceZone || zone instanceof L2ChaoticFreeZone
                || zone instanceof L2ChaoticSelfZone || zone instanceof L2PartyFarmZone
                || (zone instanceof L2TownZone && ((L2TownZone) zone).isPeaceZone()))
                return false;
        }
        return true;
    }

    private Location safeRespawn(Session session)
    {
        final GeoData geo = GeoData.getInstance();
        final PathFinding path = PathFinding.getInstance();
        if (!geo.hasGeo(session.deathX, session.deathY)
            || path instanceof net.sf.l2j.gameserver.geoengine.pathfinding.NullPathFinding)
            return null;

        final ThreadLocalRandom random = ThreadLocalRandom.current();
        final int clearance = Math.max(16, (int) Math.ceil(session.player.getBaseTemplate().getCollisionRadius()));
        for (int attempt = 0; attempt < 64; attempt++)
        {
            final int dx = random.nextInt(-respawnRadius, respawnRadius + 1);
            final int dy = random.nextInt(-respawnRadius, respawnRadius + 1);
            if ((long) dx * dx + (long) dy * dy > (long) respawnRadius * respawnRadius)
                continue;

            final int x = session.deathX + dx;
            final int y = session.deathY + dy;
            if (!geo.hasGeo(x, y))
                continue;
            final int z = geo.getHeight(x, y, session.deathZ);
            if (Math.abs(z - session.deathZ) > maxZ || !validSpawnZone(x, y, z + 5)
                || !reachesCell(geo, path, session.deathX, session.deathY, session.deathZ, x, y, z))
                continue;
            if (openNeighbor(geo, path, x, y, z, x + clearance, y)
                && openNeighbor(geo, path, x, y, z, x - clearance, y)
                && openNeighbor(geo, path, x, y, z, x, y + clearance)
                && openNeighbor(geo, path, x, y, z, x, y - clearance))
                return new Location(x, y, z);
        }
        return null;
    }

    private static boolean openNeighbor(GeoData geo, PathFinding path, int x, int y, int z, int tx, int ty)
    {
        if (!geo.hasGeo(tx, ty))
            return false;
        final int tz = geo.getHeight(tx, ty, z);
        return Math.abs(tz - z) <= 32 && reachesCell(geo, path, x, y, z, tx, ty, tz)
            && reachesCell(geo, path, tx, ty, tz, x, y, z);
    }

    private static boolean reachesCell(GeoData geo, PathFinding path, int x, int y, int z, int tx, int ty, int tz)
    {
        final Location reached = path.canMoveToTargetLoc(x, y, z, tx, ty, tz);
        return reached != null && geo.getGeoX(reached.getX()) == geo.getGeoX(tx)
            && geo.getGeoY(reached.getY()) == geo.getGeoY(ty) && Math.abs(reached.getZ() - tz) <= 8;
    }

    private void start(L2PcInstance player)
    {
        synchronized (player)
        {
            final String denied = rejection(player);
            if (denied != null)
            {
                player.sendMessage(denied);
                return;
            }
            final L2GameClient client = player.getClient();
            if (client == null || client.isDetached() || client.getActiveChar() != player
                || client.getState() != L2GameClient.GameClientState.IN_GAME)
                return;
            if (Files.isRegularFile(reportPath(player.getObjectId())))
            {
                player.sendMessage("Aguarde o relat\u00f3rio da sess\u00e3o anterior.");
                onEnterWorld(player);
                return;
            }
            final Session session = new Session(player, client, minutes);
            synchronized (sessions)
            {
                if (shuttingDown || sessions.size() >= maxSessions
                    || accounts.putIfAbsent(session.account, session) != null)
                {
                    player.sendMessage("Offline Farm sem vagas ou j\u00e1 ativo nesta conta.");
                    return;
                }
                sessions.put(player.getObjectId(), session);
            }
            try
            {
                Files.createDirectories(REPORTS);
                AutofarmSecondaryManager.INSTANCE.startFarm(player);
                if (!AutofarmSecondaryManager.INSTANCE.isAutofarming(player))
                    return;
                if (!player.destroyItemByItemId("OfflineFarm", ticketId, 1, player, true))
                    return;
                session.charged = true;
                player.store();
                session.initialItems = inventory(player);
                saveReport(session, "Em andamento");
                session.running = true;
                showMenu(player);
            }
            catch (IOException | RuntimeException e)
            {
                LOG.log(Level.WARNING, "Could not start Offline Farm.", e);
                player.sendMessage("N\u00e3o foi poss\u00edvel iniciar o Offline Farm.");
            }
            finally
            {
                if (!session.running)
                {
                    remove(session);
                    try
                    {
                        AutofarmSecondaryManager.INSTANCE.stopFarm(player);
                    }
                    finally
                    {
                        if (session.charged)
                            player.addItem("OfflineFarmRefund", ticketId, 1, player, true);
                    }
                    if (session.charged)
                    {
                        try { Files.deleteIfExists(reportPath(player.getObjectId())); }
                        catch (IOException e) { LOG.log(Level.WARNING, "Could not remove aborted Offline Farm report.", e); }
                    }
                }
            }
        }
    }

    public boolean disconnect(L2PcInstance player)
    {
        return detachSession(player, player.getClient(), false);
    }

    public boolean onConnectionLost(L2PcInstance player, L2GameClient client)
    {
        return detachSession(player, client, true);
    }

    /**
     * Consumes the logout request when the player has an armed session.
     * A rejected transition must not fall through to regular character deletion.
     */
    public boolean handleLogout(L2PcInstance player)
    {
        synchronized (player)
        {
            final Session session = sessions.get(player.getObjectId());
            if (session == null || !session.running || session.detached)
                return false;

            detachSession(player, player.getClient(), false);
            return true;
        }
    }

    private boolean detachSession(L2PcInstance player, L2GameClient client, boolean connectionAlreadyClosed)
    {
        synchronized (player)
        {
            final Session session = sessions.get(player.getObjectId());
            if (session == null || !session.running || session.detached)
                return false;

            final String failure = detachFailure(session, client);
            if (failure != null)
                return reportDetachFailure(player, connectionAlreadyClosed, failure);

            if (!client.detachForOfflineFarm(player, connectionAlreadyClosed))
                return reportDetachFailure(player, connectionAlreadyClosed,
                    "Conexao ja desligada ou com limpeza de logout agendada.");

            session.detached = true;
            if (player.isTeleporting())
                player.onTeleported();
            if (!player.isAlikeDead())
            {
                player.abortCast();
                player.abortAttack();
                player.stopMove(null);
                player.setTarget(null);
                player.getAI().setIntention(CtrlIntention.ACTIVE);
            }
            if (!player.isAlikeDead() && validLocation(player)
                && !AutofarmSecondaryManager.INSTANCE.isAutofarming(player))
                AutofarmSecondaryManager.INSTANCE.startFarm(player);
            LOG.info("Offline Farm: detached character " + player.getObjectId()
                + ", routine active=" + AutofarmSecondaryManager.INSTANCE.isAutofarming(player));
            return true;
        }
    }

    private String detachFailure(Session session, L2GameClient client)
    {
        final L2PcInstance player = session.player;
        if (client == null || client != session.client || player.getClient() != client || !player.isOnline())
            return "Sessao sem conexao vinculada ao personagem.";
        if (System.currentTimeMillis() >= session.until)
            return "Tempo da sessao esgotado.";
        if (!validLocation(player) || player.isInsideZone(ZoneId.NO_RESTART))
            return "A zona atual nao permite a transicao para o modo offline.";
        if (player.isInParty() || player.isInStoreMode())
            return "Saia da party ou feche a loja.";
        if (player.isInOlympiadMode() || player.isInArenaEvent() || player.isInFunEvent())
            return "Saia do evento antes de desconectar.";
        if (player.isLocked() || player.getActiveEnchantItem() != null || player.getActiveTradeList() != null)
            return "Finalize a acao, o enchant ou a troca em andamento.";
        return null;
    }

    private boolean reportDetachFailure(L2PcInstance player, boolean connectionAlreadyClosed, String failure)
    {
        LOG.info("Offline Farm: detach refused for " + player.getObjectId() + ": " + failure);
        if (!connectionAlreadyClosed)
        {
            player.sendMessage("Offline Farm: " + failure);
            player.sendPacket(net.sf.l2j.gameserver.network.serverpackets.ActionFailed.STATIC_PACKET);
        }
        return false;
    }

    private void stopOnline(L2PcInstance player)
    {
        synchronized (player)
        {
            final Session session = sessions.get(player.getObjectId());
            if (session != null && session.running && !session.detached && player.getClient() == session.client)
                finish(session, "Sessao encerrada", false);
        }
    }

    public L2PcInstance reconnect(L2PcInstance player, String account)
    {
        synchronized (player)
        {
            final Session session = sessions.get(player.getObjectId());
            if (session == null || !session.running || !session.detached || !session.account.equals(account))
                return null;
            finish(session, "Reconex\u00e3o", true);
            return player;
        }
    }

    public boolean isDetachedSession(L2PcInstance player)
    {
        final Session session = sessions.get(player.getObjectId());
        return session != null && session.player == player && session.running && session.detached
            && System.currentTimeMillis() < session.until;
    }

    public void recordKill(L2PcInstance player)
    {
        final Session session = sessions.get(player.getObjectId());
        if (session != null && session.running)
            session.kills.incrementAndGet();
    }

    private void tick()
    {
        for (Session session : sessions.values())
        {
            final L2PcInstance player = session.player;
            synchronized (player)
            {
                if (!session.running || sessions.get(player.getObjectId()) != session)
                    continue;
                try
                {
                    final long now = System.currentTimeMillis();
                    if (now >= session.until || !player.isOnline() || !validLocation(player))
                    {
                        final String reason = now >= session.until ? "Tempo esgotado"
                            : !player.isOnline() ? "Personagem removido do mundo" : "Zona bloqueada";
                        finish(session, reason, false);
                        continue;
                    }
                    if (player.isAlikeDead())
                    {
                        if (session.reviveAt == 0)
                        {
                            session.deaths++;
                            session.deathX = player.getX();
                            session.deathY = player.getY();
                            session.deathZ = player.getZ();
                            session.reviveAt = now + TimeUnit.SECONDS.toMillis(respawnSeconds);
                            AutofarmSecondaryManager.INSTANCE.stopFarm(player);
                        }
                        if (now >= session.reviveAt)
                        {
                            final Location spawn = safeRespawn(session);
                            if (spawn == null)
                            {
                                finish(session, "Sem ponto seguro para renascer", false);
                                continue;
                            }
                            player.doRevive();
                            player.teleToLocation(spawn, 0);
                            session.reviveAt = 0;
                        }
                    }
                    else if (!AutofarmSecondaryManager.INSTANCE.isAutofarming(player) && !player.isTeleporting())
                    {
                        if (player.isNoBuffProtected() && player.getAllEffects().length <= 8)
                        {
                            finish(session, "Prote\u00e7\u00e3o de buffs", false);
                            continue;
                        }
                        AutofarmSecondaryManager.INSTANCE.startFarm(player);
                    }
                    if (!session.detached && now >= session.nextStatus)
                    {
                        session.nextStatus = now + 5000;
                        sendStatus(player);
                    }
                    if (now >= session.checkpoint)
                    {
                        session.checkpoint = now + 15000;
                        player.store();
                        saveReport(session, "Em andamento");
                    }
                }
                catch (IOException | RuntimeException e)
                {
                    LOG.log(Level.WARNING, "Offline Farm session failed for " + player.getObjectId(), e);
                    finish(session, "Sess\u00e3o interrompida", false);
                }
            }
        }
    }

    public void shutdown()
    {
        synchronized (sessions)
        {
            shuttingDown = true;
        }
        for (Session session : sessions.values())
        {
            synchronized (session.player)
            {
                if (session.running)
                    finish(session, "Rein\u00edcio do servidor", false);
            }
        }
    }

    private void finish(Session session, String reason, boolean reconnect)
    {
        session.running = false;
        final L2PcInstance player = session.player;
        if (session.detached)
            LOG.info("Offline Farm: finished character " + player.getObjectId() + ": " + reason);
        try
        {
            AutofarmSecondaryManager.INSTANCE.stopFarm(player);
            player.store();
            saveReport(session, reason);
        }
        catch (IOException | RuntimeException e)
        {
            LOG.log(Level.WARNING, "Could not finalize Offline Farm report.", e);
        }
        finally
        {
            remove(session);
            if (session.detached)
            {
                session.client.setActiveChar(null);
                player.setClient(null);
                if (!reconnect && player.isOnline())
                    player.deleteMe();
            }
            else if (player.isOnline() && player.getClient() == session.client && !session.client.isDetached())
            {
                sendStatus(player);
                onEnterWorld(player);
            }
        }
    }

    private void remove(Session session)
    {
        sessions.remove(session.player.getObjectId(), session);
        accounts.remove(session.account, session);
    }

    private static Map<Integer, Long> inventory(L2PcInstance player)
    {
        final Map<Integer, Long> counts = new HashMap<>();
        for (ItemInstance item : player.getInventory().getItems())
        {
            if (item != null)
                counts.merge(item.getItemId(), (long) item.getCount(), Long::sum);
        }
        return counts;
    }

    private static Path reportPath(int objectId)
    {
        return REPORTS.resolve(objectId + ".properties");
    }

    private static void saveReport(Session session, String reason) throws IOException
    {
        final L2PcInstance player = session.player;
        final Properties p = new Properties();
        p.setProperty("reason", reason);
        p.setProperty("seconds", Long.toString(Math.max(0, Math.min(System.currentTimeMillis(), session.until) - session.start) / 1000));
        p.setProperty("xp", Long.toString(Math.max(0, player.getExp() - session.xp)));
        p.setProperty("sp", Long.toString(Math.max(0, (long) player.getSp() - session.sp)));
        p.setProperty("deaths", Integer.toString(session.deaths));
        p.setProperty("kills", Integer.toString(session.kills.get()));
        for (Map.Entry<Integer, Long> entry : inventory(player).entrySet())
        {
            final long gain = entry.getValue() - session.initialItems.getOrDefault(entry.getKey(), 0L);
            if (gain > 0)
                p.setProperty("item." + entry.getKey(), Long.toString(gain));
        }
        final Path report = reportPath(player.getObjectId());
        final Path temp = Files.createTempFile(REPORTS, player.getObjectId() + "-", ".tmp");
        try
        {
            try (java.io.OutputStream output = Files.newOutputStream(temp))
            {
                p.store(output, "Offline Farm");
            }
            try { Files.move(temp, report, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temp, report, StandardCopyOption.REPLACE_EXISTING); }
        }
        finally
        {
            Files.deleteIfExists(temp);
        }
    }

    public void onEnterWorld(L2PcInstance player)
    {
        final L2GameClient client = player.getClient();
        final Path path = reportPath(player.getObjectId());
        if (client == null || !Files.isRegularFile(path))
            return;
        ThreadPoolManager.getInstance().scheduleGeneral(() ->
        {
            synchronized (player)
            {
                if (!player.isOnline() || player.getClient() != client || client.isDetached())
                    return;
                try
                {
                    final Properties p = new Properties();
                    try (java.io.InputStream input = Files.newInputStream(path)) { p.load(input); }
                    final String reason = p.getProperty("reason", "");
                    final StringBuilder body = new StringBuilder("<center><font color=LEVEL>Relat\u00f3rio do Offline Farm</font></center><br>");
                    body.append("Motivo: ").append("Em andamento".equals(reason) ? "Sess\u00e3o interrompida" : reason)
                        .append("<br1>Tempo: ").append(p.getProperty("seconds", "0")).append(" s<br1>XP: ")
                        .append(p.getProperty("xp", "0")).append("<br1>SP: ").append(p.getProperty("sp", "0"))
                        .append("<br1>Monstros abatidos: ").append(p.getProperty("kills", "0")).append("<br1>Mortes: ").append(p.getProperty("deaths", "0")).append("<br><font color=LEVEL>Itens ganhos</font><br1>");
                    final Map<Integer, String> loot = new TreeMap<>();
                    for (String key : p.stringPropertyNames())
                    {
                        if (key.startsWith("item."))
                            loot.put(Integer.parseInt(key.substring(5)), p.getProperty(key));
                    }
                    int displayed = 0;
                    for (Map.Entry<Integer, String> item : loot.entrySet())
                    {
                        if (displayed++ >= 40)
                        {
                            body.append("Mais itens no invent\u00e1rio.<br1>");
                            break;
                        }
                        final Item template = ItemTable.getInstance().getTemplate(item.getKey());
                        final String name = template == null ? "Item " + item.getKey() : template.getName();
                        body.append(name.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))
                            .append(" x").append(item.getValue()).append("<br1>");
                    }
                    if (loot.isEmpty())
                        body.append("Nenhum item ganho nesta sess\u00e3o.");
                    sendHtml(player, body.toString());
                    Files.deleteIfExists(path);
                }
                catch (IOException | RuntimeException e)
                {
                    LOG.log(Level.WARNING, "Could not show Offline Farm report.", e);
                }
            }
        }, 1500);
    }

    private static void sendHtml(L2PcInstance player, String body)
    {
        final NpcHtmlMessage html = new NpcHtmlMessage(0);
        html.setHtml("<html><title>Offline Farm</title><body>" + body + "</body></html>");
        player.sendPacket(html);
    }

    private static final class Session
    {
        final L2PcInstance player;
        final L2GameClient client;
        final String account;
        final long start = System.currentTimeMillis();
        final long until, xp;
        final int sp;
        Map<Integer, Long> initialItems;
        long checkpoint = start + 15000, reviveAt, nextStatus = start + 5000;
        int deaths, deathX, deathY, deathZ;
        final java.util.concurrent.atomic.AtomicInteger kills = new java.util.concurrent.atomic.AtomicInteger();
        boolean charged;
        volatile boolean detached;
        volatile boolean running;

        Session(L2PcInstance player, L2GameClient client, int minutes)
        {
            this.player = player;
            this.client = client;
            account = client.getAccountName();
            until = start + TimeUnit.MINUTES.toMillis(minutes);
            xp = player.getExp();
            sp = player.getSp();
        }
    }
}
