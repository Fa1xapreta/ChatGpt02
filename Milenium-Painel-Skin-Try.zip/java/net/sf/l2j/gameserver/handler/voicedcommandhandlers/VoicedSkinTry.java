/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.handler.voicedcommandhandlers;

import net.sf.l2j.gameserver.handler.IVoicedCommandHandler;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;

/** Opens the skin armor preview panel. */
public class VoicedSkinTry implements IVoicedCommandHandler
{
	/** Number of previews per full HTML page. */
	public static final int PAGE_SIZE = 42;
	private static final int PAGE_COUNT = 5;

	private static final String[] VOICED_COMMANDS =
	{
		"skintry"
	};

	@Override
	public boolean useVoicedCommand(String command, L2PcInstance activeChar, String target)
	{
		if (command.equalsIgnoreCase("skintry"))
			showSkinMenu(activeChar, 1);

		return true;
	}

	/**
	 * Builds and sends the paginated skin-list HTML to the player.
	 * Called from the voiced command (page 1) and from the
	 * "skin_try_page" bypass in RequestBypassToServer (any page).
	 *
	 * @param player the player requesting the menu
	 * @param page   1-based page number
	 */
	public static void showSkinMenu(L2PcInstance player, int page)
	{
		NpcHtmlMessage html = new NpcHtmlMessage(0);
		final int selectedPage = Math.max(1, Math.min(page, PAGE_COUNT));
		final String suffix = selectedPage == 1 ? "" : "-" + selectedPage;
		html.setFile("data/html/mods/tryskin" + suffix + ".htm");
		player.sendPacket(html);
	}

	@Override
	public String[] getVoicedCommandList()
	{
		return VOICED_COMMANDS;
	}
}