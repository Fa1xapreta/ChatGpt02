package net.sf.l2j.gameserver.handler.itemhandlers;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.handler.IItemHandler;
import net.sf.l2j.gameserver.model.actor.L2Playable;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.model.zone.ZoneId;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;
import net.sf.l2j.gameserver.taskmanager.AttackStanceTaskManager;

public class SubClassOverClick implements IItemHandler
{
	@Override
	public void useItem(L2Playable playable, ItemInstance item, boolean forceUse)
	{
		if (!(playable instanceof L2PcInstance) || item.getItemId() != Config.PREMIUM_SUB_DOMINATOR_ITEM_ID)
			return;

		L2PcInstance player = (L2PcInstance) playable;
		if (!canUseTicket(player))
			return;

		NpcHtmlMessage html = new NpcHtmlMessage(0);
		html.setFile("data/html/mods/ClickClassOver/SubClassActive.htm");
		html.replace("%ticket_object_id%", item.getObjectId());
		player.sendPacket(html);
	}

	public static boolean canUseTicket(L2PcInstance player)
	{
		if (!Config.PREMIUM_SERVICES_ENABLED || !Config.PREMIUM_SUB_DOMINATOR_ENABLED)
		{
			player.sendMessage("Overlord subclass service is disabled.");
			return false;
		}

		String reason = getRestriction(player);
		if (reason != null)
		{
			player.sendMessage("Ticket OverLord: " + reason);
			return false;
		}

		if (player.isSubClassActive())
		{
			player.sendMessage("Switch to your main class before adding a subclass.");
			return false;
		}

		return true;
	}

	private static String getRestriction(L2PcInstance player)
	{
		if (player.isAlikeDead())
			return "o personagem esta morto.";
		if (player.isParalyzed())
			return "o personagem esta paralisado.";
		if (player.isMoving())
			return "pare de andar para usar o ticket.";
		if (player.isAttackingNow() || AttackStanceTaskManager.getInstance().get(player))
			return "aguarde o fim do combate.";
		if (player.isInOlympiadMode())
			return "indisponivel durante a Olimpiada.";
		if (player.isInObserverMode())
			return "saia do modo espectador.";
		if (player.isInStoreMode())
			return "feche a loja privada.";
		if (player.isProcessingTransaction())
			return "encerre a troca ou o pedido pendente.";
		if (player.isInArenaEvent() || player.isArenaProtection())
			return "indisponivel durante o evento de arena ou sua protecao.";
		if (player.isInsideZone(ZoneId.ARENA_EVENT))
			return "saia da zona de arena.";
		if (player.isInsideZone(ZoneId.SIEGE))
			return "saia da zona de cerco.";
		if (player.isCursedWeaponEquipped())
			return "indisponivel com arma amaldicoada.";
		if (player.isInJail())
			return "indisponivel na prisao.";
		if (player.getKarma() > 0)
			return "indisponivel enquanto voce tiver karma.";
		return null;
	}
}
