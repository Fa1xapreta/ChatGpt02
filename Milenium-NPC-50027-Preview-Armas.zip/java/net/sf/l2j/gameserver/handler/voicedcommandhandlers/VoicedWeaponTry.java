/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.handler.voicedcommandhandlers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import net.sf.l2j.gameserver.datatables.custom.WeaponSkinTable;
import net.sf.l2j.gameserver.handler.IVoicedCommandHandler;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.holder.WeaponSkinHolder;
import net.sf.l2j.gameserver.network.serverpackets.ActionFailed;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;


public class VoicedWeaponTry implements IVoicedCommandHandler
{
	/** Number of weapon skins displayed per page. */
	public static final int PAGE_SIZE = 8;

	private static final String[] VOICED_COMMANDS =
	{
		"weapontry"
	};

	@Override
	public boolean useVoicedCommand(String command, L2PcInstance activeChar, String target)
	{
		if (command.equalsIgnoreCase("weapontry"))
			showWeaponMenu(activeChar, 1);

		return true;
	}

	public static void showWeaponMenu(L2PcInstance player, int page)
	{
		NpcHtmlMessage html = new NpcHtmlMessage(0);
		html.setFile("data/html/mods/tryweaponskin.htm"); 
		player.sendPacket(html);
	}

	public static void showNpcWeaponMenu(L2PcInstance player, int npcObjectId, int requestedPage)
	{
		final int pageSize = 24;
		final int columns = 6;
		final WeaponSkinTable table = WeaponSkinTable.getInstance();
		final List<Integer> ids = new ArrayList<>(table.getAllSkinIds());
		Collections.sort(ids);
		final int totalPages = Math.max(1, (ids.size() + pageSize - 1) / pageSize);
		final int page = Math.max(1, Math.min(requestedPage, totalPages));
		final int start = (page - 1) * pageSize;
		final int end = Math.min(start + pageSize, ids.size());

		final StringBuilder buttons = new StringBuilder();
		if (ids.isEmpty())
			buttons.append("<tr><td>No weapon skins available.</td></tr>");

		for (int index = start; index < end; index++)
		{
			if ((index - start) % columns == 0)
				buttons.append("<tr>");

			final int id = ids.get(index);
			final WeaponSkinHolder skin = table.getSkin(id);
			buttons.append("<td><button width=32 height=32 action=\"bypass weapon_try ").append(id)
				.append("\" fore=\"").append(escapeAttribute(skin.getIcon()))
				.append("\" back=\"Icon.etc_alphabet_m_i00\" tooltip=\"").append(escapeAttribute(skin.getName())).append("\"></td>");

			if ((index - start + 1) % columns == 0 || index + 1 == end)
				buttons.append("</tr>");
		}

		final NpcHtmlMessage html = new NpcHtmlMessage(npcObjectId);
		html.setFile("data/html/default/50027-weapons.htm");
		html.replace("%pages%", page + "/" + totalPages);
		html.replace("%weapons%", buttons.toString().replace("\\", "&#92;"));
		html.replace("%previous%", page == 1 ? navigation("Voltar", "Chat 0") : navigation("Anterior", "WeaponPreview " + (page - 1)));
		html.replace("%next%", page < totalPages ? navigation("Proximo", "WeaponPreview " + (page + 1)) : "");
		html.replace("%objectId%", npcObjectId);
		player.sendPacket(html);
		player.sendPacket(ActionFailed.STATIC_PACKET);
	}

	private static String navigation(String label, String command)
	{
		return "<button value=\"" + label + "\" action=\"bypass -h npc_%objectId%_" + command
			+ "\" width=90 height=18 back=\"custom_textures.button90x18\" fore=\"custom_textures.button90x18\">";
	}

	private static String escapeAttribute(String value)
	{
		return value.replace("&", "&amp;").replace("\"", "&quot;").replace("<", "&lt;").replace(">", "&gt;");
	}

	@Override
	public String[] getVoicedCommandList()
	{
		return VOICED_COMMANDS;
	}
}
