package net.sf.l2j.gameserver.instancemanager;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.model.L2Object;
import net.sf.l2j.gameserver.model.L2Skill;
import net.sf.l2j.gameserver.model.actor.L2Attackable;
import net.sf.l2j.gameserver.model.actor.L2Character;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.olympiad.OlympiadManager;
import net.sf.l2j.gameserver.model.zone.ZoneId;
import net.sf.l2j.gameserver.network.serverpackets.ExShowScreenMessage;
import net.sf.l2j.gameserver.network.serverpackets.PlayerModeState;
import net.sf.l2j.gameserver.taskmanager.PvpFlagTaskManager;

/**
 * Controla os modos exclusivos da interface.
 *
 * 0 = Normal
 * 1 = PvE
 * 2 = Hunter
 *
 * O estado real fica no L2PcInstance.
 * A interface recebe uma confirmacao apos cada solicitacao.
 */
public final class PlayerModeManager
{
    public static final int NORMAL = 0;
    public static final int PVE = 1;
    public static final int HUNTER = 2;

    public static final int MIN_LEVEL = 20;

    private final Map<String, L2PcInstance> hunterOwners =
        new ConcurrentHashMap<>();

    private PlayerModeManager()
    {
    }

    /**
     * Retorna true quando o comando pertence ao sistema.
     */
    public boolean handle(String command,L2PcInstance player)
    {
        final int requested;

        if ("playerModeStatus".equals(command))
        {
            requested = -1;
        }
        else if ("playerModeNormal".equals(command))
        {
            requested = NORMAL;
        }
        else if ("playerModePve".equals(command))
        {
            requested = PVE;
        }
        else if ("playerModeHunter".equals(command))
        {
            requested = HUNTER;
        }
        else
        {
            return false;
        }

        if (player == null)
        {
            return true;
        }

        synchronized (player)
        {
            enforceContext(player);

            if (requested == -1)
            {
                reply(player, PlayerModeState.SYNC);
            }
            else
            {
                setMode(player, requested);
            }
        }

        return true;
    }

    public boolean setMode(L2PcInstance player, int requested)
    {
        if (player == null)
        {
            return false;
        }

        synchronized (player)
        {
            if (requested < NORMAL || requested > HUNTER)
            {
                return reject(player, "Modo solicitado invalido.");
            }

            final int previous = player.getPlayerModeState();

            if (previous == requested)
            {
                reply(player, PlayerModeState.ACCEPTED);
                return true;
            }

            if (player.getLevel() < MIN_LEVEL)
            {
                return reject(
                    player,
                    "Os modos ficam disponiveis a partir do nivel 20."
                );
            }

            if (player.isAlikeDead()
                || player.inObserverMode()
                || player.isTeleporting()
                || player.isInCombat()
                || player.isAttackingNow()
                || player.isCastingNow()
                || (player.getPet() != null
                    && player.getPet().isInCombat()))
            {
                return reject(
                    player,
                    "Nao e possivel mudar de modo durante combate, morte, teleporte ou observacao."
                );
            }

            if (restrictedContext(player)
                || player.isInJail()
                || player.isCursedWeaponEquipped()
                || player.getKarma() > 0)
            {
                return reject(
                    player,
                    "Nao e possivel mudar de modo neste estado ou evento."
                );
            }

            if (!player.isInsideZone(ZoneId.PEACE)
                && !player.isInsideZone(ZoneId.TOWN))
            {
                return reject(
                    player,
                    "Mude de modo dentro de uma cidade ou area de paz."
                );
            }

            if (requested == PVE)
            {
                // Hunter precisa voltar ao Normal antes de entrar no PvE.
                if (previous == HUNTER)
                {
                    final String message ="Desative o Modo Hunter antes de ativar o PvE.";

                    player.sendPacket(new ExShowScreenMessage(message, 5000));

                    return reject(player, message);
                }

                // Mesmo no Normal, nao permite PvE enquanto estiver flag.
                if (player.getPvpFlag() != 0)
                {
                    final String message ="Failed, Modo PvE. Aguarde o flag terminar.";
                    player.sendPacket(new ExShowScreenMessage(message, 5000));

                    return reject(player, message);
                }

                if (pvpZone(player))
                {
                    return reject(player,"O PvE nao pode ser ativado em uma zona de PvP."
                    );
                }

                if (player.isAutoFarm() || player.isSecondaryAutoFarm())
                {
                    return reject(
                        player,
                        "Desative os sistemas de AutoFarm antes de ativar o PvE."
                    );
                }
            }

            if (requested == HUNTER)
            {
                if (!Config.PVP_DROP_MODE_ENABLED)
                {
                    return reject(
                        player,
                        "Modo Hunter desativado no servidor."
                    );
                }

                if (!Double.isFinite(Config.PVP_DROP_MODE_BONUS)
                    || Config.PVP_DROP_MODE_BONUS < 0)
                {
                    return reject(
                        player,
                        "Configuracao de bonus Hunter invalida. Avise a administracao."
                    );
                }

                if (player.getPvpFlag() != 0)
                {
                    return reject(
                        player,
                        "Aguarde o flag de combate terminar antes de ativar o Hunter."
                    );
                }

                if (!reserveHunter(player))
                {
                    return false;
                }
            }

            leaveCurrentMode(player, true);

            if (requested == PVE)
            {
                player.savePlayerModeAppearance();
                player.setPlayerModeState(PVE);
                player.setTitle("PVE Mode");
                player.getAppearance().setTitleColor(0x00FFFF);
            }
            else if (requested == HUNTER)
            {
                player.clearHunterCombatFlagTime();
                player.setPlayerModeState(HUNTER);
                player.updatePvPFlag(1);
            }

            // Ordem utilizada antes do ultimo ajuste.
            player.broadcastUserInfo();
            player.broadcastRelationsChanges();

            reply(player, PlayerModeState.ACCEPTED);

            notifyModeChange(player, previous, requested);

            return true;
        }
    }
    
    private static void notifyModeChange(
    	    L2PcInstance player,
    	    int previous,
    	    int requested)
    	{
    	    String message = "";

    	    if (previous == HUNTER)
    	    {
    	        message = "Modo Hunter: Desativado";
    	    }
    	    else if (previous == PVE)
    	    {
    	        message = "Modo PvE: Desativado";
    	    }

    	    if (requested == HUNTER || requested == PVE)
    	    {
    	        final String activated = requested == HUNTER
    	            ? "Modo Hunter: Ativado"
    	            : "Modo PvE: Ativado";

    	        if (message.isEmpty())
    	        {
    	            message = activated;
    	        }
    	        else
    	        {
    	            message += "\n" + activated;
    	        }
    	    }

    	    if (!message.isEmpty())
    	    {
    	        for (String line : message.split("\n"))
    	        {
    	            player.sendMessage(line);
    	        }

    	        player.sendPacket(
    	            new ExShowScreenMessage(message, 3500)
    	        );
    	    }
    	}
    
    /**
     * Reserva um unico personagem por HWID.
     */
    private boolean reserveHunter(L2PcInstance player)
    {
        if (!Config.PVP_DROP_MODE_HWID_PROTECTION)
        {
            return true;
        }

        final String hwid = player.getHWid();

        if (hwid == null|| hwid.trim().isEmpty()|| "0".equals(hwid.trim())|| "-1".equals(hwid.trim()))
        {
            return reject(player,"Nao foi possivel validar seu HWID "+ "para o Hunter Mode.");
        }

        final String key = hwid.trim();

        while (true)
        {
            final L2PcInstance owner =
                hunterOwners.putIfAbsent(key, player);

            if (owner == null || owner == player)
            {
                return true;
            }

            if (!owner.isOnline())
            {
                hunterOwners.remove(key, owner);
                continue;
            }

            return reject(player,"Ja existe outro personagem com Hunter ativo "+ "neste HWID.");
        }
    }

    private void releaseHunter(L2PcInstance player)
    {
        // Remove pela identidade do jogador, inclusive apos desconectar.
        for (Map.Entry<String, L2PcInstance> entry
            : hunterOwners.entrySet())
        {
            if (entry.getValue() == player)
            {
                hunterOwners.remove(entry.getKey(), player);
            }
        }
    }

    private void leaveCurrentMode(
        L2PcInstance player,
        boolean preserveCombatFlag)
    {
        final int previous = player.getPlayerModeState();

        player.setPlayerModeState(NORMAL);

        if (previous == PVE)
        {
            player.restorePlayerModeAppearance();
        }

        if (previous == HUNTER)
        {
            releaseHunter(player);

            final long remaining =
                player.getHunterCombatFlagUntil()
                - System.currentTimeMillis();

            if (preserveCombatFlag && remaining > 0)
            {
                player.updatePvPFlag(1);

                PvpFlagTaskManager.getInstance().add(
                    player,
                    (int) Math.min(
                        Integer.MAX_VALUE,
                        remaining
                    )
                );
            }
            else
            {
                PvpFlagTaskManager.getInstance().remove(player);
                player.updatePvPFlag(0);
            }

            player.clearHunterCombatFlagTime();
        }
    }

    /**
     * Retorna ao modo Normal sem exigir uma solicitacao pela interface.
     * Usado em morte, logout e entrada em contextos incompat�veis.
     */
    public void reset(
    	    L2PcInstance player,
    	    boolean notify,
    	    boolean preserveCombatFlag)
    	{
    	    if (player == null)
    	    {
    	        return;
    	    }

    	    synchronized (player)
    	    {
    	        final int previous = player.getPlayerModeState();
    	        final boolean changed = previous != NORMAL;

    	        leaveCurrentMode(player, preserveCombatFlag);
    	        releaseHunter(player);

    	        if (changed && notify)
    	        {
    	            player.broadcastUserInfo();
    	            player.broadcastRelationsChanges();

    	            reply(player, PlayerModeState.SYNC);

    	            notifyModeChange(player, previous, NORMAL);
    	        }
    	    }
    	}
    
    public void enforceContext(L2PcInstance player)
    {
        if (player.getPlayerModeState() == NORMAL)
        {
            return;
        }

        if (player.getLevel() < MIN_LEVEL
            || restrictedContext(player)
            || (player.isPvpDropModeActive()
                && !Config.PVP_DROP_MODE_ENABLED)
            || (player.isPveModeActive()
                && (pvpZone(player)
                    || player.isAutoFarm()
                    || player.isSecondaryAutoFarm())))
        {
            reset(player, true, true);
        }
    }

    private static boolean restrictedContext(
        L2PcInstance player)
    {
        return player.isInDuel()
            || player.isInSiege()
            || player.isInOlympiadMode()
            || OlympiadManager.getInstance().isRegistered(player)
            || player.isInArenaEvent()
            || player.isInFunEvent()
            || player.atEvent
            || player.atCTFEvent
            || player.atTVTEvent
            || player.atDMEvent
            || player.atLMEvent
            || player.atKTBEvent
            || player.atFOSEvent
            || player.atMultiTVTEvent
            || player.isInsideZone(ZoneId.SIEGE);
    }

    private static boolean pvpZone(L2PcInstance player)
    {
        return player.isInsideZone(ZoneId.PVP)
            || player.isInsideZone(ZoneId.AUTO_PVP_ZONE);
    }

    private static boolean protectedPve(
        L2PcInstance player)
    {
        return player.isPveModeActive()
            && !restrictedContext(player)
            && !pvpZone(player);
    }

    /**
     * Verifica ataques entre jogadores diferentes.
     * Pets e summons sao identificados pelo acting player.
     * Combate contra NPCs continua permitido.
     */
    public static boolean blocksPvp(
        L2Character attacker,
        L2Character target)
    {
        if (attacker == null || target == null)
        {
            return false;
        }

        if (net.sf.l2j.gameserver.timezone.TimeZoneFarm.blocksAttack(attacker, target))
        {
            return true;
        }

        final L2PcInstance source =
            attacker.getActingPlayer();

        final L2PcInstance victim =
            target.getActingPlayer();

        return source != null
            && victim != null
            && source != victim
            && (protectedPve(source)
                || protectedPve(victim));
    }

    public static boolean blocksSkill(
        L2Character caster,
        L2Character target,
        L2Skill skill)
    {
        if (caster == null || target == null || skill == null)
        {
            return false;
        }

        if (skill.isOffensive() || skill.isDebuff())
        {
            return blocksPvp(caster, target);
        }

        final L2PcInstance source =
            caster.getActingPlayer();

        final L2PcInstance victim =
            target.getActingPlayer();

        if (source == null
            || victim == null
            || source == victim)
        {
            return false;
        }

        // Impede suporte PvP por um personagem protegido.
        return (
            protectedPve(source)
            && (
                victim.getPvpFlag() != 0
                || victim.getKarma() > 0
                || victim.isPvpDropModeActive()
            )
        )
        || (
            protectedPve(victim)
            && (
                source.getPvpFlag() != 0
                || source.getKarma() > 0
                || source.isPvpDropModeActive()
            )
        );
    }

    /**
     * Filtra cada alvo separadamente, inclusive em skills de area.
     */
    public static L2Object[] filterSkillTargets(
        L2Character caster,
        L2Skill skill,
        L2Object[] targets)
    {
        if (targets == null || targets.length == 0)
        {
            return targets;
        }

        final List<L2Object> allowed =
            new ArrayList<>(targets.length);

        for (L2Object target : targets)
        {
            if (!(target instanceof L2Character)
                || !blocksSkill(
                    caster,
                    (L2Character) target,
                    skill))
            {
                allowed.add(target);
            }
        }

        if (allowed.size() == targets.length)
        {
            return targets;
        }

        return allowed.toArray(
            new L2Object[allowed.size()]
        );
    }

    /**
     * Multiplicador usado nos calculos de drop normal.
     * Bosses e raid minions nao recebem o bonus.
     */
    public double getHunterDropMultiplier(
        L2PcInstance player,
        L2Attackable monster)
    {
        if (!Config.PVP_DROP_MODE_ENABLED
            || player == null
            || monster == null
            || !player.isPvpDropModeActive()
            || monster.isRaid()
            || monster.isRaidMinion()
            || player.isAlikeDead()
            || restrictedContext(player))
        {
            return 1.0;
        }

        if (Config.PVP_DROP_MODE_HWID_PROTECTION)
        {
            final String hwid = player.getHWid();

            if (hwid == null
                || hunterOwners.get(hwid.trim()) != player)
            {
                return 1.0;
            }
        }

        final double bonus = Config.PVP_DROP_MODE_BONUS;

        if (!Double.isFinite(bonus) || bonus < 0)
        {
            return 1.0;
        }

        final double multiplier = 1.0 + bonus / 100.0;

        return Double.isFinite(multiplier)
            ? multiplier
            : 1.0;
    }

    private static boolean reject(
        L2PcInstance player,
        String reason)
    {
        player.sendMessage(reason);
        reply(player, PlayerModeState.REJECTED);
        return false;
    }

    private static void reply(
        L2PcInstance player,
        int result)
    {
        player.sendPacket(
            new PlayerModeState(
                player.getPlayerModeState(),
                result
            )
        );
    }

    public static PlayerModeManager getInstance()
    {
        return Holder.INSTANCE;
    }

    private static final class Holder
    {
        private static final PlayerModeManager INSTANCE =
            new PlayerModeManager();
    }
}