# Milenium AutoFarm Offline, revisão 2

Aplique sobre o pacote original e a correção do core. Mescle os trechos
em Logout.java se sua cópia tiver alterações posteriores. O pacote contém
OfflineFarm.java, Logout.java, AutoHunting.uc e a configuração atualizada.

- O painel abre pelo botão Farm offline. Ativar consome um ticket e inicia
  o AutoHunting enquanto o jogador ainda está conectado. O jogador pode
  continuar e desconectar pelo painel ou pelo logout do jogo. Ao voltar,
  recebe o relatório da sessão como na versão anterior.
- No XDAT enviado, BtnOffline é o botão e DrawerButtons.Timer.txtTimer
  é o campo separado do relógio. A textura do botão muda entre as variantes
  MannerBTNOff e MannerBTNON. Os segundos ficam no relógio existente.
- A configuração não exige mais Spots. Bloqueia as zonas de paz, flag
  e Party Farm. Os requisitos de estado do personagem e do AutoHunting
  continuam sendo verificados.
- RespawnSeconds define a espera. RespawnRadius é o raio horizontal
  a partir do ponto em que o jogador morreu. O servidor exige geodata
  carregada, verifica caminho e folga em quatro direções e evita zonas
  bloqueadas. Sem um destino seguro, a sessão termina com esse motivo
  no relatório.
- O arquivo mantém o ticket 20454, 10 minutos por sessão e 300 segundos
  de espera. O raio de respawn adotado é 250, configurável.

As duas classes Java compilaram em modo Java 8 na base disponível.
A compilação UnrealScript e a confirmação da aparência e do respawn
em terreno real ainda precisam ser feitas no cliente de teste.
