/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.network.clientpackets;

import java.util.Calendar;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.ThreadPoolManager;
import net.sf.l2j.gameserver.datatables.custom.SkinTable;
import net.sf.l2j.gameserver.handler.IItemHandler;
import net.sf.l2j.gameserver.handler.ItemHandler;
import net.sf.l2j.gameserver.model.L2Skill;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.actor.instance.L2PetInstance;
import net.sf.l2j.gameserver.model.entity.events.capturetheflag.CTFEvent;
import net.sf.l2j.gameserver.model.entity.events.deathmatch.DMEvent;
import net.sf.l2j.gameserver.model.entity.events.teamvsteam.TvTEvent;
import net.sf.l2j.gameserver.model.entity.events.tournaments.properties.ArenaConfig;
import net.sf.l2j.gameserver.model.holder.SkillHolder;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.model.item.kind.Item;
import net.sf.l2j.gameserver.model.item.type.ActionType;
import net.sf.l2j.gameserver.model.item.type.EtcItemType;
import net.sf.l2j.gameserver.model.item.type.WeaponType;
import net.sf.l2j.gameserver.model.itemcontainer.Inventory;
import net.sf.l2j.gameserver.model.quest.Quest;
import net.sf.l2j.gameserver.model.quest.QuestState;
import net.sf.l2j.gameserver.model.zone.ZoneId;
import net.sf.l2j.gameserver.network.SystemMessageId;
import net.sf.l2j.gameserver.network.serverpackets.MagicSkillUse;
import net.sf.l2j.gameserver.network.serverpackets.ActionFailed;
import net.sf.l2j.gameserver.network.serverpackets.ItemList;
import net.sf.l2j.gameserver.network.serverpackets.PetItemList;
import net.sf.l2j.gameserver.templates.skills.L2SkillType;

public final class UseItem extends L2GameClientPacket
{
	private static final int SKIN_EQUIP_CAST_TIME = 3000;
	private static final Set<L2PcInstance> SKIN_EQUIPS_PENDING = ConcurrentHashMap.newKeySet();

	private int _objectId;
	private boolean _ctrlPressed;
	
	@Override
	protected void readImpl()
	{
		_objectId = readD();
		_ctrlPressed = readD() != 0;
	}
	
	@Override
	protected void runImpl()
	{
		final L2PcInstance activeChar = getClient().getActiveChar();
		if (activeChar == null)
			return;
		
		if (activeChar.isInStoreMode())
		{
			activeChar.sendPacket(SystemMessageId.ITEMS_UNAVAILABLE_FOR_STORE_MANUFACTURE);
			return;
		}
		
		if (activeChar.getActiveTradeList() != null)
		{
			activeChar.sendPacket(SystemMessageId.CANNOT_PICKUP_OR_USE_ITEM_WHILE_TRADING);
			return;
		}
		
		final ItemInstance item = activeChar.getInventory().getItemByObjectId(_objectId);
		if (item == null)
			return;
		if (activeChar.getTreasureHuntSession().blocksUse(item))
		{
			activeChar.sendMessage("Cancele o alvo da pedra para trocar o equipamento.");
			return;
		}
		
		if (activeChar.isGM())
		activeChar.sendChatMessage(0, Say2.PARTY, "", item.getItem().getName() + " , ID: " + item.getItem().getItemId());
		
		if (item.getItem().getType2() == Item.TYPE2_QUEST)
		{
			activeChar.sendPacket(SystemMessageId.CANNOT_USE_QUEST_ITEMS);
			return;
		}
		
		if (activeChar.isAlikeDead() || activeChar.isStunned() || activeChar.isSleeping() || activeChar.isParalyzed() || activeChar.isAfraid())
			return;
		
		if (DMEvent.isPlayerParticipant(activeChar.getObjectId()))
		{
			if (!DMEvent.onItemuse(activeChar, item.getItemId()))
				return;
		}
		
		if (TvTEvent.isPlayerParticipant(activeChar.getObjectId()))
		{
			if (!TvTEvent.onItemuse(activeChar, item.getItemId()))
				return;
		}
		
		if (CTFEvent.isPlayerParticipant(activeChar.getObjectId()))
		{
			if (!CTFEvent.onItemuse(activeChar, item.getItemId()))
				return;
		}
		
		if (Config.SUMMON_MOUNT_PROTECTION && activeChar.isInsideZone(ZoneId.PEACE) || activeChar.isInsideZone(ZoneId.FLAG_AREA_SELF) || activeChar.isInsideZone(ZoneId.ZONE_PVP) || activeChar.isInsideZone(ZoneId.TOWN) || activeChar.isInsideZone(ZoneId.SIEGE) || Calendar.getInstance().get(Calendar.DAY_OF_WEEK) == 1 || Calendar.getInstance().get(Calendar.DAY_OF_WEEK) == 7 /*|| activeChar.getInstanceId() != 1*/)
		{
			if (Config.LISTID_RESTRICT.contains(Integer.valueOf(item.getItemId())))
			{
				activeChar.sendMessage("You can not summon Wyvern inside Town or on siege days.");
				activeChar.sendPacket(ActionFailed.STATIC_PACKET);
				return;
			}
		}
		
		if (activeChar.isInArenaEvent() || activeChar.isArenaProtection() || activeChar.isInsideZone(ZoneId.TOURNAMENT) || activeChar.isInsideZone(ZoneId.ARENA_EVENT))
		{
			if (ArenaConfig.TOURNAMENT_LISTID_RESTRICT.contains(Integer.valueOf(item.getItemId())))
			{
				activeChar.sendMessage("You can not use this item during Tournament.");
				activeChar.sendPacket(ActionFailed.STATIC_PACKET);
				return;
			}
		}
		
		if (!Config.KARMA_PLAYER_CAN_TELEPORT && activeChar.getKarma() > 0 /* ||  activeChar.isInCombat()*/)
		{
			final SkillHolder[] sHolders = item.getItem().getSkills();
			if (sHolders != null)
			{
				for (SkillHolder sHolder : sHolders)
				{
					final L2Skill skill = sHolder.getSkill();
					if (skill != null && (skill.getSkillType() == L2SkillType.TELEPORT || skill.getSkillType() == L2SkillType.RECALL))
						return;
				}
			}
		}
		
		if (activeChar.isFishing() && item.getItem().getDefaultAction() != ActionType.fishingshot)
		{
			activeChar.sendPacket(SystemMessageId.CANNOT_DO_WHILE_FISHING_3);
			return;
		}
		
		/*
		 * The player can't use pet items if no pet is currently summoned. If a pet is summoned and player uses the item directly, it will be used by the pet.
		 */
		if (item.isPetItem())
		{
			// If no pet, cancels the use
			if (!activeChar.hasPet())
			{
				activeChar.sendPacket(SystemMessageId.CANNOT_EQUIP_PET_ITEM);
				return;
			}
			
			final L2PetInstance pet = ((L2PetInstance) activeChar.getPet());
			
			if (!pet.canWear(item.getItem()))
			{
				activeChar.sendPacket(SystemMessageId.PET_CANNOT_USE_ITEM);
				return;
			}
			
			if (pet.isDead())
			{
				activeChar.sendPacket(SystemMessageId.CANNOT_GIVE_ITEMS_TO_DEAD_PET);
				return;
			}
			
			if (!pet.getInventory().validateCapacity(item))
			{
				activeChar.sendPacket(SystemMessageId.YOUR_PET_CANNOT_CARRY_ANY_MORE_ITEMS);
				return;
			}
			
			if (!pet.getInventory().validateWeight(item, 1))
			{
				activeChar.sendPacket(SystemMessageId.UNABLE_TO_PLACE_ITEM_YOUR_PET_IS_TOO_ENCUMBERED);
				return;
			}
			
			activeChar.transferItem("Transfer", _objectId, 1, pet.getInventory(), pet);
			
			// Equip it, removing first the previous item.
			if (item.isEquipped())
				pet.getInventory().unEquipItemInSlot(item.getLocationSlot());
			else
				pet.getInventory().equipPetItem(item);
			
			activeChar.sendPacket(new PetItemList(pet));
			pet.updateAndBroadcastStatus(1);
			return;
		}
		
		if (!activeChar.getInventory().canManipulateWithItemId(item.getItemId()))
			return;
		
		if (Config.DEBUG)
			_log.finest(activeChar.getName() + ": use item " + _objectId);
		
		if (!item.isEquipped())
		{
			if (!item.getItem().checkCondition(activeChar, activeChar, true))
				return;
		}
		
		if (item.isEquipable())
		{
			if (activeChar.isCastingNow() || activeChar.isCastingSimultaneouslyNow())
			{
				activeChar.sendPacket(SystemMessageId.CANNOT_USE_ITEM_WHILE_USING_MAGIC);
				return;
			}
			
			switch (item.getItem().getBodyPart())
			{
				case Item.SLOT_LR_HAND:
				case Item.SLOT_L_HAND:
				case Item.SLOT_R_HAND:
				{
					if (activeChar.isMounted())
					{
						activeChar.sendPacket(SystemMessageId.CANNOT_EQUIP_ITEM_DUE_TO_BAD_CONDITION);
						return;
					}
					
					// Don't allow weapon/shield equipment if a cursed weapon is equipped
					if (activeChar.isCursedWeaponEquipped())
						return;
					
					break;
				}
				case Item.SLOT_GLOVES:
				case Item.SLOT_CHEST:
				case Item.SLOT_LEGS:
				case Item.SLOT_FEET:
				case Item.SLOT_HEAD:
				{
					activeChar.removeFakeArmor();
					break;
				}
			}
			
			if ((activeChar.getFakeArmorObjectId() > 0 || activeChar.isCursedWeaponEquipped()) && item.getItemId() == 6408)
			{
				activeChar.sendPacket(SystemMessageId.CANNOT_EQUIP_ITEM_DUE_TO_BAD_CONDITION);
				return;
			}
			
			if (activeChar.getFakeWeaponObjectId() > 0 && activeChar.isCursedWeaponEquipped())
			{
				activeChar.sendPacket(SystemMessageId.CANNOT_EQUIP_ITEM_DUE_TO_BAD_CONDITION);
				return;
			}
			
			if (activeChar.isAttackingNow() && item.isFakeWeapon())
			{
				activeChar.sendMessage("You can't change weapon skin while attacking.");
				return;
			}
			
			if (activeChar.isAttackingNow())
			{
				ThreadPoolManager.getInstance().scheduleGeneral(new Runnable()
				{
					@SuppressWarnings("synthetic-access")
					@Override
					public void run()
					{
						final ItemInstance itemToTest = activeChar.getInventory().getItemByObjectId(_objectId);
						if(itemToTest == null)
							return;
						
						// Skip normal equip for skin items
						if (SkinTable.getInstance().getSkinId(itemToTest.getItemId()))
						    return;
						
						activeChar.useEquippableItem(itemToTest, false);
					}
				}, activeChar.getAttackEndTime() - System.currentTimeMillis());
			}
			else
			{
				// Skin item: toggle skin without occupying any equipment slot
				if (SkinTable.getInstance().getSkinId(item.getItemId()))
				{
					if (isSkinEquipPending(activeChar))
						return;

					if (activeChar.getActiveSkinId() == item.getItemId() && !RequestBypassToServer.isSkinPreviewActive(activeChar))
					{
						activeChar.setActiveSkinId(0);
						activeChar.broadcastUserInfo();
						activeChar.sendMessage("Skin deactivated.");
					}
					else
						activateSkinAfterCast(activeChar, item);
					return;
				}

				if (item.isFakeArmor())
				{
					// Don't allowed use fake items over the formal wear.
					List<ItemInstance> formal = activeChar.getInventory().getItemsByItemId(6408);
					for (ItemInstance tmp : formal)
					{
						if (tmp.isEquipped())
						{
							activeChar.sendPacket(SystemMessageId.CANNOT_EQUIP_ITEM_DUE_TO_BAD_CONDITION);
							return;
						}
					}

					if (activeChar.getFakeArmorObjectId() == item.getObjectId())
					{
						activeChar.setFakeArmorObjectId(0);
						activeChar.setFakeArmorItemId(0);
					}
					else
					{
						activeChar.setFakeArmorObjectId(item.getObjectId());
						activeChar.setFakeArmorItemId(item.getItemId());
					}

					activeChar.broadcastUserInfo();
					activeChar.sendPacket(new ItemList(activeChar, false));
				}
				else if (item.isFakeWeapon())
				{
					if (activeChar.getFakeWeaponObjectId() == item.getObjectId())
					{
						activeChar.setFakeWeaponObjectId(0);
						activeChar.setFakeWeaponItemId(0);
					}
					else
					{
						activeChar.setFakeWeaponObjectId(item.getObjectId());
						activeChar.setFakeWeaponItemId(item.getItemId());
					}

					activeChar.broadcastUserInfo();
					activeChar.sendPacket(new ItemList(activeChar, false));
				}
				else
					activeChar.useEquippableItem(item, true);
			}
		}
		else
		{
			if (activeChar.isCastingNow() && !(item.isPotion() || item.isElixir()))
				return;
			
			if (activeChar.getAttackType() == WeaponType.FISHINGROD && item.getItem().getItemType() == EtcItemType.LURE)
			{
				activeChar.getInventory().setPaperdollItem(Inventory.PAPERDOLL_LHAND, item);
				activeChar.broadcastUserInfo();
				
				sendPacket(new ItemList(activeChar, false));
				return;
			}
			
			final IItemHandler handler = ItemHandler.getInstance().getItemHandler(item.getEtcItem());
			if (handler != null)
				handler.useItem(activeChar, item, _ctrlPressed);
			
			for (Quest quest : item.getQuestEvents())
			{
				QuestState state = activeChar.getQuestState(quest.getName());
				if (state == null || !state.isStarted())
					continue;
				
				quest.notifyItemUse(item, activeChar, activeChar.getTarget());
			}
		}
	}

	static boolean isSkinEquipPending(L2PcInstance player)
	{
		return SKIN_EQUIPS_PENDING.contains(player);
	}

	private static void activateSkinAfterCast(L2PcInstance player, ItemInstance item)
	{
		if (!SKIN_EQUIPS_PENDING.add(player))
			return;

		final int skinId = item.getItemId();
		final int objectId = item.getObjectId();
		final int previousSkinId = player.getActiveSkinId();
		final boolean wasPreviewing = RequestBypassToServer.isSkinPreviewActive(player);
		if (player.isMoving())
			player.stopMove(null);
		player.broadcastPacket(new MagicSkillUse(player, player, 7038, 1, SKIN_EQUIP_CAST_TIME, 0));
		final ScheduledFuture<?> task = ThreadPoolManager.getInstance().scheduleGeneral(() ->
		{
			try
			{
				if (!player.isOnline() || player.isAlikeDead() || player.isInStoreMode() || player.getActiveTradeList() != null
					|| player.getInventory().getItemByObjectId(objectId) != item || !SkinTable.getInstance().getSkinId(skinId))
					return;

				if (!wasPreviewing && player.getActiveSkinId() != previousSkinId && !RequestBypassToServer.isSkinPreviewActive(player))
					return;

				RequestBypassToServer.cancelSkinPreview(player);
				if (player.getFakeArmorObjectId() != 0)
					player.removeFakeArmor();
				if (player.getActiveSkinId() != 0)
				{
					player.setActiveSkinId(0);
					player.broadcastUserInfo();
				}
				player.setActiveSkinId(skinId);
				player.broadcastUserInfo();
				player.sendMessage("Skin activated!");
			}
			finally
			{
				SKIN_EQUIPS_PENDING.remove(player);
			}
		}, SKIN_EQUIP_CAST_TIME);
		if (task == null)
			SKIN_EQUIPS_PENDING.remove(player);
	}
}