package net.sf.l2j.gameserver.handler.itemhandlers;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.handler.IItemHandler;
import net.sf.l2j.gameserver.model.actor.L2Playable;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.model.zone.ZoneId;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;
import net.sf.l2j.gameserver.taskmanager.AttackStanceTaskManager;

public class SubClassOverClick implements IItemHandler
{
	@Override
	public void useItem(L2Playable playable, ItemInstance item, boolean forceUse)
	{
		if (!(playable instanceof L2PcInstance) || item.getItemId() != Config.PREMIUM_SUB_DOMINATOR_ITEM_ID)
			return;

		L2PcInstance player = (L2PcInstance) playable;
		NpcHtmlMessage html = new NpcHtmlMessage(0);
		html.setFile("data/html/mods/ClickClassOver/SubClassActive.htm");
		html.replace("%ticket_object_id%", item.getObjectId());
		player.sendPacket(html);
	}

	public static boolean canUseTicket(L2PcInstance player)
	{
		if (!Config.PREMIUM_SERVICES_ENABLED || !Config.PREMIUM_SUB_DOMINATOR_ENABLED)
		{
			player.sendMessage("O servi\u00e7o de subclasse Overlord est\u00e1 desativado.");
			return false;
		}

		String reason = getRestriction(player);
		if (reason != null)
		{
			player.sendMessage("Ticket OverLord: " + reason);
			return false;
		}

		if (player.isSubClassActive())
		{
			player.sendMessage("Volte para sua classe principal antes de adicionar a subclasse Overlord.");
			return false;
		}

		return true;
	}

	private static String getRestriction(L2PcInstance player)
	{
		if (player.isAlikeDead())
			return "Seu personagem est\u00e1 morto.";
		if (player.isParalyzed())
			return "Seu personagem est\u00e1 paralisado.";
		if (player.isStunned() || player.isSleeping() || player.isAfraid())
			return "Aguarde seu personagem recuperar o controle.";
		if (player.isFishing())
			return "Encerre a pescaria antes de confirmar.";
		if (player.isMoving())
			return "Pare de andar antes de confirmar.";
		if (player.isAttackingNow() || AttackStanceTaskManager.getInstance().get(player))
			return "Aguarde o fim do combate.";
		if (player.isInOlympiadMode())
			return "Aguarde o fim da Olimp\u00edada.";
		if (player.inObserverMode())
			return "Saia do modo espectador.";
		if (player.isInStoreMode())
			return "Feche a loja privada.";
		if (player.isProcessingTransaction())
			return "Encerre a troca ou o pedido pendente.";
		if (player.isInArenaEvent() || player.isArenaProtection())
			return "Espere a arena ou sua prote\u00e7\u00e3o terminar.";
		if (player.isInsideZone(ZoneId.ARENA_EVENT))
			return "Saia da zona de arena.";
		if (player.isInsideZone(ZoneId.SIEGE))
			return "Saia da zona de cerco.";
		if (player.isCursedWeaponEquipped())
			return "Voc\u00ea est\u00e1 usando uma arma amaldi\u00e7oada.";
		if (player.isInJail())
			return "Voc\u00ea est\u00e1 na pris\u00e3o.";
		if (player.getKarma() > 0)
			return "Remova o karma antes de confirmar.";
		return null;
	}
}
