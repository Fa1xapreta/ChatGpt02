# Skins L2Milenium para a nova pack

O pacote inclui a árvore `java/` do anexo com a adaptação aplicada, os arquivos de datapack e as listas de importação. O patch é uma opção para integrar as mesmas alterações a uma cópia dos fontes originais.

## Teste do Java e do menu

1. Faça uma cópia dos fontes do seu projeto. Use o diretório `java/` deste pacote sobre a mesma versão de `java.rar`, ou aplique `servidor.patch` na raiz dos fontes originais. Escolha um dos dois métodos.
2. Mescle a pasta `data/` na pasta de execução do gameserver. Preserve o `data/xml/skin.xml` e os XMLs antigos de itens e armas. Se você instalou a versão anterior desta adaptação, substitua `skins.xml`, `MileniumSkinItems.xml` e os HTMLs pela versão deste pacote. Mantenha uma única cópia de `MileniumSkinItems.xml` na pasta de itens.
3. Compile com o projeto e as bibliotecas originais. Use `ALLOW_MOD_MENU` habilitado, entre com dois personagens e abra **Skin Visuals → Available Armor**. A lista oferece 51 armaduras com visuais presentes no ArmorGrp analisado. Por exemplo, selecione **Wooden Set Appearance** e alterne **Skin Helmet** enquanto a prévia dura cinco segundos. O capacete visual usa o ID 43. Após a prévia, volta o visual ativo do personagem.
4. Para testar ativação pelo inventário, importe os seis itens novos, ou os demais itens de interesse, conforme a planilha 01. **Wooden Set Appearance** é o item `32200`. O teste pelo botão de prévia usa apenas os registros visuais e pode ser feito antes de importar o item de ativação.
5. Os atalhos das lojas mantêm os nomes `Shields`, `Skins Donate` e `SkinsWeapon`. Confira os multisells do seu servidor. Se uma lista da versão anterior referenciar `22000–22005` como itens de skin, mude apenas essas referências para `32200–32205`.

## Importação dos arquivos do cliente

- **01-itens-de-ativacao.csv**. Use a coluna `id_final` para adicionar o item à ItemName-e e à EtcItemGrp. Use o nome e o ícone indicados junto com o registro original do item de aparência. Os seis IDs de origem `22000–22005` continuam reservados aos pergaminhos existentes. Os seis novos itens usam `32200–32205`.
- **02-visuais-por-skin.csv**. Mostra a relação entre ID interno, item de ativação e cada visual. `REUTILIZAR` significa que o registro de cliente existente tem slot compatível e pode ser usado no teste.
- **03-lista-de-importacao.csv**. Para `REMAPPAR`, importe a linha do cliente **de origem do mod** e use o ID final desta planilha em ArmorGrp e ItemName-e. Os 27 IDs novos são `32300–32326`. Para `ADICIONAR_ARMORGRP`, importe a linha visual e sua descrição usando o ID indicado, que estava livre nos anexos analisados. Em ambos os casos copie a linha do modelo de origem. Os registros do destino que ocupam os IDs conflitantes são outros itens. `PENDENTE_WEAPONGRP` identifica os visuais de arma ainda sem verificação no WeaponGrp.
- **04-armaduras-para-testar.csv**. Lista as 51 armaduras disponíveis para prévia no cliente atual, com o ID do capacete quando houver.
- Em **Skin Helmet**, HEAD usa o slot do capacete. O campo opcional `headSlot` permite declarar `FACE`, `HAIR` ou `HAIRALL` em um visual HAIR conforme a linha importada. Os valores Interlude de `body_part` para esses acessórios são 17, 18 e 19, respectivamente. A prévia e a aparência ativa compartilham a regra nos pacotes UserInfo e CharInfo.
- Remova `pendingClientMapping="true"` do registro correspondente em `data/xml/skins.xml` depois de importar todos os visuais daquela skin e de conferir seus recursos. A habilitação depende de cada registro. Os itens, geometrias e texturas que faltam devem vir do cliente de origem do mod. Para as armas, confira origem e destino no WeaponGrp junto com o ItemName-e antes de liberar a prévia. A aplicação permanente das armas legadas continua na lógica original da pack.

## Conferências e limites

Foram lidos 10.325 registros de ItemName-e e 1.537 de ArmorGrp. Os DATs enviados foram preservados. O ID 10014 aparece duas vezes em cada DAT do cliente atual. Uma linha identifica Titanium Armor PvP (Robe), e a outra Vesper Crystal Helmet. A adaptação não usa o ID para as skins novas e preserva as duas linhas existentes. A lista deste pacote reserva IDs com base nos DATs, no catálogo e nos XMLs fornecidos. Outros arquivos do datapack e do cliente ainda podem ocupar IDs fora do que foi enviado. O servidor interrompe a carga caso um novo item registrado no XML de aparências repita um ID entre os arquivos de itens que ele carrega.

O carregador foi compilado e executado em teste isolado com o catálogo e o XML legado. A regra de capacete passou em seis cenários isolados. O patch passou na checagem de aplicação e os 230 botões foram cruzados com o catálogo. A compilação integral e a execução em jogo exigem o projeto com as bibliotecas externas da sua pack, incluindo MMOCore.

A estrutura Interlude foi conferida com os descritores públicos do L2ClientDat de MobiusDevelopment e o formato RSA 413 com a implementação pública do open-l2encdec de ritsuwastaken.
