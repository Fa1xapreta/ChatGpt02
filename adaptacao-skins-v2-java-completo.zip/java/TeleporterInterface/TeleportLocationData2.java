package TeleporterInterface;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

import net.sf.l2j.gameserver.templates.StatsSet;
import net.sf.l2j.gameserver.xmlfactory.XMLDocument;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

/**
 * This class loads and stores {@link TeleLocation2}s.
 */
public class TeleportLocationData2 extends XMLDocument
{
    private final Map<String, TeleLocation2> _teleports = new HashMap<>();

    protected TeleportLocationData2()
    {
        load();
    }

    public void reload()
    {
        _teleports.clear();

        load();
    }
    
    
	@Override
	protected void load()
	{
		loadDocument("./data/xml/teleportLocationsinterface.xml");
		LOG.info("Loaded {} teleport locations." + _teleports.size());
	}
    
    
    @Override
    protected void parseDocument(Document doc, File file)
    {
       final StatsSet set = new StatsSet();

        final Node n = doc.getFirstChild();

        for (Node o = n.getFirstChild(); o != null; o = o.getNextSibling())
        {
            if (!"teleport".equalsIgnoreCase(o.getNodeName()))
                continue;

            parseAndFeed(o.getAttributes(), set);

           _teleports.put(set.getString("id"), new TeleLocation2(set));

            set.clear();
        }
    }



    public TeleLocation2 getTeleportLocation(String id)
    {
        return _teleports.get(id);
    }

    public static TeleportLocationData2 getInstance()
    {
        return SingletonHolder.INSTANCE;
    }
   private static class SingletonHolder
    {
        protected static final TeleportLocationData2 INSTANCE = new TeleportLocationData2();
    }


}