package TeleporterInterface;

import java.text.SimpleDateFormat;
import java.util.Date;

import net.sf.l2j.gameserver.instancemanager.GrandBossManager;
import net.sf.l2j.gameserver.instancemanager.RaidBossInfoManager;
import net.sf.l2j.gameserver.instancemanager.RaidBossSpawnManager;
import net.sf.l2j.gameserver.instancemanager.RaidBossSpawnManager.StatusEnum;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.serverpackets.ExShowScreenMessage;
import net.sf.l2j.gameserver.templates.StatsSet;

/** Read-only snapshot for the teleport interface. Does not calculate respawns. */
public final class TeleportRaidStatus
{
    private TeleportRaidStatus()
    {
    }

    public static void sendTo(L2PcInstance player)
    {
        if (player == null)
            return;

        final StringBuilder message = new StringBuilder("CustomEvent=TeleportRaidV1|");
        final SimpleDateFormat format = new SimpleDateFormat("dd/MM_HH:mm");
        boolean first = true;

        // Destination 673 belongs to the general teleport tab.
        for (int destinationId = 641; destinationId <= 695; destinationId++)
        {
            if (destinationId == 673)
                continue;

            if (!first)
                message.append(';');
            first = false;

            final int npcId = getNpcId(destinationId);
            String state = "U";
            long respawn = 0L;

            if (npcId != 0)
            {
                respawn = RaidBossInfoManager.getInstance().getRaidBossRespawnTime(npcId);

                if (destinationId <= 672)
                {
                    final RaidBossSpawnManager manager = RaidBossSpawnManager.getInstance();
                    final StatusEnum status = manager.getRaidBossStatusId(npcId);
                    final StatsSet info = manager.getStatsSet(npcId);
                    if (info != null)
                        respawn = info.getLong("respawnTime", respawn);

                    if (status == StatusEnum.ALIVE)
                        state = "A";
                    else if (status == StatusEnum.DEAD)
                        state = "D";
                }
                else
                {
                    final GrandBossManager manager = GrandBossManager.getInstance();
                    final StatsSet info = manager.getStatsSet(npcId);
                    if (info != null)
                    {
                        respawn = info.getLong("respawn_time", respawn);
                        final int status = manager.getBossStatus(npcId);
                        final int deadStatus = getGrandBossDeadStatus(npcId);

                        if (deadStatus >= 0)
                        {
                            if (status == deadStatus)
                                state = "D";
                            else if (status >= 0 && status < deadStatus)
                                state = "A";
                        }
                        else
                        {
                            // Frintezza: no dead-status constant supplied yet.
                            // Use a live instance or the stored future respawn.
                            if (manager.getBoss(npcId) != null && !manager.getBoss(npcId).isDead())
                                state = "A";
                            else if (respawn > System.currentTimeMillis())
                                state = "D";
                        }
                    }
                }
            }

            message.append(destinationId).append(',').append(state).append(',');
            if ("D".equals(state) && respawn > 0L)
                message.append(format.format(new Date(respawn)));
            else
                message.append('-');
        }

        // OnScreenMessageWnd already ignores messages containing CustomEvent=.
        player.sendPacket(new ExShowScreenMessage(message.toString(), 1));
    }

    private static int getNpcId(int destinationId)
    {
        // Only NPC IDs explicitly confirmed in the supplied server code.
        switch (destinationId)
        {
            case 641: case 642: return 25325; // Barakiel
            case 643: case 644: return 25305; // Brakki
            case 645: case 646: return 25302; // Tayr
            case 647: case 648: return 25299; // Hekaton
            case 649: case 650: return 25309; // Shadith
            case 651: case 652: return 25315; // Horus
            case 653: case 654: return 25312; // Mos
            case 657: case 658: return 25269; // Behemoth
            case 659: case 660: return 25450; // Cherub Galaxias
            case 674: case 675: return 29020; // Baium
            case 676: case 677: return 29001; // Queen Ant
            case 678: case 679: return 29019; // Antharas
            case 680: case 681: return 29028; // Valakas
            case 682: case 683: return 29022; // Zaken
            case 684: case 685: return 29006; // Core
            case 686: case 687: return 29014; // Orfen
            case 688: case 689: return 29045; // Frintezza: controle do encontro
            default: return 0;
        }
    }

    private static int getGrandBossDeadStatus(int npcId)
    {
        switch (npcId)
        {
            case 29001:
            case 29006:
            case 29014:
            case 29022:
                return 1;

            case 29020:
                return 2;

            case 29019:
            case 29028:
            case 29045:
                return 3;

            default:
                return -1;
        }
    }
}