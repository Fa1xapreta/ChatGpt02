package TeleporterInterface;

import net.sf.l2j.gameserver.model.Location;
import net.sf.l2j.gameserver.templates.StatsSet;

/**
 * A datatype extending {@link Location}, used to retain a single Gatekeeper teleport location.
 */
public class TeleLocation2 extends Location
{
    private final String _id;
    private final int _price;
    private final boolean _isNoble;
    private final int _skillEffectId;

    public TeleLocation2(StatsSet set)
    {
        super(set.getInteger("x"), set.getInteger("y"), set.getInteger("z"));

        _id = set.getString("id");
        _price = set.getInteger("price");
        _isNoble = set.getBool("isNoble");
        _skillEffectId = set.getInteger("SkillEffectId");
    }

    public String getId()
    {
       return _id;
    }

    public int getPrice()
    {
        return _price;
    }
    public boolean isNoble()
    {
        return _isNoble;
    }

    public int getSkillEffectId()
    {
        return _skillEffectId;
    }
}