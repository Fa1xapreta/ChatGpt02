package hwid.hwidmanager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.L2GameClient;

public final class HWIDHistoryManager
{
	private static final Logger _log = Logger.getLogger(HWIDHistoryManager.class.getName());
	private static boolean _tablesChecked = false;

	private HWIDHistoryManager()
	{
	}

	public static void recordLogin(L2PcInstance player, L2GameClient client)
	{
		if (player == null || client == null)
			return;

		ensureTables();

		String account = safe(client.getAccountName());
		if (account.length() == 0)
			account = safe(client.getLoginName());

		String playerName = safe(player.getName());
		String hwid = safe(client.getHWID());
		String ip = safe(player.getIP());

		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement("INSERT INTO hwid_history (account_name, player_name, player_id, hwid, ip, first_seen, last_seen, seen_count) VALUES (?,?,?,?,?,NOW(),NOW(),1) ON DUPLICATE KEY UPDATE player_name=VALUES(player_name), last_seen=NOW(), seen_count=seen_count+1"))
		{
			ps.setString(1, account);
			ps.setString(2, playerName);
			ps.setInt(3, player.getObjectId());
			ps.setString(4, hwid);
			ps.setString(5, ip);
			ps.executeUpdate();
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not record HWID history.", e);
		}
	}

	public static synchronized void ensureTables()
	{
		if (_tablesChecked)
			return;

		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			Statement st = con.createStatement())
		{
			st.executeUpdate("CREATE TABLE IF NOT EXISTS hwid_history (id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, account_name VARCHAR(45) NOT NULL DEFAULT '', player_name VARCHAR(45) NOT NULL DEFAULT '', player_id INT NOT NULL DEFAULT 0, hwid VARCHAR(128) NOT NULL DEFAULT '', ip VARCHAR(45) NOT NULL DEFAULT '', first_seen DATETIME NOT NULL, last_seen DATETIME NOT NULL, seen_count INT NOT NULL DEFAULT 1, UNIQUE KEY uniq_hwid_history (account_name, player_id, hwid, ip), KEY idx_hwid_history_hwid (hwid), KEY idx_hwid_history_account (account_name), KEY idx_hwid_history_ip (ip), KEY idx_hwid_history_last_seen (last_seen))");
			st.executeUpdate("CREATE TABLE IF NOT EXISTS hwid_flags (id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, hwid VARCHAR(128) NOT NULL DEFAULT '', account_name VARCHAR(45) NOT NULL DEFAULT '', player_name VARCHAR(45) NOT NULL DEFAULT '', status VARCHAR(16) NOT NULL DEFAULT 'suspect', reason VARCHAR(255) NOT NULL DEFAULT '', created_by VARCHAR(45) NOT NULL DEFAULT '', created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL, UNIQUE KEY uniq_hwid_flags (hwid, account_name), KEY idx_hwid_flags_status (status))");

			addColumnIfMissing(con, st, "hwid_flags", "account_name", "VARCHAR(45) NOT NULL DEFAULT ''");
			addColumnIfMissing(con, st, "hwid_flags", "player_name", "VARCHAR(45) NOT NULL DEFAULT ''");
			addColumnIfMissing(con, st, "hwid_flags", "status", "VARCHAR(16) NOT NULL DEFAULT 'suspect'");
			addColumnIfMissing(con, st, "hwid_flags", "reason", "VARCHAR(255) NOT NULL DEFAULT ''");
			addColumnIfMissing(con, st, "hwid_flags", "created_by", "VARCHAR(45) NOT NULL DEFAULT ''");
			addColumnIfMissing(con, st, "hwid_flags", "created_at", "DATETIME NOT NULL DEFAULT '1970-01-01 00:00:00'");
			addColumnIfMissing(con, st, "hwid_flags", "updated_at", "DATETIME NOT NULL DEFAULT '1970-01-01 00:00:00'");
			st.executeUpdate("UPDATE hwid_flags SET created_at=NOW() WHERE created_at='1970-01-01 00:00:00'");
			st.executeUpdate("UPDATE hwid_flags SET updated_at=NOW() WHERE updated_at='1970-01-01 00:00:00'");
			st.executeUpdate("UPDATE hwid_flags f JOIN hwid_history h ON h.hwid=f.hwid LEFT JOIN hwid_history newer ON newer.hwid=h.hwid AND newer.last_seen > h.last_seen SET f.account_name=IF(f.account_name='', h.account_name, f.account_name), f.player_name=IF(f.player_name='', h.player_name, f.player_name) WHERE newer.hwid IS NULL AND (f.account_name='' OR f.player_name='')");
			_tablesChecked = true;
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not create HWID history tables.", e);
		}
	}

	private static void addColumnIfMissing(Connection con, Statement st, String table, String column, String definition) throws Exception
	{
		try (ResultSet rs = con.getMetaData().getColumns(null, null, table, column))
		{
			if (rs.next())
				return;
		}

		st.executeUpdate("ALTER TABLE " + table + " ADD COLUMN " + column + " " + definition);
	}
	private static String safe(String value)
	{
		if (value == null)
			return "";

		return value.trim().replace("\r", "").replace("\n", "").replace("<", "").replace(">", "");
	}
}
