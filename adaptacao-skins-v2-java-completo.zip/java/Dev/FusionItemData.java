package Dev;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import net.sf.l2j.gameserver.model.L2Augmentation;
import net.sf.l2j.gameserver.model.actor.L2Npc;
import net.sf.l2j.gameserver.model.actor.instance.L2FusionItemsNpcInstance;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.network.serverpackets.MagicSkillUse;
import net.sf.l2j.gameserver.network.serverpackets.SocialAction;
import net.sf.l2j.gameserver.util.Broadcast;
import net.sf.l2j.util.Rnd;

/**
* @author FA1XAPRET4
*/
public class FusionItemData
{
    private static final Logger _log = Logger.getLogger(FusionItemData.class.getName());
    private final List<FusionRecipe> _recipes = new ArrayList<>();

    public static class FusionIngredient
    {
        public final int itemId;
        public final int count;
        public final boolean keepOnFail;

        public FusionIngredient(int itemId, int count, boolean keepOnFail)
        {
            this.itemId = itemId;
            this.count = count;
            this.keepOnFail = keepOnFail;
        }
    }
    
    public static class FusionRecipe
    {
        public int resultId, resultCount;
        public int chance;
        public int failItemId, failItemCount;
        public final List<FusionIngredient> ingredients = new ArrayList<>();
    }

    private FusionItemData()
    {
        load();
    }

    public void load()
    {
        _recipes.clear();
        try
        {
            File file = new File("./data/xml/custom/FusionItems.xml");
            Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(file);
            doc.getDocumentElement().normalize();

            NodeList nodes = doc.getElementsByTagName("fusion");
            for (int i = 0; i < nodes.getLength(); i++)
            {
                Node fusionNode = nodes.item(i);
                if (fusionNode.getNodeType() != Node.ELEMENT_NODE)
                    continue;

                FusionRecipe recipe = new FusionRecipe();

                for (Node subNode = fusionNode.getFirstChild(); subNode != null; subNode = subNode.getNextSibling())
                {
                    if (subNode.getNodeType() != Node.ELEMENT_NODE)
                        continue;

                    switch (subNode.getNodeName())
                    {
                        case "result":
                            recipe.resultId = Integer.parseInt(subNode.getAttributes().getNamedItem("id").getNodeValue());
                            recipe.resultCount = Integer.parseInt(subNode.getAttributes().getNamedItem("count").getNodeValue());
                            break;

                        case "chance":
                            recipe.chance = Integer.parseInt(subNode.getTextContent().trim());
                            break;

                        case "failItem":
                            recipe.failItemId = Integer.parseInt(subNode.getAttributes().getNamedItem("id").getNodeValue());
                            recipe.failItemCount = Integer.parseInt(subNode.getAttributes().getNamedItem("count").getNodeValue());
                            break;

                            
                        case "ingredients":
                            for (Node itemNode = subNode.getFirstChild(); itemNode != null; itemNode = itemNode.getNextSibling())
                            {
                                if (itemNode.getNodeType() != Node.ELEMENT_NODE)
                                    continue;

                                int itemId = Integer.parseInt(itemNode.getAttributes().getNamedItem("id").getNodeValue());
                                int count = Integer.parseInt(itemNode.getAttributes().getNamedItem("count").getNodeValue());

                                // Novo atributo (opcional)
                                boolean keepOnFail = false;
                                Node keepAttr = itemNode.getAttributes().getNamedItem("keepOnFail");
                                if (keepAttr != null)
                                    keepOnFail = Boolean.parseBoolean(keepAttr.getNodeValue());

                                recipe.ingredients.add(new FusionIngredient(itemId, count, keepOnFail));
                            }
                            break;
                            
                            
                        /*case "ingredients":
                            for (Node itemNode = subNode.getFirstChild(); itemNode != null; itemNode = itemNode.getNextSibling())
                            {
                                if (itemNode.getNodeType() != Node.ELEMENT_NODE)
                                    continue;

                                int itemId = Integer.parseInt(itemNode.getAttributes().getNamedItem("id").getNodeValue());
                                int count = Integer.parseInt(itemNode.getAttributes().getNamedItem("count").getNodeValue());
                                recipe.ingredients.add(new FusionIngredient(itemId, count));
                            }
                            break;*/
                    }
                }
                _recipes.add(recipe);
            }

            _log.info("FusionItemData: Carregadas " + _recipes.size() + " receitas.");
        }
        catch (Exception e)
        {
            _log.warning("Erro ao carregar FusionItems.xml: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public List<FusionRecipe> getRecipes()
    {
        return _recipes;
    }

    public boolean tryFusion(L2PcInstance player, L2Npc npc, int recipeIndex, int baseOid, int med1Oid, int med2Oid)
    {
        if (recipeIndex < 0 || recipeIndex >= _recipes.size())
            return false;

        FusionRecipe recipe = _recipes.get(recipeIndex);

        ItemInstance baseItem = player.getInventory().getItemByObjectId(baseOid);
        if (baseItem == null || baseItem.isEquipped())
            return false;

        ItemInstance medal1 = (med1Oid > 0) ? player.getInventory().getItemByObjectId(med1Oid) : null;
        ItemInstance medal2 = (med2Oid > 0) ? player.getInventory().getItemByObjectId(med2Oid) : null;

        boolean needMed1 = recipe.ingredients.size() > 1;
        boolean needMed2 = recipe.ingredients.size() > 2;

        if ((needMed1 && medal1 == null) || (needMed2 && medal2 == null))
        {
            player.sendMessage("One of the selected items is missing.");
            return false;
        }

        if (baseItem.getItemId() != recipe.ingredients.get(0).itemId)
            return false;

        if (needMed1 && medal1.getItemId() != recipe.ingredients.get(1).itemId)
            return false;

        if (needMed2 && medal2.getItemId() != recipe.ingredients.get(2).itemId)
            return false;

        boolean success = Rnd.get(100) < recipe.chance;

        if (success)
        {
          
            int baseEnchant = baseItem.getEnchantLevel();
            L2Augmentation baseAug = baseItem.getAugmentation();

            player.destroyItem("Fusion", baseItem, recipe.ingredients.get(0).count, npc, true);

            if (needMed1 && medal1 != null)
                player.destroyItem("Fusion", medal1, recipe.ingredients.get(1).count, npc, true);

            if (needMed2 && medal2 != null)
                player.destroyItem("Fusion", medal2, recipe.ingredients.get(2).count, npc, true);
 
            ItemInstance newItem = player.addItem("Fusion", recipe.resultId, recipe.resultCount, npc, true);

            if (baseEnchant > 0)
                newItem.setEnchantLevel(baseEnchant);

            if (baseAug != null)
                newItem.setAugmentation(new L2Augmentation(baseAug.getAugmentationId(), baseAug.getSkill()));

            Broadcast.gameAnnounceToOnlinePlayers(player.getName() + " has fused the item: "+ L2FusionItemsNpcInstance.getItemName(newItem.getItemId())+ (baseEnchant > 0 ? " +" + baseEnchant : "") + "!");

            player.broadcastPacket(new MagicSkillUse(player, player, 2025, 1, 1, 0));

            return true;
        }

   
        if (!recipe.ingredients.get(0).keepOnFail)
            player.destroyItem("Fusion", baseItem, recipe.ingredients.get(0).count, npc, true);

        if (needMed1 && medal1 != null && !recipe.ingredients.get(1).keepOnFail)
            player.destroyItem("Fusion", medal1, recipe.ingredients.get(1).count, npc, true);

        if (needMed2 && medal2 != null && !recipe.ingredients.get(2).keepOnFail)
            player.destroyItem("Fusion", medal2, recipe.ingredients.get(2).count, npc, true);

        
        if (recipe.failItemId > 0 && recipe.failItemCount > 0)
        {
            player.addItem("Fusion_Fail", recipe.failItemId, recipe.failItemCount, npc, true);
        }

        player.broadcastPacket(new SocialAction(player, 13));
        player.sendMessage("The fusion has failed! Your base item was preserved, but materials were lost.");

        return false;
    }

    public int getRecipeIndexByBaseItem(int itemId)
    {
        //System.out.println("Procurando receita para ItemId: " + itemId);

        for (int i = 0; i < _recipes.size(); i++)
        {
            FusionRecipe recipe = _recipes.get(i);

            //System.out.println("Receita " + i + " -> BaseItem = " + recipe.ingredients.get(0).itemId);

            if (!recipe.ingredients.isEmpty() &&
                recipe.ingredients.get(0).itemId == itemId)
            {
                System.out.println("Receita encontrada! Index = " + i);
                return i;
            }
        }

        //System.out.println("Nenhuma receita encontrada.");

        return -1;
    }
    
    public boolean tryFusion(L2PcInstance player, L2Npc npc, int recipeIndex)
    {
        return tryFusion(player, npc, recipeIndex, -1, -1, -1);
    }

    public static FusionItemData getInstance()
    {
        return SingletonHolder._instance;
    }

    private static class SingletonHolder
    {
        protected static final FusionItemData _instance = new FusionItemData();
    }
}

