package net.sf.l2j.gameserver.gearscore;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.gearscore.GearScoreRecord.GearItem;

/** Dedicated tables: never changes characters or original inventory tables. */
final class GearScoreStore
{
    Map<Integer, GearScoreRecord> load() throws Exception
    {
        Map<Integer, List<GearItem>> items = new HashMap<>();
        Map<Integer, GearScoreRecord> records = new HashMap<>();
        try (Connection c = L2DatabaseFactory.getInstance().getConnection();
            PreparedStatement p = c.prepareStatement("SELECT * FROM milenium_gear_items"); ResultSet r = p.executeQuery())
        {
            while (r.next()) items.computeIfAbsent(r.getInt("char_id"), k -> new ArrayList<>()).add(new GearItem(
                r.getInt("object_id"),r.getInt("item_id"),r.getInt("enchant_level"),r.getInt("ref1"),
                r.getInt("ref2"),r.getInt("slot_mask"),r.getInt("score")));
        }
        try (Connection c = L2DatabaseFactory.getInstance().getConnection();
            PreparedStatement p = c.prepareStatement("SELECT g.* FROM milenium_gear_players g INNER JOIN characters c ON c.obj_Id=g.char_id");
            ResultSet r = p.executeQuery())
        {
            while (r.next())
            {
                int id=r.getInt("char_id");
                records.put(id,new GearScoreRecord(id,r.getString("name"),r.getInt("class_id"),r.getString("clan"),
                    r.getInt("score"),r.getInt("pvp"),r.getBoolean("gm"),items.getOrDefault(id,new ArrayList<>())));
            }
        }
        return records;
    }
    void save(GearScoreRecord record) throws Exception
    {
        try (Connection c=L2DatabaseFactory.getInstance().getConnection())
        {
            c.setAutoCommit(false);
            try
            {
                try (PreparedStatement p=c.prepareStatement("INSERT INTO milenium_gear_players (char_id,name,class_id,clan,score,pvp,gm) VALUES (?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name),class_id=VALUES(class_id),clan=VALUES(clan),score=VALUES(score),pvp=VALUES(pvp),gm=VALUES(gm)"))
                {
                    p.setInt(1,record.id);p.setString(2,record.name);p.setInt(3,record.classId);p.setString(4,record.clan);
                    p.setInt(5,record.score);p.setInt(6,record.pvp);p.setBoolean(7,record.gm);p.executeUpdate();
                }
                try (PreparedStatement p=c.prepareStatement("DELETE FROM milenium_gear_items WHERE char_id=?"))
                { p.setInt(1,record.id);p.executeUpdate(); }
                try (PreparedStatement p=c.prepareStatement("INSERT INTO milenium_gear_items (char_id,object_id,item_id,enchant_level,ref1,ref2,slot_mask,score) VALUES (?,?,?,?,?,?,?,?)"))
                {
                    for (GearItem i:record.items)
                    {
                        p.setInt(1,record.id);p.setInt(2,i.objectId);p.setInt(3,i.itemId);p.setInt(4,i.enchant);
                        p.setInt(5,i.ref1);p.setInt(6,i.ref2);p.setInt(7,i.slot);p.setInt(8,i.score);p.addBatch();
                    }
                    p.executeBatch();
                }
                c.commit();
            }
            catch (Exception e) { c.rollback();throw e; }
        }
    }
}
