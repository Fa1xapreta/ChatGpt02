package net.sf.l2j.gameserver.gearscore;

/** No hidden grade multiplier. Saturation prevents negative/overflowed client values. */
public final class GearScoreMath
{
    private GearScoreMath() { }
    public static int clamp(long value) { return (int) Math.max(0L, Math.min(Integer.MAX_VALUE, value)); }
    public static int item(int base, int enchant, boolean augmented, int perEnchant, int augmentBonus)
    {
        // Missing/zero XML score opts an item out, including optional bonuses.
        if (base <= 0) return 0;
        return clamp((long) base + (long) Math.max(0, enchant) * Math.max(0, perEnchant)
            + (augmented ? Math.max(0, augmentBonus) : 0));
    }
    public static String field(String s)
    {
        if (s == null) return "";
        return s.replace('|', ' ').replace('"', ' ').replace('\r', ' ').replace('\n', ' ');
    }
}
