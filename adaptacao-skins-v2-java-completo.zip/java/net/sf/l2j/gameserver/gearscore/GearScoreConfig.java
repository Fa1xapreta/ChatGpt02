package net.sf.l2j.gameserver.gearscore;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Independent configuration; unconfigured item templates contribute zero points. */
final class GearScoreConfig
{
    final boolean enabled, includeGm;
    final int enchantBonus, augmentBonus, updateMs, saveMs, limit;

    GearScoreConfig()
    {
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(Paths.get("config/custom/GearScore.properties")))
        {
            p.load(in);
        }
        catch (Exception e)
        {
            Logger.getLogger(getClass().getName()).log(Level.WARNING,
                "GearScore: config/custom/GearScore.properties unavailable; using defaults", e);
        }
        enabled = Boolean.parseBoolean(p.getProperty("Enabled", "true"));
        includeGm = Boolean.parseBoolean(p.getProperty("IncludeGm", "false"));
        enchantBonus = number(p, "EnchantBonusPerLevel", 0, 0, 1000000);
        augmentBonus = number(p, "AugmentBonus", 0, 0, 1000000);
        updateMs = number(p, "UpdateIntervalMs", 2000, 1000, 60000);
        saveMs = number(p, "SaveIntervalMs", 30000, 10000, 3600000);
        limit = number(p, "RankingLimit", 200, 1, 200);
    }

    private static int number(Properties p, String key, int fallback, int min, int max)
    {
        try { return Math.max(min, Math.min(max, Integer.parseInt(p.getProperty(key, "" + fallback).trim()))); }
        catch (NumberFormatException e) { return fallback; }
    }
}
