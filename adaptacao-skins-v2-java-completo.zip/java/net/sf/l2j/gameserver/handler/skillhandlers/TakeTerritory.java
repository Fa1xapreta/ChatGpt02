package net.sf.l2j.gameserver.handler.skillhandlers;

import net.sf.l2j.gameserver.handler.ISkillHandler;
import net.sf.l2j.gameserver.model.L2Object;
import net.sf.l2j.gameserver.model.L2Skill;
import net.sf.l2j.gameserver.model.actor.L2Character;
import net.sf.l2j.gameserver.model.actor.L2Npc;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.entity.events.territorywar.TerritoryWarManager;
import net.sf.l2j.gameserver.templates.skills.L2SkillType;

/** Validates current flag object identity, never NPC title. */
public final class TakeTerritory implements ISkillHandler
{
    private static final L2SkillType[] IDS = { L2SkillType.TAKETERRITORY };

    @Override
    public void useSkill(L2Character activeChar, L2Skill skill, L2Object[] targets)
    {
        if (!(activeChar instanceof L2PcInstance) || skill == null || targets == null || targets.length == 0 || !(targets[0] instanceof L2Npc))
            return;
        final L2PcInstance player = (L2PcInstance) activeChar;
        if (!TerritoryWarManager.getInstance().capture(player, (L2Npc) targets[0], skill))
            player.sendMessage("Unable to capture this territory.");
    }

    @Override
    public L2SkillType[] getSkillIds()
    {
        return IDS;
    }
}
