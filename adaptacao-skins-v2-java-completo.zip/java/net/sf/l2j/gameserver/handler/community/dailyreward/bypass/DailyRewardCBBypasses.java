package net.sf.l2j.gameserver.handler.community.dailyreward.bypass;

import net.sf.l2j.gameserver.handler.ICBBypassHandler;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;

public class DailyRewardCBBypasses implements ICBBypassHandler
{
    @Override
    public boolean handleBypass(
        String bypass,
        L2PcInstance activeChar)
    {
        return false;
    }

    @Override
    public String[] getBypassHandlersList()
    {
        return new String[0];
    }
}