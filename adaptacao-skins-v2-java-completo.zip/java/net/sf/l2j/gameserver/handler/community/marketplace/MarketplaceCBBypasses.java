package net.sf.l2j.gameserver.handler.community.marketplace;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import net.sf.l2j.Config;
import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.communitybbs.Manager.BaseBBSManager;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.datatables.SkillTable;
import net.sf.l2j.gameserver.datatables.custom.AuctionTable;
import net.sf.l2j.gameserver.datatables.custom.IconTable;
import net.sf.l2j.gameserver.handler.ICBBypassHandler;
import net.sf.l2j.gameserver.handler.community.marketplace.htm.HtmlBuilder;
import net.sf.l2j.gameserver.model.L2Augmentation;
import net.sf.l2j.gameserver.model.L2Skill;
import net.sf.l2j.gameserver.model.L2World;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.holder.AuctionHolder;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.model.item.kind.Item;
import net.sf.l2j.gameserver.model.item.type.EtcItemType;
import net.sf.l2j.gameserver.model.item.type.WeaponType;
import net.sf.l2j.gameserver.network.serverpackets.InventoryUpdate;
import net.sf.l2j.gameserver.util.Broadcast;
import net.sf.l2j.gameserver.util.MarketBuy;
import net.sf.l2j.gameserver.util.MarketCollect;
import net.sf.l2j.gameserver.util.MarketSell;
import net.sf.l2j.util.StringUtil;

public class MarketplaceCBBypasses implements ICBBypassHandler {
   private static final ConcurrentHashMap<Integer, MarketplaceCBBypasses.SellerCacheEntry> SELLER_CACHE = new ConcurrentHashMap<>();
   private static volatile boolean EARNINGS_TABLE_READY = false;
   private static final Object EARNINGS_TABLE_LOCK = new Object();

   private static final String BTN_BACK = "L2Arts.T_110x32";
   private static final String BTN_FORE = "L2Arts.T_110x32_over";
   
   private static final String BTN_BACK2 = "L2Arts.T_74x32";
   private static final String BTN_FORE2 = "L2Arts.T_74x32_over";

   private static int safeParseFirstInt(String s) {
      if (s == null) {
         return -1;
      }

      String t = s.trim();
      int cut = t.length();
      int us = t.indexOf(95);
      int sp = t.indexOf(32);
      int hy = t.indexOf(45);
      if (us >= 0 && us < cut) {
         cut = us;
      }

      if (sp >= 0 && sp < cut) {
         cut = sp;
      }

      if (hy >= 0 && hy < cut) {
         cut = hy;
      }

      if (cut < t.length()) {
         t = t.substring(0, cut).trim();
      }

      if (t.isEmpty()) {
         return -1;
      }

      for (int i = 0; i < t.length(); i++) {
         if (!Character.isDigit(t.charAt(i))) {
            return -1;
         }
      }

      try {
         return Integer.parseInt(t);
      } catch (NumberFormatException e) {
         return -1;
      }
   }

   private static String escapeHtml(String s) {
      return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#x27;");
   }

   private static String normalizeSearch(String search) {
      if (search == null) {
         return "*null*";
      }

      String s = search.trim();
      return s.isEmpty() ? "*null*" : s;
   }

   private static boolean matchesNameFilter(int itemId, String search) {
      if (search != null && !"*null*".equals(search)) {
         try {
            String name = ItemTable.getInstance().getTemplate(itemId).getName();
            return name != null && name.toLowerCase().contains(search.toLowerCase());
         } catch (Exception e) {
            return false;
         }
      } else {
         return true;
      }
   }

   private static List<MarketplaceCBBypasses.GroupEntry> buildGroupedList(L2PcInstance player, String search, String categoryType) {
      List<MarketplaceCBBypasses.GroupEntry> grouped = new ArrayList<>();
      HashMap<Integer, ArrayList<AuctionHolder>> byItem = new HashMap<>();
      Iterator<Entry<Integer, AuctionHolder>> var5 = AuctionTable.getInstance().getItems().entrySet().iterator();

      while (true) {
         AuctionHolder ah;
         while (true) {
            if (!var5.hasNext()) {
               for (Entry<Integer, ArrayList<AuctionHolder>> e : byItem.entrySet()) {
                  ArrayList<AuctionHolder> list = e.getValue();
                  if (list != null && !list.isEmpty()) {
                     AuctionHolder cheapest = null;
                     long totalCount = 0L;
                     int bestEnchant = 0;

                     for (AuctionHolder ahx : list) {
                        totalCount += Math.max(0, ahx.getCount());
                        bestEnchant = Math.max(bestEnchant, ahx.getEnchant());
                        if (cheapest == null) {
                           cheapest = ahx;
                        } else if (ahx.getCostCount() < cheapest.getCostCount()) {
                           cheapest = ahx;
                        } else if (ahx.getCostCount() == cheapest.getCostCount()) {
                           if (ahx.getEnchant() > cheapest.getEnchant()) {
                              cheapest = ahx;
                           } else if (ahx.getEnchant() == cheapest.getEnchant() && ahx.getCount() > cheapest.getCount()) {
                              cheapest = ahx;
                           }
                        }
                     }

                     grouped.add(new MarketplaceCBBypasses.GroupEntry(e.getKey(), list.size(), totalCount, bestEnchant, cheapest));
                  }
               }

               Collections.sort(grouped, new Comparator<MarketplaceCBBypasses.GroupEntry>() {
                  public int compare(MarketplaceCBBypasses.GroupEntry a, MarketplaceCBBypasses.GroupEntry b) {
                     if (a == null && b == null) {
                        return 0;
                     } else if (a == null) {
                        return 1;
                     } else if (b == null) {
                        return -1;
                     } else {
                        int pa = a.cheapest != null ? a.cheapest.getCostCount() : Integer.MAX_VALUE;
                        int pb = b.cheapest != null ? b.cheapest.getCostCount() : Integer.MAX_VALUE;
                        if (pa != pb) {
                           return pa < pb ? -1 : 1;
                        } else if (a.itemId != b.itemId) {
                           return a.itemId < b.itemId ? -1 : 1;
                        } else {
                           return 0;
                        }
                     }
                  }
               });
               return grouped;
            }

            Entry<Integer, AuctionHolder> entry = var5.next();
            ah = entry.getValue();
            if (ah != null && ah.getOwnerId() != player.getObjectId()) {
               if (categoryType == null || "*null*".equals(categoryType)) {
                  break;
               }

               try {
                  if (!ItemTable.getInstance().getTemplate(ah.getItemId()).searchItemByType(categoryType)) {
                     continue;
                  }
                  break;
               } catch (Exception e) {
               }
            }
         }

         if (matchesNameFilter(ah.getItemId(), search)) {
            ArrayList<AuctionHolder> list = byItem.get(ah.getItemId());
            if (list == null) {
               list = new ArrayList<>();
               byItem.put(ah.getItemId(), list);
            }

            list.add(ah);
         }
      }
   }

   private static MarketplaceCBBypasses.SellerCacheEntry getSellerCache(int ownerId) {
      MarketplaceCBBypasses.SellerCacheEntry e = SELLER_CACHE.get(ownerId);
      if (e != null && !e.isExpired()) {
         return e;
      }

      String name = "Unknown";
      L2PcInstance seller = L2World.getInstance().getPlayer(ownerId);
      if (seller != null) {
         name = seller.getName();
      } else {
         try (
            Connection con = L2DatabaseFactory.getInstance().getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT char_name FROM characters WHERE obj_id=?");
         ) {
            ps.setInt(1, ownerId);

            try (ResultSet rs = ps.executeQuery()) {
               if (rs.next()) {
                  String n = rs.getString("char_name");
                  if (n != null) {
                     name = n;
                  }
               }
            }
         } catch (Exception var62) {
         }
      }

      MarketplaceCBBypasses.SellerCacheEntry fresh = new MarketplaceCBBypasses.SellerCacheEntry(name);
      SELLER_CACHE.put(ownerId, fresh);
      return fresh;
   }

   private static String uiButton(String label, String action, int width, int height) {
      return "<button value=\"" + label + "\" action=\"bypass " + action + "\" width=" + width + " height=" + height
         + " back=\"" + BTN_BACK + "\" fore=\"" + BTN_FORE + "\">";
   }
   
   private static String uiButton2(String label, String action, int width, int height) {
	      return "<button value=\"" + label + "\" action=\"bypass " + action + "\" width=" + width + " height=" + height
	         + " back=\"" + BTN_BACK2 + "\" fore=\"" + BTN_FORE2 + "\">";
	   }

   private static void uiCbTopNav(HtmlBuilder hb, L2PcInstance player, String activeTab)
   {
       long pending = getPendingEarnings(player.getObjectId(), Config.ID_MARKET_1);

       hb.append("<table width=640 height=32 cellpadding=0 cellspacing=0>");
       hb.append("<tr>");

       hb.append("<td width=115 align=center>");
       hb.append(uiCbNavButton("Auction List",
           "bp_showMarketPlace 1 - *null*",
           "auction".equals(activeTab)));
       hb.append("</td>");

       hb.append("<td width=115 align=center>");
       hb.append(uiCbNavButton("Create Auction",
           "bp_addpanel 1",
           "sell".equals(activeTab)));
       hb.append("</td>");

       hb.append("<td width=115 align=center>");
       hb.append(uiCbNavButton("My Auction",
           "bp_myitems 1",
           "my".equals(activeTab)));
       hb.append("</td>");

       hb.append("<td width=105 align=right>");
       hb.append("<font color=LEVEL>");
       hb.append(StringUtil.formatNumber(
           (int)Math.min(Integer.MAX_VALUE, pending)
       ));
       hb.append("</font>");
       hb.append("&nbsp;&nbsp;");
       hb.append("</td>");

       hb.append("<td width=90 align=center>");
       hb.append(uiButton2(
           "Collect",
           "bp_collectMarket",
           74,
           32
       ));
       hb.append("</td>");

       hb.append("</tr>");
       hb.append("</table><br1>");
   }

   private static String uiCbNavButton(String label, String action, boolean active) {
      String title = active ? "[ " + label + " ]" : label;
      return uiButton(title, action, 110, 32);
   }

   private static void uiOpen(HtmlBuilder hb, L2PcInstance player, String activeTab) {
      hb.append("<html><body><center>");
      
      uiCbTopNav(hb, player, activeTab);
      hb.append("<table width=640 cellpadding=0 cellspacing=0><tr><td>");
   }

   private static void uiClose(HtmlBuilder hb) {
      hb.append("</td></tr></table><br1></center></body></html>");
   }

   public static void uiTabButton(HtmlBuilder hb, String label, String bypass, boolean active) {
      hb.append(uiCbNavButton(label, bypass, active));
   }

   private static void uiCategoryButton(HtmlBuilder hb, String label, String category, boolean active) {
      String value = active ? "> " + label : label;
      String action = "*null*".equals(category) ? "bp_showMarketPlace 1 - *null*" : "bp_showByCategory 1 - " + category;
      hb.append(uiButton(value, action, 110, 32));
      hb.append("<br1>");
   }

   public static void uiSidebar(HtmlBuilder hb) {
      uiSidebar(hb, "*null*");
   }

   public static void uiSidebar(HtmlBuilder hb, String activeCategory) {
      String cat = activeCategory == null ? "*null*" : activeCategory;
      hb.append("<table width=135 cellpadding=4 cellspacing=0><tr><td>");
      hb.append("<font color=E6C98A>CATEGORIES</font><br1>");
      uiCategoryButton(hb, "All Items", "*null*", "*null*".equals(cat));
      uiCategoryButton(hb, "Weapons", "WEAPON", "WEAPON".equalsIgnoreCase(cat));
      uiCategoryButton(hb, "Armors", "ARMOR", "ARMOR".equalsIgnoreCase(cat));
      uiCategoryButton(hb, "Jewels", "JEWELS", "JEWELS".equalsIgnoreCase(cat));
      uiCategoryButton(hb, "Accessories", "ACCESSORY", "ACCESSORY".equalsIgnoreCase(cat));
      uiCategoryButton(hb, "Scrolls", "SCROLL", "SCROLL".equalsIgnoreCase(cat));
      uiCategoryButton(hb, "Misc", "MISC", "MISC".equalsIgnoreCase(cat));
      hb.append("<br1><table width=125 cellpadding=0 cellspacing=0><tr><td height=1 bgcolor=332A1B></td></tr></table><br1>");
      hb.append("<font color=E6C98A>SEARCH</font><br1>");
      hb.append("<edit var=srch width=110 height=13><br1>");
      hb.append(uiButton("Search", "bp_showMarketPlace 1 - $srch", 110, 32));
      hb.append("<br1>");
      hb.append(uiButton("Reset", "bp_showMarketPlace 1 - *null*", 110, 32));
      hb.append("</td></tr></table>");
   }

   private static boolean isWeaponAugmented(ItemInstance item) {
      return item != null && item.isAugmented() && isWeaponItem(item.getItemId());
   }

   private static boolean isMarketplaceAugmentedAllowed(ItemInstance item) {
      return Config.MARKETPLACE_ALLOW_AUGMENTED_SALES && isWeaponAugmented(item);
   }

   private static boolean isMarketplaceTradable(ItemInstance item) {
      if (item == null) {
         return false;
      } else {
         return isMarketplaceAugmentedAllowed(item) ? item.getItem().isTradable() : item.isTradable();
      }
   }

   private static boolean isMarketplaceDepositable(ItemInstance item) {
      if (item == null) {
         return false;
      } else if (item.isEquipped() || !item.getItem().isDepositable()) {
         return false;
      } else {
         return item.isShadowItem() ? false : isMarketplaceTradable(item);
      }
   }

   private static String invAugTag(ItemInstance item) {
      return isWeaponAugmented(item) ? "<font color=00ff00>[Aug]</font>" : "";
   }

   private static void uiAppendName(HtmlBuilder hb, String itemName, int enchant) {
      hb.append("<font color=FFFFFF>" + itemName + "</font>");
      if (enchant > 0) {
         hb.append(" <font color=LEVEL>+" + enchant + "</font>");
      }
   }

   private static void uiAppendNameLink(HtmlBuilder hb, String bypass, String itemName, int enchant) {
      hb.append("<font color=FFFFFF><a action=\"bypass " + bypass + "\">" + itemName + "</a></font>");
      if (enchant > 0) {
         hb.append(" <font color=LEVEL>+" + enchant + "</font>");
      }
   }

   public static void uiAppendAugNameLink(HtmlBuilder hb, AuctionHolder item, String bypass, String itemName, int enchant) {
      String aug = auctionAugTag(item);
      if (!aug.isEmpty()) {
         hb.append(aug + "&nbsp;");
      }

      uiAppendNameLink(hb, bypass, itemName, enchant);
   }

   private static void uiAppendAugName(HtmlBuilder hb, AuctionHolder item, String itemName, int enchant) {
      String aug = auctionAugTag(item);
      if (!aug.isEmpty()) {
         hb.append(aug + "&nbsp;");
      }

      uiAppendName(hb, itemName, enchant);
   }

   private static void uiAppendPriceInline(HtmlBuilder hb, AuctionHolder item) {
      hb.append("<font color=LEVEL>" + StringUtil.formatNumber(item.getCostCount()) + "</font>");
   }

   public static String pageLink(String bypass, int page, String param, String label) {
      return "<td width=30 align=center><a action=\"bypass " + bypass + " " + page + " - " + param + "\">" + label + "</a></td>";
   }

   public static String disabledCell(String label) {
      return "<td width=30 align=center><font color=777777>" + label + "</font></td>";
   }

   private static void renderVariantsPagination(HtmlBuilder hb, String listType, int listPage, int itemId, int page, int totalPages, String filter) {
      hb.append("<table width=640 cellpadding=2 cellspacing=0><tr>");
      hb.append("<td width=180 align=left>");
      if (page > 1) {
         hb.append(
            "<button value=\"<-\" action=\"bypass bp_showItemVariants "
               + listType
               + " "
               + Math.max(1, listPage)
               + " "
               + (page - 1)
               + " "
               + itemId
               + " - "
               + filter
               + "\" width=24 height=24 back=\"L2Arts.BTN_24\" fore=\"L2Arts.BTN_24_Over\">"

         );
      }

      hb.append("</td>");
      hb.append("<td width=180 align=center><font color=CCCCCC>Page " + page + " / " + totalPages + "</font></td>");
      hb.append("<td width=180 align=right>");
      if (page < totalPages) {
         hb.append(
            "<button value=\"->\" action=\"bypass bp_showItemVariants "
               + listType
               + " "
               + Math.max(1, listPage)
               + " "
               + (page + 1)
               + " "
               + itemId
               + " - "
               + filter
               + "\" width=24 height=24 back=\"L2Arts.BTN_24\" fore=\"L2Arts.BTN_24_Over\">"
         );
      }

      hb.append("</td>");
      hb.append("</tr></table>");
   }

   public static String variantsPageLink(String listType, int listPage, int itemId, int varPage, String filter, String label) {
      return "<td width=30 align=center><a action=\"bypass bp_showItemVariants "
         + listType
         + " "
         + Math.max(1, listPage)
         + " "
         + Math.max(1, varPage)
         + " "
         + itemId
         + " - "
         + filter
         + "\">"
         + label
         + "</a></td>";
   }

   private static String uiFormatPrice(AuctionHolder ah) {
      if (ah == null) {
         return "0";
      }

      int costId = ah.getCostId();
      long amount = ah.getCostCount();
      if (costId > 0 && costId != 57) {
         String name = null;

         try {
            Item tmpl = ItemTable.getInstance().getTemplate(costId);
            name = tmpl != null ? tmpl.getName() : null;
         } catch (Exception var6) {
         }

         if (name == null) {
            name = "Item";
         }

         return "x" + StringUtil.formatNumber((int)Math.min(2147483647L, Math.max(0L, amount))) + " " + escapeHtml(name);
      } else {
         return StringUtil.formatNumber((int)Math.min(2147483647L, Math.max(0L, amount)));
      }
   }

   private static boolean isWeaponItem(int itemId) {
      try {
         return ItemTable.getInstance().getTemplate(itemId).getItemType() instanceof WeaponType;
      } catch (Exception e) {
         return false;
      }
   }

   private static AugInfo augFromHolder(AuctionHolder ah) {
	    if (ah == null)
	      return new AugInfo(0, 0, 0); 
	    return new AugInfo(ah.getAugAttributes(), ah.getAugSkillId(), ah.getAugSkillLevel());
	  }

   private static MarketplaceCBBypasses.AugInfo augFromItem(ItemInstance item) {
      if (item != null && item.isAugmented() && isWeaponItem(item.getItemId())) {
         try {
            L2Augmentation aug = item.getAugmentation();
            if (aug == null) {
               return new MarketplaceCBBypasses.AugInfo(0, 0, 0);
            }

            int attrs = aug.getAttributes();
            int skillId = 0;
            int skillLvl = 0;
            L2Skill sk = aug.getSkill();
            if (sk != null) {
               skillId = sk.getId();
               skillLvl = sk.getLevel();
            }

            return new MarketplaceCBBypasses.AugInfo(attrs, skillId, skillLvl);
         } catch (Exception e) {
            return new MarketplaceCBBypasses.AugInfo(0, 0, 0);
         }
      } else {
         return new MarketplaceCBBypasses.AugInfo(0, 0, 0);
      }
   }

   private static void applyAugInfo(AuctionHolder ah, ItemInstance createdItem) {
      if (createdItem != null && ah != null) {
         MarketplaceCBBypasses.AugInfo ai = augFromHolder(ah);
         if (ai.hasAugment()) {
            try {
               createdItem.setAugmentation(new L2Augmentation(ai.attributes, ai.skillId, ai.skillLevel));
            } catch (Exception var4) {
            }
         }
      }
   }

   private static String augTypeLabel(MarketplaceCBBypasses.AugInfo aug) {
      if (aug == null || !aug.hasAugment()) {
         return "";
      }

      if (aug.skillId > 0) {
         L2Skill sk = SkillTable.getInstance().getInfo(aug.skillId, aug.skillLevel);
         if (sk == null) {
            return "Skill";
         } else if (sk.isChance()) {
            return "Chance";
         } else if (sk.isPassive()) {
            return "Passive";
         } else {
            return !sk.isActive() && !sk.isToggle() ? "Skill" : "Active";
         }
      } else {
         return "Attributes";
      }
   }

   private static String auctionAugTag(AuctionHolder ah) {
      if (ah != null && isWeaponItem(ah.getItemId())) {
         MarketplaceCBBypasses.AugInfo aug = augFromHolder(ah);
         return aug != null && aug.hasAugment() ? "<font color=00ff00><a action=\"bypass bp_auginfo " + ah.getAuctionId() + "\">[Aug]</a></font>" : "";
      } else {
         return "";
      }
   }

   private static boolean hasAugmentInfo(int auctionId) {
      AuctionHolder ah = AuctionTable.getInstance().getItem(auctionId);
      if (ah != null && isWeaponItem(ah.getItemId())) {
         MarketplaceCBBypasses.AugInfo aug = augFromHolder(ah);
         return aug != null && aug.hasAugment();
      } else {
         return false;
      }
   }

   public static String uiCbAugmentInfo(int auctionId) {
      return !hasAugmentInfo(auctionId) ? "" : "<a action=\"bypass bp_auginfo " + auctionId + "\"><font color=FF88CC>[Aug]</font></a>";
   }

   private static void showAugInfo(L2PcInstance player, int auctionId) {
      AuctionHolder ah = AuctionTable.getInstance().getItem(auctionId);
      if (ah == null) {
         player.sendMessage("Invalid choice. Please try again.");
      } else {
         MarketplaceCBBypasses.AugInfo aug = augFromHolder(ah);
         HtmlBuilder hb = new HtmlBuilder(HtmlBuilder.HtmlType.COMUNITY);
         uiOpen(hb, player, "auction");
         String itemName = ItemTable.getInstance().getTemplate(ah.getItemId()).getName();
         ah.getEnchant();
         ah.getEnchant();
         hb.append("<table width=640 cellpadding=6 cellspacing=0>");
         hb.append("<tr><td><font color=F28034>Augment Details</font></td></tr>");
         hb.append("</table>");
         hb.append("<table width=640 cellpadding=0 cellspacing=0><tr><td height=1 bgcolor=333333></td></tr></table>");
         hb.append("<table width=640 cellpadding=8 cellspacing=0>");
         hb.append("<tr>");
         hb.append("<td width=40 valign=top><img src=\"" + IconTable.getIcon(ah.getItemId()) + "\" width=32 height=32></td>");
         hb.append("<td valign=top>");
         uiAppendName(hb, itemName, ah.getEnchant());
         hb.append("<br1>");
         if (aug != null && aug.hasAugment()) {
            try {
               L2Augmentation tmp = new L2Augmentation(aug.attributes, aug.skillId, aug.skillLevel);
               String type = augTypeLabel(aug);
               hb.append("<font color=00ff00>Augmented</font>");
               if (type != null && !type.isEmpty()) {
                  hb.append(" <font color=LEVEL>(" + type + ")</font>");
               }

               hb.append("<br1>");
               L2Skill sk = aug.skillId > 0 ? SkillTable.getInstance().getInfo(aug.skillId, aug.skillLevel) : null;
               if (sk != null) {
                  hb.append("<font color=FFFFCC>Skill:</font> " + sk.getName() + "<br1>");
               }

               for (String d : tmp.getDetails()) {
                  if (d != null && !d.isEmpty()) {
                     hb.append("<font color=CCCCCC>" + d + "</font><br1>");
                  }
               }
            } catch (Exception e) {
               hb.append("<font color=FF0000>Failed to build augment details.</font>");
            }
         } else {
            hb.append("<font color=FF0000>No augment data found.</font>");
         }

         hb.append("<br><br>");
         hb.append(
            "<button value=\"Back\" action=\"bypass bp_showMarketPlace 1 - *null*\" width=74 height=25 back=\"L2Arts.T_74x25\" fore=\"L2Arts.T_74x25_over\">"
         );
         hb.append("</td>");
         hb.append("</tr>");
         hb.append("</table>");
         uiClose(hb);
         BaseBBSManager.separateAndSend(hb.toString(), player);
      }
   }

   @Override
   public boolean handleBypass(String bypass, L2PcInstance activeChar) {
      if (bypass.startsWith("bp_showMarketPlace")) {
         String[] data = bypass.substring(19).split(" - ", 2);
         int page = safeParseFirstInt(data.length > 0 ? data[0] : "-1");
         String search = data.length > 1 ? data[1].trim() : "";
         this.showMarketBoard(activeChar, page, search);
      } else if (bypass.startsWith("bp_showByCategory")) {
         String[] category = bypass.substring(18).split(" - ", 2);
         int pageCategory = safeParseFirstInt(category.length > 0 ? category[0] : "-1");
         String searchCategory = category.length > 1 ? category[1].trim() : "";
         this.showMarketBoardByCategory(activeChar, pageCategory, searchCategory);
      } else {
         if (bypass.startsWith("bp_showItemVariants")) {
            try {
               String body = bypass.substring("bp_showItemVariants".length()).trim();
               String[] parts = body.split(" - ", 2);
               String left = parts[0].trim();
               String filter = parts.length > 1 ? parts[1].trim() : "*null*";
               String[] args = left.split(" ");
               String listType = args.length > 0 ? args[0].trim() : "M";
               int listPage = args.length > 1 ? safeParseFirstInt(args[1]) : 1;
               int varPage = args.length > 2 ? safeParseFirstInt(args[2]) : 1;
               int itemId = args.length > 3 ? safeParseFirstInt(args[3]) : -1;
               if (listPage <= 0) {
                  listPage = 1;
               }

               if (varPage <= 0) {
                  varPage = 1;
               }

               if (itemId <= 0) {
                  activeChar.sendMessage("Invalid choice. Please try again.");
                  this.showMarketBoard(activeChar, 1, "*null*");
                  return false;
               }

               this.showItemVariantsBoard(activeChar, listType, listPage, varPage, itemId, filter);
            } catch (Exception e) {
               activeChar.sendMessage("Invalid choice. Please try again.");
               this.showMarketBoard(activeChar, 1, "*null*");
            }

            return false;
         }

         if (bypass.startsWith("bp_auginfo")) {
            try {
               int auctionId = safeParseFirstInt(bypass.substring(10));
               showAugInfo(activeChar, auctionId);
            } catch (Exception e) {
               activeChar.sendMessage("Invalid choice. Please try again.");
            }

            return false;
         }

         if (bypass.startsWith("bp_buy")) {
            int auctionId = safeParseFirstInt(bypass.substring(7));
            AuctionHolder item = AuctionTable.getInstance().getItem(auctionId);
            if (item == null) {
               activeChar.sendMessage("Invalid choice. Please try again.");
               return false;
            }

            showBuyBoard(activeChar, item);
         } else if (bypass.startsWith("bp_confirmBuy")) {
            try {
               int auctionId = safeParseFirstInt(bypass.substring(14));
               AuctionHolder item = AuctionTable.getInstance().getItem(auctionId);
               if (item == null) {
                  activeChar.sendMessage("Invalid choice. Please try again.");
                  return false;
               }
               
               int requiredSlots = 1;
               
               if (requiredSlots > 0 && !activeChar.getInventory().validateCapacity(requiredSlots)) {
            	    activeChar.sendMessage("Your inventory is full.");
            	    return false;
            	}

               if (activeChar.getInventory().getItemByItemId(item.getCostId()) == null
                  || activeChar.getInventory().getItemByItemId(item.getCostId()).getCount() < item.getCostCount()) {
                  activeChar.sendMessage("Incorrect item count.");
                  return false;
               }

               activeChar.destroyItemByItemId("auction", item.getCostId(), item.getCostCount(), activeChar, true);
               creditPendingEarnings(item.getOwnerId(), item.getCostId(), item.getCostCount());
               L2PcInstance owner = L2World.getInstance().getPlayer(item.getOwnerId());
               if (owner != null && owner.isOnline()) {
                  owner.sendMessage("You have sold an item. Your payment is waiting in Marketplace > My Auction > Collect.");
               }

               ItemInstance i = activeChar.addItem("auction", item.getItemId(), item.getCount(), activeChar, true);
               i.setEnchantLevel(item.getEnchant());
               applyAugInfo(item, i);
               activeChar.sendPacket(new InventoryUpdate());
               activeChar.sendMessage("You have purchased an item from the marketplace.");
               MarketBuy.method_23(
                  activeChar.getName(),
                  ItemTable.getInstance().getTemplate(item.getItemId()).getName(),
                  item.getEnchant(),
                  item.getCount(),
                  item.getOwnerId(),
                  item.getCostId(),
                  item.getCostCount()
               );
               AuctionTable.getInstance().deleteItem(item);
               this.showMarketBoard(activeChar, 1, "*null*");
            } catch (Exception e) {
               e.printStackTrace();
            }
         } else if (bypass.startsWith("bp_addpanel")) {
            int page = safeParseFirstInt(bypass.substring(12));
            showAddBoard(activeChar, page);
         } else if (bypass.startsWith("bp_additem")) {
            int itemId = safeParseFirstInt(bypass.substring(11));
            if (activeChar.getInventory().getItemByObjectId(itemId) == null) {
               activeChar.sendMessage("Invalid item. Please try again.");
               return false;
            }

            showAddBoard2(activeChar, itemId);
         } else if (bypass.startsWith("bp_addit2")) {
            try {
               String[] data = bypass.substring(10).split(" ");
               int itemId = safeParseFirstInt(data[0]);
               String costitemtype = data[1];
               int costCount = safeParseFirstInt(data[2]);
               int itemAmount = safeParseFirstInt(data[3]);
               int feeId = Config.MARKETPLACE_FEE[0];
               int feeAmount = Config.MARKETPLACE_FEE[1];
               ItemInstance item = activeChar.getInventory().getItemByObjectId(itemId);
               if (activeChar.getInventory().getInventoryItemCount(feeId, -1) < feeAmount) {
                  activeChar.sendMessage(
                     "You don't have "
                        + StringUtil.concat(String.valueOf(feeAmount))
                        + " - "
                        + ItemTable.getInstance().getTemplate(feeId).getName()
                        + " to pay the fee."
                  );
                  return false;
               }

               if (item == null) {
                  activeChar.sendMessage("Invalid item. Please try again.");
                  return false;
               }

               if (item.getCount() < itemAmount) {
                  activeChar.sendMessage("Invalid item. Please try again.");
                  return false;
               }

               if (isWeaponAugmented(item) && !Config.MARKETPLACE_ALLOW_AUGMENTED_SALES) {
                  activeChar.sendMessage("Augmented items are not allowed in the Marketplace.");
                  return false;
               }

               if (!checkItem(item)) {
                  activeChar.sendMessage("Invalid item. Please try again.");
                  return false;
               }

               if (!isMarketplaceTradable(item)) {
                  activeChar.sendMessage("Invalid item. Please try again.");
                  return false;
               }

               if (!isMarketplaceDepositable(item)) {
                  activeChar.sendMessage("Invalid item. Please try again.");
                  return false;
               }

               int costId = 0;
               if (costitemtype.equals(Config.NAME_MARKET_1)) {
                  costId = Config.ID_MARKET_1;
               }

               MarketSell.method_21(
                  activeChar.getObjectId(), activeChar.getName(), item.getItemName(), item.getEnchantLevel(), item.getCount(), item.getObjectId()
               );
               MarketplaceCBBypasses.AugInfo ai = augFromItem(item);
               AuctionTable.getInstance()
                  .addItem(
                     new AuctionHolder(
                        AuctionTable.getInstance().getNextAuctionId(),
                        activeChar.getObjectId(),
                        item.getItemId(),
                        itemAmount,
                        item.getEnchantLevel(),
                        costId,
                        costCount,
                        ai.attributes,
                        ai.skillId,
                        ai.skillLevel
                     )
                  );
               activeChar.destroyItemByItemId("Auction Fee", feeId, feeAmount, activeChar, true);
               activeChar.destroyItem("Auction Item", itemId, itemAmount, activeChar, true);
               activeChar.sendPacket(new InventoryUpdate());
               activeChar.sendMessage("You have added an item for sale in the Marketplace.");
               if (item.getEnchantLevel() > 0) {
                  Broadcast.EventsAnnounce("Added " + itemAmount + ", " + item.getItemName() + " +" + item.getEnchantLevel() + " on Market.");
               } else {
                  Broadcast.EventsAnnounce("Added " + itemAmount + ", " + item.getItemName() + " on Market.");
               }

               showAddBoard(activeChar, 1);
            } catch (Exception e) {
               activeChar.sendMessage("Invalid input. Please try again.");
               return false;
            }
         } else if (bypass.startsWith("bp_collectMarket")) {
            collectPendingEarnings(activeChar);
            showMyItemsBoard(activeChar, 1);
         } else if (bypass.startsWith("bp_myitems")) {
            int page = safeParseFirstInt(bypass.substring(11));
            showMyItemsBoard(activeChar, page);
         } else if (bypass.startsWith("bp_removeMarket")) {
            int auctionId = safeParseFirstInt(bypass.substring(16));
            AuctionHolder item = AuctionTable.getInstance().getItem(auctionId);
            if (item == null) {
               activeChar.sendMessage("Invalid choice. Please try again.");
               return false;
            }

            AuctionTable.getInstance().deleteItem(item);
            ItemInstance i = activeChar.addItem("auction", item.getItemId(), item.getCount(), activeChar, true);
            i.setEnchantLevel(item.getEnchant());
            applyAugInfo(item, i);
            activeChar.sendPacket(new InventoryUpdate());
            activeChar.sendMessage("You have removed an item from the Auction Shop.");
            showMyItemsBoard(activeChar, 1);
         }
      }

      return false;
   }

   void showMarketBoard(L2PcInstance player, int page, String search) {
      showMarketBoardInternal(player, page, search, "*null*");
   }

   void showMarketBoardByCategory(L2PcInstance player, int page, String category) {
      showMarketBoardInternal(player, page, "*null*", normalizeSearch(category));
   }

   private void showMarketBoardInternal(L2PcInstance player, int page, String search, String category) {
      if (player == null) {
         return;
      }

      search = normalizeSearch(search);
      category = normalizeSearch(category);
      boolean searching = !"*null*".equals(search);
      boolean hasCategory = !"*null*".equals(category) && !"ALL".equalsIgnoreCase(category);
      String term = searching ? search.trim() : "*null*";
      if (term.length() > 30) {
         term = term.substring(0, 30);
      }

      List<MarketplaceCBBypasses.GroupEntry> groups = buildGroupedList(player, searching ? term : "*null*", hasCategory ? category : "*null*");
      int total = groups.size();
      int perPage = 5;
      int totalPages = Math.max(1, (int)Math.ceil(total / (double)perPage));
      if (page < 1 || page > totalPages) {
         page = 1;
      }

      int from = (page - 1) * perPage;
      int to = Math.min(from + perPage, total);
      List<MarketplaceCBBypasses.GroupEntry> pageItems = from < to ? groups.subList(from, to) : Collections.emptyList();

      HtmlBuilder hb = new HtmlBuilder(HtmlBuilder.HtmlType.COMUNITY);
      hb.append("<html><body><center>");
      
      uiCbTopNav(hb, player, "auction");
      hb.append("<table width=640 cellpadding=0 cellspacing=0><tr>");
      hb.append("<td width=140 valign=top>");
      uiSidebar(hb, hasCategory ? category : "*null*");
      hb.append("</td><td width=8></td><td width=472 valign=top>");

      // Hot items: newest 3 offers, presented as compact cards.
      List<AuctionHolder> hot = new ArrayList<>();
      for (AuctionHolder ah : AuctionTable.getInstance().getItems().values()) {
         if (ah != null && ah.getOwnerId() != player.getObjectId()) {
            hot.add(ah);
         }
      }
      hot.sort((a, b) -> Integer.compare(b.getAuctionId(), a.getAuctionId()));
      if (hot.size() > 3) {
         hot = hot.subList(0, 3);
      }

      hb.append("<table width=392 height=18 cellpadding=2 cellspacing=0><tr><td><font color=E6C98A>HOT ITEMS</font></td></tr></table>");
      hb.append("<table width=392 cellpadding=0 cellspacing=2>");
      hb.append("<tr>");

      if (hot.isEmpty())
      {
          hb.append("<td width=392 height=112 align=center bgcolor=000000>");
          hb.append("<font color=777777>No hot items available.</font>");
          hb.append("</td>");
      }
      else
      {
          for (AuctionHolder hi : hot)
          {
              Item tmpl = ItemTable.getInstance().getTemplate(hi.getItemId());
              String name = tmpl != null ? tmpl.getName() : "Unknown";

              if (name.length() > 17)
              {
                  name = name.substring(0, 17) + "..";
              }

              hb.append("<td width=128 valign=top>");

              hb.append("<table width=128 height=118 cellpadding=2 cellspacing=0 bgcolor=000000>");
              hb.append("<tr>");
              hb.append("<td width=128 height=118 align=center valign=top bgcolor=000000>");

              hb.append("<font color=FF6644>HOT</font><br1>");

              hb.append("<font color=E6E6E6>");
              hb.append(escapeHtml(name));
              hb.append("</font><br1>");

              hb.append("<table width=66 height=66 cellpadding=1 cellspacing=0 bgcolor=000000>");
              hb.append("<tr>");
              hb.append("<td width=64 height=64 align=center valign=middle bgcolor=000000>");

              hb.append("<a action=\"bypass bp_buy " + hi.getAuctionId() + "\">");
              hb.append("<img src=\"" + IconTable.getIcon(hi.getItemId()) + "\" width=32 height=32>");
              hb.append("</a>");

              hb.append("</td>");
              hb.append("</tr>");
              hb.append("</table>");

              hb.append("<br1>");
              hb.append("<font color=LEVEL>" + uiFormatPrice(hi) + "</font>");

              hb.append("</td>");
              hb.append("</tr>");
              hb.append("</table>");

              hb.append("</td>");
          }
      }

      hb.append("</tr>");
      hb.append("</table>");
      hb.append("<br>");

      hb.append("<table width=472 cellpadding=2 cellspacing=0><tr>");
      hb.append("<td width=190><font color=E6C98A>Item</font></td>");
      hb.append("<td width=45 align=center><font color=E6C98A>Offers</font></td>");
      hb.append("<td width=75 align=center><font color=E6C98A>Price</font></td>");
      hb.append("<td width=82 align=center><font color=E6C98A>Action</font></td>");
      hb.append("</tr></table>");


      if (pageItems.isEmpty()) {
         hb.append("<table width=472 height=170><tr><td align=center><font color=777777>No items found.</font></td></tr></table>");
      } else {
         int row = 0;
         for (MarketplaceCBBypasses.GroupEntry g : pageItems) {
            if (g == null || g.cheapest == null) {
               continue;
            }
            AuctionHolder rep = g.cheapest;
            Item tmpl = ItemTable.getInstance().getTemplate(g.itemId);
            String baseName = tmpl != null ? tmpl.getName() : "Unknown";
            if (baseName.length() > 25)
            {
                baseName = baseName.substring(0, 25) + "..";
            }
            String bg = (++row % 2 == 0) ? " bgcolor=000000" : "";
            String listType = hasCategory ? "C" : "M";
            String filter = hasCategory ? category : (searching ? term : "*null*");
            StringBuilder link = new StringBuilder();
            link.append("<a action=\"bypass bp_showItemVariants ").append(listType).append(" ")
               .append(page).append(" 1 ").append(g.itemId).append(" - ").append(escapeHtml(filter)).append("\">");
            link.append("<font color=E6E6E6>").append(escapeHtml(baseName)).append("</font>");
            if (rep.getEnchant() > 0) {
               link.append(" <font color=LEVEL>+").append(rep.getEnchant()).append("</font>");
            }
            link.append("</a>");

            hb.append("<table width=472 cellpadding=1 cellspacing=0" + bg + ">");
            hb.append("<tr>");

            hb.append("<td width=38 height=38>");
            hb.append("<img src=\"" + IconTable.getIcon(g.itemId) + "\" width=32 height=32>");
            hb.append("</td>");

            hb.append("<td width=152 nowrap>");
            hb.append(link.toString());
            hb.append("</td>");

            hb.append("<td width=45 align=center>");
            hb.append("<font color=9EE6C8>" + g.offers + "</font>");
            hb.append("</td>");

            hb.append("<td width=75 align=center>");
            hb.append("<font color=LEVEL>" + uiFormatPrice(rep) + "</font>");
            hb.append("</td>");

            hb.append("<td width=82 align=center>");
            hb.append("<button value=\"Buy\" action=\"bypass bp_buy "
                + rep.getAuctionId()
                + "\" width=74 height=25 back=\"L2Arts.T_74x25\" fore=\"L2Arts.T_74x25_over\">");
            hb.append("</td>");

            hb.append("</tr>");
            hb.append("</table>");
         }
      }

      hb.append("<br1><table width=472 cellpadding=0 cellspacing=0><tr>");
      hb.append("<td width=100 align=left>");
      if (page > 1) {
         String prev = hasCategory ? "bp_showByCategory " + (page - 1) + " - " + category : "bp_showMarketPlace " + (page - 1) + " - " + (searching ? escapeHtml(term) : "*null*");
         hb.append(uiButton("<", prev, 38, 22));
      }
      hb.append("</td><td width=192 align=center><font color=CCCCCC>Page " + page + " / " + totalPages + "</font></td>");
      hb.append("<td width=100 align=right>");
      if (page < totalPages) {
         String next = hasCategory ? "bp_showByCategory " + (page + 1) + " - " + category : "bp_showMarketPlace " + (page + 1) + " - " + (searching ? escapeHtml(term) : "*null*");
         hb.append(uiButton(">", next, 38, 22));
      }
      hb.append("</td></tr></table>");
      hb.append("</td></tr></table>");
      hb.append("<br><table width=640><tr><td align=left><font color=777777>Marketplace fee: </font><font color=LEVEL>" + getMarketPlaceFee() + "</font></td><td align=right><font color=8A7A5A>Sales are collected manually.</font></td></tr></table>");
      hb.append("<br1></center></body></html>");
      BaseBBSManager.separateAndSend(hb.toString(), player);
   }

   void showItemVariantsBoard(L2PcInstance player, String listType, int listPage, int varPage, int itemId, String filter) {
      if (player != null) {
         filter = normalizeSearch(filter);
         List<AuctionHolder> variants = new ArrayList<>();

         for (AuctionHolder ah : AuctionTable.getInstance().getItems().values()) {
            if (ah != null && ah.getItemId() == itemId && ah.getOwnerId() != player.getObjectId()) {
               variants.add(ah);
            }
         }

         variants.sort((a, b) -> {
            int cmp = Integer.compare(a.getCostCount(), b.getCostCount());
            if (cmp != 0) {
               return cmp;
            }

            cmp = Integer.compare(b.getEnchant(), a.getEnchant());
            if (cmp != 0) {
               return cmp;
            }

            cmp = Integer.compare(b.getCount(), a.getCount());
            return cmp != 0 ? cmp : Integer.compare(b.getAuctionId(), a.getAuctionId());
         });
         int total = variants.size();
         int perPage = 5;
         int totalPages = Math.max(1, (int)Math.ceil(total / (double)perPage));
         if (varPage < 1 || varPage > totalPages) {
            varPage = 1;
         }

         int from = (varPage - 1) * perPage;
         int to = Math.min(from + perPage, total);
         List<AuctionHolder> pageItems = from < to ? variants.subList(from, to) : Collections.emptyList();
         Item baseTemplate = ItemTable.getInstance().getTemplate(itemId);
         String baseName = baseTemplate != null ? baseTemplate.getName() : "Unknown";
         boolean isStackableModel = baseTemplate != null && baseTemplate.isStackable();
         String iconPath = IconTable.getIcon(itemId);
         HtmlBuilder hb = new HtmlBuilder(HtmlBuilder.HtmlType.COMUNITY);
         hb.append("<html><body><center>");
         
         hb.append("<table><tr>");
         String backAction = "C".equalsIgnoreCase(listType)
            ? "bp_showMarketPlaceCategory " + Math.max(1, listPage) + " - " + filter
            : "bp_showMarketPlace " + Math.max(1, listPage) + " - " + filter;
         hb.append(uiCbNavButton("Back to List", backAction, false));
         hb.append(uiCbNavButton("Create Auction", "bp_addpanel 1", false));
         hb.append(uiCbNavButton("My Auction", "bp_myitems 1", false));
         hb.append("</tr></table><br>");
         hb.append("<table width=640 height=15 bgcolor=000000 cellpadding=0 cellspacing=0><tr><td align=center>");
         hb.append("<font color=F28034><b>Offers for: " + escapeHtml(baseName) + "</b></font>");
         hb.append("</td></tr></table>");
         if (pageItems.isEmpty()) {
            hb.append("<table width=640><tr><td align=center><font color=777777>No offers for this item.</font></td></tr></table>");
         } else {
            int idx = 0;

            for (AuctionHolder ah : pageItems) {
               idx++;
               String bg = idx % 2 == 0 ? " bgcolor=000000" : "";
               int enchant = ah.getEnchant();
               String prefix = "";
               if (baseTemplate != null && baseTemplate.getType2() == 0 && hasAugmentInfo(ah.getAuctionId())) {
                  prefix = "<a action=\"bypass bp_auginfo " + ah.getAuctionId() + "\"><font color=FF88CC>[Aug]</font></a><font color=FFFFFF> </font>";
               }

               StringBuilder nameHtml = new StringBuilder();
               nameHtml.append(prefix);
               nameHtml.append("<a action=\"bypass bp_buy ").append(ah.getAuctionId()).append("\">");
               nameHtml.append("<font color=FFFFFF>").append(escapeHtml(baseName)).append("</font>");
               if (enchant > 0) {
                  nameHtml.append(" <font color=6FC3FF>+").append(enchant).append("</font>");
               }

               if (isStackableModel) {
                  nameHtml.append(" <font color=808080>(").append(ah.getCount()).append(")</font>");
               }

               nameHtml.append("</a>");
               String priceText = uiFormatPrice(ah);
               hb.append("<table width=640" + bg + "><tr>");
               hb.append("<td width=40 height=37><img src=\"" + iconPath + "\" width=32 height=32></td>");
               if (player.isGM()) {
                  hb.append("<td width=300 nowrap>" + nameHtml.toString() + "</td>");
                  MarketplaceCBBypasses.SellerCacheEntry sc = getSellerCache(ah.getOwnerId());
                  hb.append("<td width=90 align=center nowrap><font color=7CFF7C>" + escapeHtml(sc.name) + "</font></td>");
                  hb.append("<td width=110 align=right nowrap><font color=LEVEL>" + priceText + "</font></td>");
               } else {
                  hb.append("<td width=350 nowrap>" + nameHtml.toString() + "</td>");
                  hb.append("<td width=150 align=right nowrap><font color=LEVEL>" + priceText + "</font></td>");
               }

               hb.append("</tr></table><br1>");
            }
         }

         hb.append("<br>");
         renderVariantsPagination(hb, listType, listPage, itemId, varPage, totalPages, filter);
         hb.append("<br></center></body></html>");
         BaseBBSManager.separateAndSend(hb.toString(), player);
      }
   }

   private static void showAddBoard(L2PcInstance player, int page) {
      HashMap<Integer, ArrayList<ItemInstance>> items = new HashMap<>();
      int curr = 1;
      int counter = 0;
      ArrayList<ItemInstance> temp = new ArrayList<>();

      for (ItemInstance item : player.getInventory().getItems()) {
         if (item.getItemId() != 57 && isMarketplaceTradable(item) && isMarketplaceDepositable(item) && checkItem(item)) {
            temp.add(item);
            if (++counter == 7) {
               items.put(curr, temp);
               temp = new ArrayList<>();
               curr++;
               counter = 0;
            }
         }
      }

      items.put(curr, temp);
      if (!items.containsKey(page)) {
         player.sendMessage("Invalid page. Please try again.");
      } else {
         HtmlBuilder hb = new HtmlBuilder(HtmlBuilder.HtmlType.COMUNITY);
         uiOpen(hb, player, "sell");
         hb.append("<table width=640 cellpadding=6 cellspacing=0>");
         hb.append("<tr><td>");
         hb.append("<font color=F28034>Select an item to sell</font><br1>");
         hb.append("<font color=777777>Only tradable, unequipped items appear.</font>");
         hb.append("</td></tr>");
         hb.append("</table>");
         hb.append("<table width=640 cellpadding=0 cellspacing=0><tr><td height=1 bgcolor=333333></td></tr></table>");
         hb.append("<table width=640 cellpadding=3 cellspacing=0>");
         hb.append("<tr>");
         hb.append("<td width=36></td>");
         hb.append("<td width=260><font color=F28034>Item</font></td>");
         hb.append("<td width=60 align=center><font color=F28034>Count</font></td>");
         hb.append("<td width=84 align=center><font color=F28034>Action</font></td>");
         hb.append("</tr>");
         hb.append("</table>");
         hb.append("<table width=640 cellpadding=0 cellspacing=0><tr><td height=1 bgcolor=333333></td></tr></table>");
         hb.append("<table width=640 cellpadding=3 cellspacing=0>");

         for (ItemInstance item : items.get(page)) {
            String itemName = ItemTable.getInstance().getTemplate(item.getItemId()).getName();
            item.getEnchantLevel();
            item.getEnchantLevel();
            hb.append("<tr>");
            hb.append("<td width=36 height=40><img src=\"" + IconTable.getIcon(item.getItemId()) + "\" width=32 height=32></td>");
            hb.append("<td width=260 nowrap>");
            String augTag = invAugTag(item);
            if (!augTag.isEmpty()) {
               hb.append(augTag + "&nbsp;");
            }

            uiAppendName(hb, itemName, item.getEnchantLevel());
            hb.append("</td>");
            hb.append("<td width=50 align=center><font color=CCCCCC>" + item.getCount() + "</font></td>");
            hb.append(
               "<td width=90 align=center><button value=\"Select\" action=\"bypass bp_additem "
                  + item.getObjectId()
                  + "\" width=74 height=25 back=\"L2Arts.T_74x25\" fore=\"L2Arts.T_74x25_over\"></td>"
            );
            hb.append("</tr>");
         }

         hb.append("</table>");
         int totalPages = items.keySet().size();
         hb.append("<br>");
         hb.append("<table width=640 cellpadding=4 cellspacing=0>");
         hb.append("<tr>");
         hb.append("<td width=140 align=left>");
         if (page > 1) {
            hb.append(
               "<button value=\"<-\" action=\"bypass bp_addpanel "
                  + (page - 1)
                  + "\" width=24 height=24 back=\"L2Arts.BTN_24\" fore=\"L2Arts.BTN_24_Over\">"
            );
         }

         hb.append("</td>");
         hb.append("<td width=160 align=center><font color=CCCCCC>Page " + page + " / " + totalPages + "</font></td>");
         hb.append("<td width=140 align=right>");
         if (totalPages > page) {
            hb.append(
               "<button value=\"->\" action=\"bypass bp_addpanel "
                  + (page + 1)
                  + "\" width=24 height=24 back=\"L2Arts.BTN_24\" fore=\"L2Arts.BTN_24_Over\">"
            );
         }

         hb.append("</td>");
         hb.append("</tr>");
         hb.append("</table>");
         uiClose(hb);
         BaseBBSManager.separateAndSend(hb.toString(), player);
      }
   }

   private static void showAddBoard2(L2PcInstance player, int itemId) {
      ItemInstance item = player.getInventory().getItemByObjectId(itemId);
      if (item == null) {
         player.sendMessage("Item not found.");
         showAddBoard(player, 1);
      } else {
         HtmlBuilder hb = new HtmlBuilder(HtmlBuilder.HtmlType.COMUNITY);
         uiOpen(hb, player, "sell");
         String itemName = ItemTable.getInstance().getTemplate(item.getItemId()).getName();
         item.getEnchantLevel();
         item.getEnchantLevel();
         hb.append("<table width=640 cellpadding=6 cellspacing=0>");
         hb.append("<tr><td>");
         hb.append("<font color=F28034>Sell Item</font><br1>");
         hb.append("<font color=777777>Choose the price and confirm.</font>");
         hb.append("</td></tr>");
         hb.append("</table>");
         hb.append("<table width=640 cellpadding=0 cellspacing=0><tr><td height=1 bgcolor=333333></td></tr></table>");
         hb.append("<table width=640 cellpadding=8 cellspacing=0>");
         hb.append("<tr>");
         hb.append("<td width=40 valign=top><img src=\"" + IconTable.getIcon(item.getItemId()) + "\" width=32 height=32></td>");
         hb.append("<td valign=top>");
         String augTag = invAugTag(item);
         if (!augTag.isEmpty()) {
            hb.append(augTag + "&nbsp;");
         }

         uiAppendName(hb, itemName, item.getEnchantLevel());
         hb.append("<br1>");
         if (isWeaponAugmented(item)) {
            hb.append("<font color=00ff00>Augmentation:</font><br1>");

            try {
               L2Augmentation aug = item.getAugmentation();
               if (aug != null) {
                  L2Skill s = aug.getSkill();
                  if (s != null) {
                     hb.append("<font color=00C8FF>Skill: " + s.getName() + " Lv" + s.getLevel() + "</font><br1>");
                  }

                  for (String d : aug.getDetails()) {
                     hb.append("<font color=CCCCCC>" + d + "</font><br1>");
                  }
               }
            } catch (Exception var12) {
            }

            hb.append("<br1>");
         }

         hb.append("<font color=CCCCCC>Available: " + item.getCount() + "</font><br>");
         hb.append("<font color=CCCCCC>Fee: </font><font color=LEVEL>" + getMarketPlaceFee() + "</font><br><br>");
         if (item.isStackable()) {
            hb.append("<font color=F28034>Amount to sell</font><br1>");
            hb.append("<edit var=amm type=number width=100 height=15><br><br>");
         }

         hb.append("<font color=F28034>Currency</font><br1>");
         hb.append("<combobox width=160 height=17 var=ebox list=" + Config.NAME_MARKET_1 + "><br><br>");
         hb.append("<font color=F28034>Price</font><br1>");
         hb.append("<edit var=count type=number width=160 height=15><br><br>");
         hb.append(
            "<button value=\"Add to Market\" action=\"bypass bp_addit2 "
               + itemId
               + " $ebox $count "
               + (item.isStackable() ? "$amm" : "1")
               + "\" width=110 height=32 back=\"L2Arts.T_110x32\" fore=\"L2Arts.T_110x32_over\">"
         );
         hb.append("&nbsp;");
         hb.append("<button value=\"Back\" action=\"bypass bp_addpanel 1\" width=74 height=25 back=\"L2Arts.T_74x25\" fore=\"L2Arts.T_74x25_over\">");
         hb.append("</td>");
         hb.append("</tr>");
         hb.append("</table>");
         uiClose(hb);
         BaseBBSManager.separateAndSend(hb.toString(), player);
      }
   }

   public static String getMarketPlaceFee() {
      int feeId = Config.MARKETPLACE_FEE[0];
      int feeCount = Config.MARKETPLACE_FEE[1];
      return StringUtil.concat(String.valueOf(feeCount), " - ", ItemTable.getInstance().getTemplate(feeId).getName());
   }

   private static void showMyItemsBoard(L2PcInstance player, int page) {
      Map<Integer, ArrayList<AuctionHolder>> items = new ConcurrentHashMap<>();
      int curr = 1;
      int counter = 0;
      ArrayList<AuctionHolder> temp = new ArrayList<>();

      for (Entry<Integer, AuctionHolder> entry : AuctionTable.getInstance().getItems().entrySet()) {
         if (entry.getValue().getOwnerId() == player.getObjectId()) {
            temp.add(entry.getValue());
            if (++counter == 7) {
               items.put(curr, temp);
               temp = new ArrayList<>();
               curr++;
               counter = 0;
            }
         }
      }

      items.put(curr, temp);
      if (!items.containsKey(page)) {
         player.sendMessage("Invalid page. Please try again.");
      } else {
         HtmlBuilder hb = new HtmlBuilder(HtmlBuilder.HtmlType.COMUNITY);
         uiOpen(hb, player, "my");
         hb.append("<table width=640 cellpadding=6 cellspacing=0>");
         hb.append("<tr><td>");
         hb.append("<font color=F28034>My Sales</font><br1>");
         hb.append("<font color=777777>Remove an item to return it to your inventory.</font>");
         hb.append("</td></tr>");
         hb.append("</table>");

         hb.append("<table width=640 cellpadding=0 cellspacing=0>");
         hb.append("<tr><td height=1 bgcolor=333333></td></tr>");
         hb.append("</table>");

         hb.append("<table width=640 cellpadding=3 cellspacing=0>");
         hb.append("<tr>");
         hb.append("<td width=40></td>");
         hb.append("<td width=275><font color=F28034>Item</font></td>");
         hb.append("<td width=55 align=center><font color=F28034>Qtd</font></td>");
         hb.append("<td width=90 align=center><font color=F28034>Price</font></td>");
         hb.append("<td width=80 align=center><font color=F28034>Action</font></td>");
         hb.append("</tr>");
         hb.append("</table>");

         hb.append("<table width=640 cellpadding=0 cellspacing=0>");
         hb.append("<tr><td height=1 bgcolor=333333></td></tr>");
         hb.append("</table>");

         hb.append("<table width=640 cellpadding=3 cellspacing=0>");

         for (AuctionHolder item : items.get(page))
         {
             String itemName = ItemTable.getInstance().getTemplate(item.getItemId()).getName();

             hb.append("<tr>");

             hb.append("<td width=40 height=40>");
             hb.append("<img src=\"" + IconTable.getIcon(item.getItemId()) + "\" width=32 height=32>");
             hb.append("</td>");

             hb.append("<td width=275 nowrap>");
             uiAppendAugName(hb, item, itemName, item.getEnchant());
             hb.append("</td>");

             hb.append("<td width=55 align=center>");
             hb.append("<font color=CCCCCC>" + item.getCount() + "</font>");
             hb.append("</td>");

             hb.append("<td width=90 align=center>");
             uiAppendPriceInline(hb, item);
             hb.append("</td>");

             hb.append("<td width=80 align=center>");
             hb.append("<button value=\"Remove\" action=\"bypass bp_removeMarket "
                 + item.getAuctionId()
                 + "\" width=74 height=25 back=\"L2Arts.T_74x25\" fore=\"L2Arts.T_74x25_over\">");
             hb.append("</td>");

             hb.append("</tr>");
         }

         hb.append("</table>");
         uiClose(hb);
         BaseBBSManager.separateAndSend(hb.toString(), player);
      }
   }

   private static void showBuyBoard(L2PcInstance player, AuctionHolder item) {
      HtmlBuilder hb = new HtmlBuilder(HtmlBuilder.HtmlType.COMUNITY);
      uiOpen(hb, player, "auction");
      String itemName = ItemTable.getInstance().getTemplate(item.getItemId()).getName();
      item.getEnchant();
      item.getEnchant();
      hb.append("<table width=640 cellpadding=6 cellspacing=0>");
      hb.append("<tr><td>");
      hb.append("<font color=F28034>Confirm Purchase</font>");
      hb.append("</td></tr>");
      hb.append("</table>");
      hb.append("<table width=640 cellpadding=0 cellspacing=0><tr><td height=1 bgcolor=333333></td></tr></table>");
      hb.append("<table width=640 cellpadding=8 cellspacing=0>");
      hb.append("<tr>");
      hb.append("<td width=40 valign=top><img src=\"" + IconTable.getIcon(item.getItemId()) + "\" width=32 height=32></td>");
      hb.append("<td valign=top>");
      uiAppendAugName(hb, item, itemName, item.getEnchant());
      hb.append("<br1>");
      hb.append("<font color=CCCCCC>Quantity: " + item.getCount() + "</font><br1>");
      hb.append("<font color=CCCCCC>Price: </font><font color=LEVEL>" + StringUtil.formatNumber(item.getCostCount()) + "</font><br><br>");
      if (player.isGM()) {
         MarketplaceCBBypasses.SellerCacheEntry sc = getSellerCache(item.getOwnerId());
         hb.append("<font color=777777>Seller:</font> <font color=00FF00>" + escapeHtml(sc.name) + "</font><br1>");
      }

      hb.append(
         "<button value=\"Buy\" action=\"bypass bp_confirmBuy "
            + item.getAuctionId()
            + "\" width=74 height=25 back=\"L2Arts.T_74x25\" fore=\"L2Arts.T_74x25_over\">"
      );
      hb.append("&nbsp;");
      hb.append(
         "<button value=\"Cancel\" action=\"bypass bp_showMarketPlace 1 - *null*\" width=74 height=25 back=\"L2Arts.T_74x25\" fore=\"L2Arts.T_74x25_over\">"
      );
      hb.append("</td>");
      hb.append("</tr>");
      hb.append("</table>");
      uiClose(hb);
      BaseBBSManager.separateAndSend(hb.toString(), player);
   }

   private static void ensureEarningsTable() {
      if (EARNINGS_TABLE_READY) {
         return;
      }

      synchronized (EARNINGS_TABLE_LOCK) {
         if (EARNINGS_TABLE_READY) {
            return;
         }

         try (Connection con = L2DatabaseFactory.getInstance().getConnection();
              PreparedStatement ps = con.prepareStatement(
                 "CREATE TABLE IF NOT EXISTS marketplace_earnings (owner_id INT NOT NULL, currency_id INT NOT NULL, amount BIGINT NOT NULL DEFAULT 0, PRIMARY KEY (owner_id, currency_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8")) {
            ps.executeUpdate();
            EARNINGS_TABLE_READY = true;
         } catch (Exception e) {
            e.printStackTrace();
         }
      }
   }

   private static void creditPendingEarnings(int ownerId, int currencyId, long amount) {
      if (ownerId <= 0 || currencyId <= 0 || amount <= 0) {
         return;
      }

      ensureEarningsTable();
      try (Connection con = L2DatabaseFactory.getInstance().getConnection();
           PreparedStatement ps = con.prepareStatement(
              "INSERT INTO marketplace_earnings (owner_id, currency_id, amount) VALUES (?,?,?) ON DUPLICATE KEY UPDATE amount=amount+VALUES(amount)")) {
         ps.setInt(1, ownerId);
         ps.setInt(2, currencyId);
         ps.setLong(3, amount);
         ps.executeUpdate();
      } catch (Exception e) {
         e.printStackTrace();
      }
   }

   private static long getPendingEarnings(int ownerId, int currencyId) {
      if (ownerId <= 0 || currencyId <= 0) {
         return 0L;
      }

      ensureEarningsTable();
      try (Connection con = L2DatabaseFactory.getInstance().getConnection();
           PreparedStatement ps = con.prepareStatement(
              "SELECT amount FROM marketplace_earnings WHERE owner_id=? AND currency_id=?")) {
         ps.setInt(1, ownerId);
         ps.setInt(2, currencyId);
         try (ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getLong("amount") : 0L;
         }
      } catch (Exception e) {
         return 0L;
      }
   }

   /**
    * Adds a potentially large marketplace balance using this core's int-count addItem API.
    * Splitting prevents overflow when the pending balance is larger than Integer.MAX_VALUE.
    */
   private static void addCollectedCurrency(L2PcInstance player, int currencyId, long amount) {
      long remaining = amount;
      while (remaining > 0L) {
         int chunk = (int)Math.min(remaining, (long)Integer.MAX_VALUE);
         player.addItem("Marketplace Collect", currencyId, chunk, player, true);
         remaining -= chunk;
      }
   }

   private static void collectPendingEarnings(L2PcInstance player) {
      ensureEarningsTable();
      List<int[]> currencies = new ArrayList<>();
      List<Long> amounts = new ArrayList<>();

      try (Connection con = L2DatabaseFactory.getInstance().getConnection()) {
         con.setAutoCommit(false);
         try (PreparedStatement ps = con.prepareStatement(
                 "SELECT currency_id, amount FROM marketplace_earnings WHERE owner_id=? AND amount>0 FOR UPDATE")) {
            ps.setInt(1, player.getObjectId());
            try (ResultSet rs = ps.executeQuery()) {
               while (rs.next()) {
                  currencies.add(new int[]{rs.getInt("currency_id")});
                  amounts.add(rs.getLong("amount"));
               }
            }
         }

         if (currencies.isEmpty()) {
            con.rollback();
            player.sendMessage("You don't have marketplace earnings to collect.");
            return;
         }

         try (PreparedStatement ps = con.prepareStatement(
                 "UPDATE marketplace_earnings SET amount=0 WHERE owner_id=?")) {
            ps.setInt(1, player.getObjectId());
            ps.executeUpdate();
         }
         con.commit();
      } catch (Exception e) {
         e.printStackTrace();
         player.sendMessage("Marketplace earnings could not be collected.");
         return;
      }

      for (int i = 0; i < currencies.size(); i++) {
         int currencyId = currencies.get(i)[0];
         long amount = amounts.get(i);
         addCollectedCurrency(player, currencyId, amount);
         
         MarketCollect.log(
        	      player.getName(),
        	      player.getObjectId(),
        	      currencyId,
        	      amount
        	   );
      }
      player.sendPacket(new InventoryUpdate());
      player.sendMessage("Marketplace earnings collected.");
   }

   public static boolean checkItem(ItemInstance item) {
     if (Config.ENABLE_GRADE_ITEMS_SPAWNSHOP)
       if ((!Config.GRADE_ITEMS_PAWNSHOP.contains(item.getItem().getCrystalType()) && !Config.ITEMS_NO_RULES_PAWNSHOP.contains(Integer.valueOf(item.getItemId()))) || item.getItemType() == EtcItemType.ARROW || item.getItemType() == EtcItemType.SHOT || item.getItemType() == EtcItemType.POTION || item.getItemType() == EtcItemType.ELIXIR || item.getItemType() == EtcItemType.DYE)
         return false;  
     if (!Config.MARKETPLACE_ALLOW_AUGMENTED_SALES && isWeaponAugmented(item))
       return false; 
     return true;
   }

   @Override
   public String[] getBypassHandlersList() {
      return new String[]{
         "bp_showMarketPlace",
         "bp_showByCategory",
         "bp_buy",
         "bp_confirmBuy",
         "bp_addpanel",
         "bp_additem",
         "bp_addit2",
         "bp_myitems",
         "bp_collectMarket",
         "bp_removeMarket",
         "bp_auginfo",
         "bp_showItemVariants"
      };
   }

   private static final class AugInfo {
      final int attributes;
      final int skillId;
      final int skillLevel;

      AugInfo(int attributes, int skillId, int skillLevel) {
         this.attributes = attributes;
         this.skillId = skillId;
         this.skillLevel = skillLevel;
      }

      boolean hasAugment() {
         return this.attributes != 0 || this.skillId != 0;
      }
   }

   public static final class GroupEntry {
      final int itemId;
      final int offers;
      final long totalCount;
      final int bestEnchant;
      final AuctionHolder cheapest;

      GroupEntry(int itemId, int offers, long totalCount, int bestEnchant, AuctionHolder cheapest) {
         this.itemId = itemId;
         this.offers = offers;
         this.totalCount = totalCount;
         this.bestEnchant = bestEnchant;
         this.cheapest = cheapest;
      }
   }

   private static final class SellerCacheEntry {
      final String name;
      final long time;

      SellerCacheEntry(String name) {
         this.name = name;
         this.time = System.currentTimeMillis();
      }

      boolean isExpired() {
         return System.currentTimeMillis() - this.time > 30000L;
      }
   }
}
