package net.sf.l2j.gameserver.handler.community.marketplace.htm;

public class HtmlBuilder {
   private final StringBuilder html;
   private final HtmlBuilder.HtmlType type;

   public HtmlBuilder(HtmlBuilder.HtmlType type) {
      this.html = new StringBuilder(type.getMaxValue());
      this.type = type;
   }

   public HtmlBuilder() {
      this.html = new StringBuilder();
      this.type = HtmlBuilder.HtmlType.HTML;
   }

   public void append(String string) {
      this.html.append(string);
      if (this.html.length() >= this.type.getMaxValue()) {
         System.out.println("Warning html is too long! ----> " + string);
      }
   }

   public void append(Object... obj) {
      for (Object o : obj) {
         this.html.append(o);
      }
   }

   @Override
   public String toString() {
      if (this.html.length() >= this.type.getMaxValue()) {
         System.out.println("Warning html is too long! -> " + this.html.length());
         return "<html><body><br>Html was too long.</body></html>";
      } else {
         return this.html.toString();
      }
   }

   public enum HtmlType {
      COMUNITY(12270),
      HTML(8191);

      int lenght;

      HtmlType(int lenght) {
         this.lenght = lenght;
      }

      public int getMaxValue() {
         return this.lenght;
      }
   }
}
