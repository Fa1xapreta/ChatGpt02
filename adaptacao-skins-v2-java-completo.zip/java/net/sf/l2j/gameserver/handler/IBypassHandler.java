package net.sf.l2j.gameserver.handler;

import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;

public interface IBypassHandler
{
	boolean handleBypass(String paramString, L2PcInstance paramL2PcInstance);
	
	String[] getBypassHandlersList();
}
