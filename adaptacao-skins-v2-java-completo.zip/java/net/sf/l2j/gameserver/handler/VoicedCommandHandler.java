/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.handler;

import java.util.HashMap;
import java.util.Map;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.ShiftClickToNpc;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedAutoFarm;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedAutoFarmSecondary;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedAutoGB;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedBanking;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedBoss;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedCastles;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedCharInfo;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedCharacterPin;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedClanMission;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedColor;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedDeleteBuffs;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedDonate;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedEvent;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedMenu;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedMileniumMonsterData;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedMission;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedPk;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedPremiumServices;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedPvp;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedRanking;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedSkinTry;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedStatus;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedTradeHistory;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedVotePvpZone;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedWeaponTry;

public class VoicedCommandHandler
{
	private final Map<Integer, IVoicedCommandHandler> _datatable = new HashMap<>();
	
	public static VoicedCommandHandler getInstance()
	{
		return SingletonHolder._instance;
	}
	
	protected VoicedCommandHandler()
	{
		registerHandler(new VoicedMileniumMonsterData());
		registerHandler(new VoicedStatus());
		registerHandler(new VoicedCharInfo());

		if (Config.TRADE_HISTORY_ENABLED)
			registerHandler(new VoicedTradeHistory());

		if (Config.PREMIUM_SERVICES_ENABLED)
			registerHandler(new VoicedPremiumServices());
		
		if (Config.ALLOW_MOD_MENU)
		{
			registerHandler(new VoicedWeaponTry());
			registerHandler(new VoicedSkinTry());
			registerHandler(new VoicedBanking());
			registerHandler(new VoicedColor());
			registerHandler(new VoicedMenu());
			registerHandler(new VoicedRanking());
			registerHandler(new VoicedPk());
			registerHandler(new VoicedPvp());
			registerHandler(new VoicedRanking());
			registerHandler(new VoicedCastles());
			registerHandler(new VoicedVotePvpZone());
			registerHandler(new VoicedBoss());
			registerHandler(new VoicedAutoGB());
			registerHandler(new VoicedClanMission());
		}
		
		registerHandler(new VoicedDeleteBuffs());
		registerHandler(new VoicedAutoFarm());
		registerHandler(new VoicedAutoFarmSecondary());
		registerHandler(new VoicedCharacterPin());
		registerHandler(new VoicedEvent());
		registerHandler(new ShiftClickToNpc());
		
		if (Config.ALLOW_MISSION_COMMANDS)
			registerHandler(new VoicedMission());
		
		if (Config.ALLOW_DONATE_COMMANDS)
		{
			registerHandler(new VoicedDonate());
		}
	}
	
	public void registerHandler(IVoicedCommandHandler handler)
	{
		String[] ids = handler.getVoicedCommandList();
		
		for (int i = 0; i < ids.length; i++)        
			_datatable.put(ids[i].hashCode(), handler);
	}
	
	public IVoicedCommandHandler getHandler(String voicedCommand)
	{
		String command = voicedCommand;
		
		if (voicedCommand.indexOf(" ") != -1)        
			command = voicedCommand.substring(0, voicedCommand.indexOf(" "));        
		
		return _datatable.get(command.hashCode());        
	}
	
	public int size()
	{
		return _datatable.size();
	}
	
	private static class SingletonHolder
	{
		protected static final VoicedCommandHandler _instance = new VoicedCommandHandler();
	}
}


