package net.sf.l2j.gameserver.handler.admincommandhandlers;

import java.util.StringTokenizer;

import net.sf.l2j.gameserver.datatables.AugmentationData;
import net.sf.l2j.gameserver.handler.IAdminCommandHandler;
import net.sf.l2j.gameserver.model.L2Augmentation;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.model.itemcontainer.Inventory;
import net.sf.l2j.gameserver.network.serverpackets.InventoryUpdate;
import net.sf.l2j.gameserver.network.serverpackets.ItemList;

public class AdminAugment implements IAdminCommandHandler
{
	private static final String[] _adminCommands =
	{
		"admin_add_arglist",
		"admin_add_arglist_glow",
		"admin_add_arg",
		"admin_add_int",
		"admin_add_str",
		"admin_add_men",
		"admin_add_con",
	};
	
	@Override
	public boolean useAdminCommand(String command, L2PcInstance activeChar)
	{
		if (activeChar.getAccessLevel().getLevel() < 7)
			return false;
		
		StringTokenizer st = new StringTokenizer(command);
		command = st.nextToken();
		
		if (command.startsWith("admin_add_arglist_glow"))
			AdminHelpPage.showHelpPage(activeChar, "augmentweapon_glow.htm");
		
		else if (command.startsWith("admin_add_arglist"))
		{
			AdminHelpPage.showHelpPage(activeChar, "augments.htm");
			return true;
		}
		else if (command.equals("admin_add_arg"))
		{
			L2PcInstance target = activeChar;
			if (activeChar.getTarget() instanceof L2PcInstance)
				target = (L2PcInstance) activeChar.getTarget();
			
			try
			{
				final int skillId = Integer.parseInt(st.nextToken());
				final int skillLevel = Integer.parseInt(st.nextToken());
				
				boolean glow = false;
				int stoneLevel = 9;
				int stoneGrade = 3;
				
				if (st.hasMoreTokens())
					glow = Integer.parseInt(st.nextToken()) == 1;
				
				if (st.hasMoreTokens())
					stoneLevel = Integer.parseInt(st.nextToken());
				
				if (st.hasMoreTokens())
					stoneGrade = Integer.parseInt(st.nextToken());
				
				addSkillAugment(activeChar, target, skillId, skillLevel, glow, stoneLevel, stoneGrade);
				AdminHelpPage.showHelpPage(activeChar, "augmentweapon.htm");
				return true;
			}
			catch (Exception e)
			{
				activeChar.sendMessage("Usage: //add_arg [skillId] [skillLvl] [glow 0/1] [stoneLevel 0-9] [stoneGrade 0-3]");
				AdminHelpPage.showHelpPage(activeChar, "augmentweapon.htm");
				return false;
			}
		}
		else if (command.startsWith("admin_add_int"))
		{
			L2PcInstance target = activeChar;
			if (activeChar.getTarget() instanceof L2PcInstance)
			{
				target = (L2PcInstance) activeChar.getTarget();
				addBaseStat(activeChar, target, 1);
			}
			else
				activeChar.sendMessage("Target invalido");
			
			return true;
		}
		else if (command.startsWith("admin_add_str"))
		{
			L2PcInstance target = activeChar;
			if (activeChar.getTarget() instanceof L2PcInstance)
			{
				target = (L2PcInstance) activeChar.getTarget();
				addBaseStat(activeChar, target, 2);
			}
			else
				activeChar.sendMessage("Target invalido");
			
			return true;
		}
		else if (command.startsWith("admin_add_men"))
		{
			L2PcInstance target = activeChar;
			if (activeChar.getTarget() instanceof L2PcInstance)
			{
				target = (L2PcInstance) activeChar.getTarget();
				addBaseStat(activeChar, target, 3);
			}
			else
				activeChar.sendMessage("Target invalido");
			
			return true;
		}
		else if (command.startsWith("admin_add_con"))
		{
			L2PcInstance target = activeChar;
			if (activeChar.getTarget() instanceof L2PcInstance)
			{
				target = (L2PcInstance) activeChar.getTarget();
				addBaseStat(activeChar, target, 4);
			}
			else
				activeChar.sendMessage("Target invalido");
			
			return true;
		}
		
		return false;
	}
	
	@Override
	public String[] getAdminCommandList()
	{
		return _adminCommands;
	}
	
	public static void addBaseStat(L2PcInstance activeChar, L2PcInstance target, int id)
	{
		if (id == 1)
			id = 1071062100;
		else if (id == 2)
			id = 1070927410;
		else if (id == 3)
			id = 1071123988;
		else if (id == 4)
			id = 1070996530;
		else
		{
			activeChar.sendMessage("Invalido.");
			return;
		}
		
		ItemInstance rhand = target.getInventory().getPaperdollItem(Inventory.PAPERDOLL_RHAND);
		
		if (rhand == null)
		{
			activeChar.sendMessage("O jogador nao esta com arma equipada.");
			return;
		}
		
		if (rhand.isAugmented())
		{
			activeChar.sendMessage("SYS: Esta arma ja esta Argumentada.");
			return;
		}
		
		rhand.setAugmentation(new L2Augmentation(id, 0, 0));
		
		ItemInstance[] unequipped = target.getInventory().unEquipItemInBodySlotAndRecord(rhand.getItem().getBodyPart());
		InventoryUpdate iu = new InventoryUpdate();
		for (ItemInstance item : unequipped)
			iu.addModifiedItem(item);
		
		target.sendPacket(iu);
		
		if (rhand.isAugmented())
			rhand.getAugmentation().applyBonus(target);
		
		target.sendPacket(new ItemList(target, true));
		target.broadcastUserInfo();
	}
	
	public static void addSkillAugment(L2PcInstance activeChar, L2PcInstance target, int skillId, int skillLevel, boolean glow, int stoneLevel, int stoneGrade)
	{
		ItemInstance rhand = target.getInventory().getPaperdollItem(Inventory.PAPERDOLL_RHAND);
		
		if (rhand == null)
		{
			activeChar.sendMessage("O jogador nao esta com arma equipada.");
			return;
		}
		
		if (rhand.isAugmented())
		{
			activeChar.sendMessage("SYS: Esta arma ja esta Argumentada.");
			return;
		}
		
		final int augmentationId = AugmentationData.getInstance().buildSkillAugmentationId(skillId, skillLevel, stoneLevel, stoneGrade, glow);
		
		if (augmentationId == 0)
		{
			activeChar.sendMessage("Nao foi encontrado augmentation para essa skill/level.");
			return;
		}
		
		rhand.setAugmentation(new L2Augmentation(augmentationId, skillId, skillLevel));
		
		ItemInstance[] unequipped = target.getInventory().unEquipItemInBodySlotAndRecord(rhand.getItem().getBodyPart());
		InventoryUpdate iu = new InventoryUpdate();
		for (ItemInstance item : unequipped)
			iu.addModifiedItem(item);
		
		target.sendPacket(iu);
		
		if (rhand.isAugmented())
			rhand.getAugmentation().applyBonus(target);
		
		target.sendPacket(new ItemList(target, true));
		target.broadcastUserInfo();
		
		activeChar.sendMessage("SYS: Voce adicionou augment skill no jogador " + target.getName() + " | Glow: " + (glow ? "ON" : "OFF"));
	}
}