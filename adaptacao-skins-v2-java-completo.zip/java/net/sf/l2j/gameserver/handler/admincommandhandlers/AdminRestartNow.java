package net.sf.l2j.gameserver.handler.admincommandhandlers;

import net.sf.l2j.gameserver.Restart;
import net.sf.l2j.gameserver.handler.IAdminCommandHandler;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;

public class AdminRestartNow implements IAdminCommandHandler
{
	private static final String[] ADMIN_COMMANDS = { "admin_restart","admin_abort" };

	@Override
	public boolean useAdminCommand(String command, L2PcInstance activeChar)
	{
		if (command.startsWith("admin_restart"))
		{
			Restart.getInstance().abortRestart();
			Restart.getInstance().StartCalculationOfNextRestartTime();
			String time = Restart.getInstance().getRestartNextTime().toString();
			activeChar.sendMessage("Restart programado para as [ " + time + " ]");
		}
		else if (command.startsWith("admin_abort"))
		{
			Restart.getInstance().abortRestart();
			activeChar.sendMessage("Restart programado Abortado");
		}
		return true;
	}

	@Override
	public String[] getAdminCommandList()
	{
		return ADMIN_COMMANDS;
	}
}