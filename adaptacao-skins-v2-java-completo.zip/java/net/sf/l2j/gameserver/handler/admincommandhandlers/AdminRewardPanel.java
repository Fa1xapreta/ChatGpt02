/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 */
package net.sf.l2j.gameserver.handler.admincommandhandlers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.handler.IAdminCommandHandler;
import net.sf.l2j.gameserver.model.L2Object;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.item.kind.Item;
import net.sf.l2j.gameserver.network.serverpackets.ItemList;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;

public class AdminRewardPanel implements IAdminCommandHandler
{
	private static final Logger _log = Logger.getLogger(AdminRewardPanel.class.getName());
	
	private static final String[] ADMIN_COMMANDS =
	{
		"admin_reward_panel"
	};
	
	private static final String TYPE_CLAN = "clan";
	private static final String TYPE_STREAMER = "streamer";
	
	@Override
	public boolean useAdminCommand(String command, L2PcInstance activeChar)
	{
		if (activeChar.getAccessLevel().getLevel() < 1)
			return false;
		
		ensureTables();
		
		StringTokenizer st = new StringTokenizer(command);
		st.nextToken();
		
		if (!st.hasMoreTokens())
		{
			showPanel(activeChar);
			return true;
		}
		
		String action = st.nextToken();
		if ("add_clan_config".equalsIgnoreCase(action))
			addConfigReward(activeChar, TYPE_CLAN, st);
		else if ("add_streamer_config".equalsIgnoreCase(action))
			addConfigReward(activeChar, TYPE_STREAMER, st);
		else if ("delete_config".equalsIgnoreCase(action))
			deleteConfigReward(activeChar, st);
		else if ("delete".equalsIgnoreCase(action))
			deleteReward(activeChar, st);
		else if (TYPE_CLAN.equalsIgnoreCase(action))
			rewardClan(activeChar);
		else if (TYPE_STREAMER.equalsIgnoreCase(action))
			rewardStreamer(activeChar, st);
		
		showPanel(activeChar);
		return true;
	}
	
	@Override
	public String[] getAdminCommandList()
	{
		return ADMIN_COMMANDS;
	}
	
	private void addConfigReward(L2PcInstance activeChar, String type, StringTokenizer st)
	{
		try
		{
			int itemId = Integer.parseInt(st.nextToken());
			int count = Integer.parseInt(st.nextToken());
			RewardConfig config = getConfig(type);
			config.items.add(new RewardItem(itemId, count));
			
			if (!isValidReward(activeChar, config))
				return;
			
			saveConfig(type, config);
			activeChar.sendMessage("Reward item added: " + type + ".");
		}
		catch (Exception e)
		{
			activeChar.sendMessage("Usage: //reward_panel add_" + type + "_config <itemId> <count>");
		}
	}
	
	private void deleteConfigReward(L2PcInstance activeChar, StringTokenizer st)
	{
		try
		{
			String type = clean(st.nextToken()).toLowerCase();
			int index = Integer.parseInt(st.nextToken());
			if (!TYPE_CLAN.equals(type) && !TYPE_STREAMER.equals(type))
			{
				activeChar.sendMessage("Invalid reward type.");
				return;
			}
			
			RewardConfig config = getConfig(type);
			if (index < 0 || index >= config.items.size())
			{
				activeChar.sendMessage("Reward config item not found.");
				return;
			}
			
			config.items.remove(index);
			if (config.items.isEmpty())
			{
				activeChar.sendMessage("Config needs at least one reward item.");
				return;
			}
			
			saveConfig(type, config);
			activeChar.sendMessage("Reward config item deleted: " + type + ".");
		}
		catch (Exception e)
		{
			activeChar.sendMessage("Usage: //reward_panel delete_config <clan|streamer> <index>");
		}
	}
	
	private void rewardClan(L2PcInstance activeChar)
	{
		L2PcInstance target = getTargetPlayer(activeChar);
		if (target == null)
		{
			activeChar.sendMessage("Select an online player.");
			return;
		}
		if (target.getClan() == null || !target.isClanLeader())
		{
			activeChar.sendMessage("Target must be a clan leader.");
			return;
		}
		
		RewardConfig config = getConfig(TYPE_CLAN);
		if (!isValidReward(activeChar, config))
			return;
		
		String ip = target.getIP();
		String hwid = safe(target.getHWid());
		String clanName = target.getClan().getName();
		
		if (hasClanReward(target.getObjectId(), ip, hwid, clanName))
		{
			activeChar.sendMessage("This clan leader/clan already received reward.");
			return;
		}
		
		if (!giveReward(activeChar, target, config))
			return;
		
		insertHistory(TYPE_CLAN, target, ip, hwid, clanName, "", "", config, activeChar.getName());
		activeChar.sendMessage("Clan reward delivered to " + target.getName() + " (" + clanName + ").");
	}
	
	private void deleteReward(L2PcInstance activeChar, StringTokenizer st)
	{
		try
		{
			int id = Integer.parseInt(st.nextToken());
			
			try (Connection con = L2DatabaseFactory.getInstance().getConnection();
				PreparedStatement ps = con.prepareStatement("DELETE FROM admin_reward_history WHERE id=?"))
			{
				ps.setInt(1, id);
				if (ps.executeUpdate() > 0)
					activeChar.sendMessage("Reward history deleted: " + id);
				else
					activeChar.sendMessage("Reward history not found: " + id);
			}
		}
		catch (Exception e)
		{
			activeChar.sendMessage("Usage: //reward_panel delete <id>");
		}
	}
	
	private void rewardStreamer(L2PcInstance activeChar, StringTokenizer st)
	{
		L2PcInstance target = getTargetPlayer(activeChar);
		if (target == null)
		{
			activeChar.sendMessage("Select an online player.");
			return;
		}
		if (st.countTokens() < 2)
		{
			activeChar.sendMessage("Usage: //reward_panel streamer <facebook|youtube|tiktok|twitch> <streamer>");
			return;
		}
		
		String platform = clean(st.nextToken()).toLowerCase();
		String streamer = clean(st.nextToken()).replace('_', ' ');
		if (!isStreamerPlatform(platform) || streamer.isEmpty())
		{
			activeChar.sendMessage("Use platform facebook, youtube, tiktok or twitch and streamer name/link.");
			return;
		}
		
		RewardConfig config = getConfig(TYPE_STREAMER);
		if (!isValidReward(activeChar, config))
			return;
		
		String ip = target.getIP();
		String hwid = safe(target.getHWid());
		
		if (hasStreamerReward(target.getObjectId(), ip, hwid, streamer))
		{
			activeChar.sendMessage("This streamer/player already received reward.");
			return;
		}
		
		if (!giveReward(activeChar, target, config))
			return;
		
		insertHistory(TYPE_STREAMER, target, ip, hwid, "", platform, streamer, config, activeChar.getName());
		activeChar.sendMessage("Streamer reward delivered to " + target.getName() + " (" + platform + ": " + streamer + ").");
	}
	
	private L2PcInstance getTargetPlayer(L2PcInstance activeChar)
	{
		L2Object target = activeChar.getTarget();
		if (target instanceof L2PcInstance)
			return (L2PcInstance) target;
		
		return activeChar;
	}
	
	private boolean giveReward(L2PcInstance activeChar, L2PcInstance target, RewardConfig config)
	{
		for (RewardItem reward : config.items)
		{
			Item item = ItemTable.getInstance().getTemplate(reward.itemId);
			if (item == null)
			{
				activeChar.sendMessage("Reward item does not exist: " + reward.itemId);
				return false;
			}
			if (reward.count > 1 && !item.isStackable())
			{
				activeChar.sendMessage("Reward item is not stackable: " + reward.itemId);
				return false;
			}
		}
		
		for (RewardItem reward : config.items)
			target.getInventory().addItem("AdminReward", reward.itemId, reward.count, target, activeChar);
		
		target.sendPacket(new ItemList(target, true));
		if (target != activeChar)
			target.sendMessage("You received a reward from the staff.");
		
		return true;
	}
	
	private boolean hasClanReward(int objectId, String ip, String hwid, String clanName)
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT id FROM admin_reward_history WHERE reward_type=? AND (object_id=? OR (ip<>'' AND ip=?) OR (hwid<>'' AND hwid=?) OR LOWER(clan_name)=LOWER(?)) LIMIT 1"))
		{
			ps.setString(1, TYPE_CLAN);
			ps.setInt(2, objectId);
			ps.setString(3, safe(ip));
			ps.setString(4, safe(hwid));
			ps.setString(5, safe(clanName));
			
			try (ResultSet rs = ps.executeQuery())
			{
				return rs.next();
			}
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not check clan reward history.", e);
			return true;
		}
	}
	
	private boolean hasStreamerReward(int objectId, String ip, String hwid, String streamer)
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT id FROM admin_reward_history WHERE reward_type=? AND (object_id=? OR (ip<>'' AND ip=?) OR (hwid<>'' AND hwid=?) OR LOWER(streamer)=LOWER(?)) LIMIT 1"))
		{
			ps.setString(1, TYPE_STREAMER);
			ps.setInt(2, objectId);
			ps.setString(3, safe(ip));
			ps.setString(4, safe(hwid));
			ps.setString(5, clean(streamer));
			
			try (ResultSet rs = ps.executeQuery())
			{
				return rs.next();
			}
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not check streamer reward history.", e);
			return true;
		}
	}
	
	private void insertHistory(String type, L2PcInstance target, String ip, String hwid, String clanName, String platform, String streamer, RewardConfig config, String rewardedBy)
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement("INSERT INTO admin_reward_history (reward_type, player_name, ip, hwid, object_id, clan_name, platform, streamer, item_id, item_count, reward_items, rewarded_by, reward_date) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,NOW())"))
		{
			ps.setString(1, type);
			ps.setString(2, target.getName());
			ps.setString(3, safe(ip));
			ps.setString(4, safe(hwid));
			ps.setInt(5, target.getObjectId());
			ps.setString(6, safe(clanName));
			ps.setString(7, safe(platform));
			ps.setString(8, safe(streamer));
			ps.setInt(9, config.first().itemId);
			ps.setInt(10, config.first().count);
			ps.setString(11, config.toConfigString());
			ps.setString(12, rewardedBy);
			ps.executeUpdate();
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not insert reward history.", e);
		}
	}
	
	private RewardConfig getConfig(String type)
	{
		ensureConfig(type);
		
		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT item_id, item_count, rewards FROM admin_reward_config WHERE reward_type=?"))
		{
			ps.setString(1, type);
			try (ResultSet rs = ps.executeQuery())
			{
				if (rs.next())
					return parseConfig(rs.getString("rewards"), rs.getInt("item_id"), rs.getInt("item_count"));
			}
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not load reward config.", e);
		}
		
		return parseConfig("", 57, 1);
	}
	
	private void saveConfig(String type, RewardConfig config)
	{
		ensureConfig(type);
		
		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement("UPDATE admin_reward_config SET item_id=?, item_count=?, rewards=? WHERE reward_type=?"))
		{
			ps.setInt(1, config.first().itemId);
			ps.setInt(2, config.first().count);
			ps.setString(3, config.toConfigString());
			ps.setString(4, type);
			ps.executeUpdate();
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not save reward config.", e);
		}
	}
	
	private void ensureConfig(String type)
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement("INSERT IGNORE INTO admin_reward_config (reward_type, item_id, item_count, rewards) VALUES (?,57,1,'57,1')"))
		{
			ps.setString(1, type);
			ps.executeUpdate();
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not ensure reward config.", e);
		}
	}
	
	private void ensureTables()
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			Statement st = con.createStatement())
		{
			st.executeUpdate("CREATE TABLE IF NOT EXISTS admin_reward_config (reward_type VARCHAR(16) NOT NULL PRIMARY KEY, item_id INT NOT NULL DEFAULT 57, item_count INT NOT NULL DEFAULT 1, rewards TEXT NOT NULL)");
			st.executeUpdate("CREATE TABLE IF NOT EXISTS admin_reward_history (id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, reward_type VARCHAR(16) NOT NULL, player_name VARCHAR(35) NOT NULL, ip VARCHAR(45) NOT NULL DEFAULT '', hwid VARCHAR(128) NOT NULL DEFAULT '', object_id INT NOT NULL, clan_name VARCHAR(45) NOT NULL DEFAULT '', platform VARCHAR(16) NOT NULL DEFAULT '', streamer VARCHAR(255) NOT NULL DEFAULT '', item_id INT NOT NULL, item_count INT NOT NULL, reward_items TEXT NOT NULL, rewarded_by VARCHAR(35) NOT NULL DEFAULT '', reward_date DATETIME NOT NULL, KEY idx_reward_type_object (reward_type, object_id), KEY idx_reward_type_ip (reward_type, ip), KEY idx_reward_type_hwid (reward_type, hwid), KEY idx_reward_type_clan (reward_type, clan_name), KEY idx_reward_type_streamer (reward_type, platform, streamer))");
			addColumnIfMissing(st, "admin_reward_config", "rewards", "TEXT NOT NULL");
			addColumnIfMissing(st, "admin_reward_history", "reward_items", "TEXT NOT NULL");
			modifyColumn(st, "admin_reward_config", "rewards", "TEXT NOT NULL");
			modifyColumn(st, "admin_reward_history", "reward_items", "TEXT NOT NULL");
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not create admin reward tables.", e);
		}
	}
	
	private void addColumnIfMissing(Statement st, String table, String column, String definition)
	{
		try
		{
			st.executeUpdate("ALTER TABLE " + table + " ADD COLUMN " + column + " " + definition);
		}
		catch (Exception ignored)
		{
		}
	}
	
	private void modifyColumn(Statement st, String table, String column, String definition)
	{
		try
		{
			st.executeUpdate("ALTER TABLE " + table + " MODIFY COLUMN " + column + " " + definition);
		}
		catch (Exception ignored)
		{
		}
	}
	
	private boolean isValidReward(L2PcInstance activeChar, RewardConfig config)
	{
		if (config.items.isEmpty())
		{
			activeChar.sendMessage("Reward list is empty.");
			return false;
		}
		
		for (RewardItem reward : config.items)
		{
			if (reward.itemId <= 0 || reward.count <= 0)
			{
				activeChar.sendMessage("Reward item and count must be greater than zero.");
				return false;
			}
			if (ItemTable.getInstance().getTemplate(reward.itemId) == null)
			{
				activeChar.sendMessage("Reward item does not exist: " + reward.itemId);
				return false;
			}
		}
		
		return true;
	}
	
	private RewardConfig parseConfig(String rewards, int fallbackItemId, int fallbackCount)
	{
		try
		{
			if (rewards != null && !rewards.trim().isEmpty())
				return parseRewards(rewards);
		}
		catch (Exception ignored)
		{
		}
		
		RewardConfig config = new RewardConfig();
		config.items.add(new RewardItem(fallbackItemId, fallbackCount));
		return config;
	}
	
	private RewardConfig parseRewards(String value)
	{
		RewardConfig config = new RewardConfig();
		value = clean(value).trim().replace(":", ",");
		
		String[] tokens = value.split("\\s+");
		if (tokens.length > 1 && tokens.length % 2 == 0 && !value.contains(",") && !value.contains(";"))
		{
			for (int i = 0; i < tokens.length; i += 2)
				config.items.add(new RewardItem(Integer.parseInt(tokens[i].trim()), Integer.parseInt(tokens[i + 1].trim())));
			
			return config;
		}
		
		value = value.replaceAll("\\s+", ";");
		for (String reward : value.split(";"))
		{
			if (reward.trim().isEmpty())
				continue;
			
			String[] parts = reward.split(",");
			if (parts.length != 2)
				continue;
			
			config.items.add(new RewardItem(Integer.parseInt(parts[0].trim()), Integer.parseInt(parts[1].trim())));
		}
		
		return config;
	}
	
	private boolean isStreamerPlatform(String platform)
	{
		return "facebook".equals(platform) || "youtube".equals(platform) || "tiktok".equals(platform) || "twitch".equals(platform);
	}
	
	private void showPanel(L2PcInstance activeChar)
	{
		RewardConfig clanConfig = getConfig(TYPE_CLAN);
		RewardConfig streamerConfig = getConfig(TYPE_STREAMER);
		L2PcInstance target = getTargetPlayer(activeChar);
		
		String targetName = target != null ? target.getName() : "Nenhum";
		String targetIp = target != null ? target.getIP() : "";
		String targetHwid = target != null ? safe(target.getHWid()) : "";
		String targetObjectId = target != null ? String.valueOf(target.getObjectId()) : "";
		String clanName = target != null && target.getClan() != null ? target.getClan().getName() : "";
		String clanStatus = target != null && target.getClan() != null && target.isClanLeader() ? "Lider" : "Nao lider";
		
		StringBuilder html = new StringBuilder();
		html.append("<html><body>");
		html.append("<center><font color=\"LEVEL\">Reward Panel</font><br1>");
		html.append("<a action=\"bypass -h admin_reward_panel\">Refresh</a></center><br>");
		
		html.append(sectionHeader("Target"));
		html.append("<table width=300 bgcolor=\"111111\">");
		html.append("<tr><td width=62>Player:</td><td width=238><font color=\"LEVEL\">").append(escape(targetName)).append("</font></td></tr>");
		html.append("<tr><td>IP:</td><td>").append(escape(targetIp)).append("</td></tr>");
		html.append("<tr><td>HWID:</td><td>").append(escape(shorten(targetHwid, 32))).append("</td></tr>");
		html.append("<tr><td>Obj:</td><td>").append(escape(targetObjectId)).append("</td></tr>");
		html.append("<tr><td>Clan:</td><td>").append(escape(clanName)).append(" <font color=\"777777\">").append(escape(clanStatus)).append("</font></td></tr>");
		html.append("</table><br>");
		
		html.append(sectionHeader("Clan Reward"));
		html.append(configRewardsHtml(TYPE_CLAN, clanConfig));
		html.append("<table width=300><tr><td width=38>Item:</td><td width=82><edit var=\"ClanItem\" width=75 height=15></td><td width=30>Qtd:</td><td width=70><edit var=\"ClanCount\" width=65 height=15></td><td width=80><button value=\"Add\" action=\"bypass -h admin_reward_panel add_clan_config $ClanItem $ClanCount\" width=75 height=20 back=\"L2UI_ch3.smallbutton2_over\" fore=\"L2UI_ch3.smallbutton2\"></td></tr></table>");
		html.append("<center><button value=\"Reward Clan Leader\" action=\"bypass -h admin_reward_panel clan\" width=140 height=20 back=\"L2UI_ch3.smallbutton2_over\" fore=\"L2UI_ch3.smallbutton2\"></center><br>");
		
		html.append(sectionHeader("Streamer Reward"));
		html.append(configRewardsHtml(TYPE_STREAMER, streamerConfig));
		html.append("<table width=300><tr><td width=38>Item:</td><td width=82><edit var=\"StreamerItem\" width=75 height=15></td><td width=30>Qtd:</td><td width=70><edit var=\"StreamerCount\" width=65 height=15></td><td width=80><button value=\"Add\" action=\"bypass -h admin_reward_panel add_streamer_config $StreamerItem $StreamerCount\" width=75 height=20 back=\"L2UI_ch3.smallbutton2_over\" fore=\"L2UI_ch3.smallbutton2\"></td></tr></table><br1>");
		
		html.append(sectionHeader("Deliver Streamer"));
		html.append("<table width=300 bgcolor=\"111111\">");
		html.append("<tr><td width=62>Platform:</td><td width=238><edit var=\"Platform\" width=140 height=15></td></tr>");
		html.append("<tr><td>Channel:</td><td><edit var=\"Streamer\" width=180 height=15></td></tr>");
		html.append("</table>");
		html.append("<center><button value=\"Reward Streamer\" action=\"bypass -h admin_reward_panel streamer $Platform $Streamer\" width=130 height=20 back=\"L2UI_ch3.smallbutton2_over\" fore=\"L2UI_ch3.smallbutton2\"></center>");
		html.append("<font color=\"777777\">facebook, youtube, tiktok, twitch. Use _ for spaces.</font><br><br>");
		
		html.append(sectionHeader("Clan History"));
		html.append(lastRewards(TYPE_CLAN));
		html.append("<br>").append(sectionHeader("Streamer History"));
		html.append(lastRewards(TYPE_STREAMER));
		html.append("</body></html>");
		
		NpcHtmlMessage msg = new NpcHtmlMessage(0);
		msg.setHtml(html.toString());
		activeChar.sendPacket(msg);
	}
	
	private String sectionHeader(String title)
	{
		return "<table width=300 bgcolor=\"222222\"><tr><td><font color=\"LEVEL\">" + title + "</font></td></tr></table>";
	}
	
	private String configRewardsHtml(String type, RewardConfig config)
	{
		StringBuilder sb = new StringBuilder();
		sb.append("<table width=300>");
		if (config.items.isEmpty())
		{
			sb.append("<tr><td width=300><font color=\"777777\">No rewards configured.</font></td></tr>");
		}
		
		for (int i = 0; i < config.items.size(); i++)
		{
			RewardItem item = config.items.get(i);
			sb.append("<tr><td width=40>#").append(i + 1).append("</td><td width=155>");
			sb.append("Item ").append(item.itemId).append(" x").append(item.count);
			sb.append("</td><td width=85><a action=\"bypass -h admin_reward_panel delete_config ");
			sb.append(type).append(" ").append(i).append("\">Delete</a></td></tr>");
		}
		sb.append("</table>");
		return sb.toString();
	}
	
	private String lastRewards(String type)
	{
		StringBuilder sb = new StringBuilder();
		sb.append("<table width=300>");
		boolean found = false;
		
		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT id, player_name, ip, hwid, object_id, clan_name, platform, streamer, item_id, item_count, reward_items, reward_date FROM admin_reward_history WHERE reward_type=? ORDER BY id DESC LIMIT 5"))
		{
			ps.setString(1, type);
			try (ResultSet rs = ps.executeQuery())
			{
				while (rs.next())
				{
					found = true;
					String rewards = rs.getString("reward_items");
					if (rewards == null || rewards.isEmpty())
						rewards = rs.getInt("item_id") + "," + rs.getInt("item_count");
					
					sb.append("<tr><td width=300>");
					sb.append("<table width=300 bgcolor=\"111111\">");
					sb.append("<tr><td width=45>#").append(rs.getInt("id")).append("</td><td width=185><font color=\"LEVEL\">").append(escape(rs.getString("player_name"))).append("</font></td><td width=70><a action=\"bypass -h admin_reward_panel delete ").append(rs.getInt("id")).append("\">Delete</a></td></tr>");
					if (TYPE_CLAN.equals(type))
						sb.append("<tr><td>Clan:</td><td colspan=2>").append(escape(rs.getString("clan_name"))).append("</td></tr>");
					else
						sb.append("<tr><td>Live:</td><td colspan=2>").append(escape(rs.getString("platform"))).append(": ").append(escape(rs.getString("streamer"))).append("</td></tr>");
					sb.append("<tr><td>IP:</td><td colspan=2>").append(escape(rs.getString("ip"))).append("</td></tr>");
					sb.append("<tr><td>HWID:</td><td colspan=2>").append(escape(shorten(rs.getString("hwid"), 24))).append("</td></tr>");
					sb.append("<tr><td>Items:</td><td colspan=2>").append(escape(shorten(rewards, 38))).append("</td></tr>");
					sb.append("</table><br1>");
					sb.append("</td></tr>");
				}
			}
		}
		catch (Exception e)
		{
			sb.append("<tr><td>Failed to list rewards.</td></tr>");
			found = true;
		}
		
		if (!found)
			sb.append("<tr><td><font color=\"777777\">No history.</font></td></tr>");
		
		sb.append("</table>");
		return sb.toString();
	}
	private String safe(String value)
	{
		return value == null ? "" : clean(value);
	}
	
	private String clean(String value)
	{
		if (value == null)
			return "";
		
		return value.trim().replace("\r", "").replace("\n", "").replace("|", "").replace("<", "").replace(">", "");
	}
	
	private String escape(String value)
	{
		return safe(value).replace("&", "&amp;").replace("\"", "&quot;");
	}
	
	private String shorten(String value, int max)
	{
		value = safe(value);
		if (value.length() <= max)
			return value;
		
		return value.substring(0, max);
	}
	
	private static final class RewardConfig
	{
		final List<RewardItem> items = new ArrayList<>();
		
		RewardItem first()
		{
			return items.get(0);
		}
		
		String toConfigString()
		{
			StringBuilder sb = new StringBuilder();
			for (RewardItem item : items)
			{
				if (sb.length() > 0)
					sb.append(';');
				sb.append(item.itemId).append(',').append(item.count);
			}
			return sb.toString();
		}
	}
	
	private static final class RewardItem
	{
		final int itemId;
		final int count;
		
		RewardItem(int itemId, int count)
		{
			this.itemId = itemId;
			this.count = count;
		}
	}
}
