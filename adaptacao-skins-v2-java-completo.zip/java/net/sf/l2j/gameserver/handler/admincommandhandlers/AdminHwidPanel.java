package net.sf.l2j.gameserver.handler.admincommandhandlers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

import hwid.Hwid;
import hwid.hwidmanager.HWIDHistoryManager;
import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.handler.IAdminCommandHandler;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;

public class AdminHwidPanel implements IAdminCommandHandler
{
	private static final Logger _log = Logger.getLogger(AdminHwidPanel.class.getName());
	private static final int PAGE_SIZE = 8;
	private static final String VIEW_SHARED = "shared";
	private static final String VIEW_CHANGES = "changes";
	private static final String VIEW_FLAGS = "flags";
	private static final String VIEW_SEARCH = "search";
	private static final String[] ADMIN_COMMANDS =
	{
		"admin_hwid_panel"
	};

	@Override
	public boolean useAdminCommand(String command, L2PcInstance activeChar)
	{
		if (activeChar.getAccessLevel().getLevel() < 1)
			return false;

		HWIDHistoryManager.ensureTables();

		StringTokenizer st = new StringTokenizer(command);
		st.nextToken();

		if (!st.hasMoreTokens())
		{
			showPanel(activeChar, VIEW_SHARED, "", 0);
			return true;
		}

		String action = clean(st.nextToken()).toLowerCase();
		if ("view".equals(action))
		{
			String view = st.hasMoreTokens() ? clean(st.nextToken()).toLowerCase() : VIEW_SHARED;
			int page = st.hasMoreTokens() ? parsePage(st.nextToken()) : 0;
			showPanel(activeChar, normalizeView(view), "", page);
		}
		else if ("search".equals(action))
		{
			String search = st.hasMoreTokens() ? clean(st.nextToken()) : "";
			int page = st.hasMoreTokens() ? parsePage(st.nextToken()) : 0;
			showPanel(activeChar, VIEW_SEARCH, search, page);
		}
		else if ("flag".equals(action))
		{
			flag(activeChar, st);
			showPanel(activeChar, VIEW_FLAGS, "", 0);
		}
		else if ("unblock".equals(action))
		{
			unblock(activeChar, st);
			showPanel(activeChar, VIEW_FLAGS, "", 0);
		}
		else
			showPanel(activeChar, VIEW_SEARCH, clean(action), 0);

		return true;
	}

	@Override
	public String[] getAdminCommandList()
	{
		return ADMIN_COMMANDS;
	}

	private void flag(L2PcInstance activeChar, StringTokenizer st)
	{
		try
		{
			String status = clean(st.nextToken()).toLowerCase();
			String hwid = clean(st.nextToken());
			String reason = collectRemaining(st);

			if (!"trusted".equals(status) && !"suspect".equals(status) && !"blocked".equals(status))
			{
				activeChar.sendMessage("Use status trusted, suspect or blocked.");
				return;
			}

			try (Connection con = L2DatabaseFactory.getInstance().getConnection())
			{
				String accountName = "";
				String playerName = "";
				try (PreparedStatement info = con.prepareStatement("SELECT account_name, player_name FROM hwid_history WHERE hwid=? ORDER BY last_seen DESC LIMIT 1"))
				{
					info.setString(1, hwid);
					try (ResultSet rs = info.executeQuery())
					{
						if (rs.next())
						{
							accountName = clean(rs.getString("account_name"));
							playerName = clean(rs.getString("player_name"));
						}
					}
				}

				try (PreparedStatement ps = con.prepareStatement("INSERT INTO hwid_flags (hwid, account_name, player_name, status, reason, created_by, created_at, updated_at) VALUES (?,?,?,?,?,?,NOW(),NOW()) ON DUPLICATE KEY UPDATE player_name=VALUES(player_name), status=VALUES(status), reason=VALUES(reason), created_by=VALUES(created_by), updated_at=NOW()"))
				{
					ps.setString(1, hwid);
					ps.setString(2, accountName);
					ps.setString(3, playerName);
					ps.setString(4, status);
					ps.setString(5, reason);
					ps.setString(6, activeChar.getName());
					ps.executeUpdate();
				}
			}

			activeChar.sendMessage("HWID marked as " + status + ".");
		}
		catch (Exception e)
		{
			activeChar.sendMessage("Usage: //hwid_panel flag <trusted|suspect|blocked> <hwid> <reason>");
		}
	}
	private void unblock(L2PcInstance activeChar, StringTokenizer st)
	{
		try
		{
			String hwid = clean(st.nextToken());
			try (Connection con = L2DatabaseFactory.getInstance().getConnection();
				PreparedStatement ps = con.prepareStatement("DELETE FROM hwid_flags WHERE hwid=?"))
			{
				ps.setString(1, hwid);
				ps.executeUpdate();
			}

			activeChar.sendMessage("HWID unblocked.");
		}
		catch (Exception e)
		{
			activeChar.sendMessage("Usage: //hwid_panel unblock <hwid>");
		}
	}

	private void showPanel(L2PcInstance activeChar, String view, String search, int page)
	{
		page = Math.max(0, page);
		view = normalizeView(view);
		search = clean(search);

		StringBuilder html = new StringBuilder();
		html.append("<html><body>");
		html.append("<center><font color=\"LEVEL\">HWID Panel</font></center><br1>");
		html.append(nav(view));
		html.append(summary());
		html.append("<br1><table width=300><tr><td width=45>Find:</td><td width=175><edit var=\"HwidSearch\" width=170 height=15></td><td width=80><button value=\"Search\" action=\"bypass -h admin_hwid_panel search $HwidSearch\" width=75 height=20 back=\"L2UI_ch3.smallbutton2_over\" fore=\"L2UI_ch3.smallbutton2\"></td></tr></table><br1>");

		if (VIEW_SEARCH.equals(view))
			html.append(searchRows(search, page));
		else if (VIEW_CHANGES.equals(view))
			html.append(changingAccounts(page));
		else if (VIEW_FLAGS.equals(view))
			html.append(flagRows(page));
		else
			html.append(sharedHwids(page));

		html.append("<br><font color=\"777777\">Block removes access. Unblock deletes the flag.</font>");
		html.append("</body></html>");

		NpcHtmlMessage msg = new NpcHtmlMessage(0);
		msg.setHtml(html.toString());
		activeChar.sendPacket(msg);
	}

	private String nav(String currentView)
	{
		StringBuilder sb = new StringBuilder();
		sb.append("<center>");
		appendTab(sb, "Shared", VIEW_SHARED, currentView);
		sb.append(" ");
		appendTab(sb, "Changes", VIEW_CHANGES, currentView);
		sb.append(" ");
		appendTab(sb, "Flags", VIEW_FLAGS, currentView);
		sb.append(" ");
		sb.append("<a action=\"bypass -h admin_hwid_panel\">Refresh</a>");
		sb.append("</center><br>");
		return sb.toString();
	}

	private void appendTab(StringBuilder sb, String label, String view, String currentView)
	{
		if (view.equals(currentView))
			sb.append("<font color=\"LEVEL\">[").append(label).append("]</font>");
		else
			sb.append("<a action=\"bypass -h admin_hwid_panel view ").append(view).append(" 0\">[").append(label).append("]</a>");
	}

	private String summary()
	{
		int history = 0;
		int hwids = 0;
		int flags = 0;

		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			Statement st = con.createStatement())
		{
			try (ResultSet rs = st.executeQuery("SELECT COUNT(*) records, COUNT(DISTINCT hwid) hwids FROM hwid_history"))
			{
				if (rs.next())
				{
					history = rs.getInt("records");
					hwids = rs.getInt("hwids");
				}
			}

			try (ResultSet rs = st.executeQuery("SELECT COUNT(*) flags FROM hwid_flags"))
			{
				if (rs.next())
					flags = rs.getInt("flags");
			}
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not load HWID panel summary.", e);
		}

		StringBuilder sb = new StringBuilder();
		sb.append("<table width=300 bgcolor=\"111111\"><tr>");
		sb.append("<td width=100>Records: <font color=\"LEVEL\">").append(history).append("</font></td>");
		sb.append("<td width=100>HWIDs: <font color=\"LEVEL\">").append(hwids).append("</font></td>");
		sb.append("<td width=100>Flags: <font color=\"LEVEL\">").append(flags).append("</font></td>");
		sb.append("</tr></table>");
		return sb.toString();
	}

	private String sharedHwids(int page)
	{
		StringBuilder sb = new StringBuilder();
		int total = countSharedHwids();
		header(sb, "Shared HWIDs", page, total);
		sb.append("<table width=300>");
		boolean found = false;

		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT h.hwid, SUBSTRING_INDEX(GROUP_CONCAT(DISTINCT h.account_name ORDER BY h.last_seen DESC SEPARATOR ','), ',', 1) account_name, SUBSTRING_INDEX(GROUP_CONCAT(DISTINCT h.player_name ORDER BY h.last_seen DESC SEPARATOR ','), ',', 1) player_name, COUNT(DISTINCT h.account_name) accounts, COUNT(DISTINCT h.ip) ips, SUM(h.seen_count) seen, MAX(h.last_seen) last_seen, COALESCE(f.status,'') status FROM hwid_history h LEFT JOIN hwid_flags f ON f.hwid=h.hwid AND f.account_name='' WHERE h.hwid<>'' GROUP BY h.hwid, f.status HAVING accounts > 1 ORDER BY accounts DESC, last_seen DESC LIMIT ? OFFSET ?"))
		{
			ps.setInt(1, PAGE_SIZE);
			ps.setInt(2, page * PAGE_SIZE);

			try (ResultSet rs = ps.executeQuery())
			{
				while (rs.next())
				{
					found = true;
					String hwid = rs.getString("hwid");
					String status = rs.getString("status");
					sb.append("<tr><td width=300>");
					sb.append(riskColor(rs.getInt("accounts"), rs.getInt("ips"), hwid));
					sb.append(" accs:").append(rs.getInt("accounts"));
					sb.append(" ips:").append(rs.getInt("ips"));
					sb.append(" seen:").append(rs.getInt("seen"));
					sb.append("<br1>account:").append(escape(rs.getString("account_name")));
					sb.append(" player:").append(escape(rs.getString("player_name")));
					sb.append("<br1>hwid:").append(escape(shorten(hwid, 28)));
					if (status != null && status.length() > 0)
						sb.append(" flag:").append(statusColor(status));
					sb.append(" <a action=\"bypass -h admin_hwid_panel search ").append(escape(hwid)).append("\">View</a>");
					sb.append("<br1>").append(actionLinks(hwid, status));
					sb.append("</td></tr>");
				}
			}
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not list shared HWIDs.", e);
			sb.append("<tr><td>Could not list shared HWIDs.</td></tr>");
			found = true;
		}

		if (!found)
			sb.append("<tr><td>No shared HWIDs found.</td></tr>");
		sb.append("</table>");
		sb.append(pager("admin_hwid_panel view shared", page, total));
		return sb.toString();
	}

	private String changingAccounts(int page)
	{
		StringBuilder sb = new StringBuilder();
		int total = countChangingAccounts();
		header(sb, "HWID Changes 24h", page, total);
		sb.append("<table width=300>");
		boolean found = false;

		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT account_name, MAX(player_name) player_name, COUNT(DISTINCT hwid) hwids, COUNT(DISTINCT ip) ips, MAX(last_seen) last_seen FROM hwid_history WHERE last_seen >= DATE_SUB(NOW(), INTERVAL 1 DAY) GROUP BY account_name HAVING hwids >= 3 ORDER BY hwids DESC, last_seen DESC LIMIT ? OFFSET ?"))
		{
			ps.setInt(1, PAGE_SIZE);
			ps.setInt(2, page * PAGE_SIZE);

			try (ResultSet rs = ps.executeQuery())
			{
				while (rs.next())
				{
					found = true;
					sb.append("<tr><td width=300>");
					sb.append("<font color=\"FF5555\">HIGH</font> ");
					sb.append("account:").append(escape(rs.getString("account_name")));
					sb.append(" player:").append(escape(rs.getString("player_name")));
					sb.append("<br1>hwids:").append(rs.getInt("hwids"));
					sb.append(" ips:").append(rs.getInt("ips"));
					sb.append(" last:").append(escape(shorten(rs.getString("last_seen"), 16)));
					sb.append(" <a action=\"bypass -h admin_hwid_panel search ").append(escape(rs.getString("account_name"))).append("\">View</a>");
					sb.append("</td></tr>");
				}
			}
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not list HWID changes.", e);
			sb.append("<tr><td>Could not list HWID changes.</td></tr>");
			found = true;
		}

		if (!found)
			sb.append("<tr><td>No fast HWID changes found.</td></tr>");
		sb.append("</table>");
		sb.append(pager("admin_hwid_panel view changes", page, total));
		return sb.toString();
	}

	private String searchRows(String search, int page)
	{
		StringBuilder sb = new StringBuilder();
		if (search.length() == 0)
		{
			sb.append("<center><font color=\"777777\">Type account, player, HWID or IP.</font></center>");
			return sb.toString();
		}

		int total = countSearchRows(search);
		header(sb, "Search: " + escape(shorten(search, 24)), page, total);
		sb.append("<table width=300>");
		boolean found = false;

		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT h.account_name, h.player_name, h.player_id, h.hwid, h.ip, h.first_seen, h.last_seen, h.seen_count, COALESCE(f.status,'') status FROM hwid_history h LEFT JOIN hwid_flags f ON f.hwid=h.hwid AND f.account_name='' WHERE h.account_name LIKE ? OR h.player_name LIKE ? OR h.hwid LIKE ? OR h.ip LIKE ? ORDER BY h.last_seen DESC LIMIT ? OFFSET ?"))
		{
			String like = "%" + search + "%";
			ps.setString(1, like);
			ps.setString(2, like);
			ps.setString(3, like);
			ps.setString(4, like);
			ps.setInt(5, PAGE_SIZE);
			ps.setInt(6, page * PAGE_SIZE);

			try (ResultSet rs = ps.executeQuery())
			{
				while (rs.next())
				{
					found = true;
					String hwid = rs.getString("hwid");
					String status = rs.getString("status");
					sb.append("<tr><td width=300>");
					sb.append("<table width=300 bgcolor=\"111111\">");
					sb.append("<tr><td width=48>Acc:</td><td width=252><font color=\"LEVEL\">").append(escape(rs.getString("account_name"))).append("</font></td></tr>");
					sb.append("<tr><td>Char:</td><td>").append(escape(rs.getString("player_name"))).append("</td></tr>");
					sb.append("<tr><td>IP:</td><td>").append(escape(rs.getString("ip"))).append("</td></tr>");
					sb.append("<tr><td>HWID:</td><td>").append(escape(shorten(hwid, 32))).append("</td></tr>");
					sb.append("<tr><td>Seen:</td><td>").append(rs.getInt("seen_count"));
					if (status != null && status.length() > 0)
						sb.append(" flag:").append(statusColor(status));
					sb.append("</td></tr>");
					sb.append("<tr><td>Act:</td><td>").append(actionLinks(hwid, status)).append("</td></tr>");
					sb.append("</table><br1>");
					sb.append("</td></tr>");
				}
			}
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not search HWID history.", e);
			sb.append("<tr><td>Search failed.</td></tr>");
			found = true;
		}

		if (!found)
			sb.append("<tr><td>No results.</td></tr>");
		sb.append("</table>");
		sb.append(pager("admin_hwid_panel search " + escape(search), page, total));
		return sb.toString();
	}

	private String flagRows(int page)
	{
		StringBuilder sb = new StringBuilder();
		int total = countSimple("SELECT COUNT(*) FROM hwid_flags");
		header(sb, "Recent Flags", page, total);
		sb.append("<table width=300>");
		boolean found = false;

		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT f.hwid, f.status, f.reason, f.created_by, f.updated_at, COALESCE(NULLIF(f.account_name,''), MAX(h.account_name), '') account_name, COALESCE(NULLIF(f.player_name,''), MAX(h.player_name), '') player_name FROM hwid_flags f LEFT JOIN hwid_history h ON h.hwid=f.hwid GROUP BY f.hwid, f.account_name, f.player_name, f.status, f.reason, f.created_by, f.updated_at ORDER BY f.updated_at DESC LIMIT ? OFFSET ?"))
		{
			ps.setInt(1, PAGE_SIZE);
			ps.setInt(2, page * PAGE_SIZE);

			try (ResultSet rs = ps.executeQuery())
			{
				while (rs.next())
				{
					found = true;
					sb.append("<tr><td width=300>");
					sb.append(statusColor(rs.getString("status")));
					sb.append(" by:").append(escape(rs.getString("created_by")));
					sb.append(" last:").append(escape(shorten(rs.getString("updated_at"), 16)));
					sb.append("<br1>account:").append(escape(rs.getString("account_name")));
					sb.append(" player:").append(escape(rs.getString("player_name")));
					sb.append("<br1>hwid:").append(escape(shorten(rs.getString("hwid"), 28)));
					sb.append("<br1>reason:").append(escape(shorten(rs.getString("reason"), 38)));
					sb.append("<br1>").append(actionLinks(rs.getString("hwid"), rs.getString("status")));
					sb.append("</td></tr>");
				}
			}
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not list HWID flags.", e);
			sb.append("<tr><td>No flags.</td></tr>");
			found = true;
		}

		if (!found)
			sb.append("<tr><td>No flags.</td></tr>");
		sb.append("</table>");
		sb.append(pager("admin_hwid_panel view flags", page, total));
		return sb.toString();
	}

	private void header(StringBuilder sb, String title, int page, int total)
	{
		int maxPage = maxPage(total);
		sb.append("<table width=300 bgcolor=\"222222\"><tr>");
		sb.append("<td width=210><font color=\"LEVEL\">").append(title).append("</font></td>");
		sb.append("<td width=90 align=right>").append(total).append(" p.").append(page + 1).append("/").append(maxPage + 1).append("</td>");
		sb.append("</tr></table>");
	}

	private String pager(String commandBase, int page, int total)
	{
		int maxPage = maxPage(total);
		if (maxPage <= 0)
			return "";

		StringBuilder sb = new StringBuilder();
		sb.append("<center>");
		if (page > 0)
			sb.append("<a action=\"bypass -h ").append(commandBase).append(" ").append(page - 1).append("\">Prev</a>");
		else
			sb.append("<font color=\"777777\">Prev</font>");
		sb.append(" <font color=\"LEVEL\">").append(page + 1).append("/").append(maxPage + 1).append("</font> ");
		if (page < maxPage)
			sb.append("<a action=\"bypass -h ").append(commandBase).append(" ").append(page + 1).append("\">Next</a>");
		else
			sb.append("<font color=\"777777\">Next</font>");
		sb.append("</center>");
		return sb.toString();
	}

	private int countSharedHwids()
	{
		return countSimple("SELECT COUNT(*) FROM (SELECT h.hwid FROM hwid_history h WHERE h.hwid<>'' GROUP BY h.hwid HAVING COUNT(DISTINCT h.account_name) > 1) x");
	}

	private int countChangingAccounts()
	{
		return countSimple("SELECT COUNT(*) FROM (SELECT account_name FROM hwid_history WHERE last_seen >= DATE_SUB(NOW(), INTERVAL 1 DAY) GROUP BY account_name HAVING COUNT(DISTINCT hwid) >= 3) x");
	}

	private int countSearchRows(String search)
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM hwid_history WHERE account_name LIKE ? OR player_name LIKE ? OR hwid LIKE ? OR ip LIKE ?"))
		{
			String like = "%" + search + "%";
			ps.setString(1, like);
			ps.setString(2, like);
			ps.setString(3, like);
			ps.setString(4, like);

			try (ResultSet rs = ps.executeQuery())
			{
				return rs.next() ? rs.getInt(1) : 0;
			}
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not count HWID search rows.", e);
			return 0;
		}
	}

	private int countSimple(String sql)
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql))
		{
			return rs.next() ? rs.getInt(1) : 0;
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not count HWID panel rows.", e);
			return 0;
		}
	}

	private String riskColor(int accounts, int ips, String hwid)
	{
		if (Hwid.isInvalidHWID(hwid) || accounts >= 5 || ips >= 5)
			return "<font color=\"FF5555\">HIGH</font>";
		if (accounts >= 3 || ips >= 3)
			return "<font color=\"FFA500\">MED</font>";
		return "<font color=\"99CC66\">LOW</font>";
	}

	private String actionLinks(String hwid, String status)
	{
		String safeHwid = escape(hwid);
		String cleanStatus = clean(status).toLowerCase();
		StringBuilder sb = new StringBuilder();
		if ("blocked".equals(cleanStatus))
			sb.append("<a action=\"bypass -h admin_hwid_panel unblock ").append(safeHwid).append("\">Unblock</a>");
		else
			sb.append("<a action=\"bypass -h admin_hwid_panel flag blocked ").append(safeHwid).append(" panel\">Block</a>");
		sb.append(" | <a action=\"bypass -h admin_hwid_panel flag suspect ").append(safeHwid).append(" panel\">Suspect</a>");
		sb.append(" | <a action=\"bypass -h admin_hwid_panel flag trusted ").append(safeHwid).append(" panel\">Trust</a>");
		return sb.toString();
	}

	private String statusColor(String status)
	{
		status = clean(status).toLowerCase();
		if ("blocked".equals(status))
			return "<font color=\"FF5555\">blocked</font>";
		if ("suspect".equals(status))
			return "<font color=\"FFA500\">suspect</font>";
		if ("trusted".equals(status))
			return "<font color=\"99CC66\">trusted</font>";
		return escape(status);
	}

	private String collectRemaining(StringTokenizer st)
	{
		StringBuilder sb = new StringBuilder();
		while (st.hasMoreTokens())
		{
			if (sb.length() > 0)
				sb.append(' ');
			sb.append(st.nextToken());
		}
		return clean(sb.toString());
	}

	private String normalizeView(String view)
	{
		view = clean(view).toLowerCase();
		if (VIEW_CHANGES.equals(view) || VIEW_FLAGS.equals(view) || VIEW_SEARCH.equals(view))
			return view;
		return VIEW_SHARED;
	}

	private int parsePage(String value)
	{
		try
		{
			return Math.max(0, Integer.parseInt(clean(value)));
		}
		catch (Exception e)
		{
			return 0;
		}
	}

	private int maxPage(int total)
	{
		if (total <= 0)
			return 0;
		return (total - 1) / PAGE_SIZE;
	}

	private String clean(String value)
	{
		if (value == null)
			return "";

		return value.trim().replace("\r", "").replace("\n", "").replace("<", "").replace(">", "");
	}

	private String escape(String value)
	{
		return clean(value).replace("&", "&amp;").replace("\"", "&quot;");
	}

	private String shorten(String value, int max)
	{
		value = clean(value);
		if (value.length() <= max)
			return value;

		return value.substring(0, max);
	}
}