/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.handler.admincommandhandlers;

import java.util.logging.Logger;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.handler.IAdminCommandHandler;
import net.sf.l2j.gameserver.model.L2Object;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.util.Rnd;

/**
 * @author MeGaPacK
 */
public class AdminGiran implements IAdminCommandHandler
{
	
	private static final String[] ADMIN_COMMANDS =
	{
		"admin_giran"
	};
	
	protected static final Logger _log = Logger.getLogger(AdminGiran.class.getName());
	
	@Override
	public boolean useAdminCommand(String command, L2PcInstance activeChar)
	{
		
		if ((activeChar.getTarget() == null))
		{
			activeChar.sendMessage("Select a target");
			return false;
		}
		
		L2Object target = activeChar.getTarget();
		
		if (!(target instanceof L2PcInstance))
		{
			activeChar.sendMessage("Target need to be player");
			return false;
		}
		
		L2PcInstance player = activeChar.getTarget().getActingPlayer();
		
		if (command.equals("admin_giran"))
		{
			player.teleToLocation(Config.SPAWN_X_1 + Rnd.get(-50, 50), Config.SPAWN_Y_1 + Rnd.get(-50, 50), Config.SPAWN_Z_1, 50); // Giran
			activeChar.sendMessage("Player " + player.getName() + " foi teleportado pra giran");
		}
		
		return true;
	}
	
	@Override
	public String[] getAdminCommandList()
	{
		return ADMIN_COMMANDS;
	}
}
