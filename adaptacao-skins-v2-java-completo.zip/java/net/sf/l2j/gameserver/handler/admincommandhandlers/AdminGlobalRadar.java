/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.handler.admincommandhandlers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.sf.l2j.gameserver.datatables.MapRegionTable;
import net.sf.l2j.gameserver.handler.IAdminCommandHandler;
import net.sf.l2j.gameserver.instancemanager.ZoneManager;
import net.sf.l2j.gameserver.model.L2World;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.zone.L2ZoneType;
import net.sf.l2j.gameserver.model.zone.type.L2ArenaZone;
import net.sf.l2j.gameserver.model.zone.type.L2ChaoticSelfZone;
import net.sf.l2j.gameserver.model.zone.type.L2FarmRandomZone;
import net.sf.l2j.gameserver.model.zone.type.L2PartyFarmZone;
import net.sf.l2j.gameserver.model.zone.type.L2SoloZone;
import net.sf.l2j.gameserver.model.zone.type.L2TournamentZone;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;

public class AdminGlobalRadar implements IAdminCommandHandler
{
	private static final String[] ADMIN_COMMANDS =
	{
		"admin_global_radar",
		"admin_zone_radar"
	};
	
	private static final int MAX_ZONES_PER_PAGE = 15;
	
	@Override
	public boolean useAdminCommand(String command, L2PcInstance activeChar)
	{
		int page = 0;
		try
		{
			String[] split = command.split(" ");
			if (split.length > 1)
				page = Integer.parseInt(split[1]);
		}
		catch (Exception e)
		{
			page = 0;
		}
		
		showRadar(activeChar, page);
		return true;
	}
	
	@Override
	public String[] getAdminCommandList()
	{
		return ADMIN_COMMANDS;
	}
	
	private static void showRadar(L2PcInstance activeChar, int page)
	{
		Map<String, ZoneInfo> zones = buildRadar();
		List<ZoneInfo> zoneList = new ArrayList<>(zones.values());
		
		Collections.sort(zoneList, new Comparator<ZoneInfo>()
		{
			@Override
			public int compare(ZoneInfo left, ZoneInfo right)
			{
				if (left.players != right.players)
					return right.players - left.players;
				
				return left.name.compareToIgnoreCase(right.name);
			}
		});
		
		page = normalizePage(page, zoneList.size());
		int start = page * MAX_ZONES_PER_PAGE;
		int end = Math.min(start + MAX_ZONES_PER_PAGE, zoneList.size());
		
		StringBuilder html = new StringBuilder(3500);
		html.append("<html><body><center><font color=\"LEVEL\">Global Zone Radar</font></center><br>");
		html.append("Online players: ").append(L2World.getInstance().getAllPlayers().size()).append("<br1>");
		html.append("Zones with players: ").append(zoneList.size()).append("<br><br>");
		html.append("<table width=300>");
		html.append("<tr><td width=130>Zone</td><td width=40>Pl</td><td width=40>Pt</td><td width=45>Clan</td><td width=45>Ally</td></tr>");
		
		if (zoneList.isEmpty())
		{
			html.append("<tr><td width=300>No online players.</td></tr>");
		}
		else
		{
			for (int i = start; i < end; i++)
			{
				ZoneInfo info = zoneList.get(i);
				html.append("<tr><td width=130>").append(shorten(info.name, 22)).append("</td><td width=40>").append(info.players).append("</td><td width=40>").append(info.parties.size()).append("</td><td width=45>").append(info.clans.size()).append("</td><td width=45>").append(info.allies.size()).append("</td></tr>");
			}
		}
		
		html.append("</table><br><center>");
		html.append(getPages(page, zoneList.size()));
		html.append("<br1><a action=\"bypass -h admin_global_radar ").append(page).append("\">Refresh</a>");
		html.append("</center></body></html>");
		
		NpcHtmlMessage msg = new NpcHtmlMessage(0);
		msg.setHtml(html.toString());
		activeChar.sendPacket(msg);
	}
	
	private static Map<String, ZoneInfo> buildRadar()
	{
		Map<String, ZoneInfo> zones = new HashMap<>();
		
		for (L2PcInstance player : L2World.getInstance().getAllPlayers().values())
		{
			if (player == null)
				continue;
			
			String zoneName = getZoneName(player);
			ZoneInfo info = zones.get(zoneName);
			if (info == null)
			{
				info = new ZoneInfo(zoneName);
				zones.put(zoneName, info);
			}
			
			info.players++;
			
			if (player.isInParty() && player.getParty() != null)
				info.parties.add(player.getParty().getPartyLeaderOID());
			
			if (player.getClanId() > 0)
				info.clans.add(player.getClanId());
			
			if (player.getAllyId() > 0)
				info.allies.add(player.getAllyId());
		}
		
		return zones;
	}
	
	private static String getZoneName(L2PcInstance player)
	{
		List<L2ZoneType> zones = ZoneManager.getInstance().getZones(player.getX(), player.getY(), player.getZ());
		
		for (L2ZoneType zone : zones)
		{
			if (isRadarZone(zone))
			{
				String name = getZoneDisplayName(zone);
				if (name != null && !name.isEmpty())
					return name;
			}
		}
		
		for (L2ZoneType zone : zones)
		{
			String name = zone.getZoneName();
			if (name != null && !name.isEmpty())
				return name;
		}
		
		return "Near " + MapRegionTable.getInstance().getClosestTownName(player.getX(), player.getY());
	}
	
	private static boolean isRadarZone(L2ZoneType zone)
	{
		return zone instanceof L2FarmRandomZone || zone instanceof L2ChaoticSelfZone || zone instanceof L2TournamentZone || zone instanceof L2SoloZone || zone instanceof L2ArenaZone || zone instanceof L2PartyFarmZone;
	}
	
	private static String getZoneDisplayName(L2ZoneType zone)
	{
		String name = zone.getZoneName();
		if (name != null && !name.isEmpty())
			return name;
		
		if (zone instanceof L2FarmRandomZone)
			return "Farm Random Zone #" + zone.getId();
		
		if (zone instanceof L2ChaoticSelfZone)
			return "Chaotic Self Zone #" + zone.getId();
		
		if (zone instanceof L2TournamentZone)
			return "Tournament Zone #" + zone.getId();
		
		if (zone instanceof L2SoloZone)
			return "Solo Zone #" + zone.getId();
		
		if (zone instanceof L2ArenaZone)
			return "Arena Zone #" + zone.getId();
		
		if (zone instanceof L2PartyFarmZone)
			return "Party Farm Zone #" + zone.getId();
		
		return null;
	}
	
	private static int normalizePage(int page, int size)
	{
		if (page < 0)
			return 0;
		
		int maxPage = size / MAX_ZONES_PER_PAGE;
		if (size == 0 || size % MAX_ZONES_PER_PAGE == 0)
			maxPage--;
		
		if (maxPage < 0)
			maxPage = 0;
		
		return Math.min(page, maxPage);
	}
	
	private static String getPages(int currentPage, int size)
	{
		int maxPage = size / MAX_ZONES_PER_PAGE;
		if (size == 0 || size % MAX_ZONES_PER_PAGE == 0)
			maxPage--;
		
		if (maxPage <= 0)
			return "";
		
		StringBuilder pages = new StringBuilder();
		for (int i = 0; i <= maxPage; i++)
		{
			if (i == currentPage)
				pages.append("<font color=\"LEVEL\">").append(i + 1).append("</font> ");
			else
				pages.append("<a action=\"bypass -h admin_global_radar ").append(i).append("\">").append(i + 1).append("</a> ");
		}
		
		return pages.toString();
	}
	
	private static String shorten(String value, int maxLength)
	{
		if (value == null)
			return "";
		
		if (value.length() <= maxLength)
			return value;
		
		return value.substring(0, maxLength);
	}
	
	private static class ZoneInfo
	{
		private final String name;
		private int players;
		private final Set<Integer> parties = new HashSet<>();
		private final Set<Integer> clans = new HashSet<>();
		private final Set<Integer> allies = new HashSet<>();
		
		private ZoneInfo(String name)
		{
			this.name = name;
		}
	}
}
