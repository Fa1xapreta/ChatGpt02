package net.sf.l2j.gameserver.handler.admincommandhandlers;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.handler.IAdminCommandHandler;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.actor.instance.PvpRankHud;

public class AdminPvpRankTest implements IAdminCommandHandler
{
	private static final String[] ADMIN_COMMANDS =
	{
		"admin_pvpranktest"
	};

	@Override
	public boolean useAdminCommand(String command, L2PcInstance activeChar)
	{
		if (!Config.SHOW_PVP_RANK_HUD)
		{
			activeChar.sendMessage("PvpRank: ShowPvpRankHud esta False no npcs.properties.");
			return false;
		}

		final String[] tokens = command.split(" ");
		int rank = 1;
		if (tokens.length > 1)
		{
			try
			{
				rank = Integer.parseInt(tokens[1]);
			}
			catch (NumberFormatException e)
			{
				activeChar.sendMessage("Uso: //pvpranktest <0..10>");
				return false;
			}
		}

		PvpRankHud.getInstance().forceRank(activeChar, rank);

		if (rank <= 0)
			activeChar.sendMessage("PvpRank: badge de teste removido, voltou ao ranking real.");
		else
			activeChar.sendMessage("PvpRank: badge forcado na posicao " + rank + " (aparece em ate " + (Config.SHOW_PVP_RANK_HUD_INTERVAL / 1000) + "s).");

		return true;
	}

	@Override
	public String[] getAdminCommandList()
	{
		return ADMIN_COMMANDS;
	}
}