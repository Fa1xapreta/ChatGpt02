/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.handler.admincommandhandlers;

import phantom.FakePlayer;
import phantom.FakePlayerManager;
import net.sf.l2j.gameserver.handler.IAdminCommandHandler;
import net.sf.l2j.gameserver.model.L2World;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.zone.ZoneId;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;

/**
 * This class handles following admin commands: - help path = shows /data/html/admin/path file to char, should not be used by GM's directly
 */
public class AdminHelpPage implements IAdminCommandHandler
{
	private static final String[] ADMIN_COMMANDS =
	{
		"admin_help"
	};
	
	@Override
	public boolean useAdminCommand(String command, L2PcInstance activeChar)
	{
		if (command.startsWith("admin_help"))
		{
			try
			{
				String val = command.substring(11);
				showHelpPage(activeChar, val);
			}
			catch (StringIndexOutOfBoundsException e)
			{
			}
		}
		
		return true;
	}
	
	@Override
	public String[] getAdminCommandList()
	{
		return ADMIN_COMMANDS;
	}
	
	// FIXME: implement method to send html to player in L2PcInstance directly
	// PUBLIC & STATIC so other classes from package can include it directly
	public static void showHelpPage(L2PcInstance targetChar, String filename)
	{
		NpcHtmlMessage html = new NpcHtmlMessage(0);
		html.setFile("data/html/admin/" + filename);
		
		int counter = 0;
		int counterPlayers = 0;
		int counterVip = 0;
		int counterAdm = 0;
		int counterraid = 0;
		int counterpartyzone = 0;
		for (L2PcInstance player : L2World.getInstance().getL2Players())
		{
			if (player.isInsideZone(ZoneId.FLAG_AREA_SELF) && !player.isFakeOffline() && !(player instanceof FakePlayer))
				counterraid++;
			
			if (player.isFakeOffline() && !(player instanceof FakePlayer))
				counter++;
			
			if (!player.isFakeOffline() && !(player instanceof FakePlayer) && player.isInsideZone(ZoneId.PARTY_FARM) && !player.isFakeOffline())
				counterpartyzone++;
			
			if (player.isGM())
				counterAdm++;
			
			if (player.isVip())
				counterVip++;
			
			if (!(player instanceof FakePlayer) && !player.isFakeOffline())
				counterPlayers++;
		}
		html.replace("%countraid%", counterraid);
		html.replace("%countadm%", counterAdm);
		html.replace("%countparty%", counterpartyzone);
		html.replace("%countvip%", counterVip);
		html.replace("%countoff%", counter);
		html.replace("%countbot%", FakePlayerManager.getFakePlayersCount());
		html.replace("%count%", counterPlayers);
		
		targetChar.sendPacket(html);
	}
}