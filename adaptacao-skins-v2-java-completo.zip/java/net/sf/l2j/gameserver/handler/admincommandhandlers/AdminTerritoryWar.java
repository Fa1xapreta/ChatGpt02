package net.sf.l2j.gameserver.handler.admincommandhandlers;

import net.sf.l2j.gameserver.handler.IAdminCommandHandler;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.entity.events.territorywar.TerritoryWarManager;

/** GM-only testing: real event start/stop; no forced capture or owner deletion. */
public final class AdminTerritoryWar implements IAdminCommandHandler
{
    private static final String[] COMMANDS =
    {
        "admin_tw_start", "admin_tw_stop", "admin_tw_status"
    };

    @Override
    public boolean useAdminCommand(String command, L2PcInstance activeChar)
    {
        if (activeChar == null || !activeChar.isGM())
            return false;

        final String[] parts = command == null ? new String[0] : command.trim().split("\\s+");
        if (parts.length == 0 || parts.length > 2)
        {
            usage(activeChar);
            return true;
        }
        final String action = parts[0];
        final boolean status = "admin_tw_status".equals(action);
        if (!status && !"admin_tw_start".equals(action) && !"admin_tw_stop".equals(action))
        {
            usage(activeChar);
            return true;
        }
        if ((!status && parts.length != 2) || (status && parts.length > 2))
        {
            usage(activeChar);
            return true;
        }

        int id = 0;
        if (parts.length == 2)
        {
            try
            {
                id = Integer.parseInt(parts[1]);
                if (id <= 0)
                    throw new NumberFormatException("Territory ID must be positive.");
            }
            catch (NumberFormatException e)
            {
                activeChar.sendMessage("Invalid territory ID. Use a positive number.");
                return true;
            }
        }
        final TerritoryWarManager manager = TerritoryWarManager.getInstance();
        if (status)
        {
            for (String line : manager.gmStatus(id))
                activeChar.sendMessage(line);
        }
        else if ("admin_tw_start".equals(action))
            activeChar.sendMessage(manager.gmStart(id));
        else
            activeChar.sendMessage(manager.gmStop(id));
        return true;
    }

    private static void usage(L2PcInstance gm)
    {
        gm.sendMessage("Usage: //tw_start <territoryId> | //tw_stop <territoryId> | //tw_status [territoryId]");
    }

    @Override
    public String[] getAdminCommandList()
    {
        return COMMANDS;
    }
}
