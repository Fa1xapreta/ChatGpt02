/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.handler.admincommandhandlers;

import java.util.logging.Logger;

import net.sf.l2j.gameserver.ThreadPoolManager;
import net.sf.l2j.gameserver.handler.IAdminCommandHandler;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.entity.events.NftBossEvent;
import net.sf.l2j.gameserver.model.entity.events.SoloBossEvent;
import net.sf.l2j.gameserver.model.entity.events.PartyZoneEvent.PartyZoneTask;
import net.sf.l2j.gameserver.model.entity.events.Tyrannosaurus.TyrannosaurusTask;
import net.sf.l2j.gameserver.model.entity.events.toppvpevent.PvPEvent;
import net.sf.l2j.gameserver.model.entity.events.toppvpevent.PvPEventManager;
import net.sf.l2j.gameserver.model.entity.events.tournaments.properties.ArenaTask;


public class AdminCustom implements IAdminCommandHandler
{

	protected static final Logger _log = Logger.getLogger(AdminCustom.class.getName());

	private static final String[] ADMIN_COMMANDS =
		{
		"admin_tournament",
		"admin_partyzone",
		"admin_lszone",
		"admin_soloboss",
		"admin_pvpevent",
		"admin_nftboss"

		};

	public static final AdminCustom getInstance()
	{
		return SingletonHolder._instance;
	}

	public static boolean _arena_manual = false;
	public static boolean _partytask_manual = false;
	public static boolean _LS_manual = false;

	@Override
	public boolean useAdminCommand(String command, L2PcInstance activeChar)
	{
		if (command.equals("admin_tournament"))
		{
			if (ArenaTask._started)
			{
				_log.info("----------------------------------------------------------------------------");
				_log.info("[Tournament]: Event Finished.");
				_log.info("----------------------------------------------------------------------------");
				ArenaTask._aborted = true;
				finishEventArena();
				_arena_manual = true;

				activeChar.sendMessage("SYS: Voce Finalizou Tournament");
			}
			else
			{
				_log.info("----------------------------------------------------------------------------");
				_log.info("[Tournament]: Event Started.");
				_log.info("----------------------------------------------------------------------------");
				initEventArena();
				_arena_manual = true;
				activeChar.sendMessage("SYS: Voce ativou Tournament");
			}
		}
		else if (command.equals("admin_partyzone"))
		{
			if (PartyZoneTask._started)
			{
				_log.info("----------------------------------------------------------------------------");
				_log.info("Party Zone: Event Finished.");
				_log.info("----------------------------------------------------------------------------");
				PartyZoneTask._aborted = true;
				finishPartyZone();
				_partytask_manual = true;

				activeChar.sendMessage("SYS: Voce Finalizou Party Zone");
			}
			else
			{
				_log.info("----------------------------------------------------------------------------");
				_log.info("Party Zone: Event Started.");
				_log.info("----------------------------------------------------------------------------");
				initPartyZone();
				_partytask_manual = true;
				activeChar.sendMessage("SYS: Voce ativou Party Zone");
			}
		}
		else if (command.equals("admin_lszone"))
		{
			if (TyrannosaurusTask._started)
			{
				_log.info("----------------------------------------------------------------------------");
				_log.info("Tyrannosaurus Zone: Event Finished.");
				_log.info("----------------------------------------------------------------------------");
				TyrannosaurusTask._aborted = true;
				finishTyrannosaurusZone();
				_LS_manual = true;

				activeChar.sendMessage("SYS: Voce Finalizou Tyrannosaurus Zone");
			}
			else
			{
				_log.info("----------------------------------------------------------------------------");
				_log.info("Tyrannosaurus Zone: Event Started.");
				_log.info("----------------------------------------------------------------------------");
				initTyrannosaurusZone();
				_LS_manual = true;
				activeChar.sendMessage("SYS: Voce ativou Tyrannosaurus Zone");
			}
		}
		else if (command.equals("admin_soloboss"))
		{
			SoloBossEvent.StartEvent();
			_log.info("----------------------------------------------------------------------------");
			_log.info("Solo Boss Started by command Admin");
			_log.info("----------------------------------------------------------------------------");
			activeChar.sendMessage("SYS: Solo Boss Started by command Admin");
		}
		else if (command.equals("admin_nftboss"))
		{
			NftBossEvent.StartEvent();
			_log.info("----------------------------------------------------------------------------");
			_log.info("NFT Boss Started by command Admin");
			_log.info("----------------------------------------------------------------------------");
			activeChar.sendMessage("SYS: NFT Boss Started by command Admin");
		}
		else if (command.equals("admin_pvpevent"))
		{
			if(!PvPEvent.getInstance().isActive())
			{
				PvPEventManager.getInstance().startCountdown();
				_log.info("----------------------------------------------------------------------------");
				_log.info("Pvp Event Started by command Admin");
				_log.info("----------------------------------------------------------------------------");
				activeChar.sendMessage("SYS: Pvp Event Started by command Admin");
			}
			else
			{
				activeChar.sendMessage("SYS: Pvp event is already running");
			}
		}
		return true;
	}

	private static void initEventArena()
	{
		ThreadPoolManager.getInstance().scheduleGeneral(new Runnable()
		{
			@Override
			public void run()
			{
				ArenaTask.SpawnEvent();
			}

		}, 1);
	}

	private static void finishEventArena()
	{
		ThreadPoolManager.getInstance().scheduleGeneral(new Runnable()
		{
			@Override
			public void run()
			{
				ArenaTask.finishEvent();
			}

		}, 1);
	}

	private static void initPartyZone()
	{
		ThreadPoolManager.getInstance().scheduleGeneral(new Runnable()
		{
			@Override
			public void run()
			{
				PartyZoneTask.SpawnEvent();
			}
		}, 1);
	}

	private static void finishPartyZone()
	{
		ThreadPoolManager.getInstance().scheduleGeneral(new Runnable()
		{
			@Override
			public void run()
			{
				PartyZoneTask.finishEvent();
			}
		}, 1);
	}

	private static void initTyrannosaurusZone()
	{
		ThreadPoolManager.getInstance().scheduleGeneral(new Runnable()
		{
			@Override
			public void run()
			{
				TyrannosaurusTask.SpawnEvent();
			}
		}, 1);
	}

	private static void finishTyrannosaurusZone()
	{
		ThreadPoolManager.getInstance().scheduleGeneral(new Runnable()
		{
			@Override
			public void run()
			{
				TyrannosaurusTask.finishEvent();
			}
		}, 1);
	}

	@Override
	public String[] getAdminCommandList()
	{
		return ADMIN_COMMANDS;
	}

	private static class SingletonHolder
	{
		protected static final AdminCustom _instance = new AdminCustom();
	}

}