package net.sf.l2j.gameserver.handler.admincommandhandlers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import net.sf.l2j.gameserver.datatables.ClanTable;
import net.sf.l2j.gameserver.handler.IAdminCommandHandler;
import net.sf.l2j.gameserver.model.L2Clan;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;

public class AdminClanPanel implements IAdminCommandHandler
{
	private static final int CLANS_PER_PAGE = 15;
	private static final String[] ADMIN_COMMANDS =
	{
		"admin_clan_panel"
	};

	@Override
	public boolean useAdminCommand(String command, L2PcInstance activeChar)
	{
		if (activeChar == null)
			return false;

		int page = 1;
		String search = "";

		String[] args = command.split(" ", 4);
		if (args.length >= 3 && "page".equalsIgnoreCase(args[1]))
			page = parseInt(args[2], 1);
		else if (args.length >= 4 && "search".equalsIgnoreCase(args[1]))
		{
			page = parseInt(args[2], 1);
			search = args[3].trim();
		}

		showPanel(activeChar, page, search);
		return true;
	}

	@Override
	public String[] getAdminCommandList()
	{
		return ADMIN_COMMANDS;
	}

	private static void showPanel(L2PcInstance activeChar, int page, String search)
	{
		List<L2Clan> clans = new ArrayList<>();
		int totalMembers = 0;
		int totalOnline = 0;

		for (L2Clan clan : ClanTable.getInstance().getClans())
		{
			if (clan == null)
				continue;

			totalMembers += clan.getMembersCount();
			totalOnline += clan.getOnlineMembersCount();

			if (!search.isEmpty() && !contains(clan.getName(), search) && !contains(clan.getLeaderName(), search))
				continue;

			clans.add(clan);
		}

		Collections.sort(clans, new Comparator<L2Clan>()
		{
			@Override
			public int compare(L2Clan c1, L2Clan c2)
			{
				int diff = c2.getMembersCount() - c1.getMembersCount();
				if (diff != 0)
					return diff;

				diff = c2.getOnlineMembersCount() - c1.getOnlineMembersCount();
				if (diff != 0)
					return diff;

				return c1.getName().compareToIgnoreCase(c2.getName());
			}
		});

		int maxPage = Math.max(1, (clans.size() + CLANS_PER_PAGE - 1) / CLANS_PER_PAGE);
		page = Math.max(1, Math.min(page, maxPage));
		int start = (page - 1) * CLANS_PER_PAGE;
		int end = Math.min(start + CLANS_PER_PAGE, clans.size());

		StringBuilder html = new StringBuilder(8192);
		html.append("<html><body><center><font color=LEVEL>Clan List Panel</font></center><br>");
		html.append("<table width=300 bgcolor=111111><tr><td>Total clans:</td><td>").append(ClanTable.getInstance().getClans().length).append("</td></tr>");
		html.append("<tr><td>Total members:</td><td>").append(totalMembers).append("</td></tr>");
		html.append("<tr><td>Online members:</td><td>").append(totalOnline).append("</td></tr></table><br>");

		html.append("<table width=300><tr><td><edit var=clanq width=180 height=15></td><td><button value=Search action=\"bypass -h admin_clan_panel search 1 $clanq\" width=80 height=21 back=L2UI_ch3.Btn1_normalOn fore=L2UI_ch3.Btn1_normal></td></tr></table>");

		if (!search.isEmpty())
			html.append("<font color=LEVEL>Search: ").append(escape(shorten(search, 24))).append("</font><br1>");

		html.append("<table width=300 bgcolor=222222><tr><td width=88>Clan</td><td width=70>Leader</td><td width=25>Lv</td><td width=35>Total</td><td width=35>On</td><td width=45>Rep</td></tr></table>");

		if (clans.isEmpty())
			html.append("<br><center><font color=777777>No clans found.</font></center>");
		else
		{
			for (int i = start; i < end; i++)
			{
				L2Clan clan = clans.get(i);
				html.append("<table width=300><tr><td width=88>").append(escape(shorten(clan.getName(), 14))).append("</td><td width=70>")
					.append(escape(shorten(clan.getLeaderName(), 12))).append("</td><td width=25>").append(clan.getLevel()).append("</td><td width=35>")
					.append(clan.getMembersCount()).append("</td><td width=35>").append(clan.getOnlineMembersCount()).append("</td><td width=45>")
					.append(clan.getReputationScore()).append("</td></tr></table>");
			}
		}

		html.append("<br><center>");
		if (page > 1)
		{
			String prevCommand = search.isEmpty() ? "admin_clan_panel page " + (page - 1) : "admin_clan_panel search " + (page - 1) + " " + search;
			html.append("<a action=\"bypass -h ").append(escape(prevCommand)).append("\">Prev</a> ");
		}
		html.append("Page ").append(page).append("/").append(maxPage);
		if (page < maxPage)
		{
			String nextCommand = search.isEmpty() ? "admin_clan_panel page " + (page + 1) : "admin_clan_panel search " + (page + 1) + " " + search;
			html.append(" <a action=\"bypass -h ").append(escape(nextCommand)).append("\">Next</a>");
		}
		html.append("</center>");
		html.append("<br><center><a action=\"bypass -h admin_clan_panel\">Refresh</a></center>");
		html.append("</body></html>");

		NpcHtmlMessage msg = new NpcHtmlMessage(0);
		msg.setHtml(html.toString());
		activeChar.sendPacket(msg);
	}

	private static boolean contains(String text, String search)
	{
		return text != null && text.toLowerCase().contains(search.toLowerCase());
	}

	private static int parseInt(String text, int fallback)
	{
		try
		{
			return Integer.parseInt(text);
		}
		catch (Exception e)
		{
			return fallback;
		}
	}

	private static String escape(String text)
	{
		if (text == null)
			return "";

		return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
	}

	private static String shorten(String text, int max)
	{
		if (text == null)
			return "";

		return text.length() > max ? text.substring(0, max - 3) + "..." : text;
	}
}
