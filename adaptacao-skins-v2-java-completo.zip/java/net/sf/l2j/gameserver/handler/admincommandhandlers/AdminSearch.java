package net.sf.l2j.gameserver.handler.admincommandhandlers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.logging.Logger;

import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.commons.math.MathUtil;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.handler.IAdminCommandHandler;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.item.kind.Item;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;
import net.sf.l2j.util.StringUtil;

public class AdminSearch implements IAdminCommandHandler
{
	public static final Logger _log = Logger.getLogger(AdminSearch.class.getName());
	
	private static final String[] ADMIN_COMMANDS =
	{
		"admin_pesquisa",
		"admin_search",
		"admin_create",
		"admin_checkitem"
	
	};
	private static final int PAGE_LIMIT = 15;
	
	@Override
	public boolean useAdminCommand(String command, L2PcInstance activeChar)
	{	
		
		if (command.startsWith("admin_pesquisa") || command.startsWith("admin_search"))
		{
			StringTokenizer st = new StringTokenizer(command, " ");
			st.nextToken();
			
			if (!st.hasMoreTokens())
			{
				final NpcHtmlMessage html = new NpcHtmlMessage(0);
				html.setFile("data/html/admin/search.htm");
				html.replace("%items%", "");
				html.replace("%pages%", "");
				activeChar.sendPacket(html);
				
			}
			else
			{
				final String item = st.nextToken();
				int page = 1;
				if (st.hasMoreTokens())
				{
					
					try
					{
						page = Integer.parseInt(st.nextToken());
					}
					catch (NumberFormatException e)
					{
						page = 1;
					}
				}
				results(activeChar, item, page);
			}
		}
		if (command.startsWith("admin_checkitem"))
		{
			StringTokenizer st = new StringTokenizer(command, " ");
			st.nextToken();
			
			if (!st.hasMoreTokens())
			{
				final NpcHtmlMessage html = new NpcHtmlMessage(0);
				html.setFile("data/html/admin/checkitem.htm");
				html.replace("%items%", "");
				html.replace("%pages%", "");
				html.replace("%total%", "");
				activeChar.sendPacket(html);
				
			}
			else {
			    final String itemIdStr = st.nextToken();  // ID do item vindo como String
			    int page = 1;

			    // Tratamento da p�gina
			    if (st.hasMoreTokens()) {
			        try {
			            page = Integer.parseInt(st.nextToken());
			        } catch (NumberFormatException e) {
			            page = 1;
			        }
			    }

			    // Converte o itemId de String para int
			    int itemId = -1;
			    try {
			        itemId = Integer.parseInt(itemIdStr);  // Converte para int
			    } catch (NumberFormatException e) {
			        activeChar.sendMessage("Invalid item ID format.");
			        return false;
			    }

			    // Chama a fun��o de verifica��o dos itens passando o item_id
			    CheckItemResults(activeChar, itemId, page);
			}

		}
		    StringTokenizer st = new StringTokenizer(command);
		    command = st.nextToken();
		    
			L2PcInstance target = activeChar;
			if (activeChar.getTarget() != null && activeChar.getTarget() instanceof L2PcInstance)
				target = (L2PcInstance) activeChar.getTarget();
			
			if (command.equals("admin_create"))
			{
				try
				{
					final int id = Integer.parseInt(st.nextToken());
					
					int count = 1;
					int radius = 0;
					
					if (st.hasMoreTokens())
					{
						count = Integer.parseInt(st.nextToken());
						if (st.hasMoreTokens())
							radius = Integer.parseInt(st.nextToken());
					}
					
					AdminCreateItem.createItem(activeChar, target, id, count, radius, true);
				}
				catch (Exception e)
				{
					activeChar.sendMessage("Usage: //create_item <itemId> [amount] [radius]");
				}
			}
		return true;
	}
	
	private static void results(L2PcInstance activeChar, String item, int page)
	{
		final NpcHtmlMessage html = new NpcHtmlMessage(0);
		html.setFile("data/html/admin/search.htm");
		
		List<Item> items = new ArrayList<>();
		
		for (Item itemName : ItemTable.getInstance().getAllItems())
			if (itemName != null)
				if (itemName.getName().toLowerCase().contains(item.toLowerCase()))
					items.add(itemName);
		
		if (items.isEmpty())
		{
			html.replace("%items%", "<tr><td>No items found with word " + item + ".</td></tr>");
			html.replace("%pages%", "");
			activeChar.sendPacket(html);
			return;
		}
		
		final int max = Math.min(100, MathUtil.countPagesNumber(items.size(), PAGE_LIMIT));
		items = items.subList((page - 1) * PAGE_LIMIT, Math.min(page * PAGE_LIMIT, items.size()));
		
		final StringBuilder sb = new StringBuilder();
		
		for (Item itemName : items)
		{
			String actualName = getFontedWord(item, itemName.getName());
			StringUtil.append(sb, "<tr><td>", "<a action=\"bypass admin_create ",itemName.getItemId(),"\"> " + actualName + "</a>", " (", itemName.getItemId(), ")", "</td></tr>");
			
		}
		html.replace("%items%", sb.toString());
		
		sb.setLength(0);
		
		for (int i = 0; i < max; i++)
		{
			final int pagenr = i + 1;
			if (page == pagenr)
				StringUtil.append(sb, pagenr, "&nbsp;");
			else
				StringUtil.append(sb, "<a action=\"bypass -h admin_search ", item, " ", pagenr, "\">", pagenr, "</a>&nbsp;");
			
		}
		
		html.replace("%pages%", sb.toString());
		activeChar.sendPacket(html);
	}
	
	private static void CheckItemResults(L2PcInstance activeChar, int itemId, int page) {
	    final NpcHtmlMessage html = new NpcHtmlMessage(0);
	    html.setFile("data/html/admin/checkitem.htm");
	    
	    List<String> itemRows = new ArrayList<>();
	    boolean hasResults = false;
	    int totalItemCount = 0;  // Vari�vel para armazenar o total de itens encontrados
	    

	    
	    // Conex�o com o banco de dados
	    try (Connection con = L2DatabaseFactory.getInstance().getConnection()) {
	        // Consulta para obter os itens com o ID especificado
	        String query = "SELECT c.char_name, i.count, i.loc " +
	                       "FROM items i " +
	                       "JOIN characters c ON i.owner_id = c.obj_id " +
	                       "WHERE i.item_id = ? " +  // Pesquisa pelo item_id
	                       "AND (i.loc = 'INVENTORY' OR i.loc = 'WAREHOUSE') " + // Procurar em INVENTORY ou WAREHOUSE
	                       "ORDER BY i.count DESC LIMIT ?, ?";

	        try (PreparedStatement ps = con.prepareStatement(query)) {
	            ps.setInt(1, itemId);  // Pesquisa pelo item_id
	            ps.setInt(2, (page - 1) * PAGE_LIMIT);  // Pular os resultados anteriores
	            ps.setInt(3, PAGE_LIMIT);  // Limitar o n�mero de resultados por p�gina

	            try (ResultSet rs = ps.executeQuery()) {
	                while (rs.next()) {
	                    String playerName = rs.getString("char_name");
	                    int itemCount = rs.getInt("count");
	                    String loc = rs.getString("loc");
	                    // Soma a quantidade dos itens encontrados
	                    totalItemCount += itemCount;
	                    // Adiciona a linha da tabela com o nome do jogador e a quantidade de itens
	                    itemRows.add("<tr><td>" + playerName + "</td><td>" + itemCount + "</td><td>" + loc + "</td></tr>");
	                    hasResults = true;
	                }
	            }
	        }
	    } catch (Exception e) {
	        _log.warning("Error querying item data: " + e.getMessage());
	    }

	    // Se n�o houver resultados, exibe uma mensagem
	    if (!hasResults) {
	        html.replace("%items%", "<tr><td>No players found with the item ID " + itemId + ".</td></tr>");
	        html.replace("%pages%", "");
	        html.replace("%total%", "Total Items: 0");  // Mostra total como 0 se n�o houver resultados
	        activeChar.sendPacket(html);
	        return;
	    }
	    
	    html.replace("%total%", "Total Items: " + totalItemCount);
	    
	    // Adicionar as linhas dos itens encontrados
	    StringBuilder sb = new StringBuilder();
	    for (String row : itemRows) {
	        sb.append(row);
	    }

	    html.replace("%items%", sb.toString());

	    // Pagina��o - calcular o n�mero m�ximo de p�ginas
	    try (Connection con = L2DatabaseFactory.getInstance().getConnection()) {
	        String countQuery = "SELECT COUNT(*) FROM items i " +
	                            "WHERE i.item_id = ?";

	        try (PreparedStatement ps = con.prepareStatement(countQuery)) {
	            ps.setInt(1, itemId);

	            try (ResultSet rs = ps.executeQuery()) {
	                if (rs.next()) {
	                    int totalResults = rs.getInt(1);
	                    int maxPages = (int) Math.ceil((double) totalResults / PAGE_LIMIT);

	                    // Gerar links de navega��o
	                    StringBuilder pagination = new StringBuilder();
	                    for (int i = 1; i <= maxPages; i++) {
	                        if (page == i) {
	                            pagination.append(i).append("&nbsp;");
	                        } else {
	                            pagination.append("<a action=\"bypass -h admin_checkitem ").append(itemId).append(" ").append(i).append("\">").append(i).append("</a>&nbsp;");
	                        }
	                    }

	                    html.replace("%pages%", pagination.toString());
	                }
	            }
	        }
	    } catch (Exception e) {
	        _log.warning("Error calculating total results for pagination: " + e.getMessage());
	    }

	    // Enviar o pacote de volta para o jogador
	    activeChar.sendPacket(html);
	}

	
	private static String getFontedWord(String word, String tt)
	{
		
		int position = tt.toLowerCase().indexOf(word.toLowerCase());
		StringBuilder str = new StringBuilder(tt);
		
		String font = "<FONT COLOR=\"LEVEL\">";
		str.insert(position, font);
		str.insert(position + (font.length() + word.length()), "</FONT>");
		
		return str.toString();
	}
	
	@Override
	public String[] getAdminCommandList()
	{
		return ADMIN_COMMANDS;
	}
}
