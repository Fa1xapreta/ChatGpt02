package net.sf.l2j.gameserver.handler.admincommandhandlers;

import java.util.function.Supplier;

import net.sf.l2j.gameserver.handler.IAdminCommandHandler;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;
import net.sf.l2j.gameserver.taskmanager.PvpFlagTaskManager;
import phantom.FakePlayer;
import phantom.FakePlayerManager;
import phantom.FakePlayerTaskManager;
import phantom.ai.shop.PrivateStoreBuyAI;
import phantom.ai.shop.PrivateStoreSellAI;
import phantom.ai.walker.CitizenAI;
import phantom.task.ThreadPool;

public class AdminFakePlayers implements IAdminCommandHandler
{
	private final String fakesFolder = "data/html/admin/";
	private static final String[] ADMIN_COMMANDS =
	{
		"admin_robot",
		"admin_deleterobot",
		"admin_deleteAllrobots",
		"admin_spawncitizen",
		"admin_spawnbuyer",
		"admin_spawnseller",
		"admin_spawnclass",
		"admin_takecontrol",
		"admin_releasecontrol"
	};
	
	@Override
	public String[] getAdminCommandList()
	{
		return ADMIN_COMMANDS;
	}
	
	private void showFakeDashboard(L2PcInstance activeChar)
	{
		final NpcHtmlMessage html = new NpcHtmlMessage(0);
		html.setFile(fakesFolder + "fakeplayer.htm");
		html.replace("%fakecount%", FakePlayerManager.getFakePlayersCount());
		html.replace("%taskcount%", FakePlayerTaskManager.INSTANCE.getTaskCount());
		activeChar.sendPacket(html);
	}
	
	@Override
	public boolean useAdminCommand(String command, L2PcInstance activeChar)
	{
		if (activeChar.getAccessLevel().getLevel() < 1)
			return false;

		if (command.startsWith("admin_robot"))
			showFakeDashboard(activeChar);
		
		if (command.startsWith("admin_deleterobot"))
		{
			if (activeChar.getTarget() != null && activeChar.getTarget() instanceof FakePlayer)
			{
				FakePlayer fakePlayer = (FakePlayer) activeChar.getTarget();
				fakePlayer.despawnPlayer();
				showFakeDashboard(activeChar);
			}
			showFakeDashboard(activeChar);
		}
		
		if (command.startsWith("admin_deleteAllrobots"))
		{
			int counter = 0;
			for (FakePlayer fakePlayer : FakePlayerManager.getFakePlayers())
			{
				counter++;
				fakePlayer.despawnPlayer();
			}
			activeChar.sendMessage("A total of " + counter + " fake players have been kicked.");
			showFakeDashboard(activeChar);
		}
		
		if (command.startsWith("admin_spawnbuyer"))
		{
			if (command.contains(" "))
			{
				String locationName = command.split(" ")[1];
				switch (locationName)
				{
				    case "solo":
					    FakePlayer fakeSoloPlayer = FakePlayerManager.spawnPlayer(activeChar.getX(), activeChar.getY(), activeChar.getZ());
					    fakeSoloPlayer.setFakeAi(new PrivateStoreBuyAI(fakeSoloPlayer));
					    break;

				    case "clan":
					    FakePlayer fakeClanPlayer = FakePlayerManager.spawnClanPlayer(activeChar.getX(), activeChar.getY(), activeChar.getZ());
					    fakeClanPlayer.setFakeAi(new PrivateStoreBuyAI(fakeClanPlayer));
					    break;
				}
				showFakeDashboard(activeChar);
				return true;
			}
		}
		
		if (command.startsWith("admin_spawnseller"))
		{
			if (command.contains(" "))
			{
				String locationName = command.split(" ")[1];
				switch (locationName)
				{
				    case "solo":
					    FakePlayer fakeSoloPlayer = FakePlayerManager.spawnPlayer(activeChar.getX(), activeChar.getY(), activeChar.getZ());
					    fakeSoloPlayer.setFakeAi(new PrivateStoreSellAI(fakeSoloPlayer));
					    break;

				    case "clan":
					    FakePlayer fakeClanPlayer = FakePlayerManager.spawnClanPlayer(activeChar.getX(), activeChar.getY(), activeChar.getZ());
					    fakeClanPlayer.setFakeAi(new PrivateStoreSellAI(fakeClanPlayer));
					    break;
				}
				showFakeDashboard(activeChar);
				return true;
			}
		}
		if (command.startsWith("admin_spawncitizen"))
		{
			if (command.contains(" "))
			{
				String locationName = command.split(" ")[1];
				switch (locationName)
				{
				    case "solo":
					    FakePlayer fakeSoloPlayer = FakePlayerManager.spawnPlayer(activeChar.getX(), activeChar.getY(), activeChar.getZ());
					    fakeSoloPlayer.setFakeAi(new CitizenAI(fakeSoloPlayer));
					    showFakeDashboard(activeChar);
					    break;

				    case "clan":
					    FakePlayer fakeClanPlayer = FakePlayerManager.spawnClanPlayer(activeChar.getX(), activeChar.getY(), activeChar.getZ());
					    fakeClanPlayer.setFakeAi(new CitizenAI(fakeClanPlayer));
					    showFakeDashboard(activeChar);
					    break;
				}
				showFakeDashboard(activeChar);
				return true;
			}
		}

		if (command.startsWith("admin_spawnclass"))
		{
			if (!command.contains(" "))
				return true;

			String type = command.split(" ")[1];

			spawnAsync(() ->
			{
				switch (type)
				{
					// =========================
					// PvP WITHOUT CLAN
					// =========================
					case "archer":
						spawnPvp(() -> FakePlayerManager.spawnArcher(
							activeChar.getX(), activeChar.getY(), activeChar.getZ()), activeChar);
						break;

					case "nuker":
						spawnPvp(() -> FakePlayerManager.spawnNuker(
							activeChar.getX(), activeChar.getY(), activeChar.getZ()), activeChar);
						break;

					case "warrior":
						spawnPvp(() -> FakePlayerManager.spawnWarrior(
							activeChar.getX(), activeChar.getY(), activeChar.getZ()), activeChar);
						break;

					case "dagger":
						spawnPvp(() -> FakePlayerManager.spawnDagger(
							activeChar.getX(), activeChar.getY(), activeChar.getZ()), activeChar);
						break;

					case "tanker":
						spawnPvp(() -> FakePlayerManager.spawnTanker(
							activeChar.getX(), activeChar.getY(), activeChar.getZ()), activeChar);
						break;

					// =========================
					// PvP WITH CLAN
					// =========================
					case "archer_clan":
						spawnPvpClan(() -> FakePlayerManager.spawnClanArcher(
							activeChar.getX(), activeChar.getY(), activeChar.getZ()));
						break;

					case "nuker_clan":
						spawnPvpClan(() -> FakePlayerManager.spawnClanNuker(
							activeChar.getX(), activeChar.getY(), activeChar.getZ()));
						break;

					case "warrior_clan":
						spawnPvpClan(() -> FakePlayerManager.spawnClanWarrior(
							activeChar.getX(), activeChar.getY(), activeChar.getZ()));
						break;

					case "dagger_clan":
						spawnPvpClan(() -> FakePlayerManager.spawnClanDagger(
							activeChar.getX(), activeChar.getY(), activeChar.getZ()));
						break;

					case "tanker_clan":
						spawnPvpClan(() -> FakePlayerManager.spawnClanTanker(
							activeChar.getX(), activeChar.getY(), activeChar.getZ()));
						break;

					// =========================
					// FARM WITHOUT CLAN
					// =========================
					case "archer_farm":
						spawnFarm(() -> FakePlayerManager.spawnArcher(
							activeChar.getX(), activeChar.getY(), activeChar.getZ()), activeChar);
						break;

					case "nuker_farm":
						spawnFarm(() -> FakePlayerManager.spawnNuker(
							activeChar.getX(), activeChar.getY(), activeChar.getZ()), activeChar);
						break;

					case "warrior_farm":
						spawnFarm(() -> FakePlayerManager.spawnWarrior(
							activeChar.getX(), activeChar.getY(), activeChar.getZ()), activeChar);
						break;

					case "dagger_farm":
						spawnFarm(() -> FakePlayerManager.spawnDagger(
							activeChar.getX(), activeChar.getY(), activeChar.getZ()), activeChar);
						break;

					case "tanker_farm":
						spawnFarm(() -> FakePlayerManager.spawnTanker(
							activeChar.getX(), activeChar.getY(), activeChar.getZ()), activeChar);
						break;

					// =========================
					// FARM WITH CLAN
					// =========================
					case "archer_farm_clan":
						spawnFarmClan(() -> FakePlayerManager.spawnClanArcher(
							activeChar.getX(), activeChar.getY(), activeChar.getZ()));
						break;

					case "nuker_farm_clan":
						spawnFarmClan(() -> FakePlayerManager.spawnClanNuker(
							activeChar.getX(), activeChar.getY(), activeChar.getZ()));
						break;

					case "warrior_farm_clan":
						spawnFarmClan(() -> FakePlayerManager.spawnClanWarrior(
							activeChar.getX(), activeChar.getY(), activeChar.getZ()));
						break;

					case "dagger_farm_clan":
						spawnFarmClan(() -> FakePlayerManager.spawnClanDagger(
							activeChar.getX(), activeChar.getY(), activeChar.getZ()));
						break;

					case "tanker_farm_clan":
						spawnFarmClan(() -> FakePlayerManager.spawnClanTanker(
							activeChar.getX(), activeChar.getY(), activeChar.getZ()));
						break;
				}
			});

			showFakeDashboard(activeChar);
			return true;
		}

		
		if (command.startsWith("admin_takecontrol"))
		{
			if (activeChar.getTarget() != null && activeChar.getTarget() instanceof FakePlayer)
			{
				FakePlayer fakePlayer = (FakePlayer) activeChar.getTarget();
				fakePlayer.setUnderControl(true);
				activeChar.setPlayerUnderControl(fakePlayer);
				activeChar.sendMessage("You are now controlling: " + fakePlayer.getName());
			}
			else
				activeChar.sendMessage("You can only take control of a Fake Player");
		}
		
		if (command.startsWith("admin_releasecontrol"))
		{
			if (activeChar.isControllingFakePlayer())
			{
				FakePlayer fakePlayer = activeChar.getPlayerUnderControl();
				activeChar.sendMessage("You are no longer controlling: " + fakePlayer.getName());
				fakePlayer.setUnderControl(false);
				activeChar.setPlayerUnderControl(null);
				
			}
			else
				activeChar.sendMessage("You are not controlling a Fake Player");
		}
		
		return true;
	}
	
	private void spawnAsync(Runnable task)
	{
		ThreadPool.execute(task);
	}
	
	private void spawnPvp(Supplier<FakePlayer> supplier, L2PcInstance admin)
	{
		FakePlayer fake = supplier.get();
		fake.setInstanceId(admin.getInstanceId(), true);
		fake.setFakePvp(true);
		fake.setLastCords(fake.getX(), fake.getY(), fake.getZ());

		ThreadPool.schedule(() ->
		{
			PvpFlagTaskManager.getInstance().add(fake, 10000L);
			fake.assignDefaultAI();
		}, 300);
	}

	private void spawnPvpClan(Supplier<FakePlayer> supplier)
	{
		FakePlayer fake = supplier.get();
		fake.setFakePvp(true);
		fake.setLastCords(fake.getX(), fake.getY(), fake.getZ());

		ThreadPool.schedule(() ->
		{
			PvpFlagTaskManager.getInstance().add(fake, 10000L);
			fake.assignDefaultAI();
		}, 300);
	}

	private void spawnFarm(Supplier<FakePlayer> supplier, L2PcInstance admin)
	{
		FakePlayer fake = supplier.get();
		fake.setInstanceId(admin.getInstanceId(), true);
		fake.setFakeFarm(true);
		fake.setLastCords(fake.getX(), fake.getY(), fake.getZ());

		ThreadPool.schedule(fake::assignDefaultAI, 300);
	}

	private void spawnFarmClan(Supplier<FakePlayer> supplier)
	{
		FakePlayer fake = supplier.get();
		fake.setFakeFarm(true);
		fake.setLastCords(fake.getX(), fake.getY(), fake.getZ());

		ThreadPool.schedule(fake::assignDefaultAI, 300);
	}


}