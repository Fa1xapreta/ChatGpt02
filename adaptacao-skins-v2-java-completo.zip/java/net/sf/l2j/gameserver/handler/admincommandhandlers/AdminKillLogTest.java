package net.sf.l2j.gameserver.handler.admincommandhandlers;

import net.sf.l2j.gameserver.ThreadPoolManager;
import net.sf.l2j.gameserver.handler.IAdminCommandHandler;
import net.sf.l2j.gameserver.model.actor.instance.KillFeedHud;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;

public class AdminKillLogTest implements IAdminCommandHandler
{
	private static final String[] ADMIN_COMMANDS =
	{
		"admin_killlogtest"
	};

	private static final int[][] FACES =
	{
		{ 0, 0, 0 }, { 0, 0, 1 }, { 0, 10, 0 }, { 0, 10, 1 },
		{ 1, 18, 0 }, { 1, 18, 1 }, { 1, 25, 0 }, { 1, 25, 1 },
		{ 2, 31, 0 }, { 2, 31, 1 }, { 2, 38, 0 }, { 2, 38, 1 },
		{ 3, 44, 0 }, { 3, 44, 1 }, { 3, 49, 0 }, { 3, 49, 1 },
		{ 4, 53, 0 }, { 4, 53, 1 }
	};

	@Override
	public boolean useAdminCommand(String command, L2PcInstance activeChar)
	{
		final String[] tokens = command.split(" ");
		final String me = activeChar.getName();

		if (tokens.length >= 2 && tokens[1].equalsIgnoreCase("faces"))
		{
			sendFaceParade(activeChar);
		activeChar.sendMessage("KillLog: desfile de " + FACES.length + " retratos (2 por linha, 1.5s cada).");
			return true;
		}

		if (tokens.length >= 4)
		{
			final int raceK = parse(tokens[1], 0);
			final int classK = parse(tokens[2], 0);
			final int sexK = parse(tokens[3], 0);
			KillFeedHud.sendSynthetic(activeChar, "Teste", me, classK, activeChar.getClassId().getId(), raceK, activeChar.getRace().ordinal(), sexK, activeChar.getAppearance().getSex() ? 1 : 0);
			activeChar.sendMessage("KillLog: race=" + raceK + " class=" + classK + " sex=" + sexK + " no killer.");
			return true;
		}

		KillFeedHud.sendSynthetic(activeChar, "Estranho_Um", "Estranho_Dois", 88, 94, 0, 1, 0, 1);
		KillFeedHud.sendSynthetic(activeChar, "Quem_Me_Matou", me, 46, activeChar.getClassId().getId(), 3, activeChar.getRace().ordinal(), 0, activeChar.getAppearance().getSex() ? 1 : 0);
		KillFeedHud.sendSynthetic(activeChar, me, "Coitado_da_Vitima", activeChar.getClassId().getId(), 105, activeChar.getRace().ordinal(), 1, activeChar.getAppearance().getSex() ? 1 : 0, 1);

		activeChar.sendMessage("KillLog: 3 linhas enviadas (topo=azul eu matei, meio=vermelho eu morri, base=cinza terceiros).");
		return true;
	}

	private static void sendFaceParade(final L2PcInstance player)
	{
		for (int i = 0; i < FACES.length; i += 2)
		{
			final int[] a = FACES[i];
			final int[] b = FACES[Math.min(i + 1, FACES.length - 1)];
			final int step = i / 2;

			ThreadPoolManager.getInstance().scheduleGeneral(new Runnable()
			{
				@Override
				public void run()
				{
					if (player.isOnline())
						KillFeedHud.sendSynthetic(player, "R" + a[0] + "_C" + a[1] + "_S" + a[2], "R" + b[0] + "_C" + b[1] + "_S" + b[2], a[1], b[1], a[0], b[0], a[2], b[2]);
				}
			}, 1500L * step);
		}
	}

	private static int parse(String s, int def)
	{
		try
		{
			return Integer.parseInt(s);
		}
		catch (NumberFormatException e)
	{
			return def;
		}
	}

	@Override
	public String[] getAdminCommandList()
	{
		return ADMIN_COMMANDS;
	}
}