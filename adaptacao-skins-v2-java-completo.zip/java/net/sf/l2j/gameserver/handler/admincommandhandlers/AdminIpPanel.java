package net.sf.l2j.gameserver.handler.admincommandhandlers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.handler.IAdminCommandHandler;
import net.sf.l2j.gameserver.instancemanager.custom.IPHistoryManager;
import net.sf.l2j.gameserver.model.L2World;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;

public class AdminIpPanel implements IAdminCommandHandler
{
	private static final Logger _log = Logger.getLogger(AdminIpPanel.class.getName());
	private static final String[] ADMIN_COMMANDS =
	{
		"admin_ip_panel"
	};

	@Override
	public boolean useAdminCommand(String command, L2PcInstance activeChar)
	{
		if (activeChar == null)
			return false;

		IPHistoryManager.ensureTables();

		String search = "";
		if (command.startsWith("admin_ip_panel search "))
			search = command.substring("admin_ip_panel search ".length()).trim();

		showPanel(activeChar, search);
		return true;
	}

	@Override
	public String[] getAdminCommandList()
	{
		return ADMIN_COMMANDS;
	}

	private void showPanel(L2PcInstance activeChar, String search)
	{
		StringBuilder html = new StringBuilder(8192);
		html.append("<html><body><center><font color=LEVEL>IP Analysis Panel</font></center><br>");
		html.append("<center><button value=Refresh action=\"bypass -h admin_ip_panel\" width=80 height=21 back=L2UI_ch3.Btn1_normalOn fore=L2UI_ch3.Btn1_normal></center>");
		html.append("<table width=280><tr><td><edit var=ipq width=180 height=15></td><td><button value=Search action=\"bypass -h admin_ip_panel search $ipq\" width=80 height=21 back=L2UI_ch3.Btn1_normalOn fore=L2UI_ch3.Btn1_normal></td></tr></table>");

		html.append("<br><font color=LEVEL>Online same party, different IPs</font><br1>");
		appendOnlineGroups(html, true);

		html.append("<br><font color=LEVEL>Online same clan and area, different IPs</font><br1>");
		appendOnlineGroups(html, false);

		html.append("<br><font color=LEVEL>Recent login bursts by different IPs</font><br1>");
		appendRecentBursts(html);

		html.append("<br><font color=LEVEL>Accounts changing IPs in 24h</font><br1>");
		appendChangingAccounts(html);

		if (!search.isEmpty())
		{
			html.append("<br><font color=LEVEL>Search: ").append(escape(shorten(search, 28))).append("</font><br1>");
			appendSearch(html, search);
		}

		html.append("<br><font color=777777>Use this as evidence review only. Different IP alone is not proof.</font>");
		html.append("</body></html>");

		NpcHtmlMessage msg = new NpcHtmlMessage(0);
		msg.setHtml(html.toString());
		activeChar.sendPacket(msg);
	}

	private void appendOnlineGroups(StringBuilder html, boolean partyMode)
	{
		Map<String, OnlineGroup> groups = new HashMap<>();

		for (L2PcInstance player : L2World.getInstance().getAllPlayers().values())
		{
			if (!isValidOnlinePlayer(player))
				continue;

			String key;
			String label;
			if (partyMode)
			{
				if (player.getParty() == null)
					continue;

				key = "party:" + player.getParty().getPartyObjId();
				label = "Party " + player.getParty().getPartyLeaderOID();
			}
			else
			{
				if (player.getClanId() <= 0)
					continue;

				key = "clan:" + player.getClanId() + ":" + (player.getX() / 800) + ":" + (player.getY() / 800);
				label = "Clan " + player.getClanId() + " area";
			}

			OnlineGroup group = groups.get(key);
			if (group == null)
			{
				group = new OnlineGroup(label);
				groups.put(key, group);
			}
			group.add(player);
		}

		List<OnlineGroup> rows = new ArrayList<>();
		for (OnlineGroup group : groups.values())
		{
			if (group.members.size() >= 2 && group.ips.size() >= 2)
				rows.add(group);
		}

		Collections.sort(rows, new Comparator<OnlineGroup>()
		{
			@Override
			public int compare(OnlineGroup o1, OnlineGroup o2)
			{
				return o2.ips.size() - o1.ips.size();
			}
		});

		if (rows.isEmpty())
		{
			html.append("<font color=777777>No suspicion online.</font><br1>");
			return;
		}

		int shown = 0;
		for (OnlineGroup group : rows)
		{
			if (++shown > 8)
				break;

			html.append("<table width=295 bgcolor=111111><tr><td width=95>").append(escape(group.label)).append("</td><td>")
				.append(group.members.size()).append(" chars / ").append(group.ips.size()).append(" IPs</td></tr><tr><td colspan=2>")
				.append(escape(shorten(group.membersText.toString(), 80))).append("</td></tr><tr><td colspan=2><font color=AAAAAA>")
				.append(escape(shorten(group.ips.toString(), 80))).append("</font></td></tr></table><br1>");
		}
	}

	private void appendRecentBursts(StringBuilder html)
	{
		String sql = "SELECT DATE_FORMAT(login_time, '%Y-%m-%d %H:%i') AS minute_key, COUNT(DISTINCT account_name) AS accounts, COUNT(DISTINCT ip) AS ips, COUNT(*) AS logins, MAX(login_time) AS last_seen " +
			"FROM ip_login_history WHERE login_time >= DATE_SUB(NOW(), INTERVAL 6 HOUR) GROUP BY minute_key HAVING accounts >= 2 AND ips >= 2 ORDER BY last_seen DESC LIMIT 10";

		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery())
		{
			boolean any = false;
			while (rs.next())
			{
				any = true;
				html.append("<table width=295 bgcolor=111111><tr><td width=125>").append(escape(rs.getString("minute_key"))).append("</td><td>")
					.append(rs.getInt("accounts")).append(" acc / ").append(rs.getInt("ips")).append(" IPs / ").append(rs.getInt("logins")).append(" logins")
					.append("</td></tr></table><br1>");
			}
			if (!any)
				html.append("<font color=777777>No recent burst.</font><br1>");
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not load recent IP bursts.", e);
			html.append("<font color=FF0000>DB error loading bursts.</font><br1>");
		}
	}

	private void appendChangingAccounts(StringBuilder html)
	{
		String sql = "SELECT account_name, MAX(player_name) AS player_name, COUNT(DISTINCT ip) AS ips, COUNT(*) AS logins, MAX(login_time) AS last_seen " +
			"FROM ip_login_history WHERE login_time >= DATE_SUB(NOW(), INTERVAL 1 DAY) GROUP BY account_name HAVING ips >= 3 ORDER BY ips DESC, logins DESC, last_seen DESC LIMIT 10";

		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery())
		{
			boolean any = false;
			while (rs.next())
			{
				any = true;
				String account = rs.getString("account_name");
				html.append("<table width=295 bgcolor=111111><tr><td width=120>").append(escape(shorten(account, 18))).append("</td><td>")
					.append(rs.getInt("ips")).append(" IPs / ").append(rs.getInt("logins")).append(" logins")
					.append("</td></tr><tr><td colspan=2><a action=\"bypass -h admin_ip_panel search ").append(escape(account)).append("\">view account</a> ")
					.append(escape(rs.getString("last_seen"))).append("</td></tr></table><br1>");
			}
			if (!any)
				html.append("<font color=777777>No account with 3+ IPs today.</font><br1>");
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not load changing IP accounts.", e);
			html.append("<font color=FF0000>DB error loading accounts.</font><br1>");
		}
	}

	private void appendSearch(StringBuilder html, String search)
	{
		String sql = "SELECT account_name, player_name, ip, login_time FROM ip_login_history WHERE account_name LIKE ? OR player_name LIKE ? OR ip LIKE ? ORDER BY login_time DESC LIMIT 20";
		String pattern = "%" + search + "%";

		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement(sql))
		{
			ps.setString(1, pattern);
			ps.setString(2, pattern);
			ps.setString(3, pattern);

			try (ResultSet rs = ps.executeQuery())
			{
				boolean any = false;
				while (rs.next())
				{
					any = true;
					html.append("<table width=295 bgcolor=111111><tr><td width=95>").append(escape(shorten(rs.getString("player_name"), 14))).append("</td><td>")
						.append(escape(shorten(rs.getString("ip"), 18))).append("</td></tr><tr><td colspan=2>")
						.append(escape(shorten(rs.getString("account_name"), 20))).append(" - ").append(escape(rs.getString("login_time"))).append("</td></tr></table><br1>");
				}
				if (!any)
					html.append("<font color=777777>No result.</font><br1>");
			}
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not search IP history.", e);
			html.append("<font color=FF0000>DB error searching history.</font><br1>");
		}
	}

	private static boolean isValidOnlinePlayer(L2PcInstance player)
	{
		return player != null && player.isOnline() && !player.isFakeOffline() && player.getClient() != null && player.getClient().getConnection() != null && !player.getClient().getConnection().isClosed() && player.getClient().getConnection().getInetAddress() != null;
	}

	private static String escape(String text)
	{
		if (text == null)
			return "";

		return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
	}

	private static String shorten(String text, int max)
	{
		if (text == null)
			return "";

		return text.length() > max ? text.substring(0, max - 3) + "..." : text;
	}

	private static final class OnlineGroup
	{
		private final String label;
		private final List<String> members = new ArrayList<>();
		private final Set<String> ips = new HashSet<>();
		private final StringBuilder membersText = new StringBuilder();

		private OnlineGroup(String label)
		{
			this.label = label;
		}

		private void add(L2PcInstance player)
		{
			String ip = player.getIP();
			members.add(player.getName());
			ips.add(ip == null ? "" : ip);
			if (membersText.length() > 0)
				membersText.append(", ");
			membersText.append(player.getName()).append("(").append(ip).append(")");
		}
	}
}
