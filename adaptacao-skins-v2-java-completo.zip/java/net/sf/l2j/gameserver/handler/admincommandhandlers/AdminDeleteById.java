/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.handler.admincommandhandlers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.datatables.SpawnTable;
import net.sf.l2j.gameserver.handler.IAdminCommandHandler;
import net.sf.l2j.gameserver.instancemanager.RaidBossSpawnManager;
import net.sf.l2j.gameserver.model.L2Object;
import net.sf.l2j.gameserver.model.L2Spawn;
import net.sf.l2j.gameserver.model.L2World;
import net.sf.l2j.gameserver.model.actor.L2Npc;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.itemcontainer.ItemContainer;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.network.SystemMessageId;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;

/**
 * Delete items and NPCs by template id.
 */
public class AdminDeleteById implements IAdminCommandHandler
{
	private static final String[] ADMIN_COMMANDS =
	{
		"admin_delete_panel",
		"admin_delete_item_id",
		"admin_delete_item_global",
		"admin_delete_npc_id",
		"admin_delete_npc_radius"
	};
	
	private static final int DEFAULT_NPC_RADIUS = 1500;
	private static final int MAX_NPC_RADIUS = 10000;
	
	@Override
	public boolean useAdminCommand(String command, L2PcInstance activeChar)
	{
		if (activeChar.getAccessLevel().getLevel() < 1)
			return false;
		
		if (command.equals("admin_delete_panel"))
			showPanel(activeChar);
		else if (command.startsWith("admin_delete_item_id"))
			deleteItemById(activeChar, command);
		else if (command.startsWith("admin_delete_item_global"))
			deleteItemGlobal(activeChar, command);
		else if (command.startsWith("admin_delete_npc_id"))
			deleteNpcById(activeChar, command);
		else if (command.startsWith("admin_delete_npc_radius"))
			deleteNpcByRadius(activeChar, command);
		
		return true;
	}
	
	@Override
	public String[] getAdminCommandList()
	{
		return ADMIN_COMMANDS;
	}
	
	private static void showPanel(L2PcInstance activeChar)
	{
		StringBuilder html = new StringBuilder(3000);
		html.append("<html><body><center><font color=\"LEVEL\">Delete By ID Panel</font></center><br>");
		
		html.append("<table width=300><tr><td><font color=\"LEVEL\">Delete item</font></td></tr></table>");
		html.append("<table width=300>");
		html.append("<tr><td width=80>Item ID:</td><td><edit var=\"itemId\" width=120 height=15></td></tr>");
		html.append("<tr><td width=80>Count:</td><td><edit var=\"itemCount\" width=120 height=15></td></tr>");
		html.append("<tr><td width=80>Player:</td><td><edit var=\"itemPlayer\" width=120 height=15></td></tr>");
		html.append("</table><center>");
		html.append("<a action=\"bypass -h admin_delete_item_id $itemId $itemCount $itemPlayer\">Delete Item</a><br1>");
		html.append("<a action=\"bypass -h admin_delete_item_id $itemId all\">Delete All From Target</a><br1>");
		html.append("<a action=\"bypass -h admin_delete_item_global $itemId\">Delete Global</a>");
		html.append("</center>");
		
		html.append("<br><table width=300><tr><td><font color=\"LEVEL\">Delete NPC by ID</font></td></tr></table>");
		html.append("<table width=300>");
		html.append("<tr><td width=80>NPC ID:</td><td><edit var=\"npcId\" width=120 height=15></td></tr>");
		html.append("<tr><td width=80>Radius:</td><td><edit var=\"npcRadius\" width=120 height=15></td></tr>");
		html.append("</table><center>");
		html.append("<a action=\"bypass -h admin_delete_npc_id $npcId $npcRadius\">Delete NPC ID</a>");
		html.append("</center>");
		
		html.append("<br><table width=300><tr><td><font color=\"LEVEL\">Delete NPCs by radius</font></td></tr></table>");
		html.append("<table width=300>");
		html.append("<tr><td width=80>Radius:</td><td><edit var=\"allNpcRadius\" width=120 height=15></td></tr>");
		html.append("<tr><td width=80>NPC ID:</td><td><edit var=\"filterNpcId\" width=120 height=15></td></tr>");
		html.append("</table><center>");
		html.append("<a action=\"bypass -h admin_delete_npc_radius $allNpcRadius\">Delete All Radius</a><br1>");
		html.append("<a action=\"bypass -h admin_delete_npc_radius $allNpcRadius $filterNpcId\">Delete ID Radius</a>");
		html.append("</center>");
		
		html.append("</body></html>");
		
		NpcHtmlMessage msg = new NpcHtmlMessage(0);
		msg.setHtml(html.toString());
		activeChar.sendPacket(msg);
	}
	
	private static void deleteItemById(L2PcInstance activeChar, String command)
	{
		try
		{
			StringTokenizer st = new StringTokenizer(command, " ");
			st.nextToken();
			
			if (!st.hasMoreTokens())
			{
				activeChar.sendMessage("Usage: //delete_item_id <itemId> [count|all] [playerName]");
				return;
			}
			
			int itemId = Integer.parseInt(st.nextToken());
			int count = -1;
			String playerName = null;
			if (st.hasMoreTokens())
			{
				String countToken = st.nextToken();
				if (!countToken.equalsIgnoreCase("all"))
				{
					try
					{
						count = Integer.parseInt(countToken);
					}
					catch (NumberFormatException e)
					{
						playerName = countToken;
					}
				}
			}
			
			L2PcInstance target = getTargetPlayer(activeChar);
			if (st.hasMoreTokens())
				playerName = st.nextToken();
			
			if (playerName != null)
				target = L2World.getInstance().getPlayer(playerName);
			
			if (target == null)
			{
				activeChar.sendPacket(SystemMessageId.INCORRECT_TARGET);
				return;
			}
			
			ItemInstance item = target.getInventory().getItemByItemId(itemId);
			if (item == null)
			{
				activeChar.sendMessage(target.getName() + " doesn't have item id " + itemId + ".");
				return;
			}
			
			if (count <= 0 || count > item.getCount())
				count = item.getCount();
			
			if (target.destroyItemByItemId("GM Delete By Id", itemId, count, activeChar, true))
				activeChar.sendMessage("Deleted " + count + " item(s) id " + itemId + " from " + target.getName() + ".");
			else
				activeChar.sendMessage("Couldn't delete item id " + itemId + " from " + target.getName() + ".");
		}
		catch (Exception e)
		{
			activeChar.sendMessage("Usage: //delete_item_id <itemId> [count|all] [playerName]");
		}
	}
	
	private static void deleteItemGlobal(L2PcInstance activeChar, String command)
	{
		try
		{
			StringTokenizer st = new StringTokenizer(command, " ");
			st.nextToken();
			
			if (!st.hasMoreTokens())
			{
				activeChar.sendMessage("Usage: //delete_item_global <itemId>");
				return;
			}
			
			int itemId = Integer.parseInt(st.nextToken());
			int onlineCount = 0;
			
			for (L2PcInstance player : L2World.getInstance().getAllPlayers().values())
			{
				onlineCount += deleteFromContainer(player.getInventory(), itemId, activeChar);
				onlineCount += deleteFromContainer(player.getWarehouse(), itemId, activeChar);
				onlineCount += deleteFromContainer(player.getFreight(), itemId, activeChar);
			}
			
			int dbRows = deleteItemFromDb(itemId);
			activeChar.sendMessage("Global delete item id " + itemId + ": removed " + onlineCount + " loaded item(s), DB rows affected " + dbRows + ".");
		}
		catch (Exception e)
		{
			activeChar.sendMessage("Usage: //delete_item_global <itemId>");
		}
	}
	
	private static int deleteFromContainer(ItemContainer container, int itemId, L2PcInstance activeChar)
	{
		if (container == null)
			return 0;
		
		int deleted = 0;
		for (ItemInstance item : container.getItems())
		{
			if (item == null || item.getItemId() != itemId)
				continue;
			
			deleted += item.getCount();
			container.destroyItem("GM Global Delete By Id", item, item.getCount(), activeChar, activeChar);
		}
		
		return deleted;
	}
	
	private static int deleteItemFromDb(int itemId)
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection())
		{
			PreparedStatement statement = con.prepareStatement("DELETE FROM augmentations WHERE item_id IN (SELECT object_id FROM items WHERE item_id=?)");
			statement.setInt(1, itemId);
			statement.executeUpdate();
			statement.close();
			
			statement = con.prepareStatement("DELETE FROM items WHERE item_id=?");
			statement.setInt(1, itemId);
			int affectedRows = statement.executeUpdate();
			statement.close();
			
			return affectedRows;
		}
		catch (Exception e)
		{
			return 0;
		}
	}
	
	private static void deleteNpcById(L2PcInstance activeChar, String command)
	{
		try
		{
			StringTokenizer st = new StringTokenizer(command, " ");
			st.nextToken();
			
			if (!st.hasMoreTokens())
			{
				activeChar.sendMessage("Usage: //delete_npc_id <npcId> [radius]");
				return;
			}
			
			int npcId = Integer.parseInt(st.nextToken());
			int radius = st.hasMoreTokens() ? parseRadius(st.nextToken()) : DEFAULT_NPC_RADIUS;
			
			int deleted = deleteNpcs(activeChar, npcId, radius);
			activeChar.sendMessage("Deleted " + deleted + " NPC(s) id " + npcId + " within radius " + radius + ".");
		}
		catch (Exception e)
		{
			activeChar.sendMessage("Usage: //delete_npc_id <npcId> [radius]");
		}
	}
	
	private static void deleteNpcByRadius(L2PcInstance activeChar, String command)
	{
		try
		{
			StringTokenizer st = new StringTokenizer(command, " ");
			st.nextToken();
			
			if (!st.hasMoreTokens())
			{
				activeChar.sendMessage("Usage: //delete_npc_radius <radius> [npcId]");
				return;
			}
			
			int radius = parseRadius(st.nextToken());
			int npcId = st.hasMoreTokens() ? Integer.parseInt(st.nextToken()) : 0;
			
			int deleted = deleteNpcs(activeChar, npcId, radius);
			if (npcId > 0)
				activeChar.sendMessage("Deleted " + deleted + " NPC(s) id " + npcId + " within radius " + radius + ".");
			else
				activeChar.sendMessage("Deleted " + deleted + " NPC(s) within radius " + radius + ".");
		}
		catch (Exception e)
		{
			activeChar.sendMessage("Usage: //delete_npc_radius <radius> [npcId]");
		}
	}
	
	private static int deleteNpcs(L2PcInstance activeChar, int npcId, int radius)
	{
		List<L2Npc> targets = new ArrayList<>();
		for (L2Npc npc : activeChar.getKnownList().getKnownTypeInRadius(L2Npc.class, radius))
		{
			if (npc == null)
				continue;
			
			if (npcId > 0 && npc.getNpcId() != npcId)
				continue;
			
			targets.add(npc);
		}
		
		int deleted = 0;
		for (L2Npc npc : targets)
		{
			deleteNpc(npc);
			deleted++;
		}
		
		return deleted;
	}
	
	private static void deleteNpc(L2Npc npc)
	{
		L2Spawn spawn = npc.getSpawn();
		
		npc.deleteMe();
		
		if (spawn == null)
			return;
		
		spawn.stopRespawn();
		
		if (RaidBossSpawnManager.getInstance().isDefined(spawn.getNpcId()))
			RaidBossSpawnManager.getInstance().deleteSpawn(spawn, true);
		else
			SpawnTable.getInstance().deleteSpawn(spawn, true);
	}
	
	private static L2PcInstance getTargetPlayer(L2PcInstance activeChar)
	{
		L2Object target = activeChar.getTarget();
		if (target instanceof L2PcInstance)
			return (L2PcInstance) target;
		
		return activeChar;
	}
	
	private static int parseRadius(String value)
	{
		int radius = Integer.parseInt(value);
		if (radius < 1)
			radius = 1;
		
		if (radius > MAX_NPC_RADIUS)
			radius = MAX_NPC_RADIUS;
		
		return radius;
	}
}
