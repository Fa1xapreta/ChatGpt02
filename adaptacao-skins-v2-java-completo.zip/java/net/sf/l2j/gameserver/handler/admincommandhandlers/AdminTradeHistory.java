package net.sf.l2j.gameserver.handler.admincommandhandlers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.StringTokenizer;
import java.util.logging.Logger;

import net.sf.l2j.Config;
import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.handler.IAdminCommandHandler;
import net.sf.l2j.gameserver.model.L2Object;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;

public class AdminTradeHistory implements IAdminCommandHandler
{
	private static final Logger _log = Logger.getLogger(AdminTradeHistory.class.getName());
	private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM HH:mm");
	private static final String SELECT_ALL = "SELECT trade_time, char_name, partner_name, direction, item_name, item_count, enchant, augmentation_id FROM character_trade_history ORDER BY id DESC LIMIT ? OFFSET ?";
	private static final String SELECT_BY_NAME = "SELECT trade_time, char_name, partner_name, direction, item_name, item_count, enchant, augmentation_id FROM character_trade_history WHERE char_name=? ORDER BY id DESC LIMIT ? OFFSET ?";

	private static final String[] ADMIN_COMMANDS =
	{
		"admin_tradelog"
	};

	@Override
	public boolean useAdminCommand(String command, L2PcInstance activeChar)
	{
		if (activeChar == null)
			return false;

		if (!Config.TRADE_HISTORY_ENABLED)
		{
			activeChar.sendMessage("Trade history is disabled.");
			return true;
		}

		String charName = null;
		int page = 1;

		StringTokenizer st = new StringTokenizer(command, " ");
		st.nextToken();
		if (st.hasMoreTokens())
		{
			String token = st.nextToken();
			if (isInteger(token))
				page = Integer.parseInt(token);
			else
			{
				charName = token;
				if (st.hasMoreTokens())
					page = parseInt(st.nextToken(), 1);
			}
		}
		else
		{
			L2Object target = activeChar.getTarget();
			if (target instanceof L2PcInstance)
				charName = ((L2PcInstance) target).getName();
		}

		showTradeLog(activeChar, charName, page);
		return true;
	}

	private static void showTradeLog(L2PcInstance admin, String charName, int page)
	{
		page = Math.max(1, page);
		int limit = Math.max(1, Config.TRADE_HISTORY_PAGE_LIMIT);
		int offset = (page - 1) * limit;
		boolean hasNext = false;
		StringBuilder rows = new StringBuilder();

		String sql = charName == null || charName.isEmpty() ? SELECT_ALL : SELECT_BY_NAME;
		try (Connection con = L2DatabaseFactory.getInstance().getConnection(); PreparedStatement ps = con.prepareStatement(sql))
		{
			int index = 1;
			if (charName != null && !charName.isEmpty())
				ps.setString(index++, charName);
			ps.setInt(index++, limit + 1);
			ps.setInt(index, offset);

			try (ResultSet rs = ps.executeQuery())
			{
				int count = 0;
				while (rs.next())
				{
					count++;
					if (count > limit)
					{
						hasNext = true;
						break;
					}

					Timestamp time = rs.getTimestamp("trade_time");
					String direction = "GAVE".equals(rs.getString("direction")) ? "Out" : "In";
					String player = shorten(rs.getString("char_name"), 12);
					String partner = shorten(rs.getString("partner_name"), 12);
					String item = shorten(itemName(rs.getString("item_name"), rs.getInt("enchant"), rs.getLong("item_count"), rs.getInt("augmentation_id")), 26);

					rows.append("<table width=280 bgcolor=000000><tr>");
					rows.append("<td width=72><font color=B09878>").append(time != null ? DATE_FORMAT.format(time) : "--/-- --:--").append("</font></td>");
					rows.append("<td width=30><font color=").append(direction.equals("In") ? "80BFFF" : "LEVEL").append(">").append(direction).append("</font></td>");
					rows.append("<td width=178>").append(escape(item)).append("</td></tr>");
					rows.append("<tr><td></td><td></td><td><font color=808080>").append(escape(player)).append(" / ").append(escape(partner)).append("</font></td></tr>");
					rows.append("</table><img src=L2UI.SquareGray width=280 height=1>");
				}
			}
		}
		catch (Exception e)
		{
			_log.warning("Could not load admin trade history: " + e.getMessage());
			rows.append("Could not load trade history.<br>");
		}

		if (rows.length() == 0)
			rows.append("No trade history found.<br>");

		String title = charName == null || charName.isEmpty() ? "TRADE LOG" : "TRADE LOG: " + escape(shorten(charName, 18));
		String prev = page > 1 ? pageLink("Previous", charName, page - 1) : "";
		String next = hasNext ? pageLink("Next", charName, page + 1) : "";

		String html = "<html><body><center><font color=LEVEL>" + title + "</font><br1><font color=808080>Date / Item / Players</font><br><br>" + rows + "<br><table width=260><tr><td align=center>" + prev + "</td><td align=center>Page " + page + "</td><td align=center>" + next + "</td></tr></table></center></body></html>";
		NpcHtmlMessage msg = new NpcHtmlMessage(0);
		msg.setHtml(html);
		admin.sendPacket(msg);
	}

	private static String itemName(String name, int enchant, long count, int augmentationId)
	{
		StringBuilder sb = new StringBuilder();
		if (enchant > 0)
			sb.append("+").append(enchant).append(" ");
		sb.append(name == null ? "Item" : name);
		if (count > 1)
			sb.append(" x").append(count);
		if (augmentationId > 0)
			sb.append(" (Aug)");
		return sb.toString();
	}

	private static String pageLink(String text, String charName, int page)
	{
		String command = charName == null || charName.isEmpty() ? "admin_tradelog " + page : "admin_tradelog " + charName + " " + page;
		return "<a action=\"bypass -h " + command + "\"><font color=LEVEL>" + text + "</font></a>";
	}

	private static String shorten(String text, int maxLength)
	{
		if (text == null)
			return "";
		return text.length() <= maxLength ? text : text.substring(0, Math.max(0, maxLength - 3)) + "...";
	}

	private static String escape(String text)
	{
		return text == null ? "" : text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
	}

	private static int parseInt(String value, int defaultValue)
	{
		try
		{
			return Integer.parseInt(value);
		}
		catch (Exception e)
		{
			return defaultValue;
		}
	}

	private static boolean isInteger(String value)
	{
		try
		{
			Integer.parseInt(value);
			return true;
		}
		catch (Exception e)
		{
			return false;
		}
	}

	@Override
	public String[] getAdminCommandList()
	{
		return ADMIN_COMMANDS;
	}
}
