package net.sf.l2j.gameserver.handler.voicedcommandhandlers;

import java.text.DecimalFormat;
import java.util.Date;
import java.util.StringTokenizer;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.logging.Logger;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.cache.HtmCache;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.datatables.NpcTable;
import net.sf.l2j.gameserver.datatables.custom.IconTable;
import net.sf.l2j.gameserver.handler.IVoicedCommandHandler;
import net.sf.l2j.gameserver.instancemanager.GrandBossManager;
import net.sf.l2j.gameserver.instancemanager.RaidBossInfoManager;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.actor.template.NpcTemplate;
import net.sf.l2j.gameserver.model.item.DropCategory;
import net.sf.l2j.gameserver.model.item.DropData;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;
import net.sf.l2j.gameserver.templates.StatsSet;
import net.sf.l2j.util.StringUtil;
import net.sf.l2j.util.Util;

public class VoicedBoss implements IVoicedCommandHandler 
{
	private static final Logger _log = Logger.getLogger(VoicedBoss.class.getName());

	private static final String[] VOICED_COMMANDS =
	{
		"raidinfo",
		"raidlow",
		"raidmid",
		"raidhigh",
		"grandboss",
		"ShifRaidInfoShow"
	};

	@Override
	public boolean useVoicedCommand(String command, L2PcInstance activeChar, String target)
	{
		if (command.startsWith("raidinfo"))
		{
			if (Config.RAIDINFO_USE_GRAND_BOSS_LIST)
				showSimpleGrandBossPage(activeChar);
			else
				showMainHtml(activeChar);
		}
		else if (command.startsWith("raidlow"))
			showBossPage(activeChar, Config.LIST_RAID_LOW_IDS, "Raid LOW", "raidlow");

		else if (command.startsWith("raidmid"))
			showBossPage(activeChar, Config.LIST_RAID_MID_IDS, "Raid MID", "raidmid");

		else if (command.startsWith("raidhigh"))
			showBossPage(activeChar, Config.LIST_RAID_HIGH_IDS, "Raid HIGH", "raidhigh");

		else if (command.startsWith("grandboss"))
			showGrandBossPage(activeChar, Config.LIST_GRAND_BOSS_IDS, "Grand Boss", "grandboss");

		else if (command.startsWith("ShifRaidInfoShow"))
		{
			StringTokenizer st = new StringTokenizer(command, " ");
			st.nextToken();

			int npcId = Integer.parseInt(st.nextToken());
			int page = st.hasMoreTokens() ? Integer.parseInt(st.nextToken()) : 1;
			String back = st.hasMoreTokens() ? st.nextToken() : "raidinfo";

			ShiffNpcDropList(activeChar, npcId, page, back);
		}

		return true;
	}

	private static void showMainHtml(L2PcInstance activeChar)
	{
		NpcHtmlMessage html = new NpcHtmlMessage(0);
		html.setFile("data/html/mods/raidinfo.htm");
		activeChar.sendPacket(html);
	}

	private static String getMenuButtons()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("<table width=280><tr>");
		sb.append("<td align=center><button value=\"LOW\" action=\"bypass voiced_raidlow\" width=65 height=20 back=\"custom_textures.button65x20\" fore=\"custom_textures.button65x20\"></td>");
		sb.append("<td align=center><button value=\"MID\" action=\"bypass voiced_raidmid\" width=65 height=20 back=\"custom_textures.button65x20\" fore=\"custom_textures.button65x20\"></td>");
		sb.append("<td align=center><button value=\"HIGH\" action=\"bypass voiced_raidhigh\" width=65 height=20 back=\"custom_textures.button65x20\" fore=\"custom_textures.button65x20\"></td>");
		sb.append("<td align=center><button value=\"GRAND\" action=\"bypass voiced_grandboss\" width=65 height=20 back=\"custom_textures.button65x20\" fore=\"custom_textures.button65x20\"></td>");
		sb.append("</tr></table><br>");
		return sb.toString();
	}

	private static String limitName(String name)
	{
		if (name == null)
			return "";

		if (name.length() > 13)
			return name.substring(0, 13);

		return name;
	}

	private static String getTimeLeft(long respawnTime)
	{
		long diff = respawnTime - System.currentTimeMillis();

		if (diff <= 0)
			return "-";

		long days = diff / 86400000L;
		diff %= 86400000L;

		long hours = diff / 3600000L;
		diff %= 3600000L;

		long mins = diff / 60000L;

		if (days > 0)
			return days + "d " + hours + "h ";

		return hours + "h " + mins + "m";
	}

	private static void appendBossRow(
		    StringBuilder sb,
		    int boss,
		    String name,
		    long respawnTime,
		    String current)
		{
		    final long now = System.currentTimeMillis();
		    boolean dead = respawnTime > now;

		    /*
		     * Zaken utiliza exclusivamente o estado e o prazo
		     * do GrandBossManager, ignorando o cache antigo.
		     */
		 // Estado e horario oficiais dos encontros Zaken e Frintezza.
		    if (boss == 29022 || boss == 29045 || boss == 29047)
		    {
		        final int encounterId = (boss == 29047) ? 29045 : boss;
		        final int deadStatus = (encounterId == 29045) ? 3 : 1;

		        final GrandBossManager manager =
		            GrandBossManager.getInstance();

		        final StatsSet info = manager.getStatsSet(encounterId);

		        if (info != null)
		        {
		            dead = manager.getBossStatus(encounterId) == deadStatus;

		            respawnTime = dead
		                ? info.getLong("respawn_time", 0L)
		                : 0L;
		        }
		    }

		    sb.append("<tr>");
		    sb.append("<td width=95>");

		    sb.append("<a action=\"bypass RaidBossDrop ")
		        .append(boss)
		        .append(" 1 ")
		        .append(current)
		        .append("\">")
		        .append(limitName(name))
		        .append("</a>");

		    sb.append("</td>");

		    if (!dead)
		    {
		        sb.append(
		            "<td width=55 align=center>" +
		            "<font color=\"00FF00\">Alive</font></td>");

		        sb.append(
		            "<td width=55 align=center>" +
		            "<font color=\"FFFF00\">-</font></td>");

		        sb.append(
		            "<td width=75 align=center>" +
		            "<font color=\"B09878\">Now</font></td>");
		    }
		    else if (respawnTime <= now)
		    {
		        // N�o informar Alive enquanto o manager ainda registra DEAD.
		        sb.append(
		            "<td width=55 align=center>" +
		            "<font color=\"FF0000\">Dead</font></td>");

		        sb.append("<td width=55 align=center>-</td>");
		        sb.append("<td width=75 align=center>Pending</td>");
		    }
		    else
		    {
		        sb.append(
		            "<td width=55 align=center>" +
		            "<font color=\"FF0000\">Dead</font></td>");

		        sb.append(
		            "<td width=55 align=center>" +
		            "<font color=\"FFFF00\">")
		            .append(getTimeLeft(respawnTime))
		            .append("</font></td>");

		        sb.append(
		            "<td width=75 align=center>" +
		            "<font color=\"B09878\">")
		            .append(Util.formatDate(
		                new Date(respawnTime), "dd/MM HH:mm"))
		            .append("</font></td>");
		    }

		    sb.append("</tr>");
		}

	private static void showSimpleGrandBossPage(L2PcInstance activeChar)
	{
		String html = HtmCache.getInstance().getHtm("data/html/mods/boss_list.htm");
		if (html == null)
		{
			_log.warning("VoicedBoss: data/html/mods/boss_list.htm is missing!");
			return;
		}

		StringBuilder rows = new StringBuilder();
		List<Integer> bossList = Config.LIST_GRAND_BOSS_IDS;

		if (bossList != null)
		{
			for (int boss : bossList)
			{
				if (boss <= 0) continue;

				NpcTemplate template = NpcTable.getInstance().getTemplate(boss);
				if (template == null) continue;

				String name = template.getName();
				long now = System.currentTimeMillis();
				long respawnTime = 0;

				try
				{
					if (GrandBossManager.getInstance().getStatsSet(boss) != null)
						respawnTime = GrandBossManager.getInstance().getStatsSet(boss).getLong("respawn_time");
				}
				catch (Exception e)
				{
					respawnTime = 0;
				}

				if (respawnTime <= now)
				{
					try
					{
						long raidRespawn = RaidBossInfoManager.getInstance().getRaidBossRespawnTime(boss);
						if (raidRespawn > now)
							respawnTime = raidRespawn;
					}
					catch (Exception e) {}
				}

				appendBossRow(rows, boss, name, respawnTime, "raidinfo");
			}
		}

		html = html.replace("%title%", "Raid Info");
		html = html.replace("%menu_buttons%", "");
		html = html.replace("%boss_rows%", rows.toString());
		html = html.replace("%back_button%", "");

		NpcHtmlMessage msg = new NpcHtmlMessage(1);
		msg.setHtml(html);
		activeChar.sendPacket(msg);
	}

	private static void showBossPage(L2PcInstance activeChar, List<Integer> bossList, String title, String current)
	{
		String html = HtmCache.getInstance().getHtm("data/html/mods/boss_list.htm");
		if (html == null)
		{
			_log.warning("VoicedBoss: data/html/mods/boss_list.htm is missing!");
			return;
		}

		StringBuilder rows = new StringBuilder();

		if (bossList != null)
		{
			for (int boss : bossList)
			{
				if (boss <= 0) continue;

				NpcTemplate template = NpcTable.getInstance().getTemplate(boss);
				if (template == null) continue;

				String name = template.getName();
				long respawnTime = 0;

				try
				{
					respawnTime = RaidBossInfoManager.getInstance().getRaidBossRespawnTime(boss);
				}
				catch (Exception e)
				{
					continue;
				}

				appendBossRow(rows, boss, name, respawnTime, current);
			}
		}

		String backBtn = "<table width=280><tr><td align=center><button value=\"Return\" action=\"bypass voiced_raidinfo\" width=94 height=18 back=\"custom_textures.button94x18\" fore=\"custom_textures.button94x18\"></td></tr></table>";

		html = html.replace("%title%", title);
		html = html.replace("%menu_buttons%", getMenuButtons());
		html = html.replace("%boss_rows%", rows.toString());
		html = html.replace("%back_button%", backBtn);

		NpcHtmlMessage msg = new NpcHtmlMessage(1);
		msg.setHtml(html);
		activeChar.sendPacket(msg);
	}

	private static void showGrandBossPage(L2PcInstance activeChar, List<Integer> bossList, String title, String current)
	{
		String html = HtmCache.getInstance().getHtm("data/html/mods/boss_list.htm");
		if (html == null)
		{
			_log.warning("VoicedBoss: data/html/mods/boss_list.htm is missing!");
			return;
		}

		StringBuilder rows = new StringBuilder();

		if (bossList != null)
		{
			for (int boss : bossList)
			{
				if (boss <= 0) continue;

				NpcTemplate template = NpcTable.getInstance().getTemplate(boss);
				if (template == null) continue;

				String name = template.getName();
				long now = System.currentTimeMillis();
				long respawnTime = 0;

				try
				{
					respawnTime = GrandBossManager.getInstance().getStatsSet(boss).getLong("respawn_time");
				}
				catch (Exception e)
				{
					respawnTime = 0;
				}

				if (respawnTime <= now)
				{
					try
					{
						long raidRespawn = RaidBossInfoManager.getInstance().getRaidBossRespawnTime(boss);
						if (raidRespawn > now)
							respawnTime = raidRespawn;
					}
					catch (Exception e) {}
				}

				appendBossRow(rows, boss, name, respawnTime, current);
			}
		}

		String backBtn = "<table width=280><tr><td align=center><button value=\"Return\" action=\"bypass voiced_raidinfo\" width=94 height=18 back=\"custom_textures.button94x18\" fore=\"custom_textures.button94x18\"></td></tr></table>";

		html = html.replace("%title%", title);
		html = html.replace("%menu_buttons%", getMenuButtons());
		html = html.replace("%boss_rows%", rows.toString());
		html = html.replace("%back_button%", backBtn);

		NpcHtmlMessage msg = new NpcHtmlMessage(1);
		msg.setHtml(html);
		activeChar.sendPacket(msg);
	}

	private static void ShiffNpcDropList(L2PcInstance activeChar, int npcId, int page, String back)
	{
		int ITEMS_PER_LIST = 7;

		NpcTemplate npc = NpcTable.getInstance().getTemplate(npcId);
		if (npc == null)
			return;

		if (npc.getDropData().isEmpty())
		{
			activeChar.sendMessage("This target have not drop info.");
			return;
		}

		List<DropCategory> list = new ArrayList<>();
		npc.getDropData().forEach(c -> list.add(c));
		Collections.reverse(list);

		StringBuilder sb = new StringBuilder(2000);

		StringUtil.append(sb, new Object[] { "<html><title>", npc.getName(), " - Drop Info</title><body>" });
		StringUtil.append(sb, new Object[] { "<a action=\"bypass voiced_", back, "\">Back</a>" });
		StringUtil.append(sb, new Object[] { "<center><br>" });

		int myPage = 1;
		int i = 0;
		int shown = 0;
		boolean hasMore = false;

		for (DropCategory cat : npc.getDropData())
		{
			for (DropData drop : cat.getAllDrops())
			{
				if (myPage != page)
				{
					i++;

					if (i == ITEMS_PER_LIST)
					{
						myPage++;
						i = 0;
					}

					continue;
				}

				if (shown == ITEMS_PER_LIST)
				{
					hasMore = true;
					break;
				}

				DecimalFormat df2 = new DecimalFormat("##.##");
				double ChanceInt = drop.getChance() / 10000.0D * Config.RATE_DROP_ITEMS_BY_RAID;
				String Chance = df2.format(ChanceInt);

				StringUtil.append(sb, new Object[] { "<img src=\"L2UI.SquareGray\" width=260 height=1>" });
				StringUtil.append(sb, new Object[] { "<table border=0 bgcolor=000000 width=\"60%\"><tr>" });
				StringUtil.append(sb, new Object[] { "<td width=44 height=41 align=center><img src=\"", IconTable.getIcon(drop.getItemId()), "\" width=32 height=32></td><td>" });
				StringUtil.append(sb, new Object[] { "<table><tr><td width=240>", ItemTable.getInstance().getTemplate(drop.getItemId()).getName(), "</td></tr>" });
				StringUtil.append(sb, new Object[] { "<tr><td><font color=\"LEVEL\">Drop Chance</font>: ", drop.getMinDrop(), "-", drop.getMaxDrop(), " ", Chance, "%", cat.isSweep() ? "<font color=\"00FF00\"> Sweep</font>" : "", "</td></tr></table>" });
				StringUtil.append(sb, new Object[] { "</td></tr></table>" });

				shown++;
			}

			if (hasMore)
				break;
		}

		sb.append("<img height=8><img src=L2UI.SquareGray width=280 height=1>");
		sb.append("<table width=280 bgcolor=000000><tr>");

		sb.append("<td align=center width=50>");
		if (page > 1)
			sb.append("<a action=\"bypass RaidBossDrop ").append(npcId).append(" ").append(page - 1).append(" ").append(back).append("\">Prev</a>");
		sb.append("</td>");

		sb.append("<td align=center width=140>Page ").append(page).append("</td>");

		sb.append("<td align=center width=50>");
		if (hasMore)
			sb.append("<a action=\"bypass RaidBossDrop ").append(npcId).append(" ").append(page + 1).append(" ").append(back).append("\">Next</a>");
		sb.append("</td>");

		sb.append("</tr></table><img src=L2UI.SquareGray width=280 height=1>");
		sb.append("</center></body></html>");

		NpcHtmlMessage html = new NpcHtmlMessage(0);
		html.setHtml(sb.toString());
		activeChar.sendPacket(html);
	}

	@Override
	public String[] getVoicedCommandList() 
	{
		return VOICED_COMMANDS;
	}
}