package net.sf.l2j.gameserver.handler.voicedcommandhandlers;



import java.util.HashMap;
import java.util.logging.Logger;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.handler.IVoicedCommandHandler;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.serverpackets.ItemList;

/**
 * @author MeGaPacK
 */
public class VoicedAutoGB implements IVoicedCommandHandler
{
	
	static final Logger _log = Logger.getLogger(Config.class.getName());
	
	static final HashMap<String, Thread> userGB = new HashMap<>();
	
	private static String[] _voicedCommands = 
	{
		"setAutoGoldBar"
	};
	
	@Override
	public boolean useVoicedCommand(String command, L2PcInstance activeChar, String params) 
	{
		if (activeChar == null) 
		{
			return false;
		}
		
		if (command.equals("setAutoGoldBar")) 
		{
			
			if (userGB.containsKey(activeChar.toString()) && activeChar.isAutoGB())
			{
				userGB.remove(activeChar.toString()) 
				.interrupt(); 
				activeChar.setAutoGB(false);
				VoicedMenu.showMenuHtml(activeChar);
			} else {
				activeChar.setAutoGB(true);
				Thread t = new Thread(new Autogb(activeChar));
				userGB.put(activeChar.toString(), t);
				t.start();
				VoicedMenu.showMenuHtml(activeChar);
			}
			
			return true;
		}
		return false;
	}
	
	@Override
	public String[] getVoicedCommandList() 
	{
		return _voicedCommands;
	}
	
	class Autogb implements Runnable 
	{
		
		L2PcInstance activeChar;
		
		public Autogb(L2PcInstance activeChar) 
		{
			this.activeChar = activeChar;
		}
		
		@Override
		public void run() 
		{
			try {
				while (true) 
				{
					
					if (activeChar.getInventory().getInventoryItemCount(57, 0) >= Config.BANKING_SYSTEM_ADENA)
					{
						activeChar.getInventory().reduceAdena("Goldbar", Config.BANKING_SYSTEM_ADENA, activeChar, null);
						activeChar.getInventory().addItem("Goldbar", 3470, Config.BANKING_SYSTEM_GOLDBARS, activeChar, null);
						activeChar.getInventory().updateDatabase();
						activeChar.sendPacket(new ItemList(activeChar, false));
					}
					Thread.sleep(2000);
				}
			} catch (InterruptedException e)
			{
				//nothing
			} 
			catch (Exception e) 
			{
				_log.warning(e.getMessage());
				Thread.currentThread().interrupt();
			} 
			finally
			{
				userGB.remove(activeChar.toString());
			}
		}
	}
}