package net.sf.l2j.gameserver.handler.voicedcommandhandlers;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.handler.IVoicedCommandHandler;
import net.sf.l2j.gameserver.instancemanager.CastleManager;
import net.sf.l2j.gameserver.instancemanager.SiegeManager;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.entity.Castle;
import net.sf.l2j.gameserver.network.SystemMessageId;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;
import net.sf.l2j.gameserver.network.serverpackets.SiegeInfo;

public class VoicedCastles implements IVoicedCommandHandler
{
	private static final String[] VOICED_COMMANDS = 
	{
		"castlemanager",
		"siege_gludio",
		"siege_dion",
		"siege_giran",
		"siege_oren",
		"siege_aden",
		"siege_innadril",
		"siege_goddard",
		"siege_rune",
		"siege_schuttgart"
	};

	@Override
	public boolean useVoicedCommand(String command, L2PcInstance activeChar, String target)
	{
		if (command.startsWith("castlemanager") && Config.ALLOW_CMD_CASTLE) 
			sendHtml(activeChar);

		if (command.startsWith("siege_")) 
		{
			if (activeChar.getClan() != null && !activeChar.isClanLeader()) 
			{
				activeChar.sendPacket(SystemMessageId.YOU_ARE_NOT_AUTHORIZED_TO_DO_THAT);
				return false;
			}

			int castleId = 0;

			if (command.startsWith("siege_gludio") && SiegeManager.ALLOW_CMD_GLUDIO)
				castleId = 1;
			else if (command.startsWith("siege_dion") && SiegeManager.ALLOW_CMD_DION)
				castleId = 2;
			else if (command.startsWith("siege_giran") && SiegeManager.ALLOW_CMD_GIRAN)
				castleId = 3;
			else if (command.startsWith("siege_oren") && SiegeManager.ALLOW_CMD_OREN)
				castleId = 4;
			else if (command.startsWith("siege_aden") && SiegeManager.ALLOW_CMD_ADEN)
				castleId = 5;
			else if (command.startsWith("siege_innadril") && SiegeManager.ALLOW_CMD_HEINE)
				castleId = 6;
			else if (command.startsWith("siege_goddard") && SiegeManager.ALLOW_CMD_GODARD)
				castleId = 7;
			else if (command.startsWith("siege_rune") && SiegeManager.ALLOW_CMD_RUNE)
				castleId = 8;
			else if (command.startsWith("siege_schuttgart") && SiegeManager.ALLOW_CMD_STURT)
				castleId = 9;

			Castle castle = CastleManager.getInstance().getCastleById(castleId);
			if(castle != null && castleId != 0)
				activeChar.sendPacket(new SiegeInfo(castle));
		}
		return true;
	}

	private static void sendHtml(L2PcInstance activeChar)
	{
		String htmFile = "data/html/mods/menu/CastleManager.htm";

		NpcHtmlMessage msg = new NpcHtmlMessage(5);
		msg.setFile(htmFile);
		activeChar.sendPacket(msg);
	}

	@Override
	public String[] getVoicedCommandList()
	{
		return VOICED_COMMANDS;
	}
}