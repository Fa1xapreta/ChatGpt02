package net.sf.l2j.gameserver.handler.voicedcommandhandlers;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.handler.IVoicedCommandHandler;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;

public class VoicedColor implements IVoicedCommandHandler
{
	private static final String[] VOICED_COMMANDS = 
	{
		"colormanager",
		"color_name_1",
		"color_name_2",
		"color_name_3",
		"color_name_4",
		"color_name_5",
		"color_name_6",
		"color_name_7",
		"color_name_8",
		"color_name_9",
		"color_name_l",
		"color_name_v",
		"color_name_r",
		"color_name_b",
		"color_name_p",
		"color_name_g",
		"color_title_1",
		"color_title_2",
		"color_title_3",
		"color_title_4",
		"color_title_5",
		"color_title_6",
		"color_title_7",
		"color_title_8",
		"color_title_9",
		"color_title_l",
		"color_title_v",
		"color_title_r",
		"color_title_b",
		"color_title_p",
		"color_title_g",
		"color_vipname_green",
		"color_vipname_orange",
		"color_vipname_purple",
		"color_viptitle_green",
		"color_viptitle_orange",
		"color_viptitle_purple",
		"color_name_original",
		"color_title_original"
	};
	
	@Override
	public boolean useVoicedCommand(String command, L2PcInstance activeChar, String target)
	{
		if (command.startsWith("colormanager") && Config.ALLOW_COLOR_MANAGER) 
		{
			sendHtml(activeChar);
			/*
			if (activeChar.isVip())
			{
				sendHtml(activeChar);
			}
			else
			{
				activeChar.sendMessage("Only released for VIP access.");
			}*/
			
		}
		
		//Name Color Voiced
		else if (command.startsWith("color_name_original")) 
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setNameColor(16777215);
				activeChar.sendMessage("Congratulations you have restored the color of your original name!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_name_1"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setNameColor(0x009900);
				activeChar.sendMessage("[Name]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_name_2"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setNameColor(0xff7f00);
				activeChar.sendMessage("[Name]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_name_3"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setNameColor(0x994023);
				activeChar.sendMessage("[Name]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_name_4"))
		{
			if(activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setNameColor(0x00ffff);
				activeChar.sendMessage("[Name]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_name_5"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setNameColor(0x4c4c4c);
				activeChar.sendMessage("[Name]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_name_6"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setNameColor(0x990432);
				activeChar.sendMessage("[Name]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_name_7"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setNameColor(0x70db93);
				activeChar.sendMessage("[Name]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_name_8"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setNameColor(0x9f9f9f);
				activeChar.sendMessage("[Name]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_name_9"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setNameColor(0xffff00);
				activeChar.sendMessage("[Name]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_name_l"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setNameColor(0x0099ff);
				activeChar.sendMessage("[Name]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_name_v"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setNameColor(0x330066);
				activeChar.sendMessage("[Name]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_name_r"))
		{
			if(activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setNameColor(0xff66ff);
				activeChar.sendMessage("[Name]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_name_b"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setNameColor(0x997e00);
				activeChar.sendMessage("[Name]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_name_p"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setNameColor(0x9900cc);
				activeChar.sendMessage("[Name]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_name_g"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setNameColor(0x00fb87);
				activeChar.sendMessage("[Name]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		
		//Title Color Voiced
		else if (command.startsWith("color_title_original")) 
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setTitleColor(16777079);
				activeChar.sendMessage("[Msg]: You have restored the color of your original title!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_title_1"))
		{			
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setTitleColor(0x009900);
				activeChar.sendMessage("[Title]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_title_2"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setTitleColor(0xff7f00);
				activeChar.sendMessage("[Title]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_title_3"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setTitleColor(0x994023);
				activeChar.sendMessage("[Title]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_title_4"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setTitleColor(0x00ffff);
				activeChar.sendMessage("[Title]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_title_5"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setTitleColor(0x4c4c4c);
				activeChar.sendMessage("[Title]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_title_6"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setTitleColor(0x990432);
				activeChar.sendMessage("[Title]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_title_7"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setTitleColor(0x70db93);
				activeChar.sendMessage("[Title]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_title_8"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setTitleColor(0x9f9f9f);
				activeChar.sendMessage("[Title]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_title_9"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setTitleColor(0xffff00);
				activeChar.sendMessage("[Title]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_title_l"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setTitleColor(0x0099ff);
				activeChar.sendMessage("[Title]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_title_v"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setTitleColor(0x330066);
				activeChar.sendMessage("[Title]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_title_r"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setTitleColor(0xff66ff);
				activeChar.sendMessage("[Title]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_title_b"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setTitleColor(0x997e00);
				activeChar.sendMessage("[Title]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_title_p"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setTitleColor(0x9900cc);
				activeChar.sendMessage("[Title]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		else if (command.startsWith("color_title_g"))
		{
			if (activeChar.getInventory().getInventoryItemCount(Config.PVP_POINT_ID, 0) >= Config.PVP_POINT_COUNT)
			{
				activeChar.getInventory().destroyItemByItemId("Kill Point", Config.PVP_POINT_ID, Config.PVP_POINT_COUNT, activeChar, null);
				activeChar.getAppearance().setTitleColor(0x00fb87);
				activeChar.sendMessage("[Title]: Color changed successfully!");
				activeChar.broadcastUserInfo();
			}
			else
			{
				activeChar.sendMessage("You don't have enough necessary items.");
			}
		}
		
		// VIP Colors
		else if (command.startsWith("color_vipname_green"))
		{
			if (activeChar.isVip())
			{
				activeChar.getAppearance().setNameColor(0x00FF00);
				activeChar.sendMessage("[Msg]: You have restored the color of your original title!");
				activeChar.broadcastUserInfo();
			}
			else
				activeChar.sendMessage("You are not a VIP user.");
		}
		else if (command.startsWith("color_vipname_orange"))
		{
			if (activeChar.isVip())
			{
				activeChar.getAppearance().setNameColor(0x2F76F9);
				activeChar.sendMessage("[Msg]: You have restored the color of your original title!");
				activeChar.broadcastUserInfo();
			}
			else
				activeChar.sendMessage("You are not a VIP user.");
		}
		else if (command.startsWith("color_vipname_purple"))
		{
			if (activeChar.isVip())
			{
				activeChar.getAppearance().setNameColor(0x3D3987);
				activeChar.sendMessage("[Msg]: You have restored the color of your original title!");
				activeChar.broadcastUserInfo();
			}
			else
				activeChar.sendMessage("You are not a VIP user.");
		}
		else if (command.startsWith("color_viptitle_green"))
		{
			if (activeChar.isVip())
			{
				activeChar.getAppearance().setTitleColor(0x00FF00);
				activeChar.sendMessage("[Msg]: You have restored the color of your original title!");
				activeChar.broadcastUserInfo();
			}
			else
				activeChar.sendMessage("You are not a VIP user.");
		}
		else if (command.startsWith("color_viptitle_orange"))
		{
			if (activeChar.isVip())
			{
				activeChar.getAppearance().setTitleColor(0x2F76F9);
				activeChar.sendMessage("[Msg]: You have restored the color of your original title!");
				activeChar.broadcastUserInfo();
			}
			else
				activeChar.sendMessage("You are not a VIP user.");
		}
		else if (command.startsWith("color_viptitle_purple"))
		{
			if (activeChar.isVip())
			{
				activeChar.getAppearance().setTitleColor(0x3D3987);
				activeChar.sendMessage("[Msg]: You have restored the color of your original title!");
				activeChar.broadcastUserInfo();
			}
			else
				activeChar.sendMessage("You are not a VIP user.");
		}
		return true;
	}
	
	private static void sendHtml(L2PcInstance activeChar)
	{
		String htmFile = "data/html/mods/menu/ColorManager.htm";
		String playerName = activeChar.getName();
		String titlePlayer = activeChar.getTitle();
		NpcHtmlMessage msg = new NpcHtmlMessage(5);
		msg.setFile(htmFile);
		msg.replace("%playerTitle%", !titlePlayer.isEmpty() ? ((titlePlayer.length() > 6) ? (titlePlayer.substring(0, 6) + "...") : titlePlayer) : "Title");
		msg.replace("%playerName%", !activeChar.getName().isEmpty() ? ((activeChar.getName().length() > 6) ? (activeChar.getName().substring(0, 6) + "...") : playerName) : "Name");

		String itemName = ItemTable.getInstance().getTemplate(Config.PVP_POINT_ID).getName();
		msg.replace("%item%", itemName);
		msg.replace("%name%", String.valueOf(Config.PVP_POINT_COUNT));
		msg.replace("%title%", String.valueOf(Config.PVP_POINT_COUNT));
		activeChar.sendPacket(msg);
	}
	
	@Override
	public String[] getVoicedCommandList()
	{
		return VOICED_COMMANDS;
	}
}