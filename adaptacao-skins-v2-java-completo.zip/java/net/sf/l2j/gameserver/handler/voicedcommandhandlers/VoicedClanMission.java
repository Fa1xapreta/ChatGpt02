package net.sf.l2j.gameserver.handler.voicedcommandhandlers;

import net.sf.l2j.gameserver.handler.IVoicedCommandHandler;
import net.sf.l2j.gameserver.instancemanager.GuildMissionManager;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.guildmission.GuildMissionHtmlRenderer;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;

public class VoicedClanMission implements IVoicedCommandHandler
{
	    // Registramos as p�ginas direto no array para o Core do L2 aceitar o clique do HTML
	    private static final String[] VOICED_COMMANDS = { 
	        "clanmission", 
	        "clanmission_p1", 
	        "clanmission_p2", 
	        "clanmission_p3", 
	        "clanmission_p4", 
	        "clanmission_p5",
	        "clanmission_claim"
	    };

	    @Override
	    public boolean useVoicedCommand(String command, L2PcInstance activeChar, String target)
	    {
	        if (activeChar == null)
	        {
	            return false;
	        }

	     // 1. PRIMEIRO verificamos o comando de coletar (mais espec�fico)
	        if (command.startsWith("clanmission_claim"))
	        {
	            try
	            {
	                // O comando vir� como "clanmission_claim ID"
	                String[] params = command.split(" ");
	                int missionId = Integer.parseInt(params[1]);
	                
	                // Chama a l�gica de recompensas que criamos
	                GuildMissionManager.getInstance().claimReward(activeChar, missionId);
	                
	                // Atualiza a tela para o jogador ver que a miss�o foi resetada/coletada
	                showMissionWindow(activeChar, 1);
	                return true;
	            }
	            catch (Exception e)
	            {
	                activeChar.sendMessage("Erro ao coletar recompensa.");
	                return false;
	            }
	        }
	        
	        if (command.startsWith("clanmission"))
	        {
	            if (activeChar.getClan() == null)
	            {
	                activeChar.sendMessage("Voc� precisa estar em um cl� para acessar as Miss�es de Guilda.");
	                return false;
	            }

	            int page = 1;
	            
	            // Se o comando veio do clique do bot�o HTML (ex: clanmission_p2)
	            if (command.contains("_p"))
	            {
	                try
	                {
	                    page = Integer.parseInt(command.substring(command.indexOf("_p") + 2));
	                }
	                catch (NumberFormatException e)
	                {
	                    page = 1;
	                }
	            }
	            // Se o comando foi digitado manualmente no chat (ex: .clanmission 2)
	            else if (target != null && !target.isEmpty())
	            {
	                try
	                {
	                    page = Integer.parseInt(target.trim());
	                }
	                catch (NumberFormatException e)
	                {
	                    page = 1;
	                }
	            }

	            showMissionWindow(activeChar, page);
	            return true;
	        }
	        
	        return false;
	    }

	    private void showMissionWindow(L2PcInstance activeChar, int page)
	    {
	        NpcHtmlMessage html = new NpcHtmlMessage(0);
	        GuildMissionHtmlRenderer renderer = new GuildMissionHtmlRenderer();
	        int clanId = activeChar.getClanId();
	        
	        html.setHtml(renderer.render(clanId, page));
	        activeChar.sendPacket(html);
	    }

	    @Override
	    public String[] getVoicedCommandList()
	    {
	        return VOICED_COMMANDS;
	    }
	}