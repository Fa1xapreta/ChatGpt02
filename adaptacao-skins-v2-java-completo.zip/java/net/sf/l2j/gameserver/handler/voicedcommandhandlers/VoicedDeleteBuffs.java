package net.sf.l2j.gameserver.handler.voicedcommandhandlers;

import java.util.StringTokenizer;

import net.sf.l2j.gameserver.handler.IVoicedCommandHandler;
import net.sf.l2j.gameserver.model.L2Effect;
import net.sf.l2j.gameserver.model.L2Object;
import net.sf.l2j.gameserver.model.L2World;
import net.sf.l2j.gameserver.model.actor.L2Character;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.SystemMessageId;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;
import net.sf.l2j.util.StringUtil;

public class VoicedDeleteBuffs implements IVoicedCommandHandler
{
	private static final int PAGE_LIMIT = 19;
	
	private static final String[] VOICED_COMMANDS =
	{
		"player_getbuffs",
		"player_stopbuff"
	};
	
	@Override
	public boolean useVoicedCommand(String command, L2PcInstance activeChar, String target)
	{
		if (command.startsWith("player_getbuffs"))
		{
			StringTokenizer st = new StringTokenizer(command, " ");
			st.nextToken();
			
			if (st.hasMoreTokens())
			{
				String playername = st.nextToken();
				L2PcInstance player = L2World.getInstance().getPlayer(playername);
				if (player == null)
				{
					activeChar.sendPacket(SystemMessageId.TARGET_IS_NOT_FOUND_IN_THE_GAME);
					return false;
				}
				
				int page = 1;
				if (st.hasMoreTokens())
					page = Integer.parseInt(st.nextToken());
				
				showBuffs(activeChar, page);
				return true;
			}
			else if ((activeChar.getTarget() != null) && (activeChar.getTarget() instanceof L2Character))
			{
				showBuffs(activeChar, 1);
				return true;
			}
			else
			{
				activeChar.sendPacket(SystemMessageId.TARGET_IS_INCORRECT);
				return false;
			}
		}
		else if (command.startsWith("player_stopbuff"))
		{
			try
			{
				StringTokenizer st = new StringTokenizer(command, " ");
				
				st.nextToken();
				int objectId = Integer.parseInt(st.nextToken());
				int skillId = Integer.parseInt(st.nextToken());
				
				removeBuff(activeChar, objectId, skillId);
				return true;
			}
			catch (Exception e)
			{
				activeChar.sendMessage("Failed removing effect: " + e.getMessage());
				activeChar.sendMessage("Usage: //stopbuff <objectId> <skillId>");
				return false;
			}
		}
		else
			return true;
	}

	public static void showBuffs(L2PcInstance activeChar, int page)
	{
		final L2Effect[] effects = activeChar.getAllEffects();
		
		if (page > effects.length / PAGE_LIMIT + 1 || page < 1)
			return;
		
		int max = effects.length / PAGE_LIMIT;
		if (effects.length > PAGE_LIMIT * max)
			max++;
		final StringBuilder sb = new StringBuilder("<html><table width=\"100%\">");
		int start = ((page - 1) * PAGE_LIMIT);
		int end = Math.min(((page - 1) * PAGE_LIMIT) + PAGE_LIMIT, effects.length);
		
		for (int i = start; i < end; i++)
		{
			L2Effect e = effects[i];
			if (e != null){
				 StringUtil.append(sb, "<tr><td>", e.getSkill().getName() + "", "</td><td><a action=\"bypass voiced_player_stopbuff ", Integer.toString(activeChar.getObjectId()), " ", String.valueOf(e.getSkill().getId()), "\">Remove</a></td></tr>");

			}
		}
		sb.append("</table><br><table width=\"150%\"><tr>");
		for (int x = 0; x < max; x++)
		{
			int pagenr = x + 1;
			if (page == pagenr)
				StringUtil.append(sb, "<td>Page ", pagenr, "</td>");
			else
				StringUtil.append(sb, "<td><a action=\"bypass voiced_player_getbuffs ", activeChar.getName(), " ", x + 1, "\"> Page ", pagenr, "</a></td>");
		}
		
		sb.append("</tr></table>");
		
		final NpcHtmlMessage html = new NpcHtmlMessage(0);
		html.setHtml(sb.toString());
		activeChar.sendPacket(html);
	}
	
	private static void removeBuff(L2PcInstance activeChar, int objId, int skillId)
	{
		if (skillId < 1)
			return;
		
		final L2Object obj = L2World.getInstance().findObject(objId);
		if (obj instanceof L2Character)
		{
			final L2Character target = (L2Character) obj;
			
			for (L2Effect e : target.getAllEffects())
			{
				if (e != null && e.getSkill().getId() == skillId)
				{
					e.exit();
					activeChar.sendMessage("Removed " + e.getSkill().getName() + " level " + e.getSkill().getLevel() + " from " + target.getName() + "");
				}
			}
			showBuffs(activeChar, 1);
		}
	}
	
	@Override
	public String[] getVoicedCommandList()
	{
		return VOICED_COMMANDS;
	}
	
}