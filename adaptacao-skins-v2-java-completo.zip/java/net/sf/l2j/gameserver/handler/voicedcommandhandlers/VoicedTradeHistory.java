package net.sf.l2j.gameserver.handler.voicedcommandhandlers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.StringTokenizer;
import java.util.logging.Logger;

import net.sf.l2j.Config;
import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.handler.IVoicedCommandHandler;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;

public class VoicedTradeHistory implements IVoicedCommandHandler
{
	private static final Logger _log = Logger.getLogger(VoicedTradeHistory.class.getName());
	private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("HH:mm");
	private static final String SELECT = "SELECT id, trade_time, partner_name, direction, item_name, item_count, enchant, augmentation_id FROM character_trade_history WHERE char_id=? ORDER BY id DESC LIMIT ? OFFSET ?";

	private static final String[] VOICED_COMMANDS =
	{
		"trades",
		"tradehistory"
	};

	@Override
	public boolean useVoicedCommand(String command, L2PcInstance activeChar, String target)
	{
		if (activeChar == null)
			return false;

		if (!Config.TRADE_HISTORY_ENABLED)
		{
			activeChar.sendMessage("Trade history is disabled.");
			return true;
		}

		StringTokenizer st = new StringTokenizer(command, " ");
		st.nextToken();
		int page = st.hasMoreTokens() ? parseInt(st.nextToken(), 1) : 1;
		showHistory(activeChar, page);
		return true;
	}

	private static void showHistory(L2PcInstance player, int page)
	{
		page = Math.max(1, page);
		int limit = Math.max(1, Config.TRADE_HISTORY_PAGE_LIMIT);
		int offset = (page - 1) * limit;
		boolean hasNext = false;
		StringBuilder rows = new StringBuilder();

		try (Connection con = L2DatabaseFactory.getInstance().getConnection(); PreparedStatement ps = con.prepareStatement(SELECT))
		{
			ps.setInt(1, player.getObjectId());
			ps.setInt(2, limit + 1);
			ps.setInt(3, offset);

			try (ResultSet rs = ps.executeQuery())
			{
				int count = 0;
				while (rs.next())
				{
					count++;
					if (count > limit)
					{
						hasNext = true;
						break;
					}

					Timestamp time = rs.getTimestamp("trade_time");
					String direction = rs.getString("direction").equals("GAVE") ? "Out" : "In";
					String item = shorten(itemName(rs.getString("item_name"), rs.getInt("enchant"), rs.getLong("item_count"), rs.getInt("augmentation_id")), 28);
					String partner = shorten(rs.getString("partner_name"), 22);

					rows.append("<table width=280 bgcolor=000000><tr>");
					rows.append("<td width=38><font color=B09878>").append(time != null ? DATE_FORMAT.format(time) : "--:--").append("</font></td>");
					rows.append("<td width=28><font color=").append(direction.equals("In") ? "80BFFF" : "LEVEL").append(">").append(direction).append("</font></td>");
					rows.append("<td width=214>").append(escape(item)).append("</td></tr>");
					rows.append("<tr><td></td><td></td><td><font color=808080>").append(escape(partner)).append("</font></td></tr>");
					rows.append("</table><img src=L2UI.SquareGray width=280 height=1>");
				}
			}
		}
		catch (Exception e)
		{
			_log.warning("Could not load trade history: " + e.getMessage());
			rows.append("Could not load trade history.<br>");
		}

		if (rows.length() == 0)
			rows.append("No trade history found.<br>");

		NpcHtmlMessage html = new NpcHtmlMessage(0);
		html.setFile("data/html/mods/trades/History.htm");
		html.replace("%rows%", rows.toString());
		html.replace("%page%", String.valueOf(page));
		html.replace("%prev%", page > 1 ? "<a action=\"bypass -h voiced_trades " + (page - 1) + "\"><font color=LEVEL>Previous</font></a>" : "");
		html.replace("%next%", hasNext ? "<a action=\"bypass -h voiced_trades " + (page + 1) + "\"><font color=LEVEL>Next</font></a>" : "");
		player.sendPacket(html);
	}

	private static String itemName(String name, int enchant, long count, int augmentationId)
	{
		StringBuilder sb = new StringBuilder();
		if (enchant > 0)
			sb.append("+").append(enchant).append(" ");
		sb.append(name == null ? "Item" : name);
		if (count > 1)
			sb.append(" x").append(count);
		if (augmentationId > 0)
			sb.append(" (Aug)");
		return sb.toString();
	}

	private static String shorten(String text, int maxLength)
	{
		if (text == null)
			return "";
		return text.length() <= maxLength ? text : text.substring(0, Math.max(0, maxLength - 3)) + "...";
	}

	private static String escape(String text)
	{
		return text == null ? "" : text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
	}

	private static int parseInt(String value, int defaultValue)
	{
		try
		{
			return Integer.parseInt(value);
		}
		catch (Exception e)
		{
			return defaultValue;
		}
	}

	@Override
	public String[] getVoicedCommandList()
	{
		return VOICED_COMMANDS;
	}
}

