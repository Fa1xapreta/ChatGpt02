package net.sf.l2j.gameserver.handler.voicedcommandhandlers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.l2j.Config;
import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.handler.IVoicedCommandHandler;
import net.sf.l2j.gameserver.instancemanager.ServerRankingManager;
import net.sf.l2j.gameserver.instancemanager.ServerRankingManager.Ranking;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.entity.events.TopKillerRoundSystem;
import net.sf.l2j.gameserver.model.entity.events.toppvpevent.PvPEventManager;
import net.sf.l2j.gameserver.model.entity.events.tournaments.properties.ArenaRanking;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;

public class VoicedRanking implements IVoicedCommandHandler
{
    public static final Logger _log =
        Logger.getLogger(VoicedRanking.class.getName());

    private static final String[] VOICED_COMMANDS =
    {
        "ranking",
        "rankingpvp",
        "rankingpk",
        "rankingclanPoint",
        "rankingtopenchant",

        // Comandos adicionais preservados.
        "rankingclan",
        "rankingpvpHour",
        "rankingeloPoint",
        "rankingranking",
        "ranking1x1_rank",
        "ranking3x3_rank",
        "ranking5x5_rank",
        "ranking9x9_rank",
        "pvpEvent",
        "pvpevent"
    };

    @Override
    public boolean useVoicedCommand(
        String command, L2PcInstance activeChar, String target)
    {
        if (activeChar == null || command == null)
            return false;

        switch (command)
        {
            case "ranking":
            case "rankingranking":
            {
                if (!checkEnabled(activeChar, Config.ALLOW_CMD_RANKING))
                    return true;

                showRankingHtml(activeChar);
                return true;
            }

            case "rankingpvp":
            {
                showServerRanking(
                    activeChar,
                    Ranking.PVP,
                    Config.ALLOW_CMD_PVP);

                return true;
            }

            case "rankingpk":
            {
                showServerRanking(
                    activeChar,
                    Ranking.PK,
                    Config.ALLOW_CMD_PK);

                return true;
            }

            case "rankingclanPoint":
            {
                showServerRanking(
                    activeChar,
                    Ranking.CLAN,
                    Config.ALLOW_CMD_CLANPOINT);

                return true;
            }

            case "rankingtopenchant":
            {
                showServerRanking(
                    activeChar,
                    Ranking.ENCHANT,
                    Config.ALLOW_CMD_ENCHANT);

                return true;
            }

            case "rankingclan":
            {
                if (!checkEnabled(activeChar, Config.ALLOW_CMD_CLAN))
                    return true;

                showClanReputationHtml(activeChar);
                return true;
            }

            case "rankingeloPoint":
            {
                if (!checkEnabled(activeChar, Config.ALLOW_CMD_ELOPOINT))
                    return true;

                showEloRankingHtml(activeChar);
                return true;
            }

            case "rankingpvpHour":
            {
                if (!checkEnabled(
                    activeChar, Config.TOP_KILLER_PLAYER_ROUND))
                {
                    return true;
                }

                TopKillerRoundSystem.getTopHtml(activeChar);
                return true;
            }

            case "pvpEvent":
            case "pvpevent":
            {
                if (!checkEnabled(activeChar, Config.PVP_EVENT_ENABLED))
                    return true;

                PvPEventManager.getInstance().getTopHtml(activeChar);
                return true;
            }

            case "ranking1x1_rank":
            {
                if (!checkEnabled(activeChar, Config.ALLOW_CMD_1X1))
                    return true;

                ArenaRanking.getTopRank1x1Html(activeChar);
                return true;
            }

            case "ranking3x3_rank":
            {
                if (!checkEnabled(activeChar, Config.ALLOW_CMD_3x3))
                    return true;

                ArenaRanking.getTopRank3x3Html(activeChar);
                return true;
            }

            case "ranking5x5_rank":
            {
                if (!checkEnabled(activeChar, Config.ALLOW_CMD_5x5))
                    return true;

                ArenaRanking.getTopRank5x5Html(activeChar);
                return true;
            }

            case "ranking9x9_rank":
            {
                if (!checkEnabled(activeChar, Config.ALLOW_CMD_9x9))
                    return true;

                ArenaRanking.getTopRank9x9Html(activeChar);
                return true;
            }

            default:
                return false;
        }
    }

    private static void showServerRanking(
        L2PcInstance activeChar, Ranking ranking, boolean enabled)
    {
        if (!checkEnabled(
            activeChar, Config.ALLOW_CMD_RANKING && enabled))
        {
            return;
        }

        ServerRankingManager.getInstance().show(activeChar, ranking);
    }

    private static boolean checkEnabled(
        L2PcInstance activeChar, boolean enabled)
    {
        if (!enabled)
        {
            activeChar.sendMessage("Este ranking esta desativado.");
            return false;
        }

        return true;
    }

    private static void showRankingHtml(L2PcInstance activeChar)
    {
        NpcHtmlMessage html = new NpcHtmlMessage(0);
        html.setFile("data/html/mods/menu/Ranking.htm");
        activeChar.sendPacket(html);
    }

    /**
     * Ranking adicional de reputacao.
     * O Top Clan por pontos de boss usa rankingclanPoint.
     */
    private static void showClanReputationHtml(L2PcInstance activeChar)
    {
        String sql =
            "SELECT clan_name,clan_level,reputation_score "
            + "FROM clan_data "
            + "WHERE clan_level>0 "
            + "ORDER BY reputation_score DESC,clan_name ASC,clan_id ASC "
            + "LIMIT 15";

        StringBuilder table = new StringBuilder(
            "<table width=290>"
            + "<tr><td>#</td><td>Level</td>"
            + "<td>Clan</td><td>Reputacao</td></tr>");

        int position = 0;

        try (Connection con =
                L2DatabaseFactory.getInstance().getConnection();
             PreparedStatement statement = con.prepareStatement(sql);
             ResultSet result = statement.executeQuery())
        {
            while (result.next())
            {
                position++;

                table.append("<tr><td>")
                    .append(position)
                    .append("</td><td>")
                    .append(result.getInt("clan_level"))
                    .append("</td><td><font color=00FFFF>")
                    .append(htmlText(result.getString("clan_name"), 16))
                    .append("</font></td><td>")
                    .append(result.getLong("reputation_score"))
                    .append("</td></tr>");
            }
        }
        catch (Exception e)
        {
            _log.log(
                Level.WARNING,
                "Falha ao carregar ranking de reputacao dos clans.",
                e);

            showUnavailableHtml(activeChar, "Ranking de Clans");
            return;
        }

        if (position == 0)
        {
            table.append(
                "<tr><td colspan=4 align=center>"
                + "Nenhum registro encontrado.</td></tr>");
        }

        table.append("</table>");

        sendRankingHtml(
            activeChar,
            "Ranking de Clans",
            table.toString());
    }

    private static void showEloRankingHtml(L2PcInstance activeChar)
    {
        String sql =
            "SELECT char_name,pc_point,online "
            + "FROM characters "
            + "WHERE pc_point>0 AND accesslevel=0 "
            + "ORDER BY pc_point DESC,char_name ASC,obj_Id ASC "
            + "LIMIT 15";

        StringBuilder table = new StringBuilder(
            "<table width=290>"
            + "<tr><td>#</td><td>Jogador</td>"
            + "<td>Pontos</td><td>Status</td></tr>");

        int position = 0;

        try (Connection con =
                L2DatabaseFactory.getInstance().getConnection();
             PreparedStatement statement = con.prepareStatement(sql);
             ResultSet result = statement.executeQuery())
        {
            while (result.next())
            {
                position++;

                String status = result.getInt("online") == 1
                    ? "<font color=00FF00>On</font>"
                    : "<font color=FF7777>Off</font>";

                table.append("<tr><td>")
                    .append(position)
                    .append("</td><td><font color=00FFFF>")
                    .append(htmlText(result.getString("char_name"), 14))
                    .append("</font></td><td>")
                    .append(result.getLong("pc_point"))
                    .append("</td><td>")
                    .append(status)
                    .append("</td></tr>");
            }
        }
        catch (Exception e)
        {
            _log.log(
                Level.WARNING,
                "Falha ao carregar ranking Elo.",
                e);

            showUnavailableHtml(activeChar, "Ranking Elo");
            return;
        }

        if (position == 0)
        {
            table.append(
                "<tr><td colspan=4 align=center>"
                + "Nenhum registro encontrado.</td></tr>");
        }

        table.append("</table>");

        sendRankingHtml(
            activeChar,
            "Ranking Elo",
            table.toString());
    }

    private static void showUnavailableHtml(
        L2PcInstance activeChar, String title)
    {
        sendRankingHtml(
            activeChar,
            title,
            "<font color=FF7777>Ranking indisponivel."
            + "<br>Tente novamente em instantes.</font>");
    }

    private static void sendRankingHtml(
        L2PcInstance activeChar, String title, String content)
    {
        String safeTitle = htmlText(title, 40);

        String html =
            "<html><head><title>" + safeTitle
            + "</title></head><body><center>"
            + "<img src=\"l2ui_ch3.herotower_deco\" "
            + "width=256 height=32><br>"
            + "<font color=LEVEL>" + safeTitle + "</font><br>"
            + content
            + "<br><a action=\"bypass -h voiced_ranking\">"
            + "Voltar</a>"
            + "</center></body></html>";

        NpcHtmlMessage packet = new NpcHtmlMessage(0);
        packet.setHtml(html);
        activeChar.sendPacket(packet);
    }

    private static String htmlText(String value, int maxLength)
    {
        if (value == null)
            return "";

        if (value.length() > maxLength)
            value = value.substring(0, maxLength - 3) + "...";

        return value.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;");
    }

    @Override
    public String[] getVoicedCommandList()
    {
        return VOICED_COMMANDS.clone();
    }
}