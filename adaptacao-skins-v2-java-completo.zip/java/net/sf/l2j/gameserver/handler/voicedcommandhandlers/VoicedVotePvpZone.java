package net.sf.l2j.gameserver.handler.voicedcommandhandlers;

import java.util.ArrayList;
import java.util.List;

import net.sf.l2j.gameserver.handler.IVoicedCommandHandler;
import net.sf.l2j.gameserver.instancemanager.ZoneManager;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.entity.events.autopvpzone.PvPZone;
import net.sf.l2j.gameserver.model.zone.L2ZoneType;
import net.sf.l2j.gameserver.model.zone.type.L2AutoPvpZone;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;

public class VoicedVotePvpZone implements IVoicedCommandHandler
{
	public String[] VOICED_COMMANDS = new String[ZoneManager.getInstance().getAllZones(L2AutoPvpZone.class).size() + 1];

	public static List<String> zoneIds = new ArrayList<>();

	@Override
	public String[] getVoicedCommandList()
	{
		VOICED_COMMANDS[0] = "votezone";
		
		int i = 1;
		for (L2AutoPvpZone zone : ZoneManager.getInstance().getAllZones(L2AutoPvpZone.class))
		{
			if (zone != null) 
			{
				VOICED_COMMANDS[i] = Integer.toString(zone.getId());
				zoneIds.add(Integer.toString(zone.getId()));
				i++;
			} 
		} 
		return VOICED_COMMANDS;
	}

	@Override
	public boolean useVoicedCommand(String command, L2PcInstance activeChar, String target) 
	{
		PvPZone pvpZoneEvent = PvPZone.getInstance();
		
		if (command.equals("votezone") && pvpZoneEvent.isVoting()) 
			showHtml(activeChar);

		else if (zoneIds.contains(command) && pvpZoneEvent.isVoting()) 
		{
			insertVote(activeChar, command);
			showHtml(activeChar);
		} 
		return true;
	}

	public static void showHtml(L2PcInstance activeChar)
	{
		NpcHtmlMessage html = new NpcHtmlMessage(0);
		html.setFile("data/html/mods/pvpzone/vote.htm");
		StringBuilder tb = new StringBuilder();
		tb.append("<table width=290 bgcolor=\"000000\">");
		for (String zoneId : zoneIds)
		{
			L2ZoneType zone = ZoneManager.getInstance().getZoneById(Integer.parseInt(zoneId));
			tb.append("<tr><td width=5></td><td width=180>" + zone.getZoneName() + ":</td><td width=30>" + checkVoteCount(zoneId) + "</td><td width=70><button width=40 height=13 action=\"bypass voiced_" + zoneId + "\" value=\"Vote\" back=\"buttons_bs.bs_64x15_1\" fore=\"buttons_bs.bs_64x15_2\"></td></tr>");
		} 
		tb.append("</table>");
		html.replace("%zone_list%", tb.toString());
		activeChar.sendPacket(html);
	}

	public static void insertVote(L2PcInstance activeChar, String zoneId)
	{
		if (PvPZone.getInstance()._hwidVote.contains(activeChar.getHWid())) 
			activeChar.sendMessage("You have already cast your vote on this HWID."); 
		else
		{
			ZoneManager.getInstance().getZoneById(Integer.parseInt(zoneId)).setVotes();
			PvPZone.getInstance()._playerVote.add(activeChar);
			PvPZone.getInstance()._hwidVote.add(activeChar.getHWid());
			activeChar.sendMessage("Your vote has been added.");
		} 
	}

	public static int checkVoteCount(String zoneId) 
	{
		return ZoneManager.getInstance().getZoneById(Integer.parseInt(zoneId)).getVotes();
	}
}