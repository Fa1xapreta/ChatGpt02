package net.sf.l2j.gameserver.handler.voicedcommandhandlers;

import net.sf.l2j.gameserver.handler.IVoicedCommandHandler;
import net.sf.l2j.gameserver.instancemanager.characterpin.CharacterPinManager;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;

public class VoicedCharacterPin implements IVoicedCommandHandler
{
	private static final String[] VOICED_COMMANDS =
	{
		"pin",
		"charpin"
	};

	@Override
	public boolean useVoicedCommand(String command, L2PcInstance activeChar, String args)
	{
		CharacterPinManager.INSTANCE.handleCommand(activeChar, command);
		return false;
	}

	@Override
	public String[] getVoicedCommandList()
	{
		return VOICED_COMMANDS;
	}
}