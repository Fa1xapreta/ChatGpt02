package net.sf.l2j.gameserver.handler.voicedcommandhandlers;

import java.util.Calendar;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.handler.IVoicedCommandHandler;
import net.sf.l2j.gameserver.model.actor.L2Character;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.actor.instance.NewDailyRewardManager;
import net.sf.l2j.gameserver.model.base.Race;
import net.sf.l2j.gameserver.model.olympiad.Olympiad;
import net.sf.l2j.gameserver.network.SystemMessageId;
import net.sf.l2j.gameserver.network.serverpackets.ExShowScreenMessage;
import net.sf.l2j.gameserver.network.serverpackets.GMViewItemList;
import net.sf.l2j.gameserver.network.serverpackets.GMViewSkillInfo;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;

public class VoicedCharInfo implements IVoicedCommandHandler
{
	private static final String[] VOICED_COMMANDS = 
	{
		"status", "inventory", "skills",
		"rank", "charinfo"
	};
	
	@Override
	public boolean useVoicedCommand(String command, L2PcInstance activeChar, String target)
	{
		if (command.startsWith("status") && Config.ALLOW_CMD_STATUS)
		{
			if (activeChar.getTarget() == null) {
				activeChar.sendMessage("Voce nao tem um alvo.");
				activeChar.sendPacket(new ExShowScreenMessage("You have no one target.", 950));
				return false;
			} 
			if (!(activeChar.getTarget() instanceof L2PcInstance))
			{
				activeChar.sendMessage("Voce so pode obter as informacoes de um jogador.");
				activeChar.sendPacket(new ExShowScreenMessage("You can only get the info of a player.", 950));
				return false;
			} 
			NpcHtmlMessage adminReply = new NpcHtmlMessage(5);
			L2PcInstance targetp = (L2PcInstance)activeChar.getTarget();
			StringBuilder replyMSG = new StringBuilder("<html><title>Status Player</title><body>");
			replyMSG.append("<table width=80>");
			replyMSG.append("<tr>");
			replyMSG.append("<td><button value=\"\" action=\"bypass voiced_menu \" width=35 height=23 back=\"L2UI_CH3.calculate2_bs_down\" fore=\"L2UI_CH3.calculate2_bs\"></td>");
			replyMSG.append("<td> Menu </td>");
			replyMSG.append("</tr>");
			replyMSG.append("</table><center>");
			replyMSG.append("<br>");
			replyMSG.append("<img src=\"l2font-e.replay_logo-e\" width=256 height=60>");
			replyMSG.append("<br>");
			replyMSG.append("Info Target: <font color=\"FFFF00\">" + targetp.getName() + "</font><br>");
			replyMSG.append("<img src=\"L2UI.SquareGray\" width=210 height=1><br>");
			replyMSG.append("PvP Kills:<font color=\"FFFF00\"> " + targetp.getPvpKills() + "</font>   PK Kills:<font color=\"FFFF00\"> " + targetp.getPkKills() + "</font><br>");
			replyMSG.append("HP:<font color=\"FFFF00\"> " + targetp.getMaxHp() + "</font>   CP:<font color=\"FFFF00\"> " + targetp.getMaxCp() + "</font>   MP:<font color=\"FFFF00\"> " + targetp.getMaxMp() + "</font><br>");
			replyMSG.append("P. Atk:<font color=\"FFFF00\"> " + targetp.getPAtk(null) + "</font>   M. Atk:<font color=\"FFFF00\"> " + targetp.getMAtk(null, null) + "</font><br>");
			replyMSG.append("P. Def:<font color=\"FFFF00\"> " + targetp.getPDef(null) + "</font>   M. Def:<font color=\"FFFF00\"> " + targetp.getMDef(null, null) + "</font><br>");
			replyMSG.append("Accuracy:<font color=\"FFFF00\"> " + targetp.getAccuracy() + "</font>   Evasion:<font color=\"FFFF00\"> " + targetp.getEvasionRate(null) + "</font><br>");
			replyMSG.append("Speed:<font color=\"FFFF00\"> " + targetp.getRunSpeed() + "</font>   Crit. Rate:<font color=\"FFFF00\"> " + targetp.getCriticalHit(null, null) + "</font><br>");
			replyMSG.append("Atk.Spd:<font color=\"FFFF00\"> " + targetp.getPAtkSpd() + "</font>   Casting Spd:<font color=\"FFFF00\"> " + targetp.getMAtkSpd() + "</font><br>");
			replyMSG.append("<img src=\"L2UI.SquareGray\" width=210 height=1>");
			replyMSG.append("</center></body></html>");
			adminReply.setHtml(replyMSG.toString());
			activeChar.sendPacket(adminReply);
			return true;
		}
		else if (command.startsWith("rank") && Config.ALLOW_RANKED_SYSTEM)
		{
			if (activeChar.getTarget() == null || !(activeChar.getTarget() instanceof L2PcInstance))
			{
				activeChar.sendPacket(SystemMessageId.INCORRECT_TARGET);
				return false;
			}
			showRankHtm(activeChar);
		}
		else if (command.startsWith("inventory") && Config.ALLOW_CMD_INVENTORY)
		{
			if (activeChar.getTarget() == null || !(activeChar.getTarget() instanceof L2PcInstance))
			{
				activeChar.sendPacket(SystemMessageId.INCORRECT_TARGET);
				return false;
			}
			L2PcInstance targetPlayer = ((L2Character) activeChar.getTarget()).getActingPlayer();
			activeChar.sendPacket(new GMViewItemList(targetPlayer));
			return true;
		}
		else if (command.startsWith("skills") && Config.ALLOW_CMD_SKILLS)
		{
			if (activeChar.getTarget() == null || !(activeChar.getTarget() instanceof L2PcInstance))
			{
				activeChar.sendPacket(SystemMessageId.INCORRECT_TARGET);
				return false;
			}
			L2PcInstance targetPlayer = ((L2Character) activeChar.getTarget()).getActingPlayer();
			activeChar.sendPacket(new GMViewSkillInfo(targetPlayer));
			return true;
		}
		else if (command.equalsIgnoreCase("charinfo")) 
		{
			showCharInfo(activeChar);
			return true;
		}
		
		return true;
	}

	private void showCharInfo(L2PcInstance activeChar) 
	{
		NpcHtmlMessage htm = new NpcHtmlMessage(0);
		htm.setFile("data/html/mods/CharInfo.htm");

		// --- L�GICA DO �CONE DIN�MICO ---
		String icon = "l2relicicon.etc_quest_subclass_reward_i00"; 
		Race race = activeChar.getRace();
		boolean isFemale = activeChar.getAppearance().getSex(); // true = female na aCis
		boolean isMage = activeChar.isMageClass();

		if (race == Race.Human) {
			if (isMage) icon = isFemale ? "l2relicicon.HumanMF" : "l2relicicon.HumanMM";
			else icon = isFemale ? "l2relicicon.HumanFF" : "l2relicicon.HumanFM";
		} else if (race == Race.DarkElf) {
			icon = isFemale ? "l2relicicon.DEIfF" : "l2relicicon.DEIfM";
		} else if (race == Race.Elf) {
			icon = isFemale ? "l2relicicon.ElfF" : "l2relicicon.ElfM";
		} else if (race == Race.Dwarf) {
			icon = isFemale ? "l2relicicon.DwarfF" : "l2relicicon.DwarfM";
		} else if (race == Race.Orc) {
			if (isMage) icon = isFemale ? "l2relicicon.OrcMF" : "l2relicicon.OrcMM";
			else icon = isFemale ? "l2relicicon.OrcFF" : "l2relicicon.OrcFM";
		}

		// --- L�GICA VIP ---
		boolean isVip = activeChar.isVip();
		String vTimeStr = "";
		if (isVip) {
			long duration = activeChar.getVipEndTime();
			long diff = duration - System.currentTimeMillis();
			
			if (diff > 0) {
				long dias = diff / 86400000;
				long horas = (diff % 86400000) / 3600000;
				vTimeStr = "<tr>"
						 + "<td width=17><img src=L2DeathBtns.right_arrow width=16 height=16></td>"
						 + "<td><font color=\"AE9977\">Restam:</font></td>"
						 + "<td align=right><font color=\"BBBBBB\">"
						 + (dias > 0 ? dias + "d " + horas + "h" : horas + "h")
						 + "</font></td>"
						 + "</tr>";
			} else {
				vTimeStr = "<tr>"
						 + "<td width=17><img src=L2DeathBtns.right_arrow width=16 height=16></td>"
						 + "<td><font color=\"AE9977\">Restam:</font></td>"
						 + "<td align=right><font color=\"BBBBBB\">Eterno</font></td>"
						 + "</tr>";
			}
		}
		
		// --- L�GICA HERO (Custom e Olympiad) ---
		boolean isHero = activeChar.isHero();
		String hTimeStr = "";
		String heroStatusStr = "<font color=\"FF4444\">Inativo</font>";

		if (isHero)
		{
		    heroStatusStr = "<font color=\"55FF55\">Ativo</font>";
		    long diff = 0;
		    String tipoHero = "";
		    
		    long customHeroEnd = activeChar.getTimedHeroEndTime();

		    if (customHeroEnd > System.currentTimeMillis())
		    {
		        diff = customHeroEnd - System.currentTimeMillis();
		        tipoHero = " (Item)";
		    }
		    else
		    {
		        Calendar cal = Calendar.getInstance();
		        int diaAtual = cal.get(Calendar.DAY_OF_MONTH);
		        
		        if (diaAtual < 15)
		        {
		            cal.set(Calendar.DAY_OF_MONTH, 15);
		        }
		        else
		        {
		            cal.add(Calendar.MONTH, 1);
		            cal.set(Calendar.DAY_OF_MONTH, 1);
		        }
		        
		        cal.set(Calendar.HOUR_OF_DAY, 12); 
		        cal.set(Calendar.MINUTE, 0);
		        cal.set(Calendar.SECOND, 0);
		        
		        diff = cal.getTimeInMillis() - System.currentTimeMillis();
		        tipoHero = " (Oly)";
		    }
		    
		    if (diff > 0)
		    {
		        long dias = diff / 86400000;
		        long horas = (diff % 86400000) / 3600000;
		        hTimeStr = "<tr>"
		                 + "<td width=17><img src=L2DeathBtns.right_arrow width=16 height=16></td>"
		                 + "<td><font color=\"AE9977\">Hero Resta" + tipoHero + ":</font></td>"
		                 + "<td align=right><font color=\"BBBBBB\">"
		                 + (dias > 0 ? dias + "d " + horas + "h" : horas + "h")
		                 + "</font></td>"
		                 + "</tr>";
		    }
		    else
		    {
		        hTimeStr = "<tr>"
		                 + "<td width=17><img src=L2DeathBtns.right_arrow width=16 height=16></td>"
		                 + "<td><font color=\"AE9977\">Hero Resta" + tipoHero + ":</font></td>"
		                 + "<td align=right><font color=\"BBBBBB\">Eterno</font></td>"
		                 + "</tr>";
		    }
		}
		
		// --- CRON�METRO DE SESS�O ---
		long s = 0;
		if (activeChar.getClient() != null)
		{
		    s = activeChar.getUptime() / 1000;
		}
		if (s < 0) s = 0;

		String session = String.format("%02d:%02d:%02d", (s / 3600), (s % 3600) / 60, (s % 60));
		
		// --- SUBSTITUI��O DOS VALORES NO HTML ---
		htm.replace("%icon%", icon);
		htm.replace("%name%", activeChar.getName());
		htm.replace("%className%", activeChar.getTemplate().getClassName());
		htm.replace("%noble%", activeChar.isNoble() ? "<font color=\"55FF55\">Sim</font>" : "<font color=\"FF4444\">N�o</font>");
		
		htm.replace("%vipStatus%", isVip ? "<font color=\"55FF55\">Ativo</font>" : "<font color=\"FF4444\">Inativo</font>");
		htm.replace("%vipTime%", vTimeStr);
		
		htm.replace("%heroStatus%", heroStatusStr);
		htm.replace("%heroTime%", hTimeStr);
		
		htm.replace("%pvp%", String.valueOf(activeChar.getPvpKills()));
		htm.replace("%deaths%", String.valueOf(activeChar.getDeaths()));
		htm.replace("%oly%", String.valueOf(Math.max(0, Olympiad.getInstance().getNoblePoints(activeChar.getObjectId()))));
		htm.replace("%dailyReward%",NewDailyRewardManager.getInstance().getDailyRewardStatusText(activeChar));
		htm.replace("%session%", session);

		activeChar.sendPacket(htm);
	}
	
	public static void showRankHtm(L2PcInstance player) 
	{
		String htmFile = "data/html/mods/menu/RankManager.htm";
		
		L2PcInstance targetPlayer = (L2PcInstance) player.getTarget();
		NpcHtmlMessage htm = new NpcHtmlMessage(0);
		htm.setFile(htmFile);
		
		htm.replace("%name%", targetPlayer.getName());
		htm.replace("%class%", targetPlayer.getTemplate().getClassName());
		htm.replace("%color%", targetPlayer.StringToHexForVote(Integer.toHexString(targetPlayer.getAppearance().getNameColor()).toUpperCase()));
		htm.replace("%elopoints%", String.valueOf(targetPlayer.getPcBangScore()));
		
		// Unranked
		if (targetPlayer.getPcBangScore() <= 249) 
		{
			htm.replace("%namerank%", "Unranked");
			htm.replace("%rank%", "<img src=\"Ranked.unranked\" width=\"70\" height=\"74\">");
			htm.replace("%bracket%", "<img src=\"customi.deco_up\" width=\"256\" height=\"32\">");
		}
		// Iron
		if (targetPlayer.getPcBangScore() >= 250 && targetPlayer.getPcBangScore() <= 299) 
		{
			htm.replace("%namerank%", "<font color=\"4c4c4c\">Iron I</font>");
			htm.replace("%rank%", "<img src=\"WzRanked.ferro1\" width=\"170\" height=\"100\">");
			htm.replace("%bracket%", "<img src=\"WzRanked.ironbreaker\" width=\"256\" height=\"68\">");
		}
		
		player.sendPacket(htm);
	}
	
	@Override
	public String[] getVoicedCommandList()
	{
		return VOICED_COMMANDS;
	}
}