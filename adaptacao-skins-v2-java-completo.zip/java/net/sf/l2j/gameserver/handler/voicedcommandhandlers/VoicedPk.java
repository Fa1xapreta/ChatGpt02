package net.sf.l2j.gameserver.handler.voicedcommandhandlers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Logger;
import java.util.stream.IntStream;

import net.sf.l2j.Config;
import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.handler.IVoicedCommandHandler;
import net.sf.l2j.gameserver.model.L2World;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;
import net.sf.l2j.util.StringUtil;

public class VoicedPk implements IVoicedCommandHandler
{
	public static final Logger _log = Logger.getLogger(VoicedPk.class.getName());
	
	private static final String[] VOICED_COMMANDS =
	{
		"rankingpk"
	};
	
	private static final StringBuilder PK = new StringBuilder();
	private static final int PAGE_LIMIT_15 = 15;
	private long _nextUpdate;
	
	@Override
	public boolean useVoicedCommand(String command, L2PcInstance activeChar, String target)
	{
		if (command.equals("rankingpk") && Config.ALLOW_CMD_PK)
			showPkList(activeChar);
		
		return true;
	}
	
	public void showPkList(L2PcInstance player)
	{
		if (_nextUpdate < System.currentTimeMillis())
		{
			PK.setLength(0);
			
			try (Connection con = L2DatabaseFactory.getInstance().getConnection())
			{
				try (PreparedStatement ps = con.prepareStatement("SELECT char_name, pkkills FROM characters WHERE pkkills > 0 ORDER BY pkkills DESC LIMIT " + PAGE_LIMIT_15);
	                   ResultSet rs = ps.executeQuery())
					{
					int index = 1;
					while (rs.next())
					{
						final String name = rs.getString("char_name");
						final L2PcInstance databasePlayer = L2World.getInstance().getPlayer(name);
						final String status = "L2UI_CH3.msnicon" + (databasePlayer != null && databasePlayer.isOnline() ? "1" : "4");
						
						StringUtil.append(PK, "<table width=290 bgcolor=000000><tr><td width=20 align=right>", getColor(index), String.format("%02d", index), "</td>");
						StringUtil.append(PK, "<td width=20 height=18><img src=", status, " width=16 height=16></td><td width=160 align=left>", name, "</td>");
						StringUtil.append(PK, "<td width=100 align=right>", StringUtil.formatNumber(rs.getInt("pkkills")), "</font></td></tr></table><img src=L2UI.SquareGray width=296 height=1>");
						index++;
					}
					IntStream.range(index - 1, PAGE_LIMIT_15).forEach(x -> applyEmpty(PK));
					}
			}
			catch (Exception e)
			{
				_log.warning("There was problem while updating ranking system." + e);
			}
			
			_nextUpdate = System.currentTimeMillis() + 60000L;
		}
		else
		{
			final NpcHtmlMessage html = new NpcHtmlMessage(0);
			html.setFile("data/html/mods/menu/pk.htm");
			html.replace("%pk%", PK.toString());
			html.replace("%name%", player.getName());
			html.replace("%time%", String.valueOf((_nextUpdate - System.currentTimeMillis()) / 1000));
			player.sendPacket(html);	
		}
	}
	
	
	protected void applyEmpty(StringBuilder sb)
	{
		sb.append("<table width=290 bgcolor=000000><tr>");
		sb.append("<td width=20 align=right><font color=B09878>--</font></td><td width=20 height=18></td>");
		sb.append("<td width=160 align=left><font color=B09878>----------------</font></td>");
		sb.append("<td width=100 align=right><font color=FF0000>0</font></td>");
		sb.append("</tr></table><img src=L2UI.SquareGray width=290 height=1>");
	}
	
	protected String getColor(int index)
	{
		switch (index)
		{
			case 1:
				return "<font color=FFFF00>";
			case 2:
				return "<font color=FFA500>";
			case 3:
				return "<font color=E9967A>";
		}
		return "";
	}
	
	@Override
	public String[] getVoicedCommandList()
	{
		return VOICED_COMMANDS;
	}
}