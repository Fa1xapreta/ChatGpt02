/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.handler.voicedcommandhandlers;

import java.text.DecimalFormat;
import java.util.StringTokenizer;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.datatables.NpcTable;
import net.sf.l2j.gameserver.datatables.custom.IconTable;
import net.sf.l2j.gameserver.handler.IVoicedCommandHandler;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.actor.template.NpcTemplate;
import net.sf.l2j.gameserver.model.item.DropCategory;
import net.sf.l2j.gameserver.model.item.DropData;
import net.sf.l2j.gameserver.model.item.kind.Item;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;
import net.sf.l2j.util.StringUtil;

/**
 * @author Designatix
 *
 */
public class ShiftClickToNpc implements IVoicedCommandHandler
{
	
	//private static final int PAGE_LIMIT = 20;
	
	private static String[] _voicedCommands =
	{
		"show_droplist"
	};
	
	@Override
	public boolean useVoicedCommand(String command, L2PcInstance activeChar, String target)
	{
		final StringTokenizer st = new StringTokenizer(command, " ");
		st.nextToken();
		
		if (command.startsWith("show_droplist"))
		{
			try
			{
				int npcId = Integer.parseInt(st.nextToken());
				int page = (st.hasMoreTokens()) ? Integer.parseInt(st.nextToken()) : 1;
				
				showNpcDropList(activeChar, npcId, page);
			}
			catch (Exception e)
			{
				activeChar.sendMessage("Usage: .show_droplist <npc_id> [<page>]");
			}
		}
		return true;
	}
	
	private static void showNpcDropList(L2PcInstance activeChar, int npcId, int page)
	{
		final NpcTemplate npcData = NpcTable.getInstance().getTemplate(npcId);
		if (npcData == null)
		{
			activeChar.sendMessage("Npc template is unknown for id: " + npcId + ".");
			return;
		}
		
		final StringBuilder sb = new StringBuilder(2000);
		StringUtil.append(sb, "<html><title>Droplist - ", npcData.getName(), "</title><body><br>");
		sb.append("<img src=L2UI.SquareWhite width=375 height=1>");
		
		if (!npcData.getDropData().isEmpty())
		{
			int myPage = 1;
			int i = 0;
			int shown = 0;
			boolean hasMore = false;
			
			for (DropCategory cat : npcData.getDropData())
			{
				if (shown == 8)
				{
					hasMore = true;
					break;
				}
				
				for (DropData drop : cat.getAllDrops())
				{
					int mind = 0, maxd = 0, enchmax = 0, enchmin = 0, enchsucess = 0;
					double chance = (double)drop.getChance() / 10000;
					
					mind = (int) (Config.RATE_DROP_ITEMS * drop.getMinDrop());
					maxd = (int) (Config.RATE_DROP_ITEMS * drop.getMaxDrop());
					
					enchmin = drop.getMinEnchant();
					enchmax = drop.getMaxEnchant();
					enchsucess = drop.getEnchantSucess();
					
					String smind = null, smaxd = null, drops = null;
					if (mind > 999999)
					{
						DecimalFormat df = new DecimalFormat("###.#");
						smind = df.format(((double)(mind))/1000000) + "KK";
						smaxd = df.format(((double)(maxd))/1000000) + "KK";
					}
					else if (mind > 999)
					{
						smind = (mind/1000) + "K";
						smaxd = (maxd/1000) + "K";
					}                                              
					else
					{
						smind = Integer.toString(mind);
						smaxd = Integer.toString(maxd);
					}
					
					if (chance <= 0.001)
					{
						DecimalFormat df = new DecimalFormat("#.####");
						drops = df.format(chance);
					}
					else if (chance <= 0.01)
					{
						DecimalFormat df = new DecimalFormat("#.###");
						drops = df.format(chance);
					}
					else
					{
						DecimalFormat df = new DecimalFormat("##.##");
						drops = df.format(chance);
					}
					
					Item item = ItemTable.getInstance().getTemplate(drop.getItemId());
					String name = item.getName();
					
					if (name.length() >= 25)
						name = name.substring(0, 20) + "...";
					
					if (myPage != page)
					{
						i++;
						if (i == 8)
						{
							myPage++;
							i = 0;
						}
						continue;
					}
					
					if (shown == 8)
					{
						hasMore = true;
						break;
					}
					
					sb.append("<table width=295 bgcolor=000000>");
					sb.append("<tr>");
					sb.append("<td align=left width=32><button width=32 height=32 back=" + IconTable.getIcon(item.getItemId()) + " fore=" + IconTable.getIcon(item.getItemId()) + "></td>");
					sb.append("<td align=left width=263>");
					sb.append("<table>");
					
					if (enchsucess == 0)
						sb.append("<tr><td align=left width=263>" + (cat.isSweep() ? "<font color=FF0099>Sweep Chance</font>" : "<font color=00FF00>Drop Chance</font>") + " : (" + drops + "%)</td></tr>");
					else
						sb.append("<tr><td align=left width=263>" + (cat.isSweep() ? "<font color=FF0099>Sweep Chance</font>" : "<font color=00FF00>Drop Chance</font>") + " : (" + drops + "%)<font color=FF0099> Enchant Chance</font> : (" + enchsucess + "%)</td></tr>");
					
					if (Config.NOT_SHOW_DROP_INFO.contains(Integer.valueOf(item.getItemId())))
					{
						if (enchmax == 0)
							sb.append("<tr><td align=left width=263><font color=F01E23>" + name + "</font></td></tr>");
						else
							sb.append("<tr><td align=left width=263><font color=F01E23>" + name + "</font> - Enchant Min: <font color=0CFFF9>+" + enchmin + "</font> Max: <font color=FF0C0C>+" + enchmax + "</font></td></tr>");
					}
					else
						sb.append("<tr><td align=left width=263><font color=F9FF00>" + name + "</font> - Min Drop: <font color=00ECFF>" + smind + "</font> Max Drop: <font color=FF0C0C>" + smaxd + "</font></td></tr>");
					
					sb.append("</table>");
					sb.append("</td>");
					sb.append("</tr>");
					sb.append("</table>");
					sb.append("<img src=l2ui.squaregray width=294 height=1>");
					shown++;
				}
			}
			
			if (shown == 1)
				sb.append("<img height=200>");
			
			if (shown == 2)
				sb.append("<img height=160>");
			
			if (shown == 3)
				sb.append("<img height=120>");
			
			if (shown == 4)
				sb.append("<img height=80>");
			
			if (shown == 5)
				sb.append("<img height=40>");
			
			sb.append("<img src=L2UI.SquareWhite width=300 height=1>");
			
			sb.append("<table><tr>");
			
			if (page > 1)
			{
				StringUtil.append(sb, "<td width=120><a action=\"bypass voiced_show_droplist ", npcId, " ", page - 1, "\">Prev Page</a></td>");
				if (!hasMore)
					StringUtil.append(sb, "<td width=100>Page ", page, "</td><td width=70></td></tr>");
			}
			
			if (page == 1 && !hasMore)
				sb.append("<td>Page " + page + "</td>");
			
			if (hasMore)
			{
				if (page <= 1)
					sb.append("<td width=120></td>");
				
				StringUtil.append(sb, "<td width=100>Page ", page, "</td><td width=70><a action=\"bypass voiced_show_droplist ", npcId, " ", page + 1, "\">Next Page</a></td></tr>");
			}
			sb.append("</tr></table>");
		}
		else
			sb.append("This NPC has no drops.");
		
		sb.append("</body></html>");
		
		final NpcHtmlMessage html = new NpcHtmlMessage(0);
		html.setHtml(sb.toString());
		activeChar.sendPacket(html);
	}
	
	@Override
	public String[] getVoicedCommandList()
	{
		return _voicedCommands;
	}
}