package net.sf.l2j.gameserver.handler.voicedcommandhandlers;

import net.sf.l2j.gameserver.custom.MileniumMonsterData;
import net.sf.l2j.gameserver.handler.IVoicedCommandHandler;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;

public final class VoicedMileniumMonsterData implements IVoicedCommandHandler
{
    @Override
    public boolean useVoicedCommand(String command, L2PcInstance player, String params)
    {
        if (!"monsterdata".equals(command) || player == null) return false;
        MileniumMonsterData.open(player);
        return true;
    }

    @Override
    public String[] getVoicedCommandList() { return new String[] {"monsterdata"}; }
}
