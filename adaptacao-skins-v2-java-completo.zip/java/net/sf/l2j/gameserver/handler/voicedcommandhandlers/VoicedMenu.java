/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.handler.voicedcommandhandlers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.StringTokenizer;

import net.sf.l2j.Config;
import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.GameServer;
import net.sf.l2j.gameserver.datatables.SkillTable;
import net.sf.l2j.gameserver.handler.IVoicedCommandHandler;
import net.sf.l2j.gameserver.instancemanager.PlayerModeManager;
import net.sf.l2j.gameserver.instancemanager.custom.TimeInstanceManager;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.antilag.AntilagController;
import net.sf.l2j.gameserver.model.entity.events.CheckNextEvent;
import net.sf.l2j.gameserver.model.entity.events.NftBossEvent;
import net.sf.l2j.gameserver.model.entity.events.SoloBossEvent;
import net.sf.l2j.gameserver.model.entity.events.PartyZoneEvent.PartyZoneTask;
import net.sf.l2j.gameserver.model.entity.events.Tyrannosaurus.TyrannosaurusTask;
import net.sf.l2j.gameserver.model.entity.events.capturetheflag.CTFConfig;
import net.sf.l2j.gameserver.model.entity.events.capturetheflag.CTFEvent;
import net.sf.l2j.gameserver.model.entity.events.deathmatch.DMConfig;
import net.sf.l2j.gameserver.model.entity.events.deathmatch.DMEvent;
import net.sf.l2j.gameserver.model.entity.events.fortress.FOSConfig;
import net.sf.l2j.gameserver.model.entity.events.fortress.FOSEvent;
import net.sf.l2j.gameserver.model.entity.events.killtheboss.KTBConfig;
import net.sf.l2j.gameserver.model.entity.events.killtheboss.KTBEvent;
import net.sf.l2j.gameserver.model.entity.events.lastman.LMConfig;
import net.sf.l2j.gameserver.model.entity.events.lastman.LMEvent;
import net.sf.l2j.gameserver.model.entity.events.multiteamvsteam.MultiTvTConfig;
import net.sf.l2j.gameserver.model.entity.events.multiteamvsteam.MultiTvTEvent;
import net.sf.l2j.gameserver.model.entity.events.teamvsteam.TvTConfig;
import net.sf.l2j.gameserver.model.entity.events.teamvsteam.TvTEvent;
import net.sf.l2j.gameserver.model.entity.events.toppvpevent.PvPEvent;
import net.sf.l2j.gameserver.model.entity.events.tournaments.properties.ArenaConfig;
import net.sf.l2j.gameserver.model.entity.events.tournaments.properties.ArenaTask;
import net.sf.l2j.gameserver.model.olympiad.Olympiad;
import net.sf.l2j.gameserver.model.zone.ZoneId;
import net.sf.l2j.gameserver.network.SystemMessageId;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;
import net.sf.l2j.gameserver.network.serverpackets.SystemMessage;
import net.sf.l2j.util.Rnd;
import net.sf.l2j.util.Util;

public class VoicedMenu implements IVoicedCommandHandler
{
	private static final String[] VOICED_COMMANDS = 
		{ 
		"menu",
		"info",
		"setPartyRefuse", 
		"setTradeRefuse", 
		"setMessageRefuse",
		"setAutoGoldBar",
		"setBuffPrevent",
		"eventTime",
		"hideSkinHelm",
		"hidegiran",
		"hideHeroAura",
		"hideEnchantGlow",
		"hideMsg",
		"showrepair",
		"allskills",
		"listSkills",
		"hideSoulShotAnim",
		"reduceCritical",
		"antilag",
		"showSkills",
		"hidepartyAura",
		"olym",
		"hideWeaponSkin",
		"timeleft",
		"market",
		"playerModeStatus",
		"playerModeNormal",
		"playerModePve",
		"playerModeHunter",
		"repair"
		};

	public static SimpleDateFormat date = new SimpleDateFormat("yyyy.MM.dd 'at' HH:mm:ss z");
	static long _daysleft;

	static long _minleft;
	static SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");

	@Override
	public boolean useVoicedCommand(String command, L2PcInstance activeChar, String target)
	{
		if (activeChar == null || command == null)
		{
		    return false;
		}

		if (PlayerModeManager.getInstance().handle(command, activeChar))
		{
		    return true;
		}
		
		AntilagController antilagController = activeChar.getAntilagController();
		switch (command) 
		{

		case "allskills":
			antilagController.toggle("hideAllSkillsAnim");
			showMenuHtml(activeChar);
			break;
		case "listSkills":
			antilagController.toggle("hideListSkillsAnim");
			showMenuHtml(activeChar);
			break;
		case "hideSoulShotAnim":
			antilagController.toggle("hideSoulShotAnim");
			showMenuHtml(activeChar);
			break;
		case "reduceCritical":
			antilagController.toggle("reduceCritical");
			showMenuHtml(activeChar);
			break;
		case "antilag":
			final boolean enableAntilag = !(antilagController.isHideEnchantGlow() && antilagController.isHideSoulShotAnim() && antilagController.isReduceCritical() && antilagController.isHideAllSkillsAnim());
			activeChar.setDisableGlowWeapon(enableAntilag);
			antilagController.set("hideSoulShotAnim", Boolean.valueOf(enableAntilag));
			antilagController.set("reduceCritical", Boolean.valueOf(enableAntilag));
			antilagController.set("hideAllSkillsAnim", Boolean.valueOf(enableAntilag));
			activeChar.broadcastUserInfoHiden();
			showMenuHtml(activeChar);
			break;
		case "showSkills":
			showSkillsPage(activeChar);
			return true;
		} 

		if (command.equals("timeleft"))
		{
			//if (Config.TIME_INSTANCE_SCREEN_MESSAGE)
			//	activeChar.sendPacket(new ExShowScreenMessage("You have " + TimeInstanceManager.getPlayerTime(activeChar) + " minutes left in Time Instance area.", 6000));  

			activeChar.sendMessage("You have " + TimeInstanceManager.getPlayerTime(activeChar) + " minutes left in Time Instance area.");
		}
		if (command.equals("menu"))
			showMenuHtml(activeChar);

//		if (command.equals("market"))
//			RequestBypassToServer.showAuctionHtml(activeChar);

		if (command.equals("olym"))
		{
			SystemMessage sm = SystemMessage.getSystemMessage(SystemMessageId.THE_CURRENT_RECORD_FOR_THIS_OLYMPIAD_SESSION_IS_S1_MATCHES_S2_WINS_S3_DEFEATS_YOU_HAVE_EARNED_S4_OLYMPIAD_POINTS);
			sm.addNumber(Olympiad.getInstance().getCompetitionDone(activeChar.getObjectId()));
			sm.addNumber(Olympiad.getInstance().getCompetitionWon(activeChar.getObjectId()));
			sm.addNumber(Olympiad.getInstance().getCompetitionLost(activeChar.getObjectId()));
			sm.addNumber(Olympiad.getInstance().getNoblePoints(activeChar.getObjectId()));
			activeChar.sendPacket(sm);
		}

		if (command.equals("eventTime") && Config.ALLOW_EVENTTIME_COMMANDS)
			showEventTimeHtml(activeChar); 

		if (command.equals("hidegiran"))
		{  
			if (!activeChar.isInsideZone(ZoneId.FAKE_ONLINE_ZONE)) 
			{
				activeChar.sendMessage("This command can only be used on Peace zone.");
				return false;
			} 

			if (!activeChar.isHideGiran())
			{
				activeChar.setHideGiran(true);
				activeChar.decayMe();
				activeChar.broadcastUserInfoHiden();
				activeChar.spawnMe();
			}
			else
			{
				activeChar.setHideGiran(false);
				activeChar.broadcastUserInfoHiden();
			}
			showMenuHtml(activeChar);
		}

		if (command.equals("hideWeaponSkin"))
		{        
			if (activeChar.isHideWepSkin())
			{
				activeChar.setHideWepSkin(false);
				activeChar.broadcastUserInfo();
				activeChar.broadcastUserInfoHiden();
			}
			else
			{
				activeChar.setHideWepSkin(true);
				activeChar.broadcastUserInfo();
				activeChar.broadcastUserInfoHiden();
			}
			showMenuHtml(activeChar);
		}

		if (command.equals("hideSkinHelm"))
		{
			if (activeChar.isHideSkinHelm())
				activeChar.setHideSkinHelm(false);
			else
				activeChar.setHideSkinHelm(true);

			activeChar.broadcastUserInfo();
			activeChar.broadcastUserInfoHiden();
			showMenuHtml(activeChar);
		}

		if (command.startsWith("info") && Config.ALLOW_INFO_COMMANDS)
		{
			int val = 0;
			try
			{
				val = Integer.parseInt(command.substring(5));
			}
			catch (IndexOutOfBoundsException ioobe)
			{
			}
			catch (NumberFormatException nfe)
			{
			}

			showInfoHtml(activeChar, val);   
		}
		if (command.equals("setPartyRefuse"))
		{
			if (activeChar.isPartyInRefuse())
				activeChar.setIsPartyInRefuse(false);
			else
				activeChar.setIsPartyInRefuse(true);            
			showMenuHtml(activeChar);
		}    
		if (command.equals("setTradeRefuse"))
		{
			if (activeChar.getTradeRefusal())
				activeChar.setTradeRefusal(false);
			else
				activeChar.setTradeRefusal(true);
			showMenuHtml(activeChar);
		}        
		if (command.equals("setMessageRefuse"))
		{        
			if (activeChar.isInRefusalMode())
				activeChar.setInRefusalMode(false);
			else
				activeChar.setInRefusalMode(true);
			showMenuHtml(activeChar);
		}
		
		if (command.equals("setBuffPrevent"))
		{
			if (activeChar.isBuffProtected())
				activeChar.setIsBuffProtected(false);
			else
				activeChar.setIsBuffProtected(true);            
			showMenuHtml(activeChar);
		}
		if (command.equals("hideHeroAura"))
		{        
			if (activeChar.isDisableHeroAura())
			{
				activeChar.setDisableHeroAura(false);
				activeChar.broadcastUserInfoHiden();
			}
			else
			{
				activeChar.setDisableHeroAura(true);
				activeChar.broadcastUserInfoHiden();
			}
			showMenuHtml(activeChar);
		}
		if (command.equals("hideEnchantGlow"))
		{        
			if (activeChar.isDisableGlowWeapon())
			{
				activeChar.setDisableGlowWeapon(false);
				activeChar.broadcastUserInfoHiden();
			}
			else
			{
				activeChar.setDisableGlowWeapon(true);
				activeChar.broadcastUserInfoHiden();
			}
			showMenuHtml(activeChar);
		}
		if (command.equals("hidepartyAura"))
		{
			activeChar.setDisablepartyAura(!activeChar.isDisablepartyAura());
			activeChar.broadcastUserInfoHiden();
			showMenuHtml(activeChar);
		}
		if (command.equals("hideMsg"))
		{ 
			if (activeChar.isHideMsg())
			{
				activeChar.setHideMsg(false);
				activeChar.broadcastUserInfoHiden();
			}
			else
			{
				activeChar.setHideMsg(true);
				activeChar.broadcastUserInfoHiden();
			}
			showMenuHtml(activeChar);
		}
		if (command.startsWith("repair"))
		{
			showRepairWindow(activeChar);
		}
		if (command.startsWith("showrepair"))
		{
			if (command.equals("showrepair")) 
			{
				activeChar.sendMessage("Please first select character to be repaired.");
				return false;
			} 

			StringTokenizer st = new StringTokenizer(command);
			st.nextToken();
			String repairChar = st.nextToken();

			if (repairChar == null || repairChar.equals(""))
			{
				activeChar.sendMessage("Please first select character to be repaired.");
				return false;
			} 

			if (checkAcc(activeChar, repairChar)) 
			{
				if (checkChar(activeChar, repairChar)) 
				{
					activeChar.sendMessage("You cannot repair your self.");
					return false;
				} 

				repairBadCharacter(repairChar);
				NpcHtmlMessage html = new NpcHtmlMessage(0);
				html.setFile("data/html/mods/menu/Repaired.htm");
				activeChar.sendPacket(html);
			}
			else 
			{
				activeChar.sendMessage("Something went wrong. Please contact with the server's administrator.");
				return false;
			} 
		}
		return true;
	}

	private static void showRepairWindow(L2PcInstance activeChar)
	{
		NpcHtmlMessage html = new NpcHtmlMessage(0);
		html.setFile("data/html/mods/menu/repair.htm");
		html.replace("%acc_chars%", getCharList(activeChar));
		activeChar.sendPacket(html);
	}

	public static void showMenuHtml(L2PcInstance activeChar)
	{
		AntilagController antilagController = activeChar.getAntilagController();
		NpcHtmlMessage html = new NpcHtmlMessage(0);
		html.setFile("data/html/mods/menu/Menu.htm");
		// Reuse the old PvP Msg slot for Wide Aura without requiring a datapack HTML edit.
		html.replace("(?i)PvP\\s*Msg", "Wide Aura");
		html.replace("voiced_hideMsg", "voiced_hidepartyAura");
		// The old PvP Msg state token now shows whether Wide Aura is enabled.
		html.replace("%hideMsgLetter%", activeChar.isDisablepartyAura() ? "unable" : "checked");
		html.replace("%wideAuraLetter%", activeChar.isDisablepartyAura() ? "unable" : "checked");
		html.replace("%acc_chars%", getCharList(activeChar));
		html.replace("%setAutoGoldBar%", activeChar.isAutoGB() ? "checked" : "unable");
		html.replace("%hideGiran%", activeChar.isHideGiran() ? "checked" : "unable");
		html.replace("%HideWepSkin%", activeChar.isHideWepSkin() ? "checked" : "unable");
		html.replace("%HideSkinHelm%", activeChar.isHideSkinHelm() ? "unable" : "checked");
		html.replace("%btn_skins%", "<button value=\"Preview\" action=\"bypass -h voiced_skinpreview 0\" width=85 height=20 back=\"L2UI_CH3.bigbutton2_down\" fore=\"L2UI_CH3.bigbutton2\">");
		html.replace("%hideEnchantGlowLetter%", antilagController.isHideEnchantGlow() ? "checked" : "unable");
		html.replace("%hidepartyAuraLetter%", activeChar.isDisablepartyAura() ? "checked" : "unable");
		html.replace("%hideHeroAuraLetter%", activeChar.isDisableHeroAura() ? "checked" : "unable");
		html.replace("%allSkillsAnimState%", antilagController.isHideAllSkillsAnim() ? "checked" : "unable");
		html.replace("%listSkillsAnimState%", antilagController.isHideListSkillsAnim() ? "checked" : "unable");
		html.replace("%soulShotAnimState%", antilagController.isHideSoulShotAnim() ? "checked" : "unable");
		html.replace("%reduceCriticalState%", antilagController.isReduceCritical() ? "checked" : "unable");
		html.replace("%antilagState%", (antilagController.isHideEnchantGlow() && antilagController.isHideSoulShotAnim() && antilagController.isReduceCritical() && antilagController.isHideAllSkillsAnim()) ? "checked" : "unable");
		html.replace("%messageBuffLetter%", activeChar.isBuffProtected() ? "checked" : "unable");
		html.replace("%messageRefusalLetter%", activeChar.isInRefusalMode() ? "checked" : "unable");
		html.replace("%tradeRefusalLetter%", activeChar.getTradeRefusal() ? "checked" : "unable");
		html.replace("%partyRefusalLetter%", activeChar.isPartyInRefuse() ? "checked" : "unable");
		html.replace("%server_restarted%", String.valueOf(GameServer.dateTimeServerStarted.getTime()));
		html.replace("%server_os%", String.valueOf(System.getProperty("os.name")));
		html.replace("%server_free_mem%", String.valueOf((Runtime.getRuntime().maxMemory()-Runtime.getRuntime().totalMemory()+Runtime.getRuntime().freeMemory()) / 1048576));
		html.replace("%server_total_mem%", String.valueOf(Runtime.getRuntime().totalMemory() / 1048576));
		html.replace("%date%", Util.formatDate(new Date(), "dd/MM"));
		html.replace("%hour%", Util.formatDate(new Date(), "H:mm"));
		html.replace("%seeagathion%",  activeChar.canSeeAgathions() ? "checked" : "unable");
		
		if (activeChar.isNoble())
			html.replace("%noble%", "<font color=00FF00>YES</font>");
		else
			html.replace("%noble%", "<font color=00FF00>NO</font>");
		
		long now = Calendar.getInstance().getTimeInMillis();
		long endDay = activeChar.getVipEndTime();
		if(now > endDay)
		{
			html.replace("%vip%", "<font color=00FF00>NO</font>");
		}
		else
		{
			Date dt = new Date(endDay);
			_minleft = (endDay - now)/60000;
			_daysleft = (endDay - now)/86400000;

			if (_daysleft > 30)
			html.replace("%vip%", "<font color=00FF00>" + df.format(dt) + "</font>");
			else if (_daysleft > 0)

			html.replace("%vip%", "<font color=00FF00>"+ (int)_daysleft +" days.</font>");
			else if (_daysleft < 1 && _minleft > 60)
			{
				long hour = (endDay - now)/3600000;
				html.replace("%vip%", "<font color=00FF00>"+(int)hour+" hours.</font>");
			}
			else if (_minleft < 60)
			{
				long minutes = (endDay - now)/60000;
				html.replace("%vip%", "<font color=00FF00>"+(int)minutes+" min.</font>");
			}
		}
			
		activeChar.sendPacket(html);
	}

	private static void showInfoHtml(L2PcInstance activeChar, int val)
	{
		NpcHtmlMessage html = new NpcHtmlMessage(0);
		html.setFile("data/html/mods/menu/server/Page-"+ val +".htm"); 
		html.replace("%server_restarted%", String.valueOf(GameServer.dateTimeServerStarted.getTime()));
		html.replace("%server_os%", String.valueOf(System.getProperty("os.name")));
		html.replace("%server_free_mem%", String.valueOf((Runtime.getRuntime().maxMemory()-Runtime.getRuntime().totalMemory()+Runtime.getRuntime().freeMemory()) / 1048576));
		html.replace("%server_total_mem%", String.valueOf(Runtime.getRuntime().totalMemory() / 1048576));
		html.replace("%rate_xp%", String.valueOf(Config.RATE_XP));
		html.replace("%rate_sp%", String.valueOf(Config.RATE_SP));
		html.replace("%rate_party_xp%", String.valueOf(Config.RATE_PARTY_XP));
		html.replace("%rate_adena%", String.valueOf(Config.RATE_DROP_ADENA));
		html.replace("%rate_party_sp%", String.valueOf(Config.RATE_PARTY_SP));
		html.replace("%rate_items%", String.valueOf(Config.RATE_DROP_ITEMS));
		html.replace("%rate_spoil%", String.valueOf(Config.RATE_DROP_SPOIL));
		html.replace("%rate_drop_manor%", String.valueOf(Config.RATE_DROP_MANOR));
		html.replace("%pet_rate_xp%", String.valueOf(Config.PET_XP_RATE));
		html.replace("%sineater_rate_xp%", String.valueOf(Config.SINEATER_XP_RATE));
		html.replace("%pet_food_rate%", String.valueOf(Config.PET_FOOD_RATE));
		activeChar.sendPacket(html);
	}

	public static void showEventTimeHtml(L2PcInstance activeChar)
	{
		NpcHtmlMessage html = new NpcHtmlMessage(0);
		html.setFile("data/html/mods/menu/EventTime.htm");

		if (Config.PVP_EVENT_ENABLED)
		{
			if(PvPEvent.getInstance().isActive())
			{
				html.replace("%pvpTime%", "<font color=00FF00>Event in progress</font>");
			}
			else
			{
				html.replace("%pvpTime%", CheckNextEvent.getInstance().getNextPvPTime());
			}
		}
		if (Config.SOLO_BOSS_EVENT)
		{
				html.replace("%soloboss%", SoloBossEvent.getInstance().getNextTime());
		}
		if (Config.NFT_BOSS_EVENT)
		{
				html.replace("%nftboss%", NftBossEvent.getInstance().getNextTime());
		}
		if (TvTConfig.TVT_EVENT_ENABLED)
		{
			if (TvTEvent.isParticipating() || TvTEvent.isStarted())
			{
				html.replace("%tvtTime%", "<font color=00FF00>Event in progress</font>");
			}
			else
			{
				html.replace("%tvtTime%", CheckNextEvent.getInstance().getNextTvTTime());
			}
		}
		if (MultiTvTConfig.MULTI_TVT_EVENT_ENABLED)
		{
			if (MultiTvTEvent.isParticipating() || MultiTvTEvent.isStarted())
			{
				html.replace("%mtvtTime%", "<font color=00FF00>Event in progress</font>");
			}
			else
			{
				html.replace("%mtvtTime%", CheckNextEvent.getInstance().getNextMultiTvTTime());
			}
		}
		if (CTFConfig.CTF_EVENT_ENABLED)
		{
			if (CTFEvent.isParticipating() || CTFEvent.isStarted())
			{
				html.replace("%ctfTime%", "<font color=00FF00>Event in progress</font>");
			}
			else
			{
				html.replace("%ctfTime%", CheckNextEvent.getInstance().getNextCTFTime());
			}
		}
		if (DMConfig.DM_EVENT_ENABLED)
		{
			if (DMEvent.isParticipating() || DMEvent.isStarted())
			{
				html.replace("%dmTime%", "<font color=00FF00>Event in progress</font>");
			}
			else
			{
				html.replace("%dmTime%", CheckNextEvent.getInstance().getNextDMTime());
			}
		}
		if (LMConfig.LM_EVENT_ENABLED)
		{
			if (LMEvent.isParticipating() || LMEvent.isStarted())
			{
				html.replace("%lmTime%", "<font color=00FF00>Event in progress</font>");
			}
			else
			{
				html.replace("%lmTime%", CheckNextEvent.getInstance().getNextLMTime());
			}
		}
		if (FOSConfig.FOS_EVENT_ENABLED)
		{
			if (FOSEvent.isParticipating() || FOSEvent.isStarted())
			{
				html.replace("%fosTime%", "<font color=00FF00>Event in progress</font>");
			}
			else
			{
				html.replace("%fosTime%", CheckNextEvent.getInstance().getNextFOSTime());
			}
		}
		if (Config.START_AUTO_PARTY)
		{
			if (PartyZoneTask.is_started())
			{
				html.replace("%PartyZone%", "<font color=00FF00>Event in progress</font>");
			}
			else
			{
				html.replace("%PartyZone%", CheckNextEvent.getInstance().getNextPartyZoneTime());
			}
		}
		if (Config.START_AUTO_LS)
		{
			if (TyrannosaurusTask.is_started())
			{
				html.replace("%TyrannosaurusZone%", "<font color=00FF00>Event in progress</font>");
			}
			else
			{
				html.replace("%TyrannosaurusZone%", CheckNextEvent.getInstance().getNextTyrannosaurusZoneTime());
			}
		}
		if (KTBConfig.KTB_EVENT_ENABLED)
		{
			if (KTBEvent.isParticipating() || KTBEvent.isStarted())
			{
				html.replace("%ktbTime%", "<font color=00FF00>Event in progress</font>");
			}
			else
			{
				html.replace("%ktbTime%", CheckNextEvent.getInstance().getNextKTBTime());
			}
		}
		if (ArenaConfig.TOURNAMENT_EVENT_TIME)
		{
			if (ArenaTask.is_started())
			{
				html.replace("%tourTime%", "<font color=00FF00>Event in progress</font>");
			}
			else
			{
				html.replace("%tourTime%", CheckNextEvent.getInstance().getNextTournamentTime());
			}
		}

		activeChar.sendPacket(html);
	}

	private static String getCharList(L2PcInstance activeChar) 
	{
		String result = "";
		String repCharAcc = activeChar.getAccountName();
		Connection con = null;
		try
		{
			con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement statement = con.prepareStatement("SELECT char_name FROM characters WHERE account_name=?");
			statement.setString(1, repCharAcc);
			ResultSet rset = statement.executeQuery();
			while (rset.next()) 
			{
				if (activeChar.getName().compareTo(rset.getString(1)) != 0)
					result = result + rset.getString(1) + ";"; 
			} 
			rset.close();
			statement.close();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
			return result;
		}
		finally 
		{
			try 
			{
				if (con != null)
					con.close(); 
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			} 
		} 
		return result;
	}

	private static boolean checkAcc(L2PcInstance activeChar, String repairChar) 
	{
		boolean result = false;
		String repCharAcc = "";
		Connection con = null;
		try 
		{
			con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement statement = con.prepareStatement("SELECT account_name FROM characters WHERE char_name=?");
			statement.setString(1, repairChar);
			ResultSet rset = statement.executeQuery();

			if (rset.next())
				repCharAcc = rset.getString(1); 

			rset.close();
			statement.close();
			try 
			{
				if (con != null)
					con.close(); 

			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			} 

			if (activeChar.getAccountName().compareTo(repCharAcc) != 0)
				return result; 
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
			return result;
		} 
		finally 
		{
			try 
			{
				if (con != null)
					con.close(); 

			} 
			catch (SQLException e)
			{
				e.printStackTrace();
			} 
		} 
		result = true;
		return result;
	}

	private static boolean checkChar(L2PcInstance activeChar, String repairChar)
	{
		boolean result = false;

		if (activeChar.getName().compareTo(repairChar) == 0)
			result = true; 

		return result;
	}

	private static void repairBadCharacter(String charName) 
	{
		Connection con = null;
		try 
		{
			con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement statement = con.prepareStatement("SELECT obj_Id FROM characters WHERE char_name=?");
			statement.setString(1, charName);
			ResultSet rset = statement.executeQuery();
			int objId = 0;

			if (rset.next())
				objId = rset.getInt(1); 

			rset.close();
			statement.close();
			if (objId == 0)
			{
				con.close();
				return;
			} 
			statement = con.prepareStatement("UPDATE characters SET x=82698, y=148638, z=-3468 WHERE obj_Id=?");
			statement.setInt(1, objId);
			statement.execute();
			statement.close();

			statement = con.prepareStatement("UPDATE items SET loc='INVENTORY' WHERE owner_id=? AND loc='PAPERDOLL'");
			statement.setInt(1, objId);
			statement.execute();
			statement.close();
			return;
		}
		catch (Exception e)
		{
			System.out.println("GameServer: could not repair character:" + e);
		}
		finally
		{
			try 
			{
				if (con != null)
					con.close();
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			} 
		} 
	}

	private static void showSkillsPage(L2PcInstance player)
	{
		NpcHtmlMessage html = new NpcHtmlMessage(0);
		html.setFile("data/html/mods/menu/blockskills.htm");
		StringBuilder tb = new StringBuilder();
		tb.append("<table align=center width=290>");
		for (Iterator<Integer> iterator = Config.MSU_LIST_FOR_HIDE.iterator(); iterator.hasNext(); )
		{
			int skillId = ((Integer)iterator.next()).intValue();
			tb.append("<tr><td><font color=LEVEL>ID:</font> " + SkillTable.getInstance().getInfo(skillId, 1).getId() + " - <font color=LEVEL>Skill Name:</font> " + SkillTable.getInstance().getInfo(skillId, 1).getName() + "</font></td></tr>");
		} 
		tb.append("</table>");
		html.replace("%skills%", tb.toString().substring(0, tb.toString().length() - 2));
		player.sendPacket(html);
	}

	public static void FarmRandomTeleport_2(L2PcInstance activeChar, VoicedMenu voicedMenu)
	{
		switch (Rnd.get(8))
		{
		case 0:
		{
			int x = 145896 + Rnd.get(50);
			int y = -112411 + Rnd.get(50);
			activeChar.teleToLocation(x, y, -2457, 0);
			break;
		}
		case 1:
		{
			int x = 150882 + Rnd.get(50);
			int y = -115125 + Rnd.get(50);
			activeChar.teleToLocation(x, y, -1633, 0);
			break;
		}
		case 2:
		{
			int x = 157208 + Rnd.get(50);
			int y = -115981 + Rnd.get(50);
			activeChar.teleToLocation(x, y, -1885, 0);
			break;
		}
		case 3:
		{
			int x = 153353 + Rnd.get(50);
			int y = -110645 + Rnd.get(50);
			activeChar.teleToLocation(x, y, -2641, 0);
			break;
		}
		case 4:
		{
			int x = 154010 + Rnd.get(50);
			int y = -105289 + Rnd.get(50);
			activeChar.teleToLocation(x, y, -2751, 0);
			break;
		}
		case 5:
		{
			int x = 149870 + Rnd.get(50);
			int y = -110835 + Rnd.get(50);
			activeChar.teleToLocation(x, y, -2250, 0);
			break;
		}
		case 6:
		{
			int x = 144770 + Rnd.get(50);
			int y = -108670 + Rnd.get(50);
			activeChar.teleToLocation(x, y, -3462, 0);
			break;
		}
		case 7:
		{
			int x = 144428 + Rnd.get(50);
			int y = -102793 + Rnd.get(50);
			activeChar.teleToLocation(x, y, -3539, 0);
			break;
		}
		}
	}

	public static void FarmRandomTeleport_3(L2PcInstance activeChar, VoicedMenu voicedMenu)
	{
		switch (Rnd.get(8))
		{
		case 0:
		{
			int x = -16416 + Rnd.get(50);
			int y = -50003 + Rnd.get(50);
			activeChar.teleToLocation(x, y, -10917, 0);
			break;
		}
		case 1:
		{
			int x = -16383 + Rnd.get(50);
			int y = -47902 + Rnd.get(50);
			activeChar.teleToLocation(x, y, -10821, 0);
			break;
		}
		case 2:
		{
			int x = -16375 + Rnd.get(50);
			int y = -45781 + Rnd.get(50);
			activeChar.teleToLocation(x, y, -10725, 0);
			break;
		}
		case 3:
		{
			int x = -16359 + Rnd.get(50);
			int y = -38781 + Rnd.get(50);
			activeChar.teleToLocation(x, y, -10725, 0);
			break;
		}
		case 4:
		{
			int x = -12905 + Rnd.get(50);
			int y = -45623 + Rnd.get(50);
			activeChar.teleToLocation(x, y, -10720, 0);
			break;
		}
		case 5:
		{
			int x = -19870 + Rnd.get(50);
			int y = -45610 + Rnd.get(50);
			activeChar.teleToLocation(x, y, -10720, 0);
			break;
		}
		case 6:
		{
			int x = -14462 + Rnd.get(50);
			int y = -46589 + Rnd.get(50);
			activeChar.teleToLocation(x, y, -10816, 0);
			break;
		}
		case 7:
		{
			int x = -18349 + Rnd.get(50);
			int y = -46582 + Rnd.get(50);
			activeChar.teleToLocation(x, y, -10816, 0);
			break;
		}
		}
	}

	@Override
	public String[] getVoicedCommandList()
	{
		return VOICED_COMMANDS;
	}
}



