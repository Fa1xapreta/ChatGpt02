/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.handler.itemhandlers.custom.special;

import net.sf.l2j.gameserver.handler.IItemHandler;
import net.sf.l2j.gameserver.model.actor.L2Playable;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.network.serverpackets.ActionFailed;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;

/**
 * Item handler that allows a clan leader to rename their clan.
 * Opens an HTML dialog with a text field. The rename is processed
 * via the "clan_name_change" bypass in RequestBypassToServer.
 */
public class ClanNameChange implements IItemHandler
{
	@Override
	public void useItem(L2Playable playable, ItemInstance item, boolean forceUse)
	{
		if (!(playable instanceof L2PcInstance))
			return;

		final L2PcInstance activeChar = (L2PcInstance) playable;

		if (activeChar.getClan() == null)
		{
			activeChar.sendMessage("You must be in a clan to use this item.");
			return;
		}

		if (!activeChar.isClanLeader())
		{
			activeChar.sendMessage("Only the clan leader can rename the clan.");
			return;
		}

		if (activeChar.isInOlympiadMode())
		{
			activeChar.sendMessage("This item cannot be used in the Olympiad.");
			return;
		}

		// Store the item id so the bypass can consume it later
		activeChar.setNameChangeItemId(item.getItemId());

		final NpcHtmlMessage html = new NpcHtmlMessage(0);
		html.setFile("data/html/mods/ClanNameChange.htm");
		activeChar.sendPacket(html);
		activeChar.sendPacket(ActionFailed.STATIC_PACKET);
	}
}
