
package net.sf.l2j.gameserver.handler.itemhandlers;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.handler.IItemHandler;
import net.sf.l2j.gameserver.model.Certification.CertificationHandler;
import net.sf.l2j.gameserver.model.actor.L2Playable;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;

/**
 * @author FA1XAPRET4
 */
public class CertificationItemHandler implements IItemHandler
{
    @Override
    public void useItem(L2Playable playable, ItemInstance item, boolean forceUse)
    {
        // Verifica se o objeto � um jogador
        if (!(playable instanceof L2PcInstance))
            return;

        L2PcInstance player = (L2PcInstance) playable;
        int itemId = item.getItemId();

        // Tenta aplicar a certifica��o
        if (CertificationHandler.getInstance().tryApplyCertification(player, itemId))
        {
            player.destroyItem("Certification", item.getObjectId(), 1, player, true);
        }
    }

    public int[] getItemIds()
    {
        return Config.CERTIFICATION_ITEM_IDS;
    }
}
