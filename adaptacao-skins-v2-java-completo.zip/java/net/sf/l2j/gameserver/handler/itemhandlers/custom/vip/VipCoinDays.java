package net.sf.l2j.gameserver.handler.itemhandlers.custom.vip;

import net.sf.l2j.gameserver.datatables.custom.VipAuditLog;
import net.sf.l2j.gameserver.handler.IItemHandler;
import net.sf.l2j.gameserver.model.actor.L2Playable;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.network.serverpackets.EtcStatusUpdate;
import net.sf.l2j.gameserver.network.serverpackets.SocialAction;

public class VipCoinDays implements IItemHandler
{
	private final int VIP_2DAYS = 2;
	private final int VIP_7DAYS = 7;
	private final int VIP_15DAYS = 15;
	private final int VIP_30DAYS = 30;
	private final int VIP_90DAYS = 90;
	private final int VIP_LIFETIME = 36500;

	@Override
	public void useItem(L2Playable playable, ItemInstance item, boolean forceUse)
	{
		if (!(playable instanceof L2PcInstance))
			return;

		L2PcInstance activeChar = (L2PcInstance)playable;

		int itemId = item.getItemId();

		if (itemId == 10503) // 30 days
		{			
			if (activeChar.isInOlympiadMode())
			{
				activeChar.sendMessage("This item cannot be used on olympiad games.");
				return;
			}

			if (activeChar.isVip())
			{
				activeChar.sendMessage("You are already a VIP member.");
				return;
			}

			if (activeChar.destroyItem("Consume", item.getObjectId(), 1, null, false))
			{

				activeChar.setVip(true);
				VipAuditLog.setContext("ITEM_10503_30_DAYS_START");
				activeChar.setEndTime("vip", 30);
				activeChar.sendMessage("Congrats, you just became VIP per " + VIP_30DAYS + ".");
				activeChar.broadcastUserInfo();
				activeChar.sendPacket(new EtcStatusUpdate(activeChar));
			}
		}
		
		if (itemId == 20447) // 30 days
		{			
			if (activeChar.isInOlympiadMode())
			{
				activeChar.sendMessage("This item cannot be used on olympiad games.");
				return;
			}

			if (activeChar.isVip())
			{
				activeChar.sendMessage("You are already a VIP member.");
				return;
			}

			if (activeChar.destroyItem("Consume", item.getObjectId(), 1, null, false))
			{

				activeChar.setVip(true);
				VipAuditLog.setContext("ITEM_20447_30_DAYS_START");
				activeChar.setEndTime("vip", 30);
				activeChar.sendMessage("Congrats, you just became VIP per " + VIP_30DAYS + ".");
				activeChar.broadcastUserInfo();
				activeChar.sendPacket(new EtcStatusUpdate(activeChar));
			}
		}

		if (itemId == 9568) // 90 days
		{			
			if (activeChar.isInOlympiadMode())
			{
				activeChar.sendMessage("This item cannot be used on olympiad games.");
				return;
			}

			if (activeChar.isVip())
			{
				activeChar.sendMessage("You are already a VIP member.");
				return;
			}

			if (activeChar.destroyItem("Consume", item.getObjectId(), 1, null, false))
			{
				activeChar.setVip(true);
				VipAuditLog.setContext("ITEM_9568_90_DAYS_START");
				activeChar.setEndTime("vip", 90);
				activeChar.sendMessage("Congrats, you just became VIP per " + VIP_90DAYS + ".");
				activeChar.broadcastUserInfo();
				activeChar.sendPacket(new EtcStatusUpdate(activeChar));
			}
		}

		if (itemId == 10005) // Eternal
		{
			if (activeChar.isInOlympiadMode())
			{
				activeChar.sendMessage("This item cannot be used on olympiad games.");
				return;
			}

			if (activeChar.isVip())
			{
				activeChar.sendMessage("You are already a VIP member.");
				return;
			}

			if (activeChar.destroyItem("Consume", item.getObjectId(), 1, null, false))
			{
				activeChar.broadcastPacket(new SocialAction(activeChar, 15));
				activeChar.setVip(true);
				VipAuditLog.setContext("ITEM_10005_LIFETIME");
				activeChar.setEndTime("vip", VIP_LIFETIME);
				activeChar.sendMessage("You became a lifetime VIP member.");

				activeChar.broadcastUserInfo();
				activeChar.sendPacket(new EtcStatusUpdate(activeChar));
			}
		}
		
		if (itemId == 20448) // Eternal
		{
			if (activeChar.isInOlympiadMode())
			{
				activeChar.sendMessage("This item cannot be used on olympiad games.");
				return;
			}

			if (activeChar.isVip())
			{
				activeChar.sendMessage("You are already a VIP member.");
				return;
			}

			if (activeChar.destroyItem("Consume", item.getObjectId(), 1, null, false))
			{
				activeChar.broadcastPacket(new SocialAction(activeChar, 15));
				activeChar.setVip(true);
				VipAuditLog.setContext("ITEM_20448_LIFETIME");
				activeChar.setEndTime("vip", VIP_LIFETIME);
				activeChar.sendMessage("You became a lifetime VIP member.");

				activeChar.broadcastUserInfo();
				activeChar.sendPacket(new EtcStatusUpdate(activeChar));
			}
		}

		if (itemId == 10500) // 7 Days
		{			
			if (activeChar.isInOlympiadMode())
			{
				activeChar.sendMessage("This item cannot be used on olympiad games.");
				return;
			}

			if (activeChar.isVip())
			{
				activeChar.sendMessage("You are already a VIP member.");
				return;
			}

			if (activeChar.destroyItem("Consume", item.getObjectId(), 1, null, false))
			{

				activeChar.setVip(true);
				VipAuditLog.setContext("ITEM_10500_7_DAYS_START");
				activeChar.setEndTime("vip", 7);
				activeChar.sendMessage("Congrats, you just became VIP per " + VIP_7DAYS + ".");
				activeChar.broadcastUserInfo();
				activeChar.sendPacket(new EtcStatusUpdate(activeChar));
			}
		}
		
		if (itemId == 20450) // 7 Days
		{			
			if (activeChar.isInOlympiadMode())
			{
				activeChar.sendMessage("This item cannot be used on olympiad games.");
				return;
			}

			if (activeChar.isVip())
			{
				activeChar.sendMessage("You are already a VIP member.");
				return;
			}

			if (activeChar.destroyItem("Consume", item.getObjectId(), 1, null, false))
			{

				activeChar.setVip(true);
				VipAuditLog.setContext("ITEM_20450_7_DAYS_START");
				activeChar.setEndTime("vip", 7);
				activeChar.sendMessage("Congrats, you just became VIP per " + VIP_7DAYS + ".");
				activeChar.broadcastUserInfo();
				activeChar.sendPacket(new EtcStatusUpdate(activeChar));
			}
		}

		if (itemId == 10502) // 2 Days
		{			
			if (activeChar.isInOlympiadMode())
			{
				activeChar.sendMessage("This item cannot be used on olympiad games.");
				return;
			}

			if (activeChar.isVip())
			{
				activeChar.sendMessage("You are already a VIP member.");
				return;
			}

			if (activeChar.destroyItem("Consume", item.getObjectId(), 1, null, false))
			{

				activeChar.setVip(true);
				VipAuditLog.setContext("ITEM_10502_2_DAYS_START");
				activeChar.setEndTime("vip", 2);
				activeChar.sendMessage("Congrats, you just became VIP per " + VIP_2DAYS + ".");
				activeChar.broadcastUserInfo();
				activeChar.sendPacket(new EtcStatusUpdate(activeChar));
			}
		}

		if (itemId == 10004) // 15 Days
		{			
			if (activeChar.isInOlympiadMode())
			{
				activeChar.sendMessage("This item cannot be used on olympiad games.");
				return;
			}

			if (activeChar.isVip())
			{
				activeChar.sendMessage("You are already a VIP member.");
				return;
			}

			if (activeChar.destroyItem("Consume", item.getObjectId(), 1, null, false))
			{
				activeChar.setVip(true);
				VipAuditLog.setContext("ITEM_10004_15_DAYS_START");
				activeChar.setEndTime("vip", 15);
				activeChar.sendMessage("Congrats, you just became VIP per " + VIP_15DAYS + ".");
				activeChar.broadcastUserInfo();
				activeChar.sendPacket(new EtcStatusUpdate(activeChar));
			}
		}
		
		if (itemId == 20446) // 15 Days
		{			
			if (activeChar.isInOlympiadMode())
			{
				activeChar.sendMessage("This item cannot be used on olympiad games.");
				return;
			}

			if (activeChar.isVip())
			{
				activeChar.sendMessage("You are already a VIP member.");
				return;
			}

			if (activeChar.destroyItem("Consume", item.getObjectId(), 1, null, false))
			{
				activeChar.setVip(true);
				VipAuditLog.setContext("ITEM_20446_15_DAYS_START");
				activeChar.setEndTime("vip", 15);
				activeChar.sendMessage("Congrats, you just became VIP per " + VIP_15DAYS + ".");
				activeChar.broadcastUserInfo();
				activeChar.sendPacket(new EtcStatusUpdate(activeChar));
			}
		}
	}
}

