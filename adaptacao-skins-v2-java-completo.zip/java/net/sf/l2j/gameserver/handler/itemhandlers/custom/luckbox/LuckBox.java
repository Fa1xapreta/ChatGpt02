package net.sf.l2j.gameserver.handler.itemhandlers.custom.luckbox;

import java.util.List;

import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.handler.IItemHandler;
import net.sf.l2j.gameserver.model.actor.L2Playable;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.model.item.kind.Item;
import net.sf.l2j.gameserver.network.clientpackets.Say2;
import net.sf.l2j.gameserver.network.serverpackets.MagicSkillUse;
import net.sf.l2j.util.Rnd;

public class LuckBox implements IItemHandler
{
	@Override
	public void useItem(L2Playable playable, ItemInstance item, boolean forceUse)
	{
		if (!(playable instanceof L2PcInstance))
			return;
		
		L2PcInstance activeChar = (L2PcInstance) playable;
		int itemId = item.getItemId();
		
		LuckBoxTemplate box = LuckBoxData.getInstance().getBox(itemId);
		
		if (box == null)
		{
			activeChar.sendMessage("This box is not configured.");
			return;
		}
		
		int requiredItemId = box.getRequiredItemId();
		int requiredItemCount = box.getRequiredItemCount();
		String requiredItemName = "";
		
		if (requiredItemId > 0)
		{
			Item requiredItem = ItemTable.getInstance().getTemplate(requiredItemId);
			if (requiredItem != null)
				requiredItemName = requiredItem.getName();
			
			long L2PcInstanceItemCount = activeChar.getInventory().getInventoryItemCount(requiredItemId, -1);
			if (L2PcInstanceItemCount < requiredItemCount)
			{
				activeChar.sendChatMessage(0, Say2.PARTY, "SYS:", "You need " + requiredItemCount + " " + requiredItemName + " to open this box.");
				return;
			}
		}
		
		playable.destroyItem("LuckBoxUse", item.getObjectId(), 1, null, true);
		
		if (requiredItemId > 0)
			activeChar.destroyItemByItemId("LuckBoxKey", requiredItemId, requiredItemCount, null, true);
		
		if (Rnd.get(100) < box.getFailChance())
		{
			activeChar.sendChatMessage(0, Say2.PARTY, "SYS:", "Not this time! Try again.");
			return;
		}
		
		if (box.isGetAllRewards())
		{
			List<LuckBoxReward> allRewards = box.getAllRewards();
			if (!allRewards.isEmpty())
			{
				for (LuckBoxReward reward : allRewards)
				{
					ItemInstance rewardedItem = activeChar.getInventory().addItem("LuckBox", reward.getItemId(), reward.getAmount(), activeChar, null);
					if (rewardedItem != null)
					{
						int enchant = reward.getRandomEnchantLevel();
						if (enchant > 0)
						{
							rewardedItem.setEnchantLevel(enchant);
							activeChar.sendChatMessage(0, Say2.PARTY, "SYS:", "You received " + rewardedItem.getItem().getName() + " +" + enchant + "!");
							activeChar.broadcastPacket(new MagicSkillUse(activeChar, activeChar, 2024, 1, 1, 0));
						}
						else
						{
							activeChar.sendChatMessage(0, Say2.PARTY, "SYS:", "You received " + reward.getAmount() + " " + rewardedItem.getItem().getName() + ".");
			                activeChar.broadcastPacket(new MagicSkillUse(activeChar, activeChar, 2024, 1, 1, 0));
						}
					}
				}
			}
			else
			{
				activeChar.sendMessage("No rewards have been configured for this box.");
			}
		}
		else
		{
			LuckBoxReward reward = box.rollReward();
			if (reward != null)
			{
				ItemInstance rewardedItem = activeChar.getInventory().addItem("LuckBox", reward.getItemId(), reward.getAmount(), activeChar, null);
				if (rewardedItem != null)
				{
					int enchant = reward.getRandomEnchantLevel();
					if (enchant > 0)
					{
						rewardedItem.setEnchantLevel(enchant);
						activeChar.sendChatMessage(0, Say2.PARTY, "SYS:", "You received " + rewardedItem.getItem().getName() + " +" + enchant + "!");
						activeChar.broadcastPacket(new MagicSkillUse(activeChar, activeChar, 2024, 1, 1, 0));
					}
					else
					{
						activeChar.sendChatMessage(0, Say2.PARTY, "SYS:", "You received " + reward.getAmount() + " " + rewardedItem.getItem().getName() + ".");
						activeChar.broadcastPacket(new MagicSkillUse(activeChar, activeChar, 2024, 1, 1, 0));
					}
				}
			}
			else
			{
				activeChar.sendMessage("You didn't win anything this time.");
			}
		}
	}
}