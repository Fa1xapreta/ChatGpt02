package net.sf.l2j.gameserver.handler.itemhandlers.custom.luckbox;

import net.sf.l2j.util.Rnd;
import java.util.ArrayList;
import java.util.List;

public class LuckBoxTemplate
{
	private final int itemId;
	private final int failChance;
	private final int requiredItemId;
	private final int requiredItemCount;
	private final boolean _getAllRewards;
	private final List<LuckBoxReward> rewards = new ArrayList<>();

	public LuckBoxTemplate(int itemId, int failChance, int requiredItemId, int requiredItemCount, boolean getAllRewards)
	{
		this.itemId = itemId;
		this.failChance = failChance;
		this.requiredItemId = requiredItemId;
		this.requiredItemCount = requiredItemCount;
		this._getAllRewards = getAllRewards;
	}

	public int getItemId() { return itemId; }

	public int getFailChance() { return failChance; }

	public int getRequiredItemId() { return requiredItemId; }

	public int getRequiredItemCount() { return requiredItemCount; }

	public void addReward(LuckBoxReward reward)
	{
		rewards.add(reward);
	}
	
	public boolean isGetAllRewards()
	{
		return _getAllRewards;
	}

	public List<LuckBoxReward> getAllRewards()
	{
		return new ArrayList<>(rewards);
	}

	public LuckBoxReward rollReward()
	{
		if (rewards.isEmpty())
			return null;

		int totalWeight = rewards.stream().mapToInt(LuckBoxReward::getChance).sum();
		int roll = Rnd.get(totalWeight);
		int current = 0;

		for (LuckBoxReward reward : rewards)
		{
			current += reward.getChance();
			if (roll < current)
				return reward;
		}

		return null;
	}
}