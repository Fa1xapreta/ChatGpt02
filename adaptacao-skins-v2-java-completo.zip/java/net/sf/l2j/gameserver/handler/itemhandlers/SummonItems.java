/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */

/**
 *
 * @author FBIagent
 *
 */
package net.sf.l2j.gameserver.handler.itemhandlers;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.logging.Level;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.ThreadPoolManager;
import net.sf.l2j.gameserver.datatables.NpcTable;
import net.sf.l2j.gameserver.datatables.SkillTable;
import net.sf.l2j.gameserver.datatables.SummonItemsData;
import net.sf.l2j.gameserver.handler.IItemHandler;
import net.sf.l2j.gameserver.model.L2Object;
import net.sf.l2j.gameserver.model.L2Spawn;
import net.sf.l2j.gameserver.model.actor.L2Npc;
import net.sf.l2j.gameserver.model.actor.L2Playable;
import net.sf.l2j.gameserver.model.actor.instance.L2AgathionInstance;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.actor.instance.L2PetInstance;
import net.sf.l2j.gameserver.model.actor.instance.L2XmassTreeInstance;
import net.sf.l2j.gameserver.model.actor.template.NpcTemplate;
import net.sf.l2j.gameserver.model.entity.events.deathmatch.DMEvent;
import net.sf.l2j.gameserver.model.entity.events.killtheboss.KTBEvent;
import net.sf.l2j.gameserver.model.entity.events.lastman.LMEvent;
import net.sf.l2j.gameserver.model.entity.events.multiteamvsteam.MultiTvTEvent;
import net.sf.l2j.gameserver.model.entity.events.teamvsteam.TvTEvent;
import net.sf.l2j.gameserver.model.item.SummonItem;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.model.zone.ZoneId;
import net.sf.l2j.gameserver.network.SystemMessageId;
import net.sf.l2j.gameserver.network.serverpackets.MagicSkillLaunched;
import net.sf.l2j.gameserver.network.serverpackets.MagicSkillUse;
import net.sf.l2j.gameserver.network.serverpackets.PetItemList;
import net.sf.l2j.gameserver.network.serverpackets.SetupGauge;
import net.sf.l2j.gameserver.network.serverpackets.SystemMessage;
import net.sf.l2j.gameserver.util.Broadcast;
import net.sf.l2j.util.Util;

public class SummonItems implements IItemHandler
{
	private static final boolean MILENIUM_MOUNT_DIAGNOSTIC = false;
	private static final int MOUNT_EFFECT_SKILL = 92008;
	private static final int MOUNT_EFFECT_TIME = 3000;

	private static final ConcurrentMap<Integer, Boolean> PENDING_MOUNTS =
	new ConcurrentHashMap<>();
	
	@Override
	public void useItem(L2Playable playable, ItemInstance item, boolean forceUse)
	{
		if (!(playable instanceof L2PcInstance))
			return;
		
		if (!MultiTvTEvent.onItemSummon(playable.getObjectId()) || !TvTEvent.onItemSummon(playable.getObjectId()) || !LMEvent.onItemSummon(playable.getObjectId()) || !DMEvent.onItemSummon(playable.getObjectId()) || !KTBEvent.onItemSummon(playable.getObjectId()))
			return;
		
		final L2PcInstance activeChar = (L2PcInstance) playable;
		
		if (activeChar.isSitting())
		{
			activeChar.sendPacket(SystemMessageId.CANT_MOVE_SITTING);
			return;
		}
		
		if (activeChar.isArenaProtection() || activeChar.isInsideZone(ZoneId.TOURNAMENT))
		{
			activeChar.sendMessage("You can not do this in tournament event.");
			return;
		}
		
		if (activeChar.inObserverMode())
			return;
		
		if (activeChar.isAllSkillsDisabled() || activeChar.isCastingNow())
			return;
		
		final SummonItem sitem = SummonItemsData.getInstance().getSummonItem(item.getItemId());
		if (sitem == null)
			return;

		if (sitem.getType() == 3)
		{
			if (activeChar.isCustomMount()
				&& activeChar.getMountObjectID() == item.getObjectId())
			{
				activeChar.dismount();
			}
			else if (activeChar.isMounted() || activeChar.getPet() != null)
			{
				activeChar.sendPacket(SystemMessageId.SUMMON_ONLY_ONE);
			}
			else
			{
				startMountEffect(activeChar, item, sitem.getNpcId());
			}

			return;
		}
		
		if ((activeChar.getPet() != null || activeChar.isMounted()) && sitem.isPetSummon())
		{
			activeChar.sendPacket(SystemMessageId.SUMMON_ONLY_ONE);
			return;
		}
		
		if (activeChar.isAttackingNow() || activeChar.isInCombat() || activeChar.getPvpFlag() > 0)
		{
			activeChar.sendPacket(SystemMessageId.YOU_CANNOT_SUMMON_IN_COMBAT);
			return;
		}
		
		final int npcId = sitem.getNpcId();
		if (npcId == 0)
			return;
		
		final NpcTemplate npcTemplate = NpcTable.getInstance().getTemplate(npcId);
		if (npcTemplate == null)
			return;
		
		activeChar.stopMove(null);
		
		switch (sitem.getType())
		{
		case 0: // static summons (like Christmas tree)
			try
			{
				for (L2XmassTreeInstance ch : activeChar.getKnownList().getKnownTypeInRadius(L2XmassTreeInstance.class, 1200))
				{
					if (npcTemplate.isSpecialTree())
					{
						activeChar.sendPacket(SystemMessage.getSystemMessage(SystemMessageId.CANNOT_SUMMON_S1_AGAIN).addCharName(ch));
						return;
					}
				}
				if (sitem.getItemId() == 5560 || sitem.getItemId() == 5561)
				{
					if (activeChar.destroyItem("Summon", item.getObjectId(), 1, null, false))
					{
						final L2Spawn spawn = new L2Spawn(npcTemplate);
						spawn.setLocx(activeChar.getX());
						spawn.setLocy(activeChar.getY());
						spawn.setLocz(activeChar.getZ());
						spawn.stopRespawn();
						
						final L2Npc npc = spawn.doSpawn(true);
						npc.setTitle(activeChar.getName());
						npc.setIsRunning(false); // broadcast info
					}
				}
				else
				{
					// ==========================================
					// SISTEMA DE TOGGLE (LIGA/DESLIGA AGATHION)
					// ==========================================
					
					// Se o jogador clicar no MESMO Agathion que j� est� ativo, ele � desinvocado.
					if (activeChar.getAgathionId() == npcId)
					{
						activeChar.unSummonAgathion();
						activeChar.sendMessage("Agathion desativado com sucesso.");
						return; // Para a execu��o aqui, n�o sumona de novo!
					}
					
					// Se o jogador tiver um Agathion diferente ativo, desinvoca o antigo antes de sumonar o novo.
					if (activeChar.getAgathionId() != 0)
					{
						activeChar.unSummonAgathion();
					}
					// ==========================================

					final L2Spawn spawn = new L2Spawn(npcTemplate);
					spawn.setLocx(activeChar.getX() + 25);
					spawn.setLocy(activeChar.getY() + 35);
					spawn.setLocz(activeChar.getZ() + 20);
					spawn.stopRespawn();
					
					final L2Npc npc = spawn.doSpawn(true);
					if (npc instanceof L2AgathionInstance)
					{
						((L2AgathionInstance) npc).broadcastNpcInfo(2);
						((L2AgathionInstance) npc).setShowSummonAnimation(true);
						((L2AgathionInstance) npc).setOwner(activeChar);
						((L2AgathionInstance) npc).setIsInvul(true);
						((L2AgathionInstance) npc).setRunning();
						activeChar.setAgathion(((L2AgathionInstance) npc));
						activeChar.setAgathionId(((L2AgathionInstance) npc).getNpcId());
						if (Config.AGATHIONS_ENABLED && Util.contains(Config.AGATHIONS_LIST_ID, ((L2AgathionInstance) npc).getNpcId()))
						{
							((L2AgathionInstance) npc).startAgathionTask();
						}
						((L2AgathionInstance) npc).setTargetable(false);
						((L2AgathionInstance) npc).setFollowStatus(true);
					}
				}
			}
			catch (Exception e)
			{
				activeChar.sendPacket(SystemMessageId.TARGET_CANT_FOUND);
			}
			break;
		case 1: // pet summons
			final L2Object oldTarget = activeChar.getTarget();
			activeChar.setTarget(activeChar);
			Broadcast.toSelfAndKnownPlayers(activeChar, new MagicSkillUse(activeChar, 2046, 1, 5000, 0));
			activeChar.setTarget(oldTarget);
			activeChar.sendPacket(new SetupGauge(0, 5000));
			activeChar.sendPacket(SystemMessageId.SUMMON_A_PET);
			activeChar.setIsCastingNow(true);
			
			ThreadPoolManager.getInstance().scheduleGeneral(new PetSummonFinalizer(activeChar, npcTemplate, item), 5000);
			break;
		case 2: // wyvern
			activeChar.mount(sitem.getNpcId(), item.getObjectId(), true);
			break;
		}
	}
	
	static class PetSummonFeedWait implements Runnable
	{
		private final L2PcInstance _activeChar;
		private final L2PetInstance _petSummon;
		
		PetSummonFeedWait(L2PcInstance activeChar, L2PetInstance petSummon)
		{
			_activeChar = activeChar;
			_petSummon = petSummon;
		}
		
		@Override
		public void run()
		{
			try
			{
				if (_petSummon.getCurrentFed() <= 0)
					_petSummon.unSummon(_activeChar);
				else
					_petSummon.startFeed();
			}
			catch (Exception e)
			{
				_log.log(Level.SEVERE, "", e);
			}
		}
	}
	
	// TODO: this should be inside skill handler
	static class PetSummonFinalizer implements Runnable
	{
		private final L2PcInstance _activeChar;
		private final ItemInstance _item;
		private final NpcTemplate _npcTemplate;
		
		PetSummonFinalizer(L2PcInstance activeChar, NpcTemplate npcTemplate, ItemInstance item)
		{
			_activeChar = activeChar;
			_npcTemplate = npcTemplate;
			_item = item;
		}
		
		@Override
		public void run()
		{
			try
			{
				_activeChar.sendPacket(new MagicSkillLaunched(_activeChar, 2046, 1));
				_activeChar.setIsCastingNow(false);
				
				// check for summon item validity
				if (_item == null || _item.getOwnerId() != _activeChar.getObjectId() || _item.getLocation() != ItemInstance.ItemLocation.INVENTORY)
					return;
				
				final L2PetInstance petSummon = L2PetInstance.spawnPet(_npcTemplate, _activeChar, _item);
				if (petSummon == null)
					return;
				
				petSummon.setShowSummonAnimation(true);
				petSummon.setTitle(_activeChar.getName());
				
				if (!petSummon.isRespawned())
				{
					petSummon.setCurrentHp(petSummon.getMaxHp());
					petSummon.setCurrentMp(petSummon.getMaxMp());
					petSummon.getStat().setExp(petSummon.getExpForThisLevel());
					petSummon.setCurrentFed(petSummon.getMaxFed());
				}
				
				petSummon.setRunning();
				
				if (!petSummon.isRespawned())
					petSummon.store();
				
				_activeChar.setPet(petSummon);
				
				petSummon.spawnMe(_activeChar.getX() + 50, _activeChar.getY() + 100, _activeChar.getZ());
				petSummon.startFeed();
				_item.setEnchantLevel(petSummon.getLevel());
				
				if (petSummon.getCurrentFed() <= 0)
					ThreadPoolManager.getInstance().scheduleGeneral(new PetSummonFeedWait(_activeChar, petSummon), 60000);
				else
					petSummon.startFeed();
				
				petSummon.setFollowStatus(true);
				
				petSummon.getOwner().sendPacket(new PetItemList(petSummon));
				petSummon.broadcastStatusUpdate();
			}
			catch (Exception e)
			{
				_log.log(Level.SEVERE, "", e);
			}
		}
	}
	private static boolean canFinishCustomMount(L2PcInstance player)
	{
		if (player == null || !player.isOnline())
			return false;

		if (player.isAlikeDead()
			|| player.isMounted()
			|| player.getPet() != null
			|| player.isSitting()
			|| player.isFishing()
			|| player.isInOlympiadMode()
			|| player.isCursedWeaponEquipped()
			|| player.inObserverMode()
			|| player.isAllSkillsDisabled()
			|| player.isCastingNow())
		{
			return false;
		}

		if (player.isAttackingNow()
			|| player.isInCombat()
			|| player.getPvpFlag() > 0)
		{
			return false;
		}

		if (player.isArenaProtection()
			|| player.isInsideZone(ZoneId.TOURNAMENT))
		{
			return false;
		}

		final int objectId = player.getObjectId();

		return MultiTvTEvent.onItemSummon(objectId)
			&& TvTEvent.onItemSummon(objectId)
			&& LMEvent.onItemSummon(objectId)
			&& DMEvent.onItemSummon(objectId)
			&& KTBEvent.onItemSummon(objectId);
	}

	private static void startMountEffect(L2PcInstance player,ItemInstance item,int visualIndex)
	{
		if (visualIndex < 0 || visualIndex > 44)
			return;

		if (!canFinishCustomMount(player))
			return;

		if (player.getInventory().getItemByObjectId(
			item.getObjectId()) != item)
		{
			return;
		}

		if (SkillTable.getInstance().getInfo(MOUNT_EFFECT_SKILL, 1) == null)
		{
			player.sendMessage("A skill de efeito da montaria nao foi carregada.");
			return;
		}

		final int playerId = player.getObjectId();

		if (PENDING_MOUNTS.putIfAbsent(playerId, Boolean.TRUE) != null)
			return;

		player.stopMove(null);

		final CustomMountFinalizer task =
			new CustomMountFinalizer(player, item, visualIndex);

		try
		{
			Broadcast.toSelfAndKnownPlayers(
					player,
					new MagicSkillUse(
						player,
						player,
						MOUNT_EFFECT_SKILL,
						1,
						MOUNT_EFFECT_TIME,
						0
					)
				);
			player.sendPacket(
				new SetupGauge(0, MOUNT_EFFECT_TIME)
			);

			ThreadPoolManager.getInstance().scheduleGeneral(
				task,
				MOUNT_EFFECT_TIME
			);
		}
		catch (RuntimeException e)
		{
			PENDING_MOUNTS.remove(playerId);
			player.sendPacket(new SetupGauge(0, 0));
			throw e;
		}
	}

	private static final class CustomMountFinalizer implements Runnable
	{
		private final L2PcInstance _player;
		private final ItemInstance _item;
		private final int _visualIndex;

		private final int _x;
		private final int _y;
		private final int _z;

		private CustomMountFinalizer(
			L2PcInstance player,
			ItemInstance item,
			int visualIndex)
		{
			_player = player;
			_item = item;
			_visualIndex = visualIndex;

			_x = player.getX();
			_y = player.getY();
			_z = player.getZ();
		}

		@Override
		public void run()
		{
			try
			{
				synchronized (_player)
				{
					if (!canFinishCustomMount(_player))
					{
						if (_player.isOnline())
						{
							_player.sendMessage(
								"Montaria cancelada: seu estado mudou durante a preparacao."
							);
						}
						return;
					}

					// Cancela se estiver em outra posicao ao terminar.
					final double dx = (double) _player.getX() - _x;
					final double dy = (double) _player.getY() - _y;
					final double dz = Math.abs((double) _player.getZ() - _z);

					// Aceita pequenas correcoes de posicao do servidor.
					if ((dx * dx + dy * dy) > (32.0 * 32.0) || dz > 64.0)
					{
						_player.sendMessage("Montaria cancelada: voce se moveu durante a preparacao.");
						return;
					}

					// O mesmo item deve continuar no inventario.
					final ItemInstance currentItem =
						_player.getInventory().getItemByObjectId(
							_item.getObjectId()
						);

					if (currentItem != _item || currentItem.getCount() <= 0)
						return;

					final SummonItem summonItem =
						SummonItemsData.getInstance().getSummonItem(
							currentItem.getItemId()
						);

					if (summonItem == null
						|| summonItem.getType() != 3
						|| summonItem.getNpcId() != _visualIndex)
					{
						return;
					}

					_player.broadcastPacket(
						new MagicSkillLaunched(
							_player,
							MOUNT_EFFECT_SKILL,
							1
						)
					);

					if (!_player.mountCustom(
							_visualIndex,
							currentItem.getObjectId()))
						{
							_player.sendMessage("Nao foi possivel montar: as condicoes da montaria nao foram atendidas.");
						}
						else if (MILENIUM_MOUNT_DIAGNOSTIC && _player.isGM())
						{
							_player.sendMessage("[Milenium Mount] item=" + currentItem.getItemId()
								+ " xmlVisual=" + _visualIndex
								+ " estadoVisual=" + _player.getCustomMountVisualIndex()
								+ " custom=" + _player.isCustomMount()
								+ " tipo=" + _player.getMountType()
								+ " npcBase=" + _player.getMountNpcId());
						}
				}
			}
			finally
			{
				PENDING_MOUNTS.remove(_player.getObjectId());

				if (_player.isOnline())
					_player.sendPacket(new SetupGauge(0, 0));
			}
		}
	}
}
