package net.sf.l2j.gameserver.handler.itemhandlers.custom.luckbox;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilderFactory;

import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.model.item.kind.Item;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public class LuckBoxData
{
	private static final LuckBoxData INSTANCE = new LuckBoxData();
	private final Map<Integer, LuckBoxTemplate> _boxes = new HashMap<>();

	public static LuckBoxData getInstance()
	{
		return INSTANCE;
	}

	public LuckBoxTemplate getBox(int itemId)
	{
		return _boxes.get(itemId);
	}

	public void load()
	{
		_boxes.clear();
		try
		{
			File file = new File("config/custom/luckboxes.xml");
			Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(file);
			doc.getDocumentElement().normalize();

			for (Node node = doc.getFirstChild(); node != null; node = node.getNextSibling())
			{
				if (!"luckboxes".equalsIgnoreCase(node.getNodeName()))
					continue;

				for (Node boxNode = node.getFirstChild(); boxNode != null; boxNode = boxNode.getNextSibling())
				{
					if (!"box".equalsIgnoreCase(boxNode.getNodeName()))
						continue;

					NamedNodeMap boxAttr = boxNode.getAttributes();
					int id = Integer.parseInt(boxAttr.getNamedItem("id").getNodeValue());
					int failChance = 0;
					int requiredItemId = 0;
					int requiredItemCount = 0;
					boolean getAllRewards = false;

					// Primeiro cria a box sem rewards, vai atualizar depois
					LuckBoxTemplate box = null;

					for (Node child = boxNode.getFirstChild(); child != null; child = child.getNextSibling())
					{
						if ("failChance".equalsIgnoreCase(child.getNodeName()))
						{
							failChance = Integer.parseInt(child.getTextContent());
						}
						else if ("requiredItem".equalsIgnoreCase(child.getNodeName()))
						{
							NamedNodeMap requiredAttr = child.getAttributes();
							if (requiredAttr.getNamedItem("id") != null)
								requiredItemId = Integer.parseInt(requiredAttr.getNamedItem("id").getNodeValue());
							if (requiredAttr.getNamedItem("count") != null)
								requiredItemCount = Integer.parseInt(requiredAttr.getNamedItem("count").getNodeValue());
						}

						if (boxAttr.getNamedItem("getAllRewards") != null)
						{
							getAllRewards = Boolean.parseBoolean(boxAttr.getNamedItem("getAllRewards").getNodeValue());
						}
					}

					box = new LuckBoxTemplate(id, failChance, requiredItemId, requiredItemCount, getAllRewards);

					for (Node child = boxNode.getFirstChild(); child != null; child = child.getNextSibling())
					{
						if ("reward".equalsIgnoreCase(child.getNodeName()))
						{
							NamedNodeMap rewardAttr = child.getAttributes();

							int itemId = Integer.parseInt(rewardAttr.getNamedItem("itemId").getNodeValue());
							int amount = Integer.parseInt(rewardAttr.getNamedItem("amount").getNodeValue());
							int chance = Integer.parseInt(rewardAttr.getNamedItem("chance").getNodeValue());

							int enchantMin = 0;
							int enchantMax = 0;
							int enchantChance = 0;

							if (rewardAttr.getNamedItem("enchantMin") != null)
								enchantMin = Integer.parseInt(rewardAttr.getNamedItem("enchantMin").getNodeValue());
							if (rewardAttr.getNamedItem("enchantMax") != null)
								enchantMax = Integer.parseInt(rewardAttr.getNamedItem("enchantMax").getNodeValue());
							if (rewardAttr.getNamedItem("enchantChance") != null)
								enchantChance = Integer.parseInt(rewardAttr.getNamedItem("enchantChance").getNodeValue());

							Item item = ItemTable.getInstance().getTemplate(itemId);
							if (item == null)
							{
								System.out.println("LuckBoxData: Item ID " + itemId + " nao existe. Ignorando.");
								continue;
							}

							box.addReward(new LuckBoxReward(itemId, amount, chance, enchantMin, enchantMax, enchantChance));
						}
					}

					_boxes.put(id, box);
				}
			}

			System.out.println("LuckBoxData: " + _boxes.size() + " caixas carregadas.");
		}
		catch (Exception e)
		{
			System.err.println("LuckBoxData: Erro ao carregar config/mods/luckboxes.xml");
			e.printStackTrace();
		}
	}
}
