/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.handler.itemhandlers.custom.special;

import net.sf.l2j.gameserver.datatables.SkillTable;
import net.sf.l2j.gameserver.handler.IItemHandler;
import net.sf.l2j.gameserver.model.L2Skill;
import net.sf.l2j.gameserver.model.actor.L2Playable;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.network.serverpackets.MagicSkillUse;

/**
 * Item handler that grants the player skill 1405 (Divine Inspiration) level 4
 * permanently when the item is double-clicked. The item is consumed on use.
 * If the player already has the skill at the same or higher level, the item
 * is not consumed and a message is shown.
 */
public class DivineLearning implements IItemHandler
{
	private static final int SKILL_ID    = 1405;
	private static final int SKILL_LEVEL = 4;

	@Override
	public void useItem(L2Playable playable, ItemInstance item, boolean forceUse)
	{
		if (!(playable instanceof L2PcInstance))
			return;

		final L2PcInstance activeChar = (L2PcInstance) playable;

		// Block usage in Olympiad
		if (activeChar.isInOlympiadMode())
		{
			activeChar.sendMessage("This item cannot be used in the Olympiad.");
			return;
		}

		// Check if player already has the skill at the target level or higher
		final L2Skill existing = activeChar.getKnownSkill(SKILL_ID);
		if (existing != null && existing.getLevel() >= SKILL_LEVEL)
		{
			activeChar.sendMessage("You already have Divine Inspiration level " + existing.getLevel() + ".");
			return;
		}

		// Retrieve the skill from the skill table
		final L2Skill skill = SkillTable.getInstance().getInfo(SKILL_ID, SKILL_LEVEL);
		if (skill == null)
		{
			activeChar.sendMessage("Skill not found. Please contact an administrator.");
			return;
		}

		// Play skill animation
		activeChar.broadcastPacket(new MagicSkillUse(activeChar, SKILL_ID, SKILL_LEVEL, 1000, 0));

		// Add / replace the skill on the player and save it to the database
		activeChar.addSkill(skill, true);
		activeChar.sendSkillList();
		activeChar.sendMessage("You have learned Divine Inspiration level " + SKILL_LEVEL + "!");

		// Consume the item
		playable.destroyItem("DivineLearning", item.getObjectId(), 1, null, false);
	}
}
