package net.sf.l2j.gameserver.handler.itemhandlers.custom.luckbox;

import net.sf.l2j.util.Rnd;

public class LuckBoxReward
{
	private final int itemId;
	private final int amount;
	private final int chance;
	private final int enchantMin;
	private final int enchantMax;
	private final int enchantChance;

	public LuckBoxReward(int itemId, int amount, int chance, int enchantMin, int enchantMax, int enchantChance)
	{
		this.itemId = itemId;
		this.amount = amount;
		this.chance = chance;
		this.enchantMin = enchantMin;
		this.enchantMax = enchantMax;
		this.enchantChance = enchantChance;
	}

	public int getItemId() { return itemId; }

	public int getAmount() { return amount; }

	public int getChance() { return chance; }

	public int getRandomEnchantLevel()
	{
		if (enchantChance > 0 && Rnd.get(100) < enchantChance)
			return Rnd.get(enchantMin, enchantMax);
		return 0;
	}
}