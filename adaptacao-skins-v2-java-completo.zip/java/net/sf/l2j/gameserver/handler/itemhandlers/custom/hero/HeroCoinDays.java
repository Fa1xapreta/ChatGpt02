package net.sf.l2j.gameserver.handler.itemhandlers.custom.hero;

import net.sf.l2j.gameserver.handler.IItemHandler;
import net.sf.l2j.gameserver.model.actor.L2Playable;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.network.serverpackets.EtcStatusUpdate;
import net.sf.l2j.gameserver.network.serverpackets.SocialAction;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.logging.Level;
import net.sf.l2j.L2DatabaseFactory;

public class HeroCoinDays implements IItemHandler
{
	private final int HERO_7DAYS = 7;
	private final int HERO_30DAYS = 30;
	private final int HERO_LIFETIME = 36500;

	String INSERT_DATA = "REPLACE INTO characters_custom_data (obj_Id, char_name, hero, noble, hero_end_date) VALUES (?,?,?,?,?)";

	@Override
	public void useItem(L2Playable playable, ItemInstance item, boolean forceUse)
	{
		if (!(playable instanceof L2PcInstance))
			return;

		L2PcInstance activeChar = (L2PcInstance)playable;

		int itemId = item.getItemId();

		if (itemId == 10001)
		{
			if (activeChar.isInOlympiadMode())
				activeChar.sendMessage("This item cannot be used on Olympiad Games."); 

			if (activeChar.isHero())
			{
				activeChar.sendMessage("You are already a hero!");
			}
			else
			{
				activeChar.broadcastPacket(new SocialAction(activeChar, 16));
				activeChar.setHero(true);
				updateDatabase(activeChar, HERO_30DAYS * 24L * 60L * 60L * 1000L);

				activeChar.sendMessage("You became a heroic member for "+ HERO_30DAYS +" days.");
				activeChar.broadcastUserInfo();
				activeChar.sendPacket(new EtcStatusUpdate(activeChar));
				playable.destroyItem("Consume", item.getObjectId(), 1, null, false);
			} 
		}

		if (itemId == 10002)
		{
			if (activeChar.isInOlympiadMode())
				activeChar.sendMessage("This item cannot be used on Olympiad Games."); 

			if (activeChar.isHero())
			{
				activeChar.sendMessage("You are already a hero!");
			}
			else
			{
				activeChar.broadcastPacket(new SocialAction(activeChar, 16));
				activeChar.setHero(true);
				updateDatabase(activeChar, HERO_LIFETIME * 24L * 60L * 60L * 1000L);
				
				activeChar.sendMessage("You became a heroic member for "+ HERO_LIFETIME +" days.");
				activeChar.broadcastUserInfo();
				activeChar.sendPacket(new EtcStatusUpdate(activeChar));
				playable.destroyItem("Consume", item.getObjectId(), 1, null, false);
			} 
		}

		if (itemId == 10501)
		{
			if (activeChar.isInOlympiadMode())
				activeChar.sendMessage("This item cannot be used on Olympiad Games."); 

			if (activeChar.isHero())
			{
				activeChar.sendMessage("You are already a hero!");
			}
			else
			{
				activeChar.broadcastPacket(new SocialAction(activeChar, 16));
				activeChar.setHero(true);
				updateDatabase(activeChar, HERO_7DAYS * 24L * 60L * 60L * 1000L);
				
				activeChar.sendMessage("You became a heroic member for "+ HERO_7DAYS +" days.");
				activeChar.broadcastUserInfo();
				activeChar.sendPacket(new EtcStatusUpdate(activeChar));
				playable.destroyItem("Consume", item.getObjectId(), 1, null, false);
			} 
		}
	}

	private void updateDatabase(L2PcInstance player, long heroTime)
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection())
		{
			if (player == null)
				return; 
			PreparedStatement stmt = con.prepareStatement(this.INSERT_DATA);
			stmt.setInt(1, player.getObjectId());
			stmt.setString(2, player.getName());
			stmt.setInt(3, 1);
			stmt.setInt(4, player.isNoble() ? 1 : 0);
			stmt.setLong(5, (heroTime == 0L) ? 0L : (System.currentTimeMillis() + heroTime));
			stmt.execute();
			stmt.close();
			con.close();
		} 
		catch (Exception e) 
		{
			_log.log(Level.SEVERE, "Hero Coin Error: could not update database: ", e);
			e.printStackTrace();
		} 
	}
}