package net.sf.l2j.gameserver.instancemanager.custom;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import net.sf.l2j.Config;
import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.ThreadPoolManager;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.holder.RewardHolder;
import net.sf.l2j.gameserver.network.serverpackets.MagicSkillUse;
import net.sf.l2j.gameserver.taskmanager.tasks.TaskItemDestroy;
import net.sf.l2j.util.Rnd;

public class DailyRewardManager
{
	protected DailyRewardManager()
	{
		if (Config.ALLOW_DAILY_REWARD)
		{
			loadSystemThread();
			System.out.println("Daily Reward Manager: Loaded");
		}
		else
			System.out.println("Daily Reward Manager: Disabled");
	}
	
	protected static void loadSystemThread()
	{
		long spawnMillis = 0;
    	
    	Calendar c = Calendar.getInstance();
    	
    	String[] time =  "24:00".split(":");
		c.set(Calendar.DAY_OF_MONTH, c.get(Calendar.DAY_OF_MONTH)+1);
		c.set(Calendar.HOUR_OF_DAY, Integer.parseInt(time[0]));
		c.set(Calendar.MINUTE, Integer.parseInt(time[1]));
		c.set(Calendar.SECOND, 0);
		spawnMillis = c.getTimeInMillis() - System.currentTimeMillis();
		
		ThreadPoolManager.getInstance().scheduleGeneral(new Runnable()
        {
			@Override
			public void run()
			{
				clearDBTable();
				
				// Reload the system
				loadSystemThread();
				
				System.out.println("[Daily Reward] Table cleaned and restart the thread.");
			}
        }, spawnMillis);
	}
	
	protected static void clearDBTable()
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection())
		{
			PreparedStatement statement = con.prepareStatement("DELETE FROM reward_manager");
			statement.execute();
			statement.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void claimDailyReward(L2PcInstance player)
	{
		if (Config.ALLOW_DAILY_REWARD)
		{
			if (/*checkIfIPorHWIDExistInDB(player, "ip") || */checkIfIPorHWIDExistInDB(player, "hwid"))
			{
				if (/*checkForLatestHWIDReward(player, "ip") || */checkForLatestHWIDReward(player, "hwid")) // Rewarded
				{
					//if (checkForLatestHWIDReward(player, "ip"))
					//	player.sendMessage("Join again in " + Cd(player, "ip", false) + " to get your daily reward.");

					if (checkForLatestHWIDReward(player, "hwid"))
						player.sendMessage("Join again in " + Cd(player, "hwid", false) + " to get your daily reward.");
				}
				else // Not rewarded
				{ 
					//if (checkIfIPorHWIDExistInDB(player, "ip"))
					//	updateLastReward(player, "ip");

					if (checkIfIPorHWIDExistInDB(player, "hwid"))
						updateLastReward(player, "hwid");

					giveReward(player);
				}
			}
			else // Insert new Parent and reward
			{
				insertNewParentOfPlayerIPHWID(player);
				giveReward(player);
			}
		}
	}

	private static void giveReward(L2PcInstance player)
	{
		player.sendMessage("You have received your daily reward, thanks for play here!");
		
		for (RewardHolder reward : Config.DAILY_LOG_REWARDS)
		{
			if (Rnd.get(100) <= reward.getRewardChance())
			{
				if (player.getInventory().getItemByItemId(reward.getRewardId()) == null)
				{
					player.addItem("Daily Reward", reward.getRewardId(), Rnd.get(reward.getRewardMin(), reward.getRewardMax()), player, true);
					player.setTimedItens(System.currentTimeMillis());
					player.store();
					ThreadPoolManager.getInstance().scheduleGeneral(new TaskItemDestroy(player), Config.DAILY_REWARDS_DELETE_TIME * 1000 * 60);
				}
			}
		}
		
		MagicSkillUse MSU = new MagicSkillUse(player, player, 2024, 1, 1, 0);
		player.broadcastPacket(MSU);
	}

	private static boolean checkForLatestHWIDReward(L2PcInstance activeChar, String mode)
	{
		return Long.parseLong(Cd(activeChar, mode, true)) > System.currentTimeMillis();
	}

	private static void updateLastReward(L2PcInstance player, String mode)
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection())
		{
			PreparedStatement statement = con.prepareStatement("UPDATE reward_manager SET expire_time=? WHERE "+mode+"=?");
			statement.setLong(1, System.currentTimeMillis());
			statement.setString(2,  player.getHWid()/*(mode.equals("ip") ? player.getClient().getConnection().getInetAddress().getHostAddress() : player.getHWid())*/);
			statement.execute();
			statement.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	private static String Cd(L2PcInstance player, String mode, boolean returnInTimestamp)
	{
		long CdMs = 0;
		long voteDelay = 1440 * 60000L;
		
		PreparedStatement statement = null;
		try (Connection con = L2DatabaseFactory.getInstance().getConnection())
		{
			statement = con.prepareStatement("SELECT expire_time FROM reward_manager WHERE "+mode+"=?");
			statement.setString(1,  player.getHWid()/*(mode.equals("ip") ? player.getClient().getConnection().getInetAddress().getHostAddress() : player.getHWid())*/);
			
			ResultSet rset = statement.executeQuery();
			
			while (rset.next())
			{
				CdMs = rset.getLong("expire_time");
			}
			
			if((CdMs + voteDelay) < System.currentTimeMillis())
				CdMs = System.currentTimeMillis() - voteDelay;
			
			rset.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement != null)
					statement.close();
			}
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy HH:mm");
		
		if(returnInTimestamp)
			return String.valueOf(CdMs+voteDelay);
		
		Date resultdate = new Date(CdMs + voteDelay);
		return sdf.format(resultdate);
	}
	
	private static boolean checkIfIPorHWIDExistInDB(L2PcInstance player, String mode)
	{
		boolean flag = false;
		PreparedStatement statement = null;
		try (Connection con = L2DatabaseFactory.getInstance().getConnection())
		{
			statement = con.prepareStatement("SELECT * FROM reward_manager WHERE "+mode+"=?");
			statement.setString(1,  player.getHWid()/*(mode.equals("ip") ? player.getClient().getConnection().getInetAddress().getHostAddress() : player.getHWid())*/);
			
			ResultSet rset = statement.executeQuery();
			
			if (rset.next())
				flag = true;

			rset.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement != null)
					statement.close();
			}
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return flag;
	}
	
	private static void insertNewParentOfPlayerIPHWID(L2PcInstance player)
	{
		PreparedStatement statement = null;
		try (Connection con = L2DatabaseFactory.getInstance().getConnection())
		{
			//statement = con.prepareStatement("INSERT INTO reward_manager (ip,hwid,expire_time) VALUES (?,?,?)");
			statement = con.prepareStatement("INSERT INTO reward_manager (hwid,expire_time) VALUES (?,?)");
			//statement.setString(1, player.getClient().getConnection().getInetAddress().getHostAddress());
			statement.setString(1, player.getHWid());
			statement.setLong(2, System.currentTimeMillis());
			statement.execute();
			statement.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(statement != null)
					statement.close();
			}
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public static DailyRewardManager getInstance()
	{
		return SingletonHolder._instance;
	}
	
	private static class SingletonHolder
	{
		protected static final DailyRewardManager _instance = new DailyRewardManager();
	}
}