package net.sf.l2j.gameserver.instancemanager.custom;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.L2GameClient;

public final class IPHistoryManager
{
	private static final Logger _log = Logger.getLogger(IPHistoryManager.class.getName());
	private static volatile boolean _tablesReady;

	private IPHistoryManager()
	{
	}

	public static void ensureTables()
	{
		if (_tablesReady)
			return;

		synchronized (IPHistoryManager.class)
		{
			if (_tablesReady)
				return;

			try (Connection con = L2DatabaseFactory.getInstance().getConnection();
				Statement st = con.createStatement())
			{
				st.executeUpdate("CREATE TABLE IF NOT EXISTS ip_login_history (" +
					"id INT NOT NULL AUTO_INCREMENT," +
					"account_name VARCHAR(45) NOT NULL DEFAULT ''," +
					"player_name VARCHAR(45) NOT NULL DEFAULT ''," +
					"player_id INT NOT NULL DEFAULT 0," +
					"ip VARCHAR(45) NOT NULL DEFAULT ''," +
					"x INT NOT NULL DEFAULT 0," +
					"y INT NOT NULL DEFAULT 0," +
					"z INT NOT NULL DEFAULT 0," +
					"clan_id INT NOT NULL DEFAULT 0," +
					"login_time DATETIME NOT NULL," +
					"PRIMARY KEY (id)," +
					"KEY idx_ip_history_account_time (account_name, login_time)," +
					"KEY idx_ip_history_ip_time (ip, login_time)," +
					"KEY idx_ip_history_player_time (player_id, login_time)," +
					"KEY idx_ip_history_login_time (login_time)" +
					")");
				_tablesReady = true;
			}
			catch (Exception e)
			{
				_log.log(Level.WARNING, "Could not create ip_login_history table.", e);
			}
		}
	}

	public static void recordLogin(L2PcInstance player, L2GameClient client)
	{
		if (player == null)
			return;

		ensureTables();

		String account = "";
		if (client != null)
		{
			account = client.getAccountName();
			if (account == null || account.isEmpty())
				account = client.getLoginName();
		}
		if (account == null || account.isEmpty())
			account = player.getAccountName();

		String ip = player.getIP();
		if ((ip == null || ip.isEmpty()) && client != null && client.getConnection() != null && client.getConnection().getInetAddress() != null)
			ip = client.getConnection().getInetAddress().getHostAddress();

		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement("INSERT INTO ip_login_history (account_name, player_name, player_id, ip, x, y, z, clan_id, login_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())"))
		{
			ps.setString(1, safe(account, 45));
			ps.setString(2, safe(player.getName(), 45));
			ps.setInt(3, player.getObjectId());
			ps.setString(4, safe(ip, 45));
			ps.setInt(5, player.getX());
			ps.setInt(6, player.getY());
			ps.setInt(7, player.getZ());
			ps.setInt(8, player.getClanId());
			ps.executeUpdate();
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not record IP login history for " + player.getName() + ".", e);
		}
	}

	private static String safe(String value, int max)
	{
		if (value == null)
			return "";

		value = value.trim();
		return value.length() > max ? value.substring(0, max) : value;
	}
}
