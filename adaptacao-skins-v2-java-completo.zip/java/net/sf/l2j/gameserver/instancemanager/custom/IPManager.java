/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.instancemanager.custom;

import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.L2GameClient;
import net.sf.l2j.gameserver.network.serverpackets.TutorialShowHtml;
import net.sf.l2j.gameserver.util.Util;

public class IPManager
{
    private static final Logger _log = Logger.getLogger(IPManager.class.getName());

    public IPManager()
    {
        _log.log(Level.INFO, "IPManager - Loaded.");
    }

    private static boolean multiboxKickTask(L2PcInstance activeChar, Integer numberBox, Collection<L2PcInstance> world)
    {
        if (!isCountable(activeChar))
            return false;
        
        String ip = activeChar.getClient().getConnection().getInetAddress().getHostAddress();
        if (Config.MULTIBOX_PROTECTION_BYPASS_IPS.contains(ip))
            return false;
        
        int count = 1;
        
        for (L2PcInstance player : world)
        {
            if (player == activeChar || !isCountable(player))
                continue;
            
            String playerIp = player.getClient().getConnection().getInetAddress().getHostAddress();
            if (Config.MULTIBOX_PROTECTION_BYPASS_IPS.contains(playerIp))
                continue;
            
            if (ip.equals(playerIp))
            {
                count++;
                
                if (count > numberBox)
                    return true;
            }
        }
        return false;
    }
    
    private static boolean isCountable(L2PcInstance player)
    {
        return player != null && player.isOnline() && !player.isFakeOffline() && player.getClient() != null && !player.getClient().isDetached() && player.getClient().getConnection() != null && !player.getClient().getConnection().isClosed() && player.getClient().getConnection().getInetAddress() != null;
    }
    public boolean validBox(L2PcInstance activeChar, Integer numberBox, Collection<L2PcInstance> world, Boolean forcedLogOut)
    {
        if (multiboxKickTask(activeChar, numberBox, world))
        {
            if (forcedLogOut)
            {
                L2GameClient client = activeChar.getClient();
                String ip = client.getConnection().getInetAddress().getHostAddress();
                showMultiboxTutorial(activeChar, ip, numberBox);
                _log.warning("Multibox Protection: " + ip + " was trying to use over " + numberBox + " clients!");
                Util.handleIllegalPlayerAction(activeChar, "Multibox Protection: " + ip + " was trying to use over " + numberBox + " clients!", Config.MULTIBOX_PROTECTION_PUNISH);
                activeChar.sendMessage("You break the limit of " + Config.MULTIBOX_PROTECTION_CLIENTS_PER_PC + " box per IP.");
            }
            return true;
        }
        return false;
    }
    
    private static void showMultiboxTutorial(L2PcInstance activeChar, String ip, Integer numberBox)
    {
        StringBuilder html = new StringBuilder();
        html.append("<html><body><center>");
        html.append("<br><font color=LEVEL>Multibox Protection</font><br>");
        html.append("<img src=\"L2UI.SquareGray\" width=300 height=1><br>");
        html.append("You�ve reached the limit of allowed windows.<br1>");
        html.append("<img src=\"L2UI.SquareGray\" width=300 height=1><br>");
        html.append("<br>");
        html.append("Limit IP Allowed: <font color=LEVEL>").append(numberBox).append("</font>.<br1>");
        html.append("<br>");
        html.append("<button value=\"Close\" action=\"link close\" width=75 height=21 back=\"L2UI_ch3.Btn1_normalOn\" fore=\"L2UI_ch3.Btn1_normal\">");
        html.append("</center></body></html>");
        activeChar.sendPacket(new TutorialShowHtml(html.toString()));
    }
    
    private static class SingletonHolder
    {
        protected static final IPManager _instance = new IPManager();
    }

    public static final IPManager getInstance()
    {
        return SingletonHolder._instance;
    }
}