package net.sf.l2j.gameserver.instancemanager.dropcustom;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import net.sf.l2j.gameserver.GameServer;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.xmlfactory.XMLDocument;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public class DropDataCustom extends XMLDocument
{
	private static final Logger _log = Logger.getLogger(GameServer.class.getName());
	private Map<Integer, Drop> Drops = new HashMap<>();
	
	public DropDataCustom() 
	{
		load();
	}
	
	public static DropDataCustom getInstance() 
	{
		return SingleTonHolder._instance;
	}
	
	private static class SingleTonHolder 
	{
		protected static final DropDataCustom _instance = new DropDataCustom();
	}
	
	public void reload()
	{
		this.Drops.clear();
		load();
	}
	
	@Override
	protected void load()
	{
		loadDocument("./data/xml/drop/DropCustom.xml");
		_log.info("DropData: Loaded " + this.Drops.size() + " Drops.");
	}
	
	@Override
	protected void parseDocument(Document doc, File f)
	{
		try 
		{
			Node cat = doc.getFirstChild();
			for (Node dropCat = cat.getFirstChild(); dropCat != null; dropCat = dropCat.getNextSibling())
			{
				if ("Drop".equalsIgnoreCase(dropCat.getNodeName()))
				{
					NamedNodeMap attrs = dropCat.getAttributes();
					Drop Drop = null;
					int itemId = Integer.parseInt(attrs.getNamedItem("itemId").getNodeValue());
					int minAmount = Integer.parseInt(attrs.getNamedItem("minAmount").getNodeValue());
					int maxAmount = Integer.parseInt(attrs.getNamedItem("maxAmount").getNodeValue());
					int chance = Integer.parseInt(attrs.getNamedItem("chance").getNodeValue());
					String monstersIDs = attrs.getNamedItem("NpcIds").getNodeValue();
					if (ItemTable.getInstance().getTemplate(itemId) != null)
					{
						Drop = new Drop();
						Drop.setItemId(itemId);
						Drop.setChance(chance);
						int[] amount = new int[2];
						amount[0] = minAmount;
						amount[1] = maxAmount;
						Drop.setAmount(amount);
						List<Integer> monsters = new ArrayList<>();
						for (String monsterId : monstersIDs.split(";"))
							monsters.add(Integer.valueOf(Integer.parseInt(monsterId))); 
						Drop.setMonsters(monsters);
						this.Drops.put(Integer.valueOf(itemId), Drop);
					}
					else 
					{
						_log.info("Item Id: " + itemId + " is an invalid item for custom drop ID: " + itemId + "(uncategorized).");
					} 
				} 
			} 
		} 
		catch (Exception e)
		{
			_log.info("custom Drop Data: Error while creating table: " + e);
			e.printStackTrace();
		} 
	}
	
	public List<Integer> getUncategorizedDropItemsIds()
	{
		List<Integer> items = new ArrayList<>();
		for (Map.Entry<Integer, Drop> entry : this.Drops.entrySet())
			items.add(entry.getKey()); 
		return items;
	}
	
	public List<Integer> monstersWithDropId(int itemId) 
	{
		for (Map.Entry<Integer, Drop> entry : this.Drops.entrySet())
		{
			if (entry.getValue().getItemId() == itemId)
				return entry.getValue().getMonsters(); 
		} 
		return new ArrayList<>();
	}
	
	public Drop getUncategorizedDropById(int itemId) 
	{
		return this.Drops.get(Integer.valueOf(itemId));
	}
}
