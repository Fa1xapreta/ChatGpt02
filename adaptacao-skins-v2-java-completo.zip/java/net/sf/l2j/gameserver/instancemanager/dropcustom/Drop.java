package net.sf.l2j.gameserver.instancemanager.dropcustom;

import java.util.ArrayList;
import java.util.List;

public class Drop {
  private List<Integer> monsters = new ArrayList<>();
  
  private int itemId;
  
  private int chance;
  
  private int[] amount = new int[2];
  
  public List<Integer> getMonsters()
  {
    return this.monsters;
  }
  
  public void setMonsters(List<Integer> monsters) 
  {
    this.monsters = monsters;
  }
  
  public int getItemId()
  {
    return this.itemId;
  }
  
  public void setItemId(int id)
{
    this.itemId = id;
  }
  
  public int[] getAmount()
  {
    return this.amount;
  }
  
  public void setAmount(int[] amount)
  {
    this.amount = amount;
  }
  
  public int getChance()
  {
    return this.chance;
  }
  
  public void setChance(int chance)
  {
    this.chance = chance;
  }
}
