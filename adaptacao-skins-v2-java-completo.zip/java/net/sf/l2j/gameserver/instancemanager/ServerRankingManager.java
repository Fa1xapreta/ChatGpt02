package net.sf.l2j.gameserver.instancemanager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.item.kind.Item;
import net.sf.l2j.gameserver.model.item.kind.Weapon;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;

public final class ServerRankingManager
{
    private static final Logger LOG =
        Logger.getLogger(ServerRankingManager.class.getName());

    private static final int LIMIT = 15;

    private static final long CACHE_TIME =
        TimeUnit.SECONDS.toNanos(30);

    private static final ServerRankingManager INSTANCE =
        new ServerRankingManager();

    public enum Ranking
    {
        PVP("Ranking PvP"),
        PK("Ranking PK"),
        CLAN("Top Clan"),
        ENCHANT("Top Enchant");

        private final String title;
        private String cachedHtml;
        private long updatedAt;

        Ranking(String title)
        {
            this.title = title;
        }
    }

    private ServerRankingManager()
    {
    }

    public static ServerRankingManager getInstance()
    {
        return INSTANCE;
    }

    public void show(L2PcInstance player, Ranking ranking)
    {
        if (player == null || ranking == null)
            return;

        String content;

        try
        {
            content = getHtml(ranking);
        }
        catch (Exception e)
        {
            LOG.log(Level.WARNING,
                "Falha ao carregar ranking " + ranking.name(), e);

            content = page(ranking,
                "<font color=FF7777>Ranking indisponivel."
                + "<br>Tente novamente em instantes.</font>");
        }

        NpcHtmlMessage html = new NpcHtmlMessage(0);
        html.setHtml(content);
        player.sendPacket(html);
    }

    private String getHtml(Ranking ranking) throws Exception
    {
        // Cada ranking possui seu proprio cache e bloqueio.
        synchronized (ranking)
        {
            long now = System.nanoTime();

            if (ranking.cachedHtml != null
                && now - ranking.updatedAt < CACHE_TIME)
            {
                return ranking.cachedHtml;
            }

            String table;

            switch (ranking)
            {
                case PVP:
                    table = loadPlayers(true);
                    break;

                case PK:
                    table = loadPlayers(false);
                    break;

                case CLAN:
                    table = loadClans();
                    break;

                case ENCHANT:
                    table = loadWeapons();
                    break;

                default:
                    throw new IllegalArgumentException(
                        "Ranking desconhecido: " + ranking);
            }

            // So publica o cache depois de concluir a consulta.
            String result = page(ranking, table);
            ranking.cachedHtml = result;
            ranking.updatedAt = System.nanoTime();

            return result;
        }
    }

    private String loadPlayers(boolean pvp) throws Exception
    {
        // A coluna vem somente destas duas constantes.
        String column = pvp ? "pvpkills" : "pkkills";

        String sql =
            "SELECT char_name," + column + ",online "
            + "FROM characters "
            + "WHERE accesslevel=0 AND " + column + ">0 "
            + "ORDER BY " + column + " DESC,char_name ASC,obj_Id ASC "
            + "LIMIT 15";

        StringBuilder table = new StringBuilder(
            "<table width=290>"
            + "<tr><td>#</td><td>Jogador</td><td>"
            + (pvp ? "PvP" : "PK")
            + "</td><td>Status</td></tr>");

        int position = 0;

        try (Connection con =
                L2DatabaseFactory.getInstance().getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery())
        {
            while (rs.next())
            {
                position++;

                String status = rs.getInt("online") == 1
                    ? "<font color=00FF00>On</font>"
                    : "<font color=FF7777>Off</font>";

                table.append("<tr>")
                    .append(positionCell(position))
                    .append("<td>")
                    .append(text(rs.getString("char_name"), 16))
                    .append("</td><td>")
                    .append(rs.getInt(column))
                    .append("</td><td>")
                    .append(status)
                    .append("</td></tr>");
            }
        }

        return finishTable(table, position, 4);
    }

    private String loadClans() throws Exception
    {
        String sql =
            "SELECT cd.clan_name,cp.boss_points "
            + "FROM clan_points cp "
            + "INNER JOIN clan_data cd ON cd.clan_id=cp.clan_id "
            + "WHERE cp.boss_points>0 "
            + "ORDER BY cp.boss_points DESC,cd.clan_name ASC,"
            + "cp.clan_id ASC LIMIT 15";

        StringBuilder table = new StringBuilder(
            "<table width=290>"
            + "<tr><td>#</td><td>Clan</td><td>Pontos</td></tr>");

        int position = 0;

        try (Connection con =
                L2DatabaseFactory.getInstance().getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery())
        {
            while (rs.next())
            {
                position++;

                table.append("<tr>")
                    .append(positionCell(position))
                    .append("<td>")
                    .append(text(rs.getString("clan_name"), 18))
                    .append("</td><td>")
                    .append(rs.getLong("boss_points"))
                    .append("</td></tr>");
            }
        }

        return finishTable(table, position, 3);
    }

    private String loadWeapons() throws Exception
    {
        String sql =
            "SELECT c.obj_Id,c.char_name,i.item_id,i.enchant_level "
            + "FROM items i "
            + "INNER JOIN characters c ON c.obj_Id=i.owner_id "
            + "WHERE c.accesslevel=0 AND i.enchant_level>0 "
            + "ORDER BY i.enchant_level DESC,c.char_name ASC,"
            + "c.obj_Id ASC,i.item_id ASC";

        StringBuilder table = new StringBuilder(
            "<table width=290>"
            + "<tr><td>#</td><td>Jogador</td>"
            + "<td>Arma</td><td>Enchant</td></tr>");

        Set<Integer> includedPlayers = new HashSet<>();
        int position = 0;

        try (Connection con =
                L2DatabaseFactory.getInstance().getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery())
        {
            while (position < LIMIT && rs.next())
            {
                int playerId = rs.getInt("obj_Id");

                if (includedPlayers.contains(playerId))
                    continue;

                Item template = ItemTable.getInstance()
                    .getTemplate(rs.getInt("item_id"));

                // Tambem descarta templates inexistentes.
                if (!(template instanceof Weapon))
                    continue;

                // Como a consulta esta ordenada por enchant,
                // esta e a melhor arma encontrada para o jogador.
                includedPlayers.add(playerId);
                position++;

                table.append("<tr>")
                    .append(positionCell(position))
                    .append("<td>")
                    .append(text(rs.getString("char_name"), 14))
                    .append("</td><td>")
                    .append(text(template.getName(), 22))
                    .append("</td><td><font color=00FF00>+")
                    .append(rs.getInt("enchant_level"))
                    .append("</font></td></tr>");
            }
        }

        return finishTable(table, position, 4);
    }

    private static String positionCell(int position)
    {
        String color = position <= 3 ? "LEVEL" : "A19999";

        return "<td><font color=" + color + ">"
            + position + "</font></td>";
    }

    private static String finishTable(
        StringBuilder table, int count, int columns)
    {
        if (count == 0)
        {
            table.append("<tr><td colspan=")
                .append(columns)
                .append(" align=center>")
                .append("Nenhum registro encontrado.")
                .append("</td></tr>");
        }

        return table.append("</table>").toString();
    }

    private static String text(String value, int maxLength)
    {
        if (value == null)
            return "";

        if (value.length() > maxLength)
            value = value.substring(0, maxLength - 3) + "...";

        return value.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;");
    }

    private static String page(Ranking ranking, String content)
    {
        return "<html><head><title>" + ranking.title
            + "</title></head><body><center>"
            + "<img src=\"l2ui_ch3.herotower_deco\" "
            + "width=256 height=32><br>"
            + "<font color=LEVEL>" + ranking.title + "</font><br>"
            + content
            + "<br><font color=A19999>"
            + "Atualizacao em ate 30 segundos.</font>"
            + "<br><br>"
            + "<a action=\"bypass -h voiced_ranking\">Voltar</a>"
            + "</center></body></html>";
    }
}