package net.sf.l2j.gameserver.instancemanager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import phantom.task.ThreadPool;

import net.sf.l2j.Config;
import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.model.L2World;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.network.clientpackets.Say2;
import net.sf.l2j.gameserver.network.serverpackets.CreatureSay;

public class PlayerKillsManager
{
	private static final Logger _log = Logger.getLogger(PlayerKillsManager.class.getName());
	
	// SQL Queries
	private static final String RESTORE_TASKS = "SELECT id, owner_id, aim_id, count, reward_id, reward_count, start_time FROM pk_bounties";
	private static final String ADD_TASK = "INSERT INTO pk_bounties (id, owner_id, aim_id, count, reward_id, reward_count, start_time) VALUES (?,?,?,?,?,?,?)";
	private static final String DELETE_TASK = "DELETE FROM pk_bounties WHERE id=?";
	private static final String UPDATE_TASK = "UPDATE pk_bounties SET count=? WHERE id=?";
	
	private final List<KillTask> _aims;
	private static int lastTaskId;
	
	private PlayerKillsManager()
	{
	    lastTaskId = 0;
	    _aims = new CopyOnWriteArrayList<>();
	    
	    loadFromDatabase();
	    
	    // Substitua a vari�vel fixa pela do Config:
	    if (Config.TASKS_DELETE_INTERVAL != 0)
	        ThreadPool.scheduleAtFixedRate(new UpdateKillTasks(), Config.TASKS_DELETE_INTERVAL * 60 * 1000L, Config.TASKS_DELETE_INTERVAL * 60 * 1000L);
	    
	    _log.info("PlayerKillsManager: Initialized. Loaded " + _aims.size() + " active bounties.");
	}
	
	private void loadFromDatabase()
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
		     PreparedStatement ps = con.prepareStatement(RESTORE_TASKS);
		     ResultSet rs = ps.executeQuery())
		{
			while (rs.next())
			{
				int id = rs.getInt("id");
				int ownerId = rs.getInt("owner_id");
				int aimId = rs.getInt("aim_id");
				int count = rs.getInt("count");
				int rewardId = rs.getInt("reward_id");
				int rewardCount = rs.getInt("reward_count");
				long startTime = rs.getLong("start_time");
				
				KillTask task = new KillTask(id, ownerId, aimId, count, rewardId, rewardCount, startTime);
				_aims.add(task);
				
				if (id >= lastTaskId)
					lastTaskId = id + 1;
			}
		}
		catch (Exception e)
		{
			_log.log(Level.SEVERE, "PlayerKillsManager: Could not load bounties from database.", e);
		}
	}
	
	public String addKillTask(int ownerObjId, int aimObjectId, int killsCount, int rewardItemId, int rewardItemCount)
	{
	    if (getTasksCount() >= Config.TASKS_MAX_COUNT)
	        return "Ha muitos contratos no momento. Tente mais tarde.";
	    
	    if (getTaskOfPlayer(aimObjectId) != null)
	        return "Ja existe um contrato sobre a cabe�a deste jogador.";
	    
	    if (Config.MAX_KILLS_COUNT != 0 && killsCount > Config.MAX_KILLS_COUNT)
	        return "Limite de mortes (kills count) excedido.";
	        
	    if (killsCount <= 0 || rewardItemCount <= 0)
	        return "Valores inv�lidos.";
	
	    if (getCharLevel(aimObjectId) < 40)
	        return "O alvo precisa ser level 40 ou superior para receber um contrato.";
	    
	    L2PcInstance owner = L2World.getInstance().getPlayer(ownerObjId);
	    L2PcInstance aimPlayer = L2World.getInstance().getPlayer(aimObjectId); // Pode retornar null se offline, e tudo bem!
	    
	    if (owner == null)
	        return "Voce precisa estar online para fazer isso.";
	        
	    if (owner.getObjectId() == aimObjectId)
	        return "Voce nao pode colocar recompensa em si mesmo.";
	        
	    // Checagens Espec�ficas apenas SE o alvo estiver online no momento
	    if (aimPlayer != null)
	    {
	        if (aimPlayer.isGM())
	            return "Voce nao pode colocar recompensa em um Game Master.";
	            
	     // Agora o sistema s� bloqueia se o BLOCK_SELF_HWID estiver TRUE na configura��o
	        if (Config.BLOCK_SELF_HWID && owner.getClient() != null && aimPlayer.getClient() != null)
	        {
	            String ownerIP = owner.getClient().getConnection().getInetAddress().getHostAddress();
	            String aimIP = aimPlayer.getClient().getConnection().getInetAddress().getHostAddress();
	            if (ownerIP.equals(aimIP))
	                return "Voce nao pode colocar recompensa em alguem da mesma conexao.";
	        }
	    }
	    
	    // Verifica��o de itens
	    if (checkItems(owner, killsCount, rewardItemId, rewardItemCount))
	    {
	    	long totalCost = rewardItemCount; 
	        
	        owner.destroyItemByItemId("l2killmanager", rewardItemId, (int) totalCost, null, true);
	        owner.destroyItemByItemId("l2killmanager", Config.PRICE_ITEMID, Config.PRICE_ITEMCOUNT, null, true);
	        
	        int taskId = lastTaskId++;
	        long startTime = System.currentTimeMillis();
	        
	        KillTask task = new KillTask(taskId, ownerObjId, aimObjectId, killsCount, rewardItemId, rewardItemCount, startTime);
	        _aims.add(task);
	        
	        try (Connection con = L2DatabaseFactory.getInstance().getConnection();
	             PreparedStatement ps = con.prepareStatement(ADD_TASK))
	        {
	            ps.setInt(1, taskId);
	            ps.setInt(2, ownerObjId);
	            ps.setInt(3, aimObjectId);
	            ps.setInt(4, killsCount);
	            ps.setInt(5, rewardItemId);
	            ps.setInt(6, rewardItemCount);
	            ps.setLong(7, startTime);
	            ps.execute();
	        }
	        catch (Exception e)
	        {
	            _log.log(Level.SEVERE, "PlayerKillsManager: Could not save new task to database.", e);
	            return "Error saving to database.";
	        }
	        
	        if (Config.ANNOUNCE_ON_ADD)
	        {
	            String targetName = getCharName(aimObjectId); // Garante que o nome aparece no chat, mesmo do cara offline
	            String message = Config.ADD_MESSAGE 
	                .replace("%playername%", owner.getName())
	                .replace("%aimname%", targetName)
	                .replace("%itemcount%", String.valueOf(rewardItemCount))
	                .replace("%itemname%", getItemName(rewardItemId));
	            announceToAll(message);
	        }
	        
	        return "Order has been successfully added!"; // Retorno de sucesso
	    }
	    
	    return "Insufficient items."; // Retorno caso checkItems falhe
	}
	
	public String removeKillTask(L2PcInstance player, int taskId)
	{
	    KillTask task = getTaskOfPlayer(player.getObjectId());
	    if (task != null && player.getObjectId() == task.ownerObjectId)
	    {
	        // CORRIGIDO: Como os itens ficam retidos at� o fim, devolve o valor total integral
	        long refundAmount = task.rewardItemCount;
	        
	        player.addItem("l2killmanager", task.rewardItemId, (int) refundAmount, null, true);
	        _aims.remove(task);
	        deleteFromDatabase(taskId);
	        return "Contrato removido com sucesso. Recompensa devolvida.";
	    }
	    return "Nao foi possivel remover o contrato.";
	}
	
	public void onKill(int aimObjectId, int killerObjectId)
	{
		L2PcInstance aim = L2World.getInstance().getPlayer(aimObjectId);
		L2PcInstance killer = L2World.getInstance().getPlayer(killerObjectId);
	    
	    if (aim == null || killer == null)
	        return;
	        
	    KillTask task = getTaskByTarget(aimObjectId);
	    if (task == null)
	        return;
	    
	    if (Config.BLOCK_SELF_HWID && killer.getClient() != null && aim.getClient() != null)
	    {
	        String killerIP = killer.getClient().getConnection().getInetAddress().getHostAddress();
	        String aimIP = aim.getClient().getConnection().getInetAddress().getHostAddress();
	        
	        if (killerIP.equals(aimIP))
	        {
	            killer.sendMessage("Bounty Hunter: You cannot claim the reward from the same connection.");
	            return;
	        }
	    }
	    
	    if (task.count > 0)
	    {
	        // CORRIGIDO: Removeu o "killer.addItem" daqui e passou o 'killer' no m�todo abaixo
	        task.updateKills(killer.getName(), killer);
	        
	        if (Config.ANNOUNCE_ON_KILL)
	        {
	            String message = Config.KILL_MESSAGE
	                .replace("%killer%", killer.getName())
	                .replace("%aim%", aim.getName());
	            announceToAll(message);
	        }
	    }
	}
	
	public String getCharName(int objId)
	{
		L2PcInstance p = L2World.getInstance().getPlayer(objId);
	    if (p != null) return p.getName();
	    
	    String name = "Desconhecido";
	    try (Connection con = L2DatabaseFactory.getInstance().getConnection();
	         PreparedStatement ps = con.prepareStatement("SELECT char_name FROM characters WHERE obj_Id=?"))
	    {
	        ps.setInt(1, objId);
	        try (ResultSet rs = ps.executeQuery())
	        {
	            if (rs.next()) name = rs.getString("char_name");
	        }
	    }
	    catch (Exception e)
	    {
	        _log.log(Level.SEVERE, "PlayerKillsManager: Nao foi possivel obter o nome pelo ID.", e);
	    }
	    return name;
	}
	
	public int getCharLevel(int objId)
	{
	    // Tenta pegar o level do jogador se ele estiver online
		L2PcInstance p = L2World.getInstance().getPlayer(objId);
	    if (p != null) return p.getLevel();
	    
	    // Se estiver offline, pega o level direto do Banco de Dados
	    int level = 0;
	    try (Connection con = L2DatabaseFactory.getInstance().getConnection();
	         PreparedStatement ps = con.prepareStatement("SELECT level FROM characters WHERE obj_Id=?"))
	    {
	        ps.setInt(1, objId);
	        try (ResultSet rs = ps.executeQuery())
	        {
	            if (rs.next()) level = rs.getInt("level");
	        }
	    }
	    catch (Exception e)
	    {
	        _log.log(Level.SEVERE, "PlayerKillsManager: Nao foi possivel obter o level pelo ID.", e);
	    }
	    return level;
	}
	
	
	public KillTask getTaskByTarget(int aimObjectId)
	{
	    for (KillTask task : _aims)
	    {
	        if (task.aimObjectId == aimObjectId) // Procura pelo ID do ALVO ca�ado
	            return task;
	    }
	    return null;
	}
	
	
	public boolean checkItems(L2PcInstance player, int killsCount, int rewardItemId, int rewardItemCount)
	{
	    if (!Config.LIST_ALLOWED_ITEMS.contains(rewardItemId))
	        return false;
	    
	    ItemInstance rewardItem = player.getInventory().getItemByItemId(rewardItemId);
	    ItemInstance priceItem = player.getInventory().getItemByItemId(Config.PRICE_ITEMID);
	    
	    if (rewardItem == null || priceItem == null)
	        return false;
	        
	    // CORRIGIDO: O custo agora � o valor total direto digitado no painel, sem multiplicar
	    long totalCost = rewardItemCount;
	    
	    if (totalCost <= 0)
	        return false;
	    
	    if (rewardItemId == Config.PRICE_ITEMID)
	    {
	        return rewardItem.getCount() >= (totalCost + Config.PRICE_ITEMCOUNT);
	    }
	    else
	    {
	        return rewardItem.getCount() >= totalCost && priceItem.getCount() >= Config.PRICE_ITEMCOUNT;
	    }
	}
	
	public String getItemName(int id)
	{
	    return ItemTable.getInstance().getTemplate(id).getName();
	}
	
	public KillTask getTaskOfPlayer(int ownerObjId)
	{
		for (KillTask task : _aims)
		{
			if (task.ownerObjectId == ownerObjId)
				return task;
		}
		return null;
	}
	
	public KillTask getTaskById(int id)
	{
		for (KillTask task : _aims)
		{
			if (task.id == id)
				return task;
		}
		return null;
	}
	
	public int getTasksCount()
	{
		return _aims.size();
	}
	
	public List<KillTask> getKillTasks()
	{
		return _aims;
	}
	
	// No PlayerKillsManager.java
	public String getPriceList()
	{
	    StringBuilder sb = new StringBuilder();
	    for (int itemId : Config.LIST_ALLOWED_ITEMS)
	    {
	        String name = ItemTable.getInstance().getTemplate(itemId).getName();
	        // AGORA: Envia apenas o nome do item separado por ponto e v�rgula
	        sb.append(name).append(";");
	    }
	    return sb.toString();
	}
	
	public int getItemIdByName(String name)
	{
	    for (int itemId : Config.LIST_ALLOWED_ITEMS)
	    {
	        String templateName = ItemTable.getInstance().getTemplate(itemId).getName();
	        if (templateName.equalsIgnoreCase(name.trim()))
	        {
	            return itemId;
	        }
	    }
	    return 0; // Retorna 0 se n�o encontrar o item na lista de permitidos
	}
	
	private static void announceToAll(String message)
	{
		for (L2PcInstance player : L2World.getInstance().getPlayers())
			player.sendPacket(new CreatureSay(0, Say2.ANNOUNCEMENT, "", message));
	}
	
	protected void deleteFromDatabase(int taskId)
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
		     PreparedStatement ps = con.prepareStatement(DELETE_TASK))
		{
			ps.setInt(1, taskId);
			ps.execute();
		}
		catch (Exception e)
		{
			_log.log(Level.SEVERE, "PlayerKillsManager: Could not delete task from database.", e);
		}
	}
	
	protected void updateInDatabase(int taskId, int newCount)
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
		     PreparedStatement ps = con.prepareStatement(UPDATE_TASK))
		{
			ps.setInt(1, newCount);
			ps.setInt(2, taskId);
			ps.execute();
		}
		catch (Exception e)
		{
			_log.log(Level.SEVERE, "PlayerKillsManager: Could not update task in database.", e);
		}
	}
	
	public static PlayerKillsManager getInstance()
	{
		return SingletonHolder.INSTANCE;
	}
	
	private static class SingletonHolder
	{
		protected static final PlayerKillsManager INSTANCE = new PlayerKillsManager();
	}
	
	public class KillTask
	{
		public final int id;
		public final int ownerObjectId;
		public final int aimObjectId;
		public final String ownerName;
		public final String aimName;
		public int count;
		public final int rewardItemId;
		public final int rewardItemCount;
		public final long startTime;
		
		private final Map<String, Integer> killers;
		
		public KillTask(int id, int ownerObjectId, int aimObjectId, int count, int rewardItemId, int rewardItemCount, long startTime)
        {
            this.id = id;
            this.ownerObjectId = ownerObjectId;
            this.aimObjectId = aimObjectId;
            this.count = count;
            this.rewardItemId = rewardItemId;
            this.rewardItemCount = rewardItemCount;
            this.startTime = startTime;
            this.killers = new HashMap<>();
            
            // NOVO: Agora busca o nome real no Banco de Dados se a pessoa n�o estiver no jogo
            this.aimName = getCharName(aimObjectId);
            this.ownerName = getCharName(ownerObjectId);
        }
		
		protected void updateKills(String killerName, L2PcInstance killer)
		{
		    count--;
		    killers.merge(killerName, 1, Integer::sum);
		    
		    // CORRIGIDO: O contrato foi totalmente conclu�do (chegou a 0)
		    if (count == 0)
		    {
		        if (killer != null)
		        {
		            // O ca�ador que desferiu o golpe final que encerrou o contrato ganha o pr�mio total!
		            killer.addItem("l2killmanager", this.rewardItemId, this.rewardItemCount, null, true);
		            killer.sendMessage("Bounty Hunter: Parabens! Voce finalizou o contrato e recebeu a recompensa total!");
		        }
		        
		        _aims.remove(this);
		        deleteFromDatabase(this.id);
		    }
		    else
		    {
		        updateInDatabase(this.id, count);
		    }
		}
		
		public Map<String, Integer> getKillers()
		{
			return killers;
		}
	}
	
	/**
	 * Verifica se o jogador possui uma recompensa (bounty) ativa na cabe�a.
	 * @param player O jogador a ser verificado.
	 * @return true se houver recompensa, false caso contr�rio.
	 */
	public boolean hasBounty(L2PcInstance player) {
	    if (player == null)
	        return false;
	    
	    // Substitua abaixo pela l�gica real do seu gerenciador.
	    // Exemplo comum: verificar se o ID ou nome do player est� contido em um Map/List de alvos:
	    // return _bountyList.containsKey(player.getObjectId());
	    
	    return false; // Altere para retornar o resultado real da sua checagem
	}
	
	private class UpdateKillTasks implements Runnable
	{
	    @Override
	    public void run()
	    {
	        int removed = 0;
	        long now = System.currentTimeMillis();
	        // MUDAN�A AQUI: Adicione o prefixo Config.
	        long limit = Config.TASKS_DELETE_INTERVAL * 60 * 1000L;
	        
	        Iterator<KillTask> it = _aims.iterator();
	        while (it.hasNext())
	        {
	            KillTask task = it.next();
	            if ((task.startTime + limit) <= now)
	            {
	                _aims.remove(task);
	                deleteFromDatabase(task.id);
	                removed++;
	            }
	        }
	        if (removed > 0)
	            _log.info("PlayerKillsManager: " + removed + " orders expired and were removed from Database.");
	    }
	}
}
