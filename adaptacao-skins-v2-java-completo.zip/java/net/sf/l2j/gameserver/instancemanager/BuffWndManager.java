package net.sf.l2j.gameserver.instancemanager;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.w3c.dom.Element;
import org.w3c.dom.Node;

import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.datatables.SkillTable;
import net.sf.l2j.gameserver.model.L2Effect;
import net.sf.l2j.gameserver.model.L2Skill;
import net.sf.l2j.gameserver.model.actor.L2Character;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.entity.events.capturetheflag.CTFEvent;
import net.sf.l2j.gameserver.model.entity.events.deathmatch.DMEvent;
import net.sf.l2j.gameserver.model.entity.events.killtheboss.KTBEvent;
import net.sf.l2j.gameserver.model.entity.events.lastman.LMEvent;
import net.sf.l2j.gameserver.model.entity.events.teamvsteam.TvTEvent;
import net.sf.l2j.gameserver.model.olympiad.OlympiadManager;
import net.sf.l2j.gameserver.network.serverpackets.BuffWndPacket;
import net.sf.l2j.gameserver.network.serverpackets.ExShowScreenMessage;
import net.sf.l2j.gameserver.network.serverpackets.MagicSkillUse;
import net.sf.l2j.gameserver.xmlfactory.XMLDocumentFactory;

/**
 * Sistema exclusivo da interface BuffWnd.
 *
 * Catalogo: data/xml/buffwnd_skills.xml
 * Presets: tabela buffwnd_presets
 */
public final class BuffWndManager
{
    private static final Logger LOG =
        Logger.getLogger(BuffWndManager.class.getName());

    private static final String PREFIX = "BuffEngine_";
    private static final String PET = "_isServitor";

    private static final int MAX_PRESETS = 6;
    private static final int MAX_SKILLS = 40;

    private final Map<Integer, Buff> buffs = new LinkedHashMap<>();

    private static final class Buff
    {
        final L2Skill skill;
        final int category;
        final int price;
        final String auto;

        Buff(L2Skill skill, int category, int price, String auto)
        {
            this.skill = skill;
            this.category = category;
            this.price = price;
            this.auto = auto;
        }

        int packed()
        {
            return (skill.getId() << 8) | skill.getLevel();
        }
    }

    private static final class Preset
    {
        final int classId;
        final List<Buff> skills;

        Preset(int classId, List<Buff> skills)
        {
            this.classId = classId;
            this.skills = skills;
        }
    }

    private BuffWndManager()
    {
        loadCatalog();
    }

    private void loadCatalog()
    {
        try
        {
            final File file =
                new File("./data/xml/buffwnd_skills.xml");

            final Element root = XMLDocumentFactory.getInstance()
                .loadDocument(file)
                .getDocumentElement();

            final Map<Integer, Buff> loaded = new LinkedHashMap<>();
            final int[] counts = new int[6];

            for (
                Node node = root.getFirstChild();
                node != null;
                node = node.getNextSibling()
            )
            {
                if (!(node instanceof Element)
                    || !"category".equals(node.getNodeName()))
                {
                    continue;
                }

                final Element category = (Element) node;

                final int categoryId = Integer.parseInt(
                    category.getAttribute("id")
                );

                if (categoryId < -1 || categoryId > 5)
                {
                    throw new IllegalArgumentException(
                        "Categoria invalida: " + categoryId
                    );
                }

                for (
                    Node child = node.getFirstChild();
                    child != null;
                    child = child.getNextSibling()
                )
                {
                    if (!(child instanceof Element)
                        || !"buff".equals(child.getNodeName()))
                    {
                        continue;
                    }

                    final Element entry = (Element) child;

                    final int id = Integer.parseInt(
                        entry.getAttribute("id")
                    );

                    final int level = Integer.parseInt(
                        entry.getAttribute("level")
                    );

                    final int price = Integer.parseInt(
                        entry.getAttribute("price")
                    );

                    final String auto = entry.getAttribute("auto");

                    if (id <= 0
                        || id > 0x7FFFFF
                        || level <= 0
                        || level > 255
                        || price < 0)
                    {
                        throw new IllegalArgumentException(
                            "Configuracao invalida para a skill " + id
                        );
                    }

                    if (!auto.equals("both")
                        && !auto.equals("mage")
                        && !auto.equals("fighter")
                        && !auto.equals("none"))
                    {
                        throw new IllegalArgumentException(
                            "Modo automatico invalido para a skill " + id
                        );
                    }

                    if (loaded.containsKey(id))
                    {
                        throw new IllegalArgumentException(
                            "Skill duplicada: " + id
                        );
                    }

                    final L2Skill skill =
                        SkillTable.getInstance().getInfo(id, level);

                    if (skill == null)
                    {
                        LOG.warning(
                            "BuffWnd: skill inexistente "
                            + id + "," + level + ". Ignorada."
                        );
                        continue;
                    }

                    if (categoryId >= 0 && ++counts[categoryId] > 24)
                    {
                        throw new IllegalArgumentException(
                            "Categoria excede 24 skills: " + categoryId
                        );
                    }

                    loaded.put(
                        id,
                        new Buff(skill, categoryId, price, auto)
                    );
                }
            }

            if (loaded.isEmpty())
            {
                throw new IllegalArgumentException("Catalogo vazio.");
            }

            buffs.putAll(loaded);

            LOG.info(
                "BuffWnd: " + buffs.size() + " skills carregadas."
            );
        }
        catch (Exception e)
        {
            LOG.log(
                Level.SEVERE,
                "BuffWnd desativada: verifique buffwnd_skills.xml.",
                e
            );
        }
    }

    public boolean handle(L2PcInstance player, String command)
    {
        if (command == null
            || !(command.equals("BuffWnd")
                || command.startsWith(PREFIX)))
        {
            return false;
        }

        if (player == null)
        {
            return true;
        }

        try
        {
            synchronized (player)
            {
                String action = command.equals("BuffWnd")
                    ? "Open"
                    : command.substring(PREFIX.length());

                final boolean pet = action.endsWith(PET);

                if (pet)
                {
                    action = action.substring(
                        0,
                        action.length() - PET.length()
                    );
                }

                if (action.equals("Hide"))
                {
                    return true;
                }

                if (buffs.isEmpty())
                {
                    player.sendMessage(
                        "Buffer da interface indisponivel. "
                        + "Verifique o catalogo no servidor."
                    );
                    return true;
                }

                if (!allowed(player))
                {
                    return true;
                }

                if (action.equals("Open"))
                {
                    sendCategories(player);

                    player.sendPacket(
                        new BuffWndPacket(99978, 0, 0, 0, 0)
                    );
                    return true;
                }

                if (action.startsWith("GetPreset="))
                {
                    final int index = slot(action.substring(10));
                    sendPreset(player, index, false);
                    return true;
                }

                final L2Character target =
                    pet ? player.getPet() : player;

                if (target == null || target.isAlikeDead())
                {
                    player.sendMessage(
                        "O alvo nao existe ou esta morto."
                    );
                    return true;
                }

                if (target.isInCombat())
                {
                    player.sendMessage("O alvo esta em combate.");
                    return true;
                }

                if (action.equals("GetBuff=Heal"))
                {
                    heal(target);
                }
                else if (action.startsWith("Dispel="))
                {
                    final int skillId = Integer.parseInt(
                        action.substring(7)
                    );

                    if (skillId <= 0)
                    {
                        throw new IllegalArgumentException(
                            "ID invalido para remover buff."
                        );
                    }

                    dispel(target, skillId);
                }
                else if (action.equals("CancelAll"))
                {
                    target.stopAllEffects();
                }
                else if (action.equals("Automatic"))
                {
                    applyAutomatic(player, target);
                }
                else if (action.startsWith("GetBuff="))
                {
                    applySingle(player, target, action.substring(8));
                }
                else if (action.startsWith("CreatePreset=")
                    || action.startsWith("RefreshPreset="))
                {
                    saveCurrentEffects(player, target, action);
                }
                else if (action.startsWith("UsePreset="))
                {
                    final int index = slot(action.substring(10));
                    final Preset preset = load(player, index);

                    if (preset == null)
                    {
                        sendPreset(player, index, true);
                    }
                    else
                    {
                        apply(player, target, preset.skills);
                    }
                }
                else
                {
                    throw new IllegalArgumentException(
                        "Acao BuffWnd desconhecida."
                    );
                }
            }
        }
        catch (IllegalArgumentException e)
        {
            player.sendMessage(
                "Comando de buff invalido ou skill nao permitida."
            );
        }
        catch (Exception e)
        {
            LOG.log(
                Level.WARNING,
                "Erro na BuffWnd do personagem "
                + player.getObjectId(),
                e
            );

            player.sendMessage(
                "Nao foi possivel concluir a acao do buffer. "
                + "Consulte o log do servidor."
            );
        }

        return true;
    }

    private void sendCategories(L2PcInstance player)
    {
        for (int category = 0; category < 6; category++)
        {
            final List<Buff> list = new ArrayList<>();

            for (Buff buff : buffs.values())
            {
                if (buff.category == category)
                {
                    list.add(buff);
                }
            }

            sendList(player, 99970, category, list);
        }
    }

    private static void dispel(
        L2Character target,
        int skillId)
    {
        for (L2Effect effect : target.getAllEffects())
        {
            if (effect != null)
            {
                if (effect.getSkill().getId() == skillId)
                {
                    effect.exit();
                }
            }
        }
    }

    private static void heal(L2Character target)
    {
        target.getStatus().setCurrentHp(target.getMaxHp());
        target.getStatus().setCurrentMp(target.getMaxMp());

        if (target instanceof L2PcInstance)
        {
            final L2PcInstance playerTarget =
                (L2PcInstance) target;

            playerTarget.getStatus().setCurrentCp(
                playerTarget.getMaxCp()
            );
        }
    }

    private void applyAutomatic(
        L2PcInstance player,
        L2Character target)
    {
        final List<Buff> list = new ArrayList<>();

        final String mode = player.getClassId().isMage()
            ? "mage"
            : "fighter";

        for (Buff buff : buffs.values())
        {
            if (buff.auto.equals("both")
                || buff.auto.equals(mode))
            {
                list.add(buff);
            }
        }

        apply(player, target, list);
    }

    private void applySingle(
        L2PcInstance player,
        L2Character target,
        String arguments)
    {
        final String[] args = arguments.split(",", -1);

        if (args.length != 2)
        {
            throw new IllegalArgumentException(
                "Argumentos de skill invalidos."
            );
        }

        final int skillId = Integer.parseInt(args[0]);
        final int skillLevel = Integer.parseInt(args[1]);

        final Buff buff = buffs.get(skillId);

        if (buff == null || buff.skill.getLevel() != skillLevel)
        {
            throw new IllegalArgumentException(
                "Skill ou nivel nao permitido."
            );
        }

        final List<Buff> list = new ArrayList<>();
        list.add(buff);

        apply(player, target, list);
    }

    private void saveCurrentEffects(
        L2PcInstance player,
        L2Character target,
        String action) throws Exception
    {
        final int index = slot(
            action.substring(action.indexOf('=') + 1)
        );

        if (action.startsWith("CreatePreset=")
            && load(player, index) != null)
        {
            player.sendMessage(
                "Este preset ja existe. "
                + "Use atualizar para substitui-lo."
            );
            return;
        }

        final Map<Integer, Buff> snapshot =
            new LinkedHashMap<>();

        for (L2Effect effect : target.getAllEffects())
        {
            final Buff buff = buffs.get(
                effect.getSkill().getId()
            );

            if (buff != null && snapshot.size() < MAX_SKILLS)
            {
                snapshot.put(buff.skill.getId(), buff);
            }
        }

        save(
            player,
            index,
            new ArrayList<>(snapshot.values())
        );

        sendPreset(player, index, false);

        player.sendMessage(
            "Preset " + (index + 1) + " salvo."
        );
    }

    private static boolean allowed(L2PcInstance player)
    {
        final long now = System.currentTimeMillis();
        final long vipEnd = player.getVipEndTime();

        if (!player.isVip() || (vipEnd != 0L && vipEnd <= now))
        {
            final String message = vipEnd > 0L && vipEnd <= now
                ? "VIP expirado. Renove para usar."
                : "Buffer exclusivo para VIP.";

            player.sendPacket(
                new ExShowScreenMessage(
                    "CustomEvent=BuffAccessV1|DENIED",
                    1
                )
            );

            player.sendMessage(message);

            player.sendPacket(
                new ExShowScreenMessage(message, 4000)
            );

            return false;
        }

        final int objectId = player.getObjectId();

        if (player.isAlikeDead()
            || player.isInCombat()
            || player.isInOlympiadMode()
            || OlympiadManager.getInstance().isRegistered(player)
            || player.inObserverMode()
            || player.isCursedWeaponEquipped()
            || player.isInArenaEvent()
            || player.getKarma() > 0
            || CTFEvent.isPlayerParticipant(objectId)
            || DMEvent.isPlayerParticipant(objectId)
            || LMEvent.isPlayerParticipant(objectId)
            || TvTEvent.isPlayerParticipant(objectId)
            || KTBEvent.isPlayerParticipant(objectId))
        {
            player.sendMessage(
                "Buffer indisponivel neste estado: "
                + "morte, combate, evento, karma ou observador."
            );

            return false;
        }

        return true;
    }

    private static int slot(String text)
    {
        final int value = Integer.parseInt(text);

        if (value < 0 || value >= MAX_PRESETS)
        {
            throw new IllegalArgumentException(
                "Slot de preset invalido."
            );
        }

        return value;
    }

    private static void apply(
        L2PcInstance player,
        L2Character target,
        List<Buff> list)
    {
        long price = 0;

        for (Buff buff : list)
        {
            price += buff.price;
        }

        if (price > Integer.MAX_VALUE)
        {
            throw new IllegalArgumentException(
                "Preco total excede o limite."
            );
        }

        if (price > 0
            && !player.destroyItemByItemId(
                "BuffWnd",
                57,
                (int) price,
                player,
                true))
        {
            return;
        }

        for (Buff buff : list)
        {
            buff.skill.getEffects(player, target);

            target.broadcastPacket(
                new MagicSkillUse(
                    target,
                    target,
                    buff.skill.getId(),
                    buff.skill.getLevel(),
                    0,
                    0
                )
            );
        }
    }

    private static void sendList(
        L2PcInstance player,
        int tag,
        int key,
        List<Buff> list)
    {
        if (list.isEmpty())
        {
            player.sendPacket(
                new BuffWndPacket(tag, key, 0, 0, 1)
            );
            return;
        }

        for (int i = 0; i < list.size(); i++)
        {
            final int flags =
                i == list.size() - 1 ? 1 : 0;

            player.sendPacket(
                new BuffWndPacket(
                    tag,
                    key,
                    list.get(i).packed(),
                    i,
                    flags
                )
            );
        }
    }

    private void sendPreset(
        L2PcInstance player,
        int index,
        boolean missing) throws Exception
    {
        final Preset preset =
            missing ? null : load(player, index);

        if (preset == null)
        {
            player.sendPacket(
                new BuffWndPacket(99971, index, 0, 0, 2)
            );
            return;
        }

        final int key = preset.classId * 8 + index;

        sendList(player, 99971, key, preset.skills);
    }

    private Preset load(
        L2PcInstance player,
        int index) throws Exception
    {
        final String query =
            "SELECT class_id, skills "
            + "FROM buffwnd_presets "
            + "WHERE object_id=? AND slot=?";

        try (
            Connection con =
                L2DatabaseFactory.getInstance().getConnection();

            PreparedStatement statement =
                con.prepareStatement(query)
        )
        {
            statement.setInt(1, player.getObjectId());
            statement.setInt(2, index);

            try (ResultSet result = statement.executeQuery())
            {
                if (!result.next())
                {
                    return null;
                }

                final Map<Integer, Buff> unique =
                    new LinkedHashMap<>();

                final String[] savedSkills =
                    result.getString("skills").split(",");

                for (String value : savedSkills)
                {
                    if (value.isEmpty())
                    {
                        continue;
                    }

                    final Buff buff = buffs.get(
                        Integer.parseInt(value)
                    );

                    if (buff != null && unique.size() < MAX_SKILLS)
                    {
                        unique.put(buff.skill.getId(), buff);
                    }
                }

                return new Preset(
                    result.getInt("class_id"),
                    new ArrayList<>(unique.values())
                );
            }
        }
    }

    private static void save(
        L2PcInstance player,
        int index,
        List<Buff> list) throws Exception
    {
        final StringBuilder skills = new StringBuilder();

        for (Buff buff : list)
        {
            if (skills.length() > 0)
            {
                skills.append(',');
            }

            skills.append(buff.skill.getId());
        }

        final String query =
            "INSERT INTO buffwnd_presets "
            + "(object_id, slot, class_id, skills) "
            + "VALUES (?, ?, ?, ?) "
            + "ON DUPLICATE KEY UPDATE "
            + "class_id=VALUES(class_id), "
            + "skills=VALUES(skills)";

        try (
            Connection con =
                L2DatabaseFactory.getInstance().getConnection();

            PreparedStatement statement =
                con.prepareStatement(query)
        )
        {
            statement.setInt(1, player.getObjectId());
            statement.setInt(2, index);
            statement.setInt(3, player.getClassId().getId());
            statement.setString(4, skills.toString());

            statement.executeUpdate();
        }
    }

    public static BuffWndManager getInstance()
    {
        return Singleton.INSTANCE;
    }

    private static final class Singleton
    {
        private static final BuffWndManager INSTANCE =
            new BuffWndManager();
    }
}