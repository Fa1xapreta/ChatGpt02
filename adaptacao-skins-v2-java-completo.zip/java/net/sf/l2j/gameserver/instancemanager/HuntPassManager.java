package net.sf.l2j.gameserver.instancemanager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.cache.HtmCache;
import net.sf.l2j.gameserver.datatables.HuntPassData;
import net.sf.l2j.gameserver.datatables.HuntPassData.LevelReward;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.model.actor.L2Attackable;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.item.kind.Item;
import net.sf.l2j.gameserver.network.serverpackets.ExShowScreenMessage;
import net.sf.l2j.gameserver.network.serverpackets.ExShowScreenMessage.SMPOS;
import net.sf.l2j.gameserver.network.serverpackets.ItemList;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;


public final class HuntPassManager

{
	private static final Logger _log = Logger.getLogger(HuntPassManager.class.getName());
	public static final int EVENT_SHOW = 28632;
	public static final int EVENT_HIDE = 28633;
	public static final int EVENT_REWARDS = 28634;
	public static final int EVENT_PROGRESS = 28635;
	public static final int EVENT_INFO = 28636;
	private final Map<Integer, PlayerPass> _cache = new ConcurrentHashMap<>();
	private final Map<Integer, Long> _uiWatchUntil = new ConcurrentHashMap<>();
	private final Map<Integer, Integer> _uiLastPage = new ConcurrentHashMap<>();
	private static final long UI_WATCH_MS = 8000L;

	protected HuntPassManager()

	{

		HuntPassData.getInstance();

		_log.info("HuntPassManager: (Interface Hunt Pass Loading...)");

	}

	public static HuntPassManager getInstance()
	{
		return SingletonHolder._instance;
	}

	public void handle(L2PcInstance player, String rest)

	{
		if (player == null)

			return;

		if (!HuntPassData.ENABLED)

		{
			player.sendMessage("Hunt Pass is disabled.");

			return;
		}

		rest = rest == null ? "" : rest.trim();

		if (rest.isEmpty())

		{
			refreshPassInfo(player, 1);

			return;
		}

		final String[] parts = rest.split("\\s+");
		final String action = parts[0];

		try

		{
			if (action.equalsIgnoreCase("RefreshPassInfo"))

			{
				final int page = parts.length > 1 ? Integer.parseInt(parts[1]) : 1;
				refreshPassInfo(player, page);
			}
			else if (action.equalsIgnoreCase("_huntpassinterface"))
			{
				refreshPassInfo(player, 1);
			}

			else if (action.equalsIgnoreCase("Slot"))
			{
				if (parts.length < 3)

					return;

				final int level = Integer.parseInt(parts[1]);

				final boolean premium = parts[2].equalsIgnoreCase("Premium");

				final int page = parts.length > 3 ? Integer.parseInt(parts[3]) : 1;

				claimSlot(player, level, premium, page);
			}
			else if (action.equalsIgnoreCase("BuyPreInterface"))
			{
				final int page = parts.length > 1 ? Integer.parseInt(parts[1]) : 1;

				buyPremium(player, page);
			}

			else if (action.equalsIgnoreCase("ResetPassInterface"))
			{
				final int page = parts.length > 1 ? Integer.parseInt(parts[1]) : 1;

				resetPass(player, page);
			}
			else if (action.equalsIgnoreCase("rewardinterface"))
			{
				final int page = parts.length > 1 ? Integer.parseInt(parts[1]) : 1;
				claimAll(player, page);
			}

			else if (action.equalsIgnoreCase("TransferHWID") || action.equalsIgnoreCase("PayHuntPass")) {
				payHuntPass(player);
			}
			else
				_log.warning("HuntPass: unknown action '" + action + "' from " + player.getName());
		}

		catch (Exception e)

		{

			_log.log(Level.WARNING, "HuntPass handle failed for " + player.getName() + ": " + rest, e);

			player.sendMessage("Hunt Pass error.");
		}
	}

	public void onMonsterKill(L2PcInstance killer, L2Attackable mob)
	{
		if (!HuntPassData.ENABLED || killer == null || mob == null || killer.isDead())

			return;

		// === VALIDA��O DOS MOBS PERMITIDOS NO HUNT PASS ===
	    if (!HuntPassData.isAllowedMob(mob.getNpcId()))
	        return;
	    // ==================================================
		
		int add = HuntPassData.SCORE_MONSTER;

		if (mob.isRaid() && !mob.isRaidMinion())

			add = HuntPassData.SCORE_RAID;

		if (add <= 0)

			return;

		final PlayerPass data = load(killer.getObjectId());

		data.huntingScore += add;

		recalcLevel(data);

		save(data);

		_cache.put(data.charId, data);

		final Long until = _uiWatchUntil.get(killer.getObjectId());

		if (until != null && until.longValue() > System.currentTimeMillis())

			pushLiveProgress(killer, data);
	}

	public void refreshPassInfo(L2PcInstance player, int page)
	{
		if (!validateHwidRestriction(player))
		{
			return; 
		}

		final PlayerPass data = load(player.getObjectId());

		String currentHwid = (player.getClient() != null) ? player.getClient().getHWID() : "";

		if (currentHwid != null && !currentHwid.isEmpty() && !currentHwid.equals(data.hwid))
		{
			data.hwid = currentHwid;
			save(data);
		}

		page = clampPage(page);

		_uiWatchUntil.put(player.getObjectId(), System.currentTimeMillis() + UI_WATCH_MS);
		_uiLastPage.put(player.getObjectId(), Integer.valueOf(page));

		if (player == null || !player.isOnline())
			return;

		// Envio direto sem delay para responder instantaneamente ao clique
		sendEvent(player, String.valueOf(EVENT_SHOW));
		sendInfo(player, data, page);
		sendRewards(player, page);
		sendProgress(player, data, page);
	}

	public boolean validateHwidRestriction(L2PcInstance player) {
		if (player == null)
			return false;
		final String playerHwid = getPlayerHwid(player);
		if (playerHwid.isEmpty()) {
			player.sendMessage("Hunt Pass: HWID n�o dispon�vel. Tente relogar no jogo.");
			return false;
		}
		final int myCharId = player.getObjectId();
		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
				PreparedStatement ps = con
						.prepareStatement("SELECT char_id FROM huntpass_hwid_access WHERE hwid=? LIMIT 1")) {
			ps.setString(1, playerHwid);
			try (ResultSet rs = ps.executeQuery()) {
				if (!rs.next()) {
					// Primeira vez do HWID abrindo o pass - Cobran�a direta
					return processFirstAccess(player, playerHwid, myCharId);
				}
				final int ownerId = rs.getInt("char_id");
				if (ownerId == myCharId)
					return true; // � o dono, acesso livre.
					
				String ownerName = "Outro Personagem";
				try (PreparedStatement psName = con
						.prepareStatement("SELECT char_name FROM characters WHERE obj_Id=?")) {
					psName.setInt(1, ownerId);
					try (ResultSet rsName = psName.executeQuery()) {
						if (rsName.next())
							ownerName = rsName.getString("char_name");
					}
				}
				// Outro char do mesmo HWID - Abre o HTML para transfer�ncia
				showTransferWindow(player, ownerName, false);
				return false;
			}
		} catch (Exception e) {
			_log.log(Level.WARNING, "HuntPassManager: Error validating HWID restriction for " + player.getName(), e);
		}
		return false;
	}

	// NOVO: M�todo dedicado a cobrar e registrar o jogador no primeiro uso
	private boolean processFirstAccess(L2PcInstance player, String playerHwid, int myCharId) {
		final int itemId = HuntPassData.HUNT_PASS_ACCESS_ITEM_ID;
		final int cost = HuntPassData.HUNT_PASS_ACCESS_COST;

		if (itemId <= 0 || cost <= 0) {
			_log.warning("HuntPassManager: HuntPassAccessItemId/HuntPassAccessCost inv�lidos no XML.");
			player.sendMessage("Hunt Pass: cobran�a configurada incorretamente.");
			return false;
		}

		final int have = player.getInventory().getInventoryItemCount(itemId, -1);
		if (have < cost) {
			player.sendPacket(new ExShowScreenMessage("Voce nao possui " + cost + "x " + itemName(itemId) + " para abrir o Hunt Pass.", 10000, SMPOS.TOP_CENTER, false));
			return false;
		}

		if (!player.destroyItemByItemId("HuntPassFirstAccess", itemId, cost, player, true)) {
			return false;
		}

		final long now = System.currentTimeMillis();
		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
				PreparedStatement ins = con.prepareStatement("INSERT INTO huntpass_hwid_access (hwid, char_id, paid, paid_item_id, paid_at) VALUES (?,?,?,?,?)")) {
			ins.setString(1, playerHwid);
			ins.setInt(2, myCharId);
			ins.setInt(3, 1);
			ins.setInt(4, itemId);
			ins.setLong(5, now);
			ins.executeUpdate();
		} catch (Exception e) {
			_log.log(Level.WARNING, "HuntPassManager: Error saving first access for " + player.getName(), e);
			try {
				player.addItem("HuntPassAccessRefund", itemId, cost, player, true);
			} catch (Exception refundError) {}
			return false;
		}

		final PlayerPass data = load(myCharId);
		data.hwid = playerHwid;
		save(data);
		_cache.put(myCharId, data);
		
		player.sendPacket(new ItemList(player, false));
		player.sendMessage("Hunt Pass ativado com sucesso!");
		return true; // Retorna true para que o fluxo em 'refreshPassInfo' prossiga e abra a interface
	}

	private String getPlayerHwid(L2PcInstance player) {
		if (player == null || player.getClient() == null)
			return "";
		final String hwid = player.getClient().getHWID();
		return hwid == null ? "" : hwid.trim();
	}

	private void showTransferWindow(L2PcInstance player, String oldCharName) {
		showTransferWindow(player, oldCharName, false);
	}

	private void showTransferWindow(L2PcInstance player, String oldCharName, boolean firstAccess) {
		final NpcHtmlMessage html = new NpcHtmlMessage(0);
		String content = HtmCache.getInstance().getHtm("data/html/Hunt_PassIndex.htm");
		if (content == null) {
			player.sendMessage("Erro: Hunt_PassIndex.htm n�o foi encontrado.");
			return;
		}
		content = content.replace("OLD_CHAR_NAME", oldCharName == null ? "Outro Personagem" : oldCharName);
		content = content.replace("PLAYER_NAME", player.getName());
		content = content.replace("ACCESS_ITEM_ID", String.valueOf(HuntPassData.HUNT_PASS_ACCESS_ITEM_ID));
		content = content.replace("ACCESS_ITEM_QTY", String.valueOf(HuntPassData.HUNT_PASS_ACCESS_COST));
		content = content.replace("ACCESS_ITEM_NAME", itemName(HuntPassData.HUNT_PASS_ACCESS_ITEM_ID));
		content = content.replace("ACCESS_FIRST", firstAccess ? "1" : "0");
		html.setHtml(content);
		player.sendPacket(html);
	}

	public synchronized void payHuntPass(L2PcInstance player) {
		if (player == null || !HuntPassData.ENABLED)
			return;

		final String playerHwid = getPlayerHwid(player);
		if (playerHwid.isEmpty()) {
			player.sendMessage("Hunt Pass: HWID n�o dispon�vel. Tente relogar no jogo.");
			return;
		}

		final int myCharId = player.getObjectId();
		final int itemId = HuntPassData.HUNT_PASS_ACCESS_ITEM_ID;
		final int cost = HuntPassData.HUNT_PASS_ACCESS_COST;

		if (itemId <= 0 || cost <= 0) {
			_log.warning("HuntPassManager: HuntPassAccessItemId/HuntPassAccessCost inv�lidos no XML.");
			player.sendMessage("Hunt Pass: cobran�a configurada incorretamente.");
			return;
		}

		boolean charged = false;
		try (Connection con = L2DatabaseFactory.getInstance().getConnection()) {
			int ownerId = 0;
			try (PreparedStatement ps = con
					.prepareStatement("SELECT char_id FROM huntpass_hwid_access WHERE hwid=? LIMIT 1")) {
				ps.setString(1, playerHwid);
				try (ResultSet rs = ps.executeQuery()) {
					if (rs.next())
						ownerId = rs.getInt("char_id");
				}
			}

			if (ownerId == myCharId) {
				final PlayerPass data = load(myCharId);
				data.hwid = playerHwid;
				save(data);
				player.sendMessage("Hunt Pass j� est� liberado para este personagem.");
				refreshPassInfo(player, 1);
				return;
			}

			final int have = player.getInventory().getInventoryItemCount(itemId, -1);
			if (have < cost) {
				// Tela para informar falha de item na transfer�ncia tamb�m
				player.sendPacket(new ExShowScreenMessage("Voce nao possui os " + cost + "x " + itemName(itemId) + " .", 5000, SMPOS.TOP_CENTER, false));
				return;
			}

			if (!player.destroyItemByItemId("HuntPassAccess", itemId, cost, player, true))
				return;
			charged = true;

			final long now = System.currentTimeMillis();
			con.setAutoCommit(false);
			try {
				if (ownerId > 0) {
					try (PreparedStatement ps = con
							.prepareStatement("UPDATE character_battle_pass SET hwid='' WHERE char_id=?")) {
						ps.setInt(1, ownerId);
						ps.executeUpdate();
					}
				}

				try (PreparedStatement ps = con.prepareStatement(
						"UPDATE huntpass_hwid_access SET char_id=?, paid=1, paid_item_id=?, paid_at=? WHERE hwid=?")) {
					ps.setInt(1, myCharId);
					ps.setInt(2, itemId);
					ps.setLong(3, now);
					ps.setString(4, playerHwid);
					final int updated = ps.executeUpdate();
					if (updated == 0) {
						try (PreparedStatement ins = con.prepareStatement(
								"INSERT INTO huntpass_hwid_access (hwid, char_id, paid, paid_item_id, paid_at) VALUES (?,?,?,?,?)")) {
							ins.setString(1, playerHwid);
							ins.setInt(2, myCharId);
							ins.setInt(3, 1);
							ins.setInt(4, itemId);
							ins.setLong(5, now);
							ins.executeUpdate();
						}
					}
				}

				con.commit();
			} catch (Exception e) {
				try {
					con.rollback();
				} catch (Exception ignored) {
				}
				throw e;
			} finally {
				try {
					con.setAutoCommit(true);
				} catch (Exception ignored) {
				}
			}

			if (ownerId > 0) {
				final PlayerPass oldData = _cache.get(ownerId);
				if (oldData != null)
					oldData.hwid = "";
			}

			final PlayerPass data = load(myCharId);
			data.hwid = playerHwid;
			save(data);
			_cache.put(myCharId, data);

			player.sendPacket(new ItemList(player, false));
			if (ownerId > 0)
				player.sendMessage("Hunt Pass transferido com sucesso! O acesso deste HWID agora pertence a "
						+ player.getName() + ".");
			else
				player.sendMessage("Hunt Pass liberado com sucesso!");

			refreshPassInfo(player, 1);
		} catch (Exception e) {
			if (charged) {
				try {
					player.addItem("HuntPassAccessRefund", itemId, cost, player, true);
					player.sendPacket(new ItemList(player, false));
				} catch (Exception refundError) {
					_log.log(Level.SEVERE,
							"HuntPassManager: Could not refund Hunt Pass access item to " + player.getName(),
							refundError);
				}
			}
			_log.log(Level.WARNING, "HuntPassManager: Error paying Hunt Pass access for " + player.getName(), e);
			player.sendMessage(
					"N�o foi poss�vel liberar o Hunt Pass. O item foi devolvido, se a cobran�a foi realizada.");
		}
	}

	public void transferBattlePassToChar(L2PcInstance player) {
		payHuntPass(player);
	}

	private void pushLiveProgress(L2PcInstance player, PlayerPass data)

	{

		if (player == null || !player.isOnline())

			return;

		final Integer pageObj = _uiLastPage.get(player.getObjectId());

		final int page = pageObj != null ? pageObj.intValue() : 1;

		sendInfo(player, data, page);

		sendProgress(player, data, page);

	}

	private void claimSlot(L2PcInstance player, int level, boolean premium, int page)

	{

		final LevelReward lr = HuntPassData.getInstance().getLevel(level);

		if (lr == null)

		{

			player.sendMessage("Invalid Hunt Pass level.");

			return;

		}

		final PlayerPass data = load(player.getObjectId());

		if (data.huntingScore < lr.requiredScore)

		{

			player.sendMessage("Not enough Hunting Score for this level.");

			refreshPassInfo(player, page);

			return;

		}

		if (premium)

		{

			if (!data.premium)

			{

				player.sendMessage("Activate Premium Pass first.");

				refreshPassInfo(player, page);

				return;

			}

			if (data.premiumClaimed.contains(level))

			{

				player.sendMessage("Premium reward already claimed.");

				refreshPassInfo(player, page);

				return;

			}

			player.addItem("HuntPass", lr.premiumItemId, lr.premiumCount, player, true);

			data.premiumClaimed.add(level);

		}

		else

		{

			if (data.freeClaimed.contains(level))

			{

				player.sendMessage("Free reward already claimed.");

				refreshPassInfo(player, page);

				return;

			}

			player.addItem("HuntPass", lr.freeItemId, lr.freeCount, player, true);

			data.freeClaimed.add(level);

		}

		save(data);

		_cache.put(data.charId, data);

		player.sendPacket(new ItemList(player, false));

		player.sendMessage("Hunt Pass reward claimed.");

		refreshPassInfo(player, page);

	}

	private void claimAll(L2PcInstance player, int page)

	{

		final PlayerPass data = load(player.getObjectId());

		int claimed = 0;

		for (LevelReward lr : HuntPassData.getInstance().getLevels().values())

		{

			if (data.huntingScore < lr.requiredScore)

				continue;

			if (!data.freeClaimed.contains(lr.level))

			{

				player.addItem("HuntPass", lr.freeItemId, lr.freeCount, player, true);

				data.freeClaimed.add(lr.level);

				claimed++;

			}

			if (data.premium && !data.premiumClaimed.contains(lr.level))

			{

				player.addItem("HuntPass", lr.premiumItemId, lr.premiumCount, player, true);

				data.premiumClaimed.add(lr.level);

				claimed++;

			}

		}

		if (claimed <= 0)

		{

			player.sendMessage("No Hunt Pass rewards to claim.");

			refreshPassInfo(player, page);

			return;

		}

		save(data);

		_cache.put(data.charId, data);

		player.sendPacket(new ItemList(player, false));

		player.sendMessage("Claimed " + claimed + " Hunt Pass reward(s).");

		refreshPassInfo(player, page);

	}

	private void buyPremium(L2PcInstance player, int page)
	{
	    final PlayerPass data = load(player.getObjectId());

	    if (data.premium)
	    {
	        player.sendMessage("Premium Pass already active.");
	        refreshPassInfo(player, page);
	        return;
	    }

	    final int have = player.getInventory().getInventoryItemCount(HuntPassData.COIN_ITEM_ID, -1);

	    if (have < HuntPassData.PREMIUM_COST)
	    {
	        player.sendMessage("Not enough coins to activate Premium Pass.");
	        return;
	    }

	    if (!player.destroyItemByItemId("HuntPassPremium", HuntPassData.COIN_ITEM_ID, HuntPassData.PREMIUM_COST, player, true))
	        return;

	    data.premium = true;
	    save(data);
	    _cache.put(data.charId, data);

	    player.sendMessage("Premium Hunt Pass activated!");
	    
	    // Garante que a interface vai atualizar e enviar a flag "is_premium=1" / "vip_status=1" para o cliente pintar a fonte
	    refreshPassInfo(player, page);
	}

	private void resetPass(L2PcInstance player, int page)

	{

		final int have = player.getInventory().getInventoryItemCount(HuntPassData.COIN_ITEM_ID, -1);

		if (have < HuntPassData.RESET_COST)

		{

			player.sendMessage("Not enough coins to reset Hunt Pass.");

			return;

		}

		if (!player.destroyItemByItemId("HuntPassReset", HuntPassData.COIN_ITEM_ID, HuntPassData.RESET_COST, player,
				true))

			return;

		final PlayerPass data = load(player.getObjectId());

		data.huntingScore = 0;

		data.currentLevel = 0;

		data.premium = false;

		data.freeClaimed.clear();

		data.premiumClaimed.clear();

		save(data);

		_cache.put(data.charId, data);

		player.sendMessage("Hunt Pass reset.");

		refreshPassInfo(player, 1);

	}

	private void sendInfo(L2PcInstance player, PlayerPass data, int page)

	{

		final StringBuilder sb = new StringBuilder(256);

		sb.append(EVENT_INFO);

		sb.append(" expiration_date=").append(HuntPassData.EXPIRATION_DATE);

		sb.append(" is_premium=").append(data.premium ? 1 : 0);

		sb.append(" vip_status=").append(data.premium ? 1 : 0);

		sb.append(" page=").append(page);

		sb.append(" maxpage=").append(HuntPassData.getInstance().getMaxPage());

		sb.append(" current_level=").append(data.currentLevel);

		sb.append(" onlyplayerpoint=").append(data.huntingScore);

		sb.append(" maxhuntpasspoint=").append(HuntPassData.getInstance().getMaxRequiredScore());

		sb.append(" premium_price=").append(HuntPassData.PREMIUM_COST);

		sb.append(" premium_price_id=").append(HuntPassData.COIN_ITEM_ID);

		sb.append(" premium_item_qty=").append(HuntPassData.PREMIUM_COST);

		sb.append(" premium_item_name=").append(toCeToken(itemName(HuntPassData.COIN_ITEM_ID)));
		sb.append(" access_price=").append(HuntPassData.HUNT_PASS_ACCESS_COST);
		sb.append(" access_price_id=").append(HuntPassData.HUNT_PASS_ACCESS_ITEM_ID);
		sb.append(" access_item_qty=").append(HuntPassData.HUNT_PASS_ACCESS_COST);
		sb.append(" access_item_name=").append(toCeToken(itemName(HuntPassData.HUNT_PASS_ACCESS_ITEM_ID)));

		sendEvent(player, sb.toString());

	}

	private void sendRewards(L2PcInstance player, int page)

	{

		final int per = HuntPassData.LEVELS_PER_PAGE;

		final int startLevel = (page - 1) * per + 1;

		final StringBuilder sb = new StringBuilder(512);

		sb.append(EVENT_REWARDS);

		for (int slot = 0; slot < per; slot++)

		{

			final int level = startLevel + slot;

			final LevelReward lr = HuntPassData.getInstance().getLevel(level);

			if (lr == null)

				break;

			sb.append(" n_id_").append(slot).append('=').append(lr.freeItemId);

			sb.append(" n_co_").append(slot).append('=').append(lr.freeCount);

			sb.append(" normal_level_").append(slot).append('=').append(level);

			sb.append(" p_id_").append(slot).append('=').append(lr.premiumItemId);

			sb.append(" p_co_").append(slot).append('=').append(lr.premiumCount);

			sb.append(" premium_level_").append(slot).append('=').append(level);

		}

		sendEvent(player, sb.toString());

	}

	private void sendProgress(L2PcInstance player, PlayerPass data, int page)

	{

		final int per = HuntPassData.LEVELS_PER_PAGE;

		final int startLevel = (page - 1) * per + 1;

		final StringBuilder sb = new StringBuilder(384);

		sb.append(EVENT_PROGRESS);

		sb.append(" onlyplayerpoint=").append(data.huntingScore);

		for (int slot = 0; slot < per; slot++)

		{

			final int level = startLevel + slot;

			final LevelReward lr = HuntPassData.getInstance().getLevel(level);

			if (lr == null)

				break;

			sb.append(" n_p_").append(slot).append('=').append(lr.requiredScore);

			sb.append(" n_cm_").append(slot).append('=').append(data.freeClaimed.contains(level) ? 1 : 0);

			sb.append(" p_cm_").append(slot).append('=').append(data.premiumClaimed.contains(level) ? 1 : 0);

		}

		sendEvent(player, sb.toString());

	}

	private static void sendEvent(L2PcInstance player, String payload)

	{

		player.sendPacket(new ExShowScreenMessage("CustomEvent=" + payload, 1, SMPOS.TOP_LEFT, false));

	}

	private static int clampPage(int page)

	{

		final int max = HuntPassData.getInstance().getMaxPage();

		if (page < 1)

			return 1;

		if (page > max)

			return max;

		return page;

	}

	private static void recalcLevel(PlayerPass data)

	{

		int lv = 0;

		for (LevelReward lr : HuntPassData.getInstance().getLevels().values())

		{

			if (data.huntingScore >= lr.requiredScore && lr.level > lv)

				lv = lr.level;

		}

		data.currentLevel = lv;

	}

	private static String itemName(int itemId)

	{

		final Item item = ItemTable.getInstance().getTemplate(itemId);

		return item != null ? item.getName() : ("Item_" + itemId);

	}

	private static String toCeToken(String s)

	{

		if (s == null || s.isEmpty())

			return "_";

		return s.replace(' ', '_');

	}

	private PlayerPass load(int charId)

	{

		final PlayerPass cached = _cache.get(charId);

		if (cached != null)

			return cached;

		final PlayerPass data = new PlayerPass(charId);

		try (Connection con = L2DatabaseFactory.getInstance().getConnection();

				PreparedStatement ps = con.prepareStatement(
						"SELECT hunting_score, current_level, premium_active, hwid FROM character_battle_pass WHERE char_id=?"))

		{

			ps.setInt(1, charId);

			try (ResultSet rs = ps.executeQuery())

			{

				if (rs.next())

				{

					data.huntingScore = rs.getInt("hunting_score");

					data.currentLevel = rs.getInt("current_level");

					data.premium = rs.getInt("premium_active") != 0;

					data.hwid = rs.getString("hwid"); 

				}

			}

			try (PreparedStatement ps2 = con.prepareStatement(
					"SELECT level, free_claimed, premium_claimed FROM character_battle_pass_claims WHERE char_id=?"))

			{

				ps2.setInt(1, charId);

				try (ResultSet rs2 = ps2.executeQuery())

				{

					while (rs2.next())

					{

						final int level = rs2.getInt("level");

						if (rs2.getInt("free_claimed") != 0)

							data.freeClaimed.add(level);

						if (rs2.getInt("premium_claimed") != 0)

							data.premiumClaimed.add(level);

					}

				}

			}

		}

		catch (Exception e)

		{

			_log.log(Level.WARNING,
					"HuntPass load failed charId=" + charId + " (run character_hunt_pass.sql?). " + e.getMessage());

		}

		recalcLevel(data);

		_cache.put(charId, data);

		return data;

	}

	private void save(PlayerPass data)

	{

		try (Connection con = L2DatabaseFactory.getInstance().getConnection())

		{

			boolean exists = false;

			try (PreparedStatement chk = con
					.prepareStatement("SELECT char_id FROM character_battle_pass WHERE char_id=?"))

			{

				chk.setInt(1, data.charId);

				try (ResultSet rs = chk.executeQuery())

				{

					exists = rs.next();

				}

			}

			if (exists)

			{

				try (PreparedStatement ps = con.prepareStatement(
						"UPDATE character_battle_pass SET hunting_score=?, current_level=?, premium_active=?, last_updated=?, hwid=? WHERE char_id=?"))

				{

					ps.setInt(1, data.huntingScore);

					ps.setInt(2, data.currentLevel);

					ps.setInt(3, data.premium ? 1 : 0);

					ps.setLong(4, System.currentTimeMillis());

					ps.setString(5, data.hwid);

					ps.setInt(6, data.charId);

					ps.executeUpdate();

				}

			}

			else

			{

				try (PreparedStatement ps = con.prepareStatement(
						"INSERT INTO character_battle_pass (char_id, hunting_score, current_level, premium_active, cycle_id, last_updated, hwid) VALUES (?,?,?,?,1,?,?)"))

				{

					ps.setInt(1, data.charId);

					ps.setInt(2, data.huntingScore);

					ps.setInt(3, data.currentLevel);

					ps.setInt(4, data.premium ? 1 : 0);

					ps.setLong(5, System.currentTimeMillis());

					ps.setString(6, data.hwid);

					ps.executeUpdate();

				}

			}

			try (PreparedStatement del = con
					.prepareStatement("DELETE FROM character_battle_pass_claims WHERE char_id=?"))

			{

				del.setInt(1, data.charId);

				del.executeUpdate();

			}

			final Set<Integer> levels = new HashSet<>();

			levels.addAll(data.freeClaimed);

			levels.addAll(data.premiumClaimed);

			try (PreparedStatement ins = con.prepareStatement(
					"INSERT INTO character_battle_pass_claims (char_id, level, free_claimed, premium_claimed) VALUES (?,?,?,?)"))

			{

				for (int level : levels)

				{

					ins.setInt(1, data.charId);

					ins.setInt(2, level);

					ins.setInt(3, data.freeClaimed.contains(level) ? 1 : 0);

					ins.setInt(4, data.premiumClaimed.contains(level) ? 1 : 0);

					ins.addBatch();

				}

				ins.executeBatch();

			}

		}

		catch (Exception e)

		{

			_log.log(Level.WARNING, "HuntPass save failed charId=" + data.charId + ": " + e.getMessage());

		}

	}

	public void onLogout(int charId)

	{

		_cache.remove(charId);

	}

	private static final class PlayerPass

	{

		final int charId;

		int huntingScore;

		int currentLevel;

		boolean premium;

		String hwid = "";

		final Set<Integer> freeClaimed = new HashSet<>();

		final Set<Integer> premiumClaimed = new HashSet<>();

		PlayerPass(int charId)

		{

			this.charId = charId;

		}

	}

	private static class SingletonHolder

	{

		protected static final HuntPassManager _instance = new HuntPassManager();

	}
}