package net.sf.l2j.gameserver.instancemanager.autofarm;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.l2j.gameserver.ai.CtrlIntention;
import net.sf.l2j.gameserver.model.actor.L2Summon;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.zone.ZoneId;
import net.sf.l2j.gameserver.network.serverpackets.ActionFailed;
import net.sf.l2j.gameserver.network.serverpackets.ExShowScreenMessage;
import net.sf.l2j.gameserver.network.serverpackets.ExShowScreenMessage.SMPOS;
import phantom.task.ThreadPool;

public enum AutofarmManager
{
	INSTANCE;

	private static final Logger _log = Logger.getLogger(AutofarmManager.class.getName());

	/*
	 * 800 ms reduz conflitos entre pathfinding, ataque, skill e uso de item.
	 */
	private static final long ITERATION_SPEED_MS = 800L;

	private final ConcurrentHashMap<Integer, AutofarmPlayerRoutine> activeFarmers = new ConcurrentHashMap<>();

	private final ScheduledFuture<?> onUpdateTask =
		ThreadPool.scheduleAtFixedRate(onUpdate(), 1000L, ITERATION_SPEED_MS);

	private Runnable onUpdate()
	{
		return () ->
		{
			 // DEBUG: verifica se existem rotinas de Auto Farm ativas.
	        if (!activeFarmers.isEmpty())
	        {
	            _log.info("[AUTOFARM-DEBUG] Executando rotinas. Total ativos: " + activeFarmers.size());
	        }

	        
			activeFarmers.forEach((objectId, routine) ->
			{
				try
				{
					routine.executeRoutine();
				}
				catch (Exception e)
				{
					_log.log(
						Level.WARNING,
						"Autofarm routine error. Player objectId: " + objectId,
						e
					);

					AutofarmPlayerRoutine removed = activeFarmers.remove(objectId);
					if (removed != null)
					{
						try
						{
							removed.reset();
						}
						catch (Exception resetException)
						{
							_log.log(
								Level.WARNING,
								"Could not reset autofarm routine. Player objectId: " + objectId,
								resetException
							);
						}
					}
				}
			});
		};
	}

	public void startFarm(L2PcInstance player)
	{
		if (player == null)
			return;

		if (player.isInsideZone(ZoneId.PEACE) || player.isInsideZone(ZoneId.OLYMPIAD))
		{
			player.sendMessage("Command allowed only in Combat areas.");
			player.setAutoFarm(false);
			return;
		}

		if (isAutofarming(player))
		{
			player.sendMessage("You are already autofarming.");
			player.setAutoFarm(true);
			return;
		}

		/*
		 * Limpa qualquer estado antigo deixado por ataque/cast antes de iniciar.
		 */
		resetPlayerState(player);

		activeFarmers.put(player.getObjectId(), new AutofarmPlayerRoutine(player));
		_log.info("[AUTOFARM-DEBUG] Rotina registrada para: " + player.getName()+ " | ObjectId: " + player.getObjectId()+ " | Total ativos: " + activeFarmers.size());
		player.setAutoFarm(true);

		player.sendMessage("Auto Farming: Actived!");
		player.sendPacket(new ExShowScreenMessage("Auto Farming: Actived!",5 * 1000,SMPOS.MIDDLE_RIGHT,false));
	}

	public void stopFarm(L2PcInstance player)
	{
		if (player == null)
			return;

		AutofarmPlayerRoutine routine = activeFarmers.remove(player.getObjectId());

		if (routine != null)
		{
			try
			{
				routine.reset();
			}
			catch (Exception e)
			{
				_log.log(
					Level.WARNING,
					"Could not reset autofarm for player: " + player.getName(),
					e
				);
				resetPlayerState(player);
			}
		}
		else
		{
			/*
			 * Mesmo quando o mapa n�o cont�m o jogador, limpa a AI.
			 * Isso permite recuperar o personagem ao desligar o autofarm.
			 */
			resetPlayerState(player);
		}

		player.setAutoFarm(false);
		player.broadcastUserInfo();
		player.broadcastCharInfo();

		player.sendMessage("Auto Farming: Deactivated!");
		player.sendPacket(new ExShowScreenMessage(
			"Auto Farming: Deactivated!",
			5 * 1000,
			SMPOS.MIDDLE_RIGHT,
			false
		));
	}

	public void toggleFarm(L2PcInstance player)
	{
		if (isAutofarming(player))
			stopFarm(player);
		else
			startFarm(player);
	}

	public boolean isAutofarming(L2PcInstance player)
	{
		return player != null && activeFarmers.containsKey(player.getObjectId());
	}

	public void onPlayerLogout(L2PcInstance player)
	{
		if (player == null)
			return;

		activeFarmers.remove(player.getObjectId());
		player.setAutoFarm(false);
	}

	public void onDeath(L2PcInstance player)
	{
		if (player != null && (player.isAutoFarm() || isAutofarming(player)))
			stopFarm(player);
	}

	public ScheduledFuture<?> getOnUpdateTask()
	{
		return onUpdateTask;
	}

	private static void resetPlayerState(L2PcInstance player)
	{
		if (player == null)
			return;

		player.abortCast();
		player.abortAttack();
		player.setTarget(null);
		player.getAI().setIntention(CtrlIntention.ACTIVE);
		player.sendPacket(ActionFailed.STATIC_PACKET);

		L2Summon summon = player.getPet();
		if (summon != null)
		{
			summon.abortCast();
			summon.abortAttack();
			summon.setTarget(null);
			summon.getAI().setIntention(CtrlIntention.ACTIVE);
		}
	}
}
