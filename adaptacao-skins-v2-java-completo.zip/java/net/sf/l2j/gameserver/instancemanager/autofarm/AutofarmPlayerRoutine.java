package net.sf.l2j.gameserver.instancemanager.autofarm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.ai.CtrlIntention;
import net.sf.l2j.gameserver.geoengine.PathFinding;
import net.sf.l2j.gameserver.handler.IItemHandler;
import net.sf.l2j.gameserver.handler.ItemHandler;
import net.sf.l2j.gameserver.handler.voicedcommandhandlers.VoicedAutoFarm;
import net.sf.l2j.gameserver.model.L2Object;
import net.sf.l2j.gameserver.model.L2ShortCut;
import net.sf.l2j.gameserver.model.L2Skill;
import net.sf.l2j.gameserver.model.L2WorldRegion;
import net.sf.l2j.gameserver.model.actor.L2Character;
import net.sf.l2j.gameserver.model.actor.L2Summon;
import net.sf.l2j.gameserver.model.actor.instance.L2ChestInstance;
import net.sf.l2j.gameserver.model.actor.instance.L2MonsterInstance;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.actor.instance.L2PetInstance;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.network.SystemMessageId;
import net.sf.l2j.gameserver.network.serverpackets.ActionFailed;
import net.sf.l2j.gameserver.templates.skills.L2SkillType;
import net.sf.l2j.gameserver.util.Util;
import net.sf.l2j.util.Rnd;

public class AutofarmPlayerRoutine
{
	/*
	 * Se o servidor continuar considerando o personagem em cast por mais deste
	 * tempo, o estado � cancelado automaticamente.
	 */
	private static final long CAST_STUCK_TIMEOUT = 15000L;

	private final L2PcInstance player;
	private L2Character committedTarget;

	private long castingSince;

	public AutofarmPlayerRoutine(L2PcInstance player)
	{
		this.player = player;
	}

	public void executeRoutine()
	{
		if (player == null || !player.isOnline())
			return;

		if (player.isDead() || player.isAlikeDead())
		{
			castingSince = 0L;
			return;
		}

		/*
		 * Recupera o bug no qual isCastingNow() permanece true para sempre.
		 * Durante um cast normal a rotina apenas espera.
		 */
		if (player.isCastingNow())
		{
			if (castingSince == 0L)
				castingSince = System.currentTimeMillis();

			if (System.currentTimeMillis() - castingSince >= CAST_STUCK_TIMEOUT)
			{
				resetStuckState();
				castingSince = 0L;
			}
			return;
		}

		castingSince = 0L;

		if (player.isNoBuffProtected() && player.getAllEffects().length <= 8)
		{
			player.sendMessage("You don't have buffs to use autofarm.");
			AutofarmManager.INSTANCE.stopFarm(player);
			VoicedAutoFarm.showAutoFarm(player);
			return;
		}

		/*
		 * N�o tenta usar potion enquanto uma a��o f�sica est� sendo executada.
		 */
		if (!player.isAttackingNow())
			calculatePotions();

		/*
		 * Sweep precisa ser verificado antes de trocar o alvo morto.
		 */
		if (checkSpoil())
			return;

		// Procura um monstro v�lido.
		targetEligibleCreature();

		L2MonsterInstance target = getMonsterTarget();

		// DEBUG: verifica se encontrou um monstro.
		if (target == null)
		{
			System.out.println("[AUTOFARM-DEBUG] Nenhum monstro selecionado. Player: "
				+ player.getName()
				+ " | Raio: " + player.getRadius()
				+ " | P�gina: " + player.getPage()
				+ " | Atalho de ataque: " + shortcutsContainAttack());
			return;
		}

		System.out.println("[AUTOFARM-DEBUG] Alvo selecionado: "
			+ target.getName()
			+ " | Dist�ncia: " + player.getDistanceSq(target)
			+ " | P�gina: " + player.getPage()
			+ " | Atalho de ataque: " + shortcutsContainAttack());

		if (target.isDead())
			return;

		/*
		 * Primeiro tenta usar uma skill apropriada.
		 * Se nenhuma for utilizada, tenta o ataque f�sico.
		 */
		if (useAppropriateSpell())
			return;

		attack();
	}
	
	private void attack()
	{
		if (shortcutsContainAttack())
			physicalAttack();
	}

	private boolean useAppropriateSpell()
	{
		if (player.isCastingNow() || player.isOutOfControl())
			return false;

		L2Skill chanceSkill = nextAvailableSkill(getChanceSpells(), AutofarmSpellType.Chance);
		if (chanceSkill != null)
			return useMagicSkill(chanceSkill, false);

		L2Skill lowLifeSkill = nextAvailableSkill(getLowLifeSpells(), AutofarmSpellType.LowLife);
		if (lowLifeSkill != null)
			return useMagicSkill(lowLifeSkill, true);

		L2Skill attackSkill = nextAvailableSkill(getAttackSpells(), AutofarmSpellType.Attack);
		if (attackSkill != null)
			return useMagicSkill(attackSkill, false);

		return false;
	}

	public L2Skill nextAvailableSkill(List<Integer> skillIds, AutofarmSpellType spellType)
	{
		for (Integer skillId : skillIds)
		{
			L2Skill skill = player.getKnownSkill(skillId);
			if (skill == null)
				continue;

			if (skill.getSkillType() == L2SkillType.SIGNET || skill.getSkillType() == L2SkillType.SIGNET_CASTTIME)
				continue;

			if (!player.checkDoCastConditions(skill))
				continue;

			if (isSpoil(skillId))
			{
				if (monsterIsAlreadySpoiled())
					continue;

				return skill;
			}

			if (spellType == AutofarmSpellType.Chance)
			{
				L2MonsterInstance target = getMonsterTarget();
				if (target == null)
					continue;

				if (target.getFirstEffect(skillId) == null)
					return skill;

				continue;
			}

			if (spellType == AutofarmSpellType.LowLife)
			{
				if (getHpPercentage() > player.getHealPercent())
					continue;

				return skill;
			}

			return skill;
		}

		return null;
	}

	private boolean checkSpoil()
	{
		L2MonsterInstance target = getMonsterTarget();
		if (target == null || !target.isDead())
			return false;

		if (target.getIsSpoiledBy() != player.getObjectId())
			return false;

		L2Skill sweeper = player.getKnownSkill(42);
		if (sweeper == null)
			return false;

		return useMagicSkill(sweeper, false);
	}

	private double getHpPercentage()
	{
		return player.getCurrentHp() * 100.0 / player.getMaxHp();
	}

	private double percentageMpIsLessThan()
	{
		return player.getCurrentMp() * 100.0 / player.getMaxMp();
	}

	private double percentageHpIsLessThan()
	{
		return player.getCurrentHp() * 100.0 / player.getMaxHp();
	}

	private List<Integer> getAttackSpells()
	{
		return getSpellsInSlots(AutofarmConstants.attackSlots);
	}

	private List<Integer> getChanceSpells()
	{
		return getSpellsInSlots(AutofarmConstants.chanceSlots);
	}

	private List<Integer> getLowLifeSpells()
	{
		return getSpellsInSlots(AutofarmConstants.lowLifeSlots);
	}

	private List<Integer> getSpellsInSlots(List<Integer> slots)
	{
		return Arrays.stream(player.getAllShortCuts())
			.filter(shortcut ->
				shortcut.getPage() == player.getPage() &&
				shortcut.getType() == L2ShortCut.TYPE_SKILL &&
				slots.contains(shortcut.getSlot()))
			.map(L2ShortCut::getId)
			.collect(Collectors.toList());
	}

	private boolean shortcutsContainAttack()
	{
		return Arrays.stream(player.getAllShortCuts()).anyMatch(shortcut ->
			shortcut.getPage() == player.getPage() &&
			shortcut.getType() == L2ShortCut.TYPE_ACTION &&
			(shortcut.getId() == 2 || (player.isSummonAttack() && shortcut.getId() == 22)));
	}

	private boolean monsterIsAlreadySpoiled()
	{
		L2MonsterInstance target = getMonsterTarget();
		return target != null && target.getIsSpoiledBy() != 0;
	}

	private static boolean isSpoil(Integer skillId)
	{
		return skillId == 254 || skillId == 302;
	}

	private boolean useMagicSkill(L2Skill skill, boolean forceOnSelf)
	{
		if (skill == null)
			return false;

		if (player.isDead() || player.isAlikeDead() || player.isCastingNow() || player.isOutOfControl())
			return false;

		if (skill.getSkillType() == L2SkillType.SIGNET || skill.getSkillType() == L2SkillType.SIGNET_CASTTIME)
			return false;

		if (skill.getSkillType() == L2SkillType.RECALL && !Config.KARMA_PLAYER_CAN_TELEPORT && player.getKarma() > 0)
			return false;

		if (skill.isToggle() && player.isMounted())
			return false;

		return castSpellWithAppropriateTarget(skill, forceOnSelf);
	}

	private boolean castSpellWithAppropriateTarget(L2Skill skill, boolean forceOnSelf)
	{
		if (!forceOnSelf)
		{
			player.useMagic(skill, false, false);
			return true;
		}

		L2Object oldTarget = player.getTarget();

		try
		{
			player.setTarget(player);
			player.useMagic(skill, false, false);
			return true;
		}
		finally
		{
			player.setTarget(oldTarget);
		}
	}

	private void physicalAttack()
	{
		L2MonsterInstance target = getMonsterTarget();
		if (target == null)
			return;

		if (target.isDead() || !target.isVisible() || !target.isAutoAttackable(player))
		{
			clearTarget();
			return;
		}

		if (!PathFinding.getInstance().canSeeTarget(player, target))
		{
			if (PathFinding.getInstance().canMoveToTarget(
				player.getX(), player.getY(), player.getZ(),
				target.getX(), target.getY(), target.getZ()))
			{
				player.getAI().setIntention(CtrlIntention.FOLLOW, target);
			}
			else
			{
				clearTarget();
			}
			return;
		}

		if (!player.isMageClass() && !player.isCastingNow())
		{
			player.getAI().setIntention(CtrlIntention.ATTACK, target);
			player.onActionRequest();
		}

		attackWithSummon(target);
	}

	private void attackWithSummon(L2MonsterInstance target)
	{
		if (!player.isSummonAttack() || player.getPet() == null)
			return;

		L2Summon summon = player.getPet();
		int npcId = summon.getNpcId();

		if ((npcId >= 14702 && npcId <= 14798) || (npcId >= 14839 && npcId <= 14869))
			return;

		summon.setTarget(target);
		summon.getAI().setIntention(CtrlIntention.ATTACK, target);

		if (Rnd.get(100) >= player.getSummonSkillPercent())
			return;

		int[] summonAttackSkills =
		{
			4261, 4068, 4137, 4260, 4708, 4709, 4710, 4712,
			5135, 5138, 5141, 5442, 5444, 6095, 6096, 6041, 6044
		};

		for (int skillId : summonAttackSkills)
		{
			if (useMagicSkillBySummon(skillId, target))
				break;
		}
	}

	public void targetEligibleCreature()
	{
		if (committedTarget != null)
		{
			if (committedTarget.isDead() || !committedTarget.isVisible())
			{
				clearTarget();
			}
			else
			{
				player.setTarget(committedTarget);

				if (PathFinding.getInstance().canSeeTarget(player, committedTarget))
					return;

				if (PathFinding.getInstance().canMoveToTarget(
					player.getX(), player.getY(), player.getZ(),
					committedTarget.getX(), committedTarget.getY(), committedTarget.getZ()))
				{
					player.getAI().setIntention(CtrlIntention.FOLLOW, committedTarget);
					return;
				}

				clearTarget();
			}
		}

		List<L2MonsterInstance> targets = getKnownMonstersInRadius(
			player,
			player.getRadius(),
			creature ->
				PathFinding.getInstance().canMoveToTarget(
					player.getX(), player.getY(), player.getZ(),
					creature.getX(), creature.getY(), creature.getZ()) &&
				!player.ignoredMonsterContain(creature.getNpcId()) &&
				!creature.isAgathion() &&
				!creature.isRaidMinion() &&
				!creature.isRaid() &&
				!creature.isDead() &&
				!(creature instanceof L2ChestInstance) &&
				!(
					player.isAntiKsProtected() &&
					creature.getTarget() != null &&
					creature.getTarget() != player &&
					creature.getTarget() != player.getPet()
				)
		);

		if (targets.isEmpty())
		{
			clearTarget();
			return;
		}

		L2MonsterInstance closestTarget = targets.stream()
			.min((first, second) -> Double.compare(
				player.getDistanceSq(first),
				player.getDistanceSq(second)))
			.orElse(null);

		if (closestTarget == null)
		{
			clearTarget();
			return;
		}

		committedTarget = closestTarget;
		player.setTarget(closestTarget);
	}

	public static List<L2MonsterInstance> getKnownMonstersInRadius(
		L2PcInstance player,
		int radius,
		Function<L2MonsterInstance, Boolean> condition)
	{
		L2WorldRegion region = player.getWorldRegion();
		if (region == null)
			return Collections.emptyList();

		List<L2MonsterInstance> result = new ArrayList<>();

		for (L2WorldRegion surroundingRegion : region.getSurroundingRegions())
		{
			for (L2Object object : surroundingRegion.getVisibleObjects().values())
			{
				if (!(object instanceof L2MonsterInstance))
					continue;

				if (!Util.checkIfInRange(radius, player, object, true))
					continue;

				L2MonsterInstance monster = (L2MonsterInstance) object;
				if (!condition.apply(monster))
					continue;

				result.add(monster);
			}
		}

		return result;
	}

	public L2MonsterInstance getMonsterTarget()
	{
		return player.getTarget() instanceof L2MonsterInstance
			? (L2MonsterInstance) player.getTarget()
			: null;
	}

	private boolean useMagicSkillBySummon(int skillId, L2Object target)
	{
		if (player.isInStoreMode())
			return false;

		L2Summon activeSummon = player.getPet();
		if (activeSummon == null)
			return false;

		if (activeSummon instanceof L2PetInstance && activeSummon.getLevel() - player.getLevel() > 20)
		{
			player.sendPacket(SystemMessageId.PET_TOO_HIGH_TO_CONTROL);
			return false;
		}

		if (activeSummon.isOutOfControl())
		{
			player.sendPacket(SystemMessageId.PET_REFUSING_ORDER);
			return false;
		}

		if (activeSummon.isCastingNow())
			return false;

		L2Skill skill = activeSummon.getKnownSkill(skillId);
		if (skill == null)
			return false;

		if (skill.isOffensive() && player == target)
			return false;

		activeSummon.setTarget(target);
		return activeSummon.useMagic(skill, false, false);
	}

	private void calculatePotions()
	{
		if (percentageHpIsLessThan() < player.getHpPotionPercentage())
			forceUseItem(1539);

		if (percentageMpIsLessThan() < player.getMpPotionPercentage())
			forceUseItem(728);
	}

	private void forceUseItem(int itemId)
	{
		ItemInstance potion = player.getInventory().getItemByItemId(itemId);
		if (potion == null)
			return;

		IItemHandler handler = ItemHandler.getInstance().getItemHandler(potion.getEtcItem());
		if (handler != null)
			handler.useItem(player, potion, false);
	}

	private void clearTarget()
	{
		committedTarget = null;
		player.setTarget(null);
		player.getAI().setIntention(CtrlIntention.ACTIVE);
		player.sendPacket(ActionFailed.STATIC_PACKET);
	}

	private void resetStuckState()
	{
		committedTarget = null;

		player.abortCast();
		player.abortAttack();
		player.setTarget(null);
		player.getAI().setIntention(CtrlIntention.ACTIVE);
		player.sendPacket(ActionFailed.STATIC_PACKET);

		L2Summon summon = player.getPet();
		if (summon != null)
		{
			summon.abortCast();
			summon.abortAttack();
			summon.setTarget(null);
			summon.getAI().setIntention(CtrlIntention.ACTIVE);
		}

		player.sendMessage("Auto Farm: stuck casting state was automatically reset.");
	}

	public void reset()
	{
		castingSince = 0L;
		resetStuckState();
	}
}
