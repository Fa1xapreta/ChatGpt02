/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.instancemanager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

import net.sf.l2j.L2DatabaseFactory;

public class RaidBossInfoManager
{
   private static final Logger _log = Logger.getLogger(RaidBossInfoManager.class.getName());
  
   private final Map<Integer, Long> _raidBosses;
  
   public static RaidBossInfoManager getInstance()
   {
       return SingletonHolder._instance;
   }
  
   protected RaidBossInfoManager()
   {
       _raidBosses = new ConcurrentHashMap<>();
       load();
   }
  
   public void load()
   {
       try (Connection con = L2DatabaseFactory.getInstance().getConnection())
       {
           PreparedStatement statement;
           ResultSet rs;
          
           statement = con.prepareStatement("SELECT boss_id, respawn_time FROM grandboss_data UNION SELECT boss_id, respawn_time FROM raidboss_spawnlist ORDER BY boss_id");
           rs = statement.executeQuery();
           while (rs.next())
           {
               int bossId = rs.getInt("boss_id");
               long respawnTime = rs.getLong("respawn_time");

                   _raidBosses.put(bossId, respawnTime);
           }
           rs.close();
           statement.close();
       }
       catch (Exception e)
       {
           _log.warning("Exception: RaidBossInfoManager load: " + e);
       }
      
       _log.info("RaidBossInfoManager: Loaded " + _raidBosses.size() + " instances.");
   }
  
   public void updateRaidBossInfo(int bossId, long respawnTime)
   {
       final int encounterId = (bossId == 29047) ? 29045 : bossId;

       _raidBosses.put(encounterId, respawnTime);
   }

   public long getRaidBossRespawnTime(int bossId)
   {
       final int encounterId = (bossId == 29047) ? 29045 : bossId;
       final Long respawnTime = _raidBosses.get(encounterId);

       return respawnTime == null ? 0L : respawnTime.longValue();
   }
  
   private static class SingletonHolder
   {
       protected static final RaidBossInfoManager _instance = new RaidBossInfoManager();
   }
}
