package net.sf.l2j.gameserver.instancemanager;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.ThreadPoolManager;
import net.sf.l2j.gameserver.datatables.GuildMissionXmlData;
import net.sf.l2j.gameserver.datatables.custom.GuildMissionParser;
import net.sf.l2j.gameserver.datatables.custom.GuildMissionTable;
import net.sf.l2j.gameserver.model.GuildMission;
import net.sf.l2j.gameserver.model.L2Clan;
import net.sf.l2j.gameserver.model.L2World;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.guildmission.GuildMissionProgress;
import net.sf.l2j.gameserver.model.guildmission.GuildMissionReward;
import net.sf.l2j.gameserver.model.guildmission.MissionObjective;
import net.sf.l2j.gameserver.model.guildmission.MissionType;
import net.sf.l2j.gameserver.network.serverpackets.MagicSkillUse;
import net.sf.l2j.gameserver.network.serverpackets.SocialAction;

public class GuildMissionManager
{
    private final Map<Integer, GuildMission> missionsById = new HashMap<>();
    private final Map<Integer, Map<Integer, GuildMissionProgress>> progressCache = new HashMap<>();
    private final List<GuildMission> missions = new ArrayList<>();
    private final GuildMissionParser parser = new GuildMissionParser();
    private final GuildMissionTable table = new GuildMissionTable();

    protected GuildMissionManager()
    {
        loadFromXml("data/xml/guildMissions.xml");
    }

    public static GuildMissionManager getInstance()
    {
        return SingletonHolder.INSTANCE;
    }

    private static class SingletonHolder
    {
        protected static final GuildMissionManager INSTANCE = new GuildMissionManager();
    }

    public void loadFromXml(String path)
    {
        System.out.println("GuildMission: Caminho recebido no load: " + path);

        File file = new File(path);
        if (!file.exists())
        {
            System.out.println("GuildMission: Primeiro caminho nao existe. Tentando pegar o padrao...");
            path = GuildMissionXmlData.getDefaultXmlPath();
            file = new File(path);
            if (!file.exists())
            {
                path = "guildMissions.xml";
            }
        }

        File finalFile = new File(path);
        if (!finalFile.exists())
        {
            System.out.println("GuildMission: ERRO: O arquivo XML nao existe!");
            return;
        }

        List<GuildMission> loaded = parser.parse(path);
        missions.clear();
        missionsById.clear();

        if (loaded == null || loaded.isEmpty())
        {
            System.out.println("GuildMission: AVISO: A lista de miss�es veio VAZIA.");
        }
        else
        {
            System.out.println("GuildMission: SUCESSO: " + loaded.size() + " miss�es carregadas!");
        }

        for (GuildMission mission : loaded)
        {
            missions.add(mission);
            missionsById.put(mission.getId(), mission);
        }
    }

    public void initialize(Connection connection)
    {
        try
        {
            table.createTable(connection);
            table.loadAllProgress(connection, progressCache);
            System.out.println("GuildMission: Progresso de todos os clans carregado com sucesso!");
        }
        catch (Exception e)
        {
            System.out.println("GuildMission: ERRO ao carregar dados do banco: " + e.getMessage());
            e.printStackTrace();
        }

        ThreadPoolManager.getInstance().scheduleGeneralAtFixedRate(this::runResetCheck, 600000L, 600000L);
        System.out.println("GuildMission: Sistema de Reset Autom�tico Ativado.");
    }

    public List<GuildMission> getMissions()
    {
        return Collections.unmodifiableList(missions);
    }

    public GuildMission getMission(int missionId)
    {
        return missionsById.get(missionId);
    }

    public GuildMissionProgress getProgress(int clanId, int missionId)
    {
        Map<Integer, GuildMissionProgress> clanProgress = progressCache.get(clanId);
        if (clanProgress != null)
        {
            GuildMissionProgress existing = clanProgress.get(missionId);
            if (existing != null)
            {
                return existing;
            }
        }
        GuildMissionProgress progress = new GuildMissionProgress();
        progress.setClanId(clanId);
        progress.setMissionId(missionId);
        progressCache.computeIfAbsent(clanId, key -> new HashMap<>()).put(missionId, progress);
        return progress;
    }

    public void saveProgress(Connection connection, int clanId, int missionId)
    {
        GuildMissionProgress progress = getProgress(clanId, missionId);
        try
        {
            table.saveProgress(connection, progress);
        }
        catch (Exception e)
        {
            throw new IllegalStateException("Unable to save guild mission progress", e);
        }
    }

    public void refreshMission(int clanId, int missionId)
    {
        GuildMissionProgress progress = getProgress(clanId, missionId);
        if (progress.isCompleted())
        {
            progress.setCompleted(false);
        }
    }

    public void grantRewards(L2PcInstance player, GuildMission mission)
    {
        if (player == null) return;
        L2Clan clan = player.getClan();

        player.sendMessage("Parabens! Sua atividade completou a missao de Cla: " + mission.getName());

        for (GuildMissionReward reward : mission.getRewards())
        {
            if (reward.getItemId() > 0 && reward.getItemCount() > 0)
            {
                player.addItem("GuildMission", reward.getItemId(), (int) reward.getItemCount(), player, true);
            }

            if (reward.getAdena() > 0)
            {
                player.addItem("GuildMission", 57, (int) reward.getAdena(), player, true);
            }

            if (reward.getClanReputation() > 0 && clan != null)
            {
                clan.addReputationScore((int) reward.getClanReputation());

                for (L2PcInstance member : clan.getOnlineMembers())
                {
                    if (member != null)
                    {
                        member.sendMessage("O cla recebeu " + reward.getClanReputation() + " pontos de reputacao pela missao: " + mission.getName());
                    }
                }
            }
        }
    }

    public void runResetCheck()
    {
        long currentTime = System.currentTimeMillis();

        for (Map<Integer, GuildMissionProgress> clanProgress : progressCache.values())
        {
            for (GuildMissionProgress progress : clanProgress.values())
            {
                if (progress.isCompleted())
                {
                    GuildMission mission = getMission(progress.getMissionId());

                    if (mission != null && mission.getResetHours() > 0)
                    {
                        long resetTime = progress.getLastCompleted() + (mission.getResetHours() * 3600 * 1000L);

                        if (currentTime >= resetTime)
                        {
                            progress.clearProgress();

                            try (Connection con = L2DatabaseFactory.getInstance().getConnection())
                            {
                                saveProgress(con, progress.getClanId(), progress.getMissionId());
                            }
                            catch (Exception e)
                            {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }
        }
    }

    // --- ENTRADAS DE EVENTOS DO CORE (HOOKS) ---

    public void onKill(L2PcInstance player, int targetId, int level)
    {
        if (player == null || player.getClan() == null) return;
        processMission(player, MissionType.KILL_MONSTER, targetId, 1);
    }

    public void onPlayerKill(L2PcInstance player, int victimId)
    {
        if (player == null || player.getClan() == null) return;

        L2PcInstance victim = L2World.getInstance().getPlayer(victimId);
        
        // Percorre as miss�es ativas do tipo KILL_PLAYER para validar as travas de cada uma
        for (GuildMission mission : missions)
        {
            if (mission.getType() != MissionType.KILL_PLAYER || !mission.isActive())
            {
                continue;
            }

            // Valida as travas de HWID/IP configuradas no XML desta miss�o espec�fica
            if (!isAntiFarmValid(player, victim, mission))
            {
                continue; // Se falhou na trava desta miss�o, pula para a pr�xima
            }

            // Processa os objetivos desta miss�o de player kill
            for (MissionObjective objective : mission.getObjectives())
            {
                if (objective.getType() != MissionType.KILL_PLAYER)
                {
                    continue;
                }
                
                if (!objective.matchesTarget(victimId))
                {
                    continue;
                }

                updateProgress(player, mission.getId(), objective.getId(), 1);
            }
        }
    }

    public void onRaidKill(L2PcInstance player, int bossId)
    {
        if (player == null || player.getClan() == null) return;
        processMission(player, MissionType.KILL_RAID_BOSS, bossId, 1);
    }

    public void onCraft(L2PcInstance player, int itemId)
    {
        if (player == null || player.getClan() == null) return;
        processMission(player, MissionType.CRAFT_ITEM, itemId, 1);
    }

    public void onItemPickup(L2PcInstance player, int itemId, long count)
    {
        if (player == null || player.getClan() == null) return;
        processMission(player, MissionType.COLLECT_ITEM, itemId, count);
    }

    public void onOnlineTimeTick(L2PcInstance player, long hours)
    {
        if (player == null || player.getClan() == null) return;
        processMission(player, MissionType.ONLINE_TIME, 0, hours);
    }

    public void onEnchant(L2PcInstance player, int itemId, int enchantLvl)
    {
        if (player == null || player.getClan() == null) return;
        processMission(player, MissionType.ENCHANT_ITEM, itemId, 1);
    }

    public void onLevelUp(L2Clan clan, int newLevel)
    {
        if (clan == null) return;
        L2PcInstance leader = clan.getLeader().getPlayerInstance();
        if (leader != null)
        {
            processMission(leader, MissionType.CLAN_LEVEL, 0, newLevel);
        }
    }

    public void onSiege(L2Clan clan)
    {
        if (clan == null) return;
        L2PcInstance leader = clan.getLeader().getPlayerInstance();
        if (leader != null)
        {
            processMission(leader, MissionType.CASTLE_SIEGE, 0, 1);
        }
    }

    public void onOlympiadMatchEnd(L2PcInstance player)
    {
        if (player == null || player.getClan() == null) return;
        processMission(player, MissionType.OLYMPIAD, 0, 1);
    }

    public void onCustomEvent(L2PcInstance player, MissionType type, String metadata)
    {
        if (player == null || player.getClan() == null) return;
        processMission(player, type, 0, 1);
    }

    public void reloadClanProgress(int clanId)
    {
        progressCache.remove(clanId);
        Map<Integer, GuildMissionProgress> newClanCache = new HashMap<>();

        try (Connection con = L2DatabaseFactory.getInstance().getConnection())
        {
            table.loadClanProgress(con, clanId, newClanCache);
            progressCache.put(clanId, newClanCache);
        }
        catch (Exception e)
        {
            System.out.println("GuildMission: Erro ao recarregar cl� " + clanId + ": " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void processMission(L2PcInstance player, MissionType type, int targetId, long amount)
    {
        for (GuildMission mission : missions)
        {
            if (mission.getType() != type)
            {
                continue;
            }
            for (MissionObjective objective : mission.getObjectives())
            {
                if (objective.getType() != type)
                {
                    continue;
                }
                
                // === FILTRA PELO ID DO ALVO (EX: MONSTROS 515, 516) ===
                if (!objective.matchesTarget(targetId))
                {
                    continue; // Se o ID n�o estiver na lista do XML, pula para o pr�ximo
                }

                updateProgress(player, mission.getId(), objective.getId(), amount);
            }
        }
    }

    
    
 // --- ATUALIZADO: Valida��o Anti-Farm Din�mica baseada no XML da Miss�o ---
    private boolean isAntiFarmValid(L2PcInstance killer, L2PcInstance victim, GuildMission mission)
    {
        if (victim == null || killer == victim)
        {
            return false;
        }

        if (killer.getClan() != null && victim.getClan() != null && killer.getClanId() == victim.getClanId())
        {
            return false;
        }

        // Se a miss�o exige checagem de IP (configurado no XML com true)
        if (mission.isCheckIp() && killer.getClient() != null && victim.getClient() != null)
        {
            try
            {
                String killerIP = killer.getClient().getConnection().getInetAddress().getHostAddress();
                String victimIP = victim.getClient().getConnection().getInetAddress().getHostAddress();
                if (killerIP != null && killerIP.equals(victimIP))
                {
                    return false;
                }
            }
            catch (Exception e)
            {
                // Ignora se falhar ao obter IP
            }
        }

        // Se a miss�o exige checagem de HWID (configurado no XML com true)
        if (mission.isCheckHwid())
        {
            String killerHWID = killer.getHWid(); 
            String victimHWID = victim.getHWid();
            if (killerHWID != null && victimHWID != null && killerHWID.equals(victimHWID))
            {
                return false;
            }
        }

        return true;
    }

    public void claimReward(L2PcInstance player, int missionId)
    {
        GuildMission mission = getMission(missionId);
        GuildMissionProgress progress = getProgress(player.getClanId(), missionId);

        if (mission == null)
        {
            return;
        }

        if (!progress.isCompleted())
        {
            player.sendMessage("Esta missao ainda nao foi completada.");
            return;
        }

        if (progress.isClaimed())
        {
            player.sendMessage("Voce ja coletou esta recompensa.");
            return;
        }

        grantRewards(player, mission);
        player.broadcastPacket(new SocialAction(player, 16));

        progress.setClaimed(true);

        try (Connection con = L2DatabaseFactory.getInstance().getConnection())
        {
            saveProgress(con, player.getClanId(), missionId);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        player.sendMessage("Voce coletou a recompensa da missao: " + mission.getName());
    }

    private boolean isDoingMissionInParty(L2PcInstance player)
    {
        if (player.getParty() == null || player.getClan() == null)
        {
            return false;
        }

        int playerClanId = player.getClanId();
        int playerAllyId = player.getClan().getAllyId();

        for (L2PcInstance member : player.getParty().getPartyMembers())
        {
            if (member == null || member == player)
            {
                continue;
            }

            if (member.getClan() != null)
            {
                if (member.getClanId() == playerClanId)
                {
                    return true;
                }

                if (playerAllyId > 0 && member.getClan().getAllyId() == playerAllyId)
                {
                    return true;
                }
            }
        }

        return false;
    }

    public void resetClanProgressGM(int clanId)
    {
        progressCache.remove(clanId);

        try (Connection con = L2DatabaseFactory.getInstance().getConnection())
        {
            try (PreparedStatement statement = con.prepareStatement("DELETE FROM clan_mission_progress WHERE clan_id = ?"))
            {
                statement.setInt(1, clanId);
                statement.executeUpdate();
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        System.out.println("GuildMission: Progresso do clan " + clanId + " foi resetado para testes.");
    }

    private void updateProgress(L2PcInstance player, int missionId, int objectiveId, long amount)
    {    
        if (!isDoingMissionInParty(player))
        {
            return; 
        }

        int clanId = player.getClanId();
        GuildMissionProgress progress = getProgress(clanId, missionId);

        if (progress.isCompleted())
        {
            return;
        }

        progress.addProgress(objectiveId, amount);
        player.sendMessage("Progresso da Missao de Clan atualizado!");

        GuildMission mission = getMission(missionId);
        if (mission != null && mission.isCompleted(progress))
        {
            progress.setCompleted(true);
            progress.setLastCompleted(System.currentTimeMillis());
            progress.setRepeatCount(progress.getRepeatCount() + 1);

            if (player != null)
            {
                player.broadcastPacket(new MagicSkillUse(player, player, 92015, 1, 2000, 0));
                player.sendMessage("Miss�o conclu�da! Verifique o menu para coletar sua recompensa.");
            }

            try (Connection con = L2DatabaseFactory.getInstance().getConnection())
            {
                saveProgress(con, clanId, missionId);
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }
}