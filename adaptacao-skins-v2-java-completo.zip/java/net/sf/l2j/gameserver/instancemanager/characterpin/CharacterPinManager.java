package net.sf.l2j.gameserver.instancemanager.characterpin;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;

public enum CharacterPinManager
{
	INSTANCE;

	private static final Logger _log = Logger.getLogger(CharacterPinManager.class.getName());
	private static final SecureRandom RND = new SecureRandom();
	private static final int PIN_LENGTH = 4;
	private static final int RECOVERY_LENGTH = 8;
	private static final int MAX_ATTEMPTS = 5;

	private final Map<Integer, PinSession> _sessions = new ConcurrentHashMap<>();
	private volatile boolean _tableChecked;

	private enum Mode
	{
		CREATE,
		CREATE_CONFIRM,
		UNLOCK,
		CHANGE_OLD,
		CHANGE_NEW,
		RECOVERY_CODE,
		RECOVERY_NEW,
		DISABLE
	}

	private static class PinSession
	{
		Mode mode;
		String input = "";
		String firstPin = "";
		int attempts;

		PinSession(Mode mode)
		{
			this.mode = mode;
		}
	}

	public void onEnterWorld(L2PcInstance player)
	{
		if (player == null)
			return;

		ensureTable();
		if (isDisabled(player.getObjectId()) || !hasPin(player.getObjectId()))
		{
			player.setIsSubmitingPin(false);
			return;
		}
		
		updateCharacterName(player);
		player.setIsSubmitingPin(true);
		_sessions.remove(player.getObjectId());
	}

	public void showLockedWindow(L2PcInstance player)
	{
		if (player == null)
			return;

		ensureTable();
		if (isDisabled(player.getObjectId()) || !hasPin(player.getObjectId()))
		{
			player.setIsSubmitingPin(false);
			showMenu(player);
			return;
		}
		
		player.setIsSubmitingPin(true);
		
		PinSession session = _sessions.get(player.getObjectId());
		if (session != null)
		{
			showKeypad(player, session, messageFor(session));
			return;
		}
		
		if (hasPin(player.getObjectId()))
			showUnlock(player, "Digite sua senha de seguranca.");
		else
			showCreate(player, "Crie uma senha de 4 digitos.");
	}

	public void showMenu(L2PcInstance player)
	{
		if (player == null)
			return;

		ensureTable();
		boolean disabled = isDisabled(player.getObjectId());
		boolean hasPin = hasPin(player.getObjectId());

		NpcHtmlMessage html = new NpcHtmlMessage(0);
		html.setFile("data/html/mods/pin/menu.htm");
		if (disabled || !hasPin)
		{
			html.replace("%status%", disabled ? "<font color=AAAAAA>Desativado</font>" : "<font color=AAAAAA>Nao ativado</font>");
			html.replace("%status_note%", disabled ? "Protecao desligada neste personagem." : "Ative se quiser proteger os itens.");
			html.replace("%primary_button%", "<button value=\"Ativar Senha\" action=\"bypass -h voiced_charpin create\" width=100 height=23 back=\"L2UI_Death.bigbutton_down\" fore=\"L2UI_Death.bigbutton\">");
			html.replace("%change_button%", "");
			html.replace("%recover_button%", "");
			html.replace("%disable_button%", "");
		}
		else
		{
			boolean locked = player.isSubmitingPin();
			html.replace("%status%", locked ? "<font color=FF5555>Bloqueado</font>" : "<font color=00FF00>Desbloqueado</font>");
			html.replace("%status_note%", locked ? "Digite a senha para liberar os itens." : "Seus itens estao liberados.");
			html.replace("%primary_button%", locked ? "<button value=\"Desbloquear\" action=\"bypass -h voiced_charpin unlock\" width=100 height=22 back=\"L2UI_Death.bigbutton_down\" fore=\"L2UI_Death.bigbutton\">" : "<button value=\"Bloquear Agora\" action=\"bypass -h voiced_charpin lock\" width=100 height=22 back=\"L2UI_Death.bigbutton_down\" fore=\"L2UI_Death.bigbutton\">");
			html.replace("%change_button%", "<button value=\"Alterar Senha\" action=\"bypass -h voiced_charpin change\" width=100 height=22 back=\"L2UI_Death.bigbutton_down\" fore=\"L2UI_Death.bigbutton\">");
			html.replace("%recover_button%", "<button value=\"Recuperar\" action=\"bypass -h voiced_charpin recover\" width=100 height=22 back=\"L2UI_Death.bigbutton_down\" fore=\"L2UI_Death.bigbutton\">");
			html.replace("%disable_button%", "<button value=\"Desativar\" action=\"bypass -h voiced_charpin disable\" width=100 height=22 back=\"L2UI_Death.bigbutton_down\" fore=\"L2UI_Death.bigbutton\">");
		}
		player.sendPacket(html);
	}

	public void handleCommand(L2PcInstance player, String command)
	{
		if (player == null)
			return;

		ensureTable();
		String[] tokens = command.split(" ");
		if (tokens.length < 2)
		{
			showMenu(player);
			return;
		}

		String action = tokens[1];
		if ("menu".equalsIgnoreCase(action))
		{
			showMenu(player);
			return;
		}

		if ("create".equalsIgnoreCase(action))
		{
			player.setIsSubmitingPin(hasPin(player.getObjectId()));
			showCreate(player, "Crie uma senha de 4 digitos.");
			return;
		}

		if ("unlock".equalsIgnoreCase(action))
		{
			player.setIsSubmitingPin(true);
			showUnlock(player, "Digite sua senha de seguranca.");
			return;
		}
		if ("lock".equalsIgnoreCase(action))
		{
			if (!hasPin(player.getObjectId()))
			{
				showCreate(player, "Crie uma senha de 4 digitos.");
				return;
			}
			
			player.setIsSubmitingPin(true);
			_sessions.remove(player.getObjectId());
			player.sendMessage("Personagem bloqueado. Digite o PIN para liberar os itens.");
			showMenu(player);
			return;
		}

		if ("disable".equalsIgnoreCase(action))
		{
			if (!hasPin(player.getObjectId()))
			{
				saveDisabled(player);
				player.setIsSubmitingPin(false);
				showMenu(player);
				return;
			}
			
			PinSession session = new PinSession(Mode.DISABLE);
			_sessions.put(player.getObjectId(), session);
			showKeypad(player, session, "Digite a senha para desativar.");
			return;
		}
		
		if ("change".equalsIgnoreCase(action))
		{
			PinSession session = new PinSession(Mode.CHANGE_OLD);
			_sessions.put(player.getObjectId(), session);
			showKeypad(player, session, "Confirme sua senha atual.");
			return;
		}

		if ("recover".equalsIgnoreCase(action))
		{
			PinSession session = new PinSession(Mode.RECOVERY_CODE);
			_sessions.put(player.getObjectId(), session);
			showKeypad(player, session, "Digite seu codigo de recuperacao.");
			return;
		}

		if ("digit".equalsIgnoreCase(action) && tokens.length >= 3)
		{
			addDigit(player, tokens[2]);
			return;
		}

		if ("clean".equalsIgnoreCase(action))
		{
			PinSession session = getSession(player);
			session.input = "";
			showKeypad(player, session, messageFor(session));
			return;
		}

		if ("cancel".equalsIgnoreCase(action))
		{
			_sessions.remove(player.getObjectId());
			if (!hasPin(player.getObjectId()))
				player.setIsSubmitingPin(false);
			showMenu(player);
			return;
		}
		if ("back".equalsIgnoreCase(action))
		{
			showMenu(player);
			return;
		}
	}

	private void addDigit(L2PcInstance player, String value)
	{
		if (value == null || value.length() != 1 || !Character.isDigit(value.charAt(0)))
			return;

		PinSession session = getSession(player);
		int maxLength = session.mode == Mode.RECOVERY_CODE ? RECOVERY_LENGTH : PIN_LENGTH;
		if (session.input.length() >= maxLength)
			return;

		session.input += value;
		if (session.input.length() >= maxLength)
			processFullInput(player, session);
		else
			showKeypad(player, session, messageFor(session));
	}

	private void processFullInput(L2PcInstance player, PinSession session)
	{
		switch (session.mode)
		{
			case CREATE:
				session.firstPin = session.input;
				session.input = "";
				session.mode = Mode.CREATE_CONFIRM;
				showKeypad(player, session, "Confirme a senha digitando novamente.");
				break;

			case CREATE_CONFIRM:
				if (!session.firstPin.equals(session.input))
				{
					showCreate(player, "As senhas nao conferem. Tente novamente.");
					break;
				}

				String recovery = generateRecoveryCode();
				savePin(player, session.input, recovery);
				_sessions.remove(player.getObjectId());
				player.setIsSubmitingPin(false);
				showRecoveryCode(player, recovery);
				break;

			case UNLOCK:
				if (verifyPin(player.getObjectId(), session.input))
				{
					_sessions.remove(player.getObjectId());
					player.setIsSubmitingPin(false);
					player.sendMessage("Senha confirmada. Itens desbloqueados.");
					showMenu(player);
					break;
				}
				wrongAttempt(player, session, "Senha incorreta.");
				break;

			case CHANGE_OLD:
				if (!verifyPin(player.getObjectId(), session.input))
				{
					wrongAttempt(player, session, "Senha atual incorreta.");
					break;
				}
				session.input = "";
				session.mode = Mode.CHANGE_NEW;
				showKeypad(player, session, "Digite a nova senha de 4 digitos.");
				break;

			case CHANGE_NEW:
				savePinKeepingRecovery(player, session.input);
				_sessions.remove(player.getObjectId());
				player.sendMessage("Senha alterada com sucesso.");
				showMenu(player);
				break;

			case RECOVERY_CODE:
				if (!verifyRecovery(player.getObjectId(), session.input))
				{
					wrongAttempt(player, session, "Codigo de recuperacao incorreto.");
					break;
				}
				session.input = "";
				session.mode = Mode.RECOVERY_NEW;
				showKeypad(player, session, "Digite uma nova senha de 4 digitos.");
				break;

			case DISABLE:
				if (!verifyPin(player.getObjectId(), session.input))
				{
					wrongAttempt(player, session, "Senha incorreta.");
					break;
				}
				saveDisabled(player);
				_sessions.remove(player.getObjectId());
				player.setIsSubmitingPin(false);
				player.sendMessage("Protecao do personagem removida.");
				showMenu(player);
				break;

			case RECOVERY_NEW:
				String newRecovery = generateRecoveryCode();
				savePin(player, session.input, newRecovery);
				_sessions.remove(player.getObjectId());
				player.setIsSubmitingPin(false);
				showRecoveryCode(player, newRecovery);
				break;
		}
	}

	private void wrongAttempt(L2PcInstance player, PinSession session, String message)
	{
		session.attempts++;
		session.input = "";
		if (session.attempts >= MAX_ATTEMPTS)
		{
			_sessions.remove(player.getObjectId());
			player.sendMessage("Muitas tentativas incorretas. Voce sera desconectado.");
			player.logout();
			return;
		}

		showKeypad(player, session, message + " Restam: " + (MAX_ATTEMPTS - session.attempts));
	}

	private PinSession getSession(L2PcInstance player)
	{
		PinSession session = _sessions.get(player.getObjectId());
		if (session != null)
			return session;

		if (hasPin(player.getObjectId()))
			session = new PinSession(Mode.UNLOCK);
		else
			session = new PinSession(Mode.CREATE);

		_sessions.put(player.getObjectId(), session);
		return session;
	}

	private void showCreate(L2PcInstance player, String message)
	{
		PinSession session = new PinSession(Mode.CREATE);
		_sessions.put(player.getObjectId(), session);
		showKeypad(player, session, message);
	}

	private void showUnlock(L2PcInstance player, String message)
	{
		PinSession session = new PinSession(Mode.UNLOCK);
		_sessions.put(player.getObjectId(), session);
		showKeypad(player, session, message);
	}

	private void showKeypad(L2PcInstance player, PinSession session, String message)
	{
		NpcHtmlMessage html = new NpcHtmlMessage(0);
		html.setFile("data/html/mods/pin/keypad.htm");
		html.replace("%title%", titleFor(session));
		html.replace("%status%", statusForKeypad(player, session));
		html.replace("%message%", message);
		html.replace("%password_confirm%", mask(session.input, session.mode == Mode.RECOVERY_CODE ? RECOVERY_LENGTH : PIN_LENGTH));
		html.replace("%close_action%", closeActionFor(session));
		html.replace("%recover_button%", session.mode == Mode.UNLOCK ? "<button value=\"Recuperar\" action=\"bypass -h voiced_charpin recover\" width=115 height=22 back=\"L2UI_CH3.bigbutton2_down\" fore=\"L2UI_CH3.bigbutton2\">" : "");
		player.sendPacket(html);
	}

	private String statusForKeypad(L2PcInstance player, PinSession session)
	{
		if ((session.mode == Mode.CREATE || session.mode == Mode.CREATE_CONFIRM) && !hasPin(player.getObjectId()))
			return "<font color=AAAAAA>Nao ativado</font>";
		
		return player.isSubmitingPin() ? "<font color=FF5555>Bloqueado</font>" : "<font color=00FF00>Desbloqueado</font>";
	}

	private String closeActionFor(PinSession session)
	{
		if (session.mode == Mode.CREATE || session.mode == Mode.CREATE_CONFIRM)
			return "bypass -h voiced_charpin cancel";
		
		return "bypass -h voiced_charpin menu";
	}
	private void showRecoveryCode(L2PcInstance player, String recovery)
	{
		NpcHtmlMessage html = new NpcHtmlMessage(0);
		html.setFile("data/html/mods/pin/recovery.htm");
		html.replace("%recovery%", recovery);
		player.sendPacket(html);
	}

	private String titleFor(PinSession session)
	{
		switch (session.mode)
		{
			case CREATE:
			case CREATE_CONFIRM:
				return "Criar Senha";
			case CHANGE_OLD:
			case CHANGE_NEW:
				return "Alterar Senha";
			case RECOVERY_CODE:
			case RECOVERY_NEW:
				return "Recuperar Senha";
			default:
				return "Senha do Personagem";
		}
	}

	private String messageFor(PinSession session)
	{
		switch (session.mode)
		{
			case CREATE:
				return "Crie uma senha de 4 digitos.";
			case CREATE_CONFIRM:
				return "Confirme a senha digitando novamente.";
			case CHANGE_OLD:
				return "Confirme sua senha atual.";
			case CHANGE_NEW:
				return "Digite a nova senha de 4 digitos.";
			case RECOVERY_CODE:
				return "Digite seu codigo de recuperacao.";
			case RECOVERY_NEW:
				return "Digite uma nova senha de 4 digitos.";
			case DISABLE:
				return "Digite a senha para desativar.";
			default:
				return "Digite sua senha de seguranca.";
		}
	}

	private static String mask(String input, int length)
	{
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < length; i++)
			sb.append(i < input.length() ? "*" : "_");
		return sb.toString();
	}

	private static String generateRecoveryCode()
	{
		int value = 10000000 + RND.nextInt(90000000);
		return String.valueOf(value);
	}

	private boolean hasPin(int objectId)
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT char_id FROM character_pin WHERE char_id=? AND disabled=0 AND pin_hash<>''"))
		{
			ps.setInt(1, objectId);
			try (ResultSet rs = ps.executeQuery())
			{
				return rs.next();
			}
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not load character PIN for objectId: " + objectId, e);
			return false;
		}
	}

	private boolean verifyPin(int objectId, String pin)
	{
		return verifyHash(objectId, pin, "pin_hash");
	}

	private boolean verifyRecovery(int objectId, String recovery)
	{
		return verifyHash(objectId, recovery, "recovery_hash");
	}

	private boolean verifyHash(int objectId, String value, String column)
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT " + column + " FROM character_pin WHERE char_id=?"))
		{
			ps.setInt(1, objectId);
			try (ResultSet rs = ps.executeQuery())
			{
				return rs.next() && hash(objectId, value).equals(rs.getString(1));
			}
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not verify character PIN for objectId: " + objectId, e);
			return false;
		}
	}

	private void savePin(L2PcInstance player, String pin, String recovery)
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement("REPLACE INTO character_pin (char_id, char_name, pin_hash, recovery_hash, disabled, updated_at) VALUES (?, ?, ?, ?, 0, NOW())"))
		{
			ps.setInt(1, player.getObjectId());
			ps.setString(2, player.getName());
			ps.setString(3, hash(player.getObjectId(), pin));
			ps.setString(4, hash(player.getObjectId(), recovery));
			ps.executeUpdate();
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not save character PIN for objectId: " + player.getObjectId(), e);
		}
	}

	private void savePinKeepingRecovery(L2PcInstance player, String pin)
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement("UPDATE character_pin SET char_name=?, pin_hash=?, disabled=0, updated_at=NOW() WHERE char_id=?"))
		{
			ps.setString(1, player.getName());
			ps.setString(2, hash(player.getObjectId(), pin));
			ps.setInt(3, player.getObjectId());
			ps.executeUpdate();
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not update character PIN for objectId: " + player.getObjectId(), e);
		}
	}

	private boolean isDisabled(int objectId)
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT disabled FROM character_pin WHERE char_id=?"))
		{
			ps.setInt(1, objectId);
			try (ResultSet rs = ps.executeQuery())
			{
				return rs.next() && rs.getInt(1) == 1;
			}
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not load character PIN status for objectId: " + objectId, e);
			return false;
		}
	}

	private void saveDisabled(L2PcInstance player)
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement("DELETE FROM character_pin WHERE char_id=?"))
		{
			ps.setInt(1, player.getObjectId());
			ps.executeUpdate();
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not disable character PIN for objectId: " + player.getObjectId(), e);
		}
	}

	private void updateCharacterName(L2PcInstance player)
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection();
			PreparedStatement ps = con.prepareStatement("UPDATE character_pin SET char_name=? WHERE char_id=?"))
		{
			ps.setString(1, player.getName());
			ps.setInt(2, player.getObjectId());
			ps.executeUpdate();
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Could not update character PIN name for objectId: " + player.getObjectId(), e);
		}
	}
	private static String hash(int objectId, String value) throws Exception
	{
		MessageDigest md = MessageDigest.getInstance("SHA-256");
		byte[] digest = md.digest((objectId + ":" + value).getBytes(StandardCharsets.UTF_8));
		StringBuilder sb = new StringBuilder();
		for (byte b : digest)
			sb.append(String.format("%02x", b & 0xff));
		return sb.toString();
	}

	private void ensureTable()
	{
		if (_tableChecked)
			return;

		synchronized (this)
		{
			if (_tableChecked)
				return;

			try (Connection con = L2DatabaseFactory.getInstance().getConnection();
				PreparedStatement ps = con.prepareStatement("CREATE TABLE IF NOT EXISTS character_pin (char_id INT NOT NULL PRIMARY KEY, char_name VARCHAR(35) NOT NULL DEFAULT '', pin_hash VARCHAR(64) NOT NULL, recovery_hash VARCHAR(64) NOT NULL, disabled TINYINT NOT NULL DEFAULT 0, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP NULL DEFAULT NULL)"))
			{
				ps.executeUpdate();
			}
			catch (Exception e)
			{
				_log.log(Level.WARNING, "Could not create character_pin table.", e);
			}
			
			try (Connection con = L2DatabaseFactory.getInstance().getConnection();
				PreparedStatement ps = con.prepareStatement("ALTER TABLE character_pin ADD COLUMN disabled TINYINT NOT NULL DEFAULT 0"))
			{
				ps.executeUpdate();
			}
			catch (Exception e)
			{
				// Column already exists on updated databases.
			}
			
			try (Connection con = L2DatabaseFactory.getInstance().getConnection();
				PreparedStatement ps = con.prepareStatement("ALTER TABLE character_pin ADD COLUMN char_name VARCHAR(35) NOT NULL DEFAULT ''"))
			{
				ps.executeUpdate();
			}
			catch (Exception e)
			{
				// Column already exists on updated databases.
			}
			
			_tableChecked = true;
		}
	}
}