package net.sf.l2j.gameserver.instancemanager.autofarmsecondary;

public enum AutofarmSecondarySpellType
{
	Attack,
	Chance,
	Self,
	Heal
}
