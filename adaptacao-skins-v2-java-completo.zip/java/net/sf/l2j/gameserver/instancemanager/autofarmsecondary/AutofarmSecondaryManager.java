package net.sf.l2j.gameserver.instancemanager.autofarmsecondary;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.ai.CtrlIntention;
import net.sf.l2j.gameserver.instancemanager.autofarm.AutofarmManager;
import net.sf.l2j.gameserver.model.actor.L2Summon;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.zone.ZoneId;
import net.sf.l2j.gameserver.network.SystemMessageId;
import net.sf.l2j.gameserver.network.serverpackets.ActionFailed;
import net.sf.l2j.gameserver.network.serverpackets.AutoHuntingState;
import net.sf.l2j.gameserver.network.serverpackets.ExShowScreenMessage;
import net.sf.l2j.gameserver.network.serverpackets.ExShowScreenMessage.SMPOS;
import net.sf.l2j.gameserver.network.serverpackets.SystemMessage;

import phantom.task.ThreadPool;

public enum AutofarmSecondaryManager
{
    INSTANCE;

    private static final Logger LOG =
        Logger.getLogger(AutofarmSecondaryManager.class.getName());

    private static final long ITERATION_SPEED_MS = 800L;

    private final ConcurrentHashMap<Integer, AutofarmSecondaryPlayerRoutine> activeFarmers =
        new ConcurrentHashMap<>();

    private final ScheduledFuture<?> onUpdateTask =
        ThreadPool.scheduleAtFixedRate(onUpdate(), 1000L, ITERATION_SPEED_MS);

    private Runnable onUpdate()
    {
        return () -> activeFarmers.forEach((objectId, routine) ->
        {
            try
            {
                final L2PcInstance player = routine.getPlayer();

                synchronized (player)
                {
                    if (activeFarmers.get(objectId) == routine)
                        routine.executeRoutine();
                }
            }
            catch (Exception e)
            {
                LOG.log(
                    Level.WARNING,
                    "Secondary autofarm routine error. Player objectId: " + objectId,
                    e
                );

                final L2PcInstance player = routine.getPlayer();

                synchronized (player)
                {
                    if (!activeFarmers.remove(objectId, routine))
                        return;

                    try
                    {
                        routine.reset();
                    }
                    catch (Exception resetException)
                    {
                        LOG.log(
                            Level.WARNING,
                            "Could not reset secondary autofarm. Player objectId: " + objectId,
                            resetException
                        );
                    }

                    player.setSecondaryAutoFarm(false);
                    player.restoreSecondaryAutoFarmAppearance();

                    if (player.isOnline())
                    {
                        player.broadcastUserInfo();
                        player.broadcastCharInfo();
                        player.sendMessage("O AutoFarm foi interrompido devido a um erro.");
                        player.sendPacket(new AutoHuntingState(player));
                    }
                }
            }
        });
    }

    public void startFarm(L2PcInstance player)
    {
        if (player == null)
            return;

        synchronized (player)
        {
            if (player.getLevel() < 20
                || player.isDead()
                || player.isAlikeDead()
                || player.isPveModeActive()
                || player.isInsideZone(ZoneId.PEACE)
                || player.isInsideZone(ZoneId.OLYMPIAD))
            {
                player.sendMessage(
                    "AutoFarm requer nivel 20, personagem vivo, fora do PvE Mode e de areas de paz/Olympiad."
                );
                player.sendPacket(new AutoHuntingState(player));
                return;
            }

            if (isAutofarming(player))
            {
                player.setSecondaryAutoFarm(true);
                player.sendPacket(new AutoHuntingState(player));
                return;
            }

            if (AutofarmManager.INSTANCE.isAutofarming(player) || player.isAutoFarm())
                AutofarmManager.INSTANCE.stopFarm(player);

            resetPlayerState(player);
            player.setSecondaryAutoFarmStartLocation();
            player.setSecondaryAutoFarm(true);

            if (!player.isSecondaryAutoFarm())
            {
                player.sendPacket(new AutoHuntingState(player));
                return;
            }

            activeFarmers.put(
                player.getObjectId(),
                new AutofarmSecondaryPlayerRoutine(player)
            );

            player.applySecondaryAutoFarmAppearance(
                Config.NEW_TITLE_AUTO_FARM,
                Config.AUTO_FARM_TITLE_COLOR
            );

            player.broadcastUserInfo();
            player.broadcastCharInfo();

            player.sendMessage("Auto Farming: Actived!");
            player.sendPacket(
                new ExShowScreenMessage(
                    "Auto Farming: Actived!",
                    5000,
                    SMPOS.MIDDLE_RIGHT,
                    false
                )
            );
            player.sendPacket(new SystemMessage(SystemMessageId.AUTO_FARM_ACTIVATED));
            player.sendPacket(new AutoHuntingState(player));
        }
    }

    public void stopFarm(L2PcInstance player)
    {
        if (player == null)
            return;

        synchronized (player)
        {
            final AutofarmSecondaryPlayerRoutine routine =
                activeFarmers.remove(player.getObjectId());

            final boolean wasActive =
                routine != null || player.isSecondaryAutoFarm();

            player.setSecondaryAutoFarm(false);
            player.restoreSecondaryAutoFarmAppearance();

            if (routine != null)
            {
                try
                {
                    routine.reset();
                }
                catch (Exception e)
                {
                    LOG.log(
                        Level.WARNING,
                        "Could not reset secondary autofarm: " + player.getName(),
                        e
                    );

                    resetPlayerState(player);
                }
            }
            else if (wasActive)
            {
                resetPlayerState(player);
            }

            if (!player.isOnline())
                return;

            if (wasActive)
            {
                player.broadcastUserInfo();
                player.broadcastCharInfo();

                player.sendMessage("Auto Farming: Deactivated!");
                player.sendPacket(
                    new ExShowScreenMessage(
                        "Auto Farming: Deactivated!",
                        5000,
                        SMPOS.MIDDLE_RIGHT,
                        false
                    )
                );
                player.sendPacket(new SystemMessage(SystemMessageId.AUTO_FARM_DESACTIVATED));
            }

            player.sendPacket(new AutoHuntingState(player));
        }
    }

    public boolean isAutofarming(L2PcInstance player)
    {
        return player != null && activeFarmers.containsKey(player.getObjectId());
    }

    public void onPlayerLogout(L2PcInstance player)
    {
        if (player == null)
            return;

        synchronized (player)
        {
            final AutofarmSecondaryPlayerRoutine routine =
                activeFarmers.remove(player.getObjectId());

            player.setSecondaryAutoFarm(false);
            player.restoreSecondaryAutoFarmAppearance();

            if (routine != null)
                routine.reset();
        }
    }

    public void onDeath(L2PcInstance player)
    {
        if (player != null
            && (player.isSecondaryAutoFarm() || isAutofarming(player)))
        {
            stopFarm(player);
        }
    }

    public ScheduledFuture<?> getOnUpdateTask()
    {
        return onUpdateTask;
    }

    private static void resetPlayerState(L2PcInstance player)
    {
        player.abortCast();
        player.abortAttack();
        player.setTarget(null);
        player.getAI().setIntention(CtrlIntention.ACTIVE);
        player.sendPacket(ActionFailed.STATIC_PACKET);

        final L2Summon summon = player.getPet();

        if (summon != null)
        {
            summon.abortCast();
            summon.abortAttack();
            summon.setTarget(null);
            summon.getAI().setIntention(CtrlIntention.ACTIVE);
        }
    }
}