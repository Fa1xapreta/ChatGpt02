/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.instancemanager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ScheduledFuture;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.ThreadPoolManager;
import net.sf.l2j.gameserver.datatables.NpcTable;
import net.sf.l2j.gameserver.datatables.SpawnTable;
import net.sf.l2j.gameserver.datatables.custom.RaidSpawnTable;
import net.sf.l2j.gameserver.datatables.custom.RaidSpawnTable.RaidSpawnInfo;
import net.sf.l2j.gameserver.model.L2Spawn;
import net.sf.l2j.gameserver.model.L2World;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.actor.instance.L2RaidBossInstance;
import net.sf.l2j.gameserver.model.actor.template.NpcTemplate;
import net.sf.l2j.gameserver.network.serverpackets.CreatureSay;
import net.sf.l2j.gameserver.templates.StatsSet;
import net.sf.l2j.gameserver.util.Broadcast;
import net.sf.l2j.gameserver.util.Util;
import net.sf.l2j.util.Rnd;

/**
 * @author godson
 **/
public class RaidBossSpawnManager
{
	protected final static Logger _log = Logger.getLogger(RaidBossSpawnManager.class.getName());
	
	protected final static Map<Integer, L2RaidBossInstance> _bosses = new HashMap<>();
	protected final static Map<Integer, L2Spawn> _spawns = new HashMap<>();
	protected final static Map<Integer, StatsSet> _storedInfo = new HashMap<>();
	protected final static Map<Integer, ScheduledFuture<?>> _schedules = new HashMap<>();
	
	public static enum StatusEnum
	{
		ALIVE,
		DEAD,
		UNDEFINED
	}
	
	public RaidBossSpawnManager()
	{
		init();
	}
	
	public static RaidBossSpawnManager getInstance()
	{
		return SingletonHolder._instance;
	}
	
	private void init()
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection())
		{
			PreparedStatement statement = con.prepareStatement("SELECT * from raidboss_spawnlist ORDER BY boss_id");
			ResultSet rset = statement.executeQuery();
			
			long respawnTime;
			while (rset.next())
			{
				final NpcTemplate template = getValidTemplate(rset.getInt("boss_id"));
				if (template != null)
				{
					final L2Spawn spawnDat = new L2Spawn(template);
					spawnDat.setLocx(rset.getInt("loc_x"));
					spawnDat.setLocy(rset.getInt("loc_y"));
					spawnDat.setLocz(rset.getInt("loc_z"));
					spawnDat.setHeading(rset.getInt("heading"));
					
					spawnDat.setRespawnMinDelay(rset.getInt("spawn_time"));
					spawnDat.setRespawnMaxDelay(rset.getInt("random_time"));
					
					respawnTime = rset.getLong("respawn_time");
					
					final RaidSpawnInfo raidSpawnInfo = RaidSpawnTable.getInstance().getBossInfo(rset.getInt("boss_id"));
					if (raidSpawnInfo != null && raidSpawnInfo.isStartDead())
					{
						final long startupRespawnTime = raidSpawnInfo.getStartupRespawnTime(System.currentTimeMillis());
						if (startupRespawnTime > System.currentTimeMillis())
							respawnTime = startupRespawnTime;
					}
					
					StatsSet info = new StatsSet();
					info.set("respawnTime", respawnTime);
					_storedInfo.put(rset.getInt("boss_id"), info);
					
					addNewSpawn(spawnDat, respawnTime, rset.getDouble("currentHP"), rset.getDouble("currentMP"), false);
					
					if (raidSpawnInfo != null && raidSpawnInfo.isStartDead() && respawnTime > System.currentTimeMillis())
						updateDbForBoss(rset.getInt("boss_id"), respawnTime, rset.getDouble("currentHP"), rset.getDouble("currentMP"));
				}
				else
				{
					_log.warning("RaidBossSpawnManager: Could not load raidboss #" + rset.getInt("boss_id") + " from DB");
				}
			}
			
			_log.info("RaidBossSpawnManager: Loaded " + _bosses.size() + " instances.");
			_log.info("RaidBossSpawnManager: Scheduled " + _schedules.size() + " instances.");
			
			rset.close();
			statement.close();
		}
		catch (SQLException e)
		{
			_log.warning("RaidBossSpawnManager: Couldnt load raidboss_spawnlist table.");
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Error while initializing RaidBossSpawnManager: " + e.getMessage(), e);
		}
	}
	
	private static class spawnSchedule implements Runnable
	{
		private final int bossId;
		
		public spawnSchedule(int npcId)
		{
			bossId = npcId;
		}
		
		@Override
		public void run()
		{
			L2RaidBossInstance raidboss = null;
			
			if (bossId == 25328)
				raidboss = DayNightSpawnManager.getInstance().handleBoss(_spawns.get(bossId));
			else
				raidboss = (L2RaidBossInstance) _spawns.get(bossId).doSpawn();
			
			if (raidboss != null)
			{
				raidboss.setRaidStatus(StatusEnum.ALIVE);
				
				final StatsSet info = new StatsSet();
				info.set("currentHP", raidboss.getCurrentHp());
				info.set("currentMP", raidboss.getCurrentMp());
				info.set("respawnTime", 0L);
				
				_storedInfo.put(bossId, info);
				
				_log.info(raidboss.getName() + " spawned in world.");
				
				_bosses.put(bossId, raidboss);
				
				Broadcast.gameAnnounceToOnlinePlayers(raidboss.getName() + " spawned in world.");
				
				for (L2PcInstance player : L2World.getInstance().getAllPlayers().values()) 
				{
					CreatureSay b = new CreatureSay(player.getObjectId(), 2, "", "" + raidboss.getName() + " spawned in world.");
					player.sendPacket(b);
				}
			}
			
			_schedules.remove(bossId);
			
		//	if (Config.LIST_RAID_BOSS_IDS.contains(bossId))
				RaidBossInfoManager.getInstance().updateRaidBossInfo(bossId, 0);
		}
	}
	
	public void updateStatusDeath(L2RaidBossInstance boss)
	{
		if (!_storedInfo.containsKey(boss.getNpcId()))
			return;
		
		final StatsSet info = _storedInfo.get(boss.getNpcId());
		
		boss.setRaidStatus(StatusEnum.DEAD);
		
		final RaidSpawnInfo raidSpawnInfo = RaidSpawnTable.getInstance().getBossInfo(boss.getNpcId());
		int respawnDelay = 0;
		long respawnTime = 0L;
		boolean customRespawn = false;
		if (raidSpawnInfo != null)
		{
			respawnTime = raidSpawnInfo.getNextRespawnTime(System.currentTimeMillis());
			customRespawn = respawnTime > 0L;
		}
		
		if (respawnTime <= 0L)
		{
			respawnDelay = boss.getSpawn().getRespawnMinDelay() + Rnd.get(-boss.getSpawn().getRespawnMaxDelay(), boss.getSpawn().getRespawnMaxDelay());
			respawnTime = Calendar.getInstance().getTimeInMillis() + (respawnDelay * 3600000);
		} 
		
		// getRespawnMinDelay() is used as fixed timer, while getRespawnMaxDelay() is used as random timer.
		//final int respawnDelay = boss.getSpawn().getRespawnMinDelay() + Rnd.get(-boss.getSpawn().getRespawnMaxDelay(), boss.getSpawn().getRespawnMaxDelay());
		//final long respawnTime = Calendar.getInstance().getTimeInMillis() + (respawnDelay * 3600000);
		
		info.set("currentHP", boss.getMaxHp());
		info.set("currentMP", boss.getMaxMp());
		info.set("respawnTime", respawnTime);
		
		if (!_schedules.containsKey(boss.getNpcId()))
		{
			final Calendar time = Calendar.getInstance();
			time.setTimeInMillis(respawnTime);
			
			if (customRespawn) 
			{
				_log.info("RaidBoss: " + boss.getName() + " - " + Util.formatDate(time.getTime(), "d MMM yyyy HH:mm"));
				_schedules.put(Integer.valueOf(boss.getNpcId()), ThreadPoolManager.getInstance().scheduleGeneral(new spawnSchedule(boss.getNpcId()), respawnTime - System.currentTimeMillis()));
			} 
			else
			{
				_log.info("RaidBoss: " + boss.getName() + " - " + Util.formatDate(time.getTime(), "d MMM yyyy HH:mm") + " (" + respawnDelay + "h).");
				_schedules.put(boss.getNpcId(), ThreadPoolManager.getInstance().scheduleGeneral(new spawnSchedule(boss.getNpcId()), respawnDelay * 3600000));
			}
			
			scheduleSpawnAnnouncement(boss.getName(), respawnTime - System.currentTimeMillis());
			
			updateDb();
			
			//if (Config.LIST_RAID_BOSS_IDS.contains(boss.getNpcId()))
				RaidBossInfoManager.getInstance().updateRaidBossInfo(boss.getNpcId(), respawnTime);
		}
		
		_storedInfo.put(boss.getNpcId(), info);
	}
	
	public void updateStatusAlive(L2RaidBossInstance boss)
	{
		if (!_storedInfo.containsKey(boss.getNpcId()))
			return;
		
		final StatsSet info = _storedInfo.get(boss.getNpcId());
		
		boss.setRaidStatus(StatusEnum.ALIVE);
		
		info.set("currentHP", boss.getCurrentHp());
		info.set("currentMP", boss.getCurrentMp());
		info.set("respawnTime", 0L);
		
		_storedInfo.put(boss.getNpcId(), info);
	}
	
	public void addNewSpawn(L2Spawn spawnDat, long respawnTime, double currentHP, double currentMP, boolean storeInDb)
	{
		if (spawnDat == null)
			return;
		
		final int bossId = spawnDat.getNpcId();
		if (_spawns.containsKey(bossId))
			return;
		
		final long time = Calendar.getInstance().getTimeInMillis();
		
		SpawnTable.getInstance().addNewSpawn(spawnDat, false);
		
		if (respawnTime == 0L || (time > respawnTime))
		{
			L2RaidBossInstance raidboss = null;
			
			if (bossId == 25328)
				raidboss = DayNightSpawnManager.getInstance().handleBoss(spawnDat);
			else
				raidboss = (L2RaidBossInstance) spawnDat.doSpawn();
			
			if (raidboss != null)
			{
				currentHP = (currentHP == 0) ? raidboss.getMaxHp() : currentHP;
				currentMP = (currentMP == 0) ? raidboss.getMaxMp() : currentMP;
				
				raidboss.setCurrentHp(currentHP);
				raidboss.setCurrentMp(currentMP);
				raidboss.setRaidStatus(StatusEnum.ALIVE);
				
				_bosses.put(bossId, raidboss);
				
				final StatsSet info = new StatsSet();
				info.set("currentHP", currentHP);
				info.set("currentMP", currentMP);
				info.set("respawnTime", 0L);
				
				_storedInfo.put(bossId, info);
			}
		}
		else
		{
			long spawnTime = respawnTime - Calendar.getInstance().getTimeInMillis();
			_schedules.put(bossId, ThreadPoolManager.getInstance().scheduleGeneral(new spawnSchedule(bossId), spawnTime));
			scheduleSpawnAnnouncement(spawnDat.getTemplate().getName(), spawnTime);
		}
		
		_spawns.put(bossId, spawnDat);
		
		if (storeInDb)
		{
			try (Connection con = L2DatabaseFactory.getInstance().getConnection())
			{
				PreparedStatement statement = con.prepareStatement("INSERT INTO raidboss_spawnlist (boss_id,loc_x,loc_y,loc_z,heading,respawn_time,currentHp,currentMp) values(?,?,?,?,?,?,?,?)");
				statement.setInt(1, spawnDat.getNpcId());
				statement.setInt(2, spawnDat.getLocx());
				statement.setInt(3, spawnDat.getLocy());
				statement.setInt(4, spawnDat.getLocz());
				statement.setInt(5, spawnDat.getHeading());
				statement.setLong(6, respawnTime);
				statement.setDouble(7, currentHP);
				statement.setDouble(8, currentMP);
				statement.execute();
				statement.close();
			}
			catch (Exception e)
			{
				// problem with storing spawn
				_log.log(Level.WARNING, "RaidBossSpawnManager: Could not store raidboss #" + bossId + " in the DB:" + e.getMessage(), e);
			}
		}
	}
	
	public void deleteSpawn(L2Spawn spawnDat, boolean updateDb)
	{
		if (spawnDat == null)
			return;
		
		final int bossId = spawnDat.getNpcId();
		if (!_spawns.containsKey(bossId))
			return;
		
		SpawnTable.getInstance().deleteSpawn(spawnDat, false);
		_spawns.remove(bossId);
		
		if (_bosses.containsKey(bossId))
			_bosses.remove(bossId);
		
		if (_schedules.containsKey(bossId))
		{
			final ScheduledFuture<?> f = _schedules.remove(bossId);
			f.cancel(true);
		}
		
		if (_storedInfo.containsKey(bossId))
			_storedInfo.remove(bossId);
		
		if (updateDb)
		{
			try (Connection con = L2DatabaseFactory.getInstance().getConnection())
			{
				PreparedStatement statement = con.prepareStatement("DELETE FROM raidboss_spawnlist WHERE boss_id=?");
				statement.setInt(1, bossId);
				statement.execute();
				statement.close();
			}
			catch (Exception e)
			{
				// problem with deleting spawn
				_log.log(Level.WARNING, "RaidBossSpawnManager: Could not remove raidboss #" + bossId + " from DB: " + e.getMessage(), e);
			}
		}
	}
	
	private void updateDb()
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection())
		{
			PreparedStatement statement = con.prepareStatement("UPDATE raidboss_spawnlist SET respawn_time = ?, currentHP = ?, currentMP = ? WHERE boss_id = ?");
			
			for (Integer bossId : _storedInfo.keySet())
			{
				if (bossId == null)
					continue;
				
				final L2RaidBossInstance boss = _bosses.get(bossId);
				if (boss == null)
					continue;
				
				if (boss.getRaidStatus().equals(StatusEnum.ALIVE))
					updateStatusAlive(boss);
				
				final StatsSet info = _storedInfo.get(bossId);
				if (info == null)
					continue;
				
				try
				{
					statement.setLong(1, info.getLong("respawnTime"));
					statement.setDouble(2, info.getDouble("currentHP"));
					statement.setDouble(3, info.getDouble("currentMP"));
					statement.setInt(4, bossId);
					statement.executeUpdate();
					statement.clearParameters();
				}
				catch (SQLException e)
				{
					_log.log(Level.WARNING, "RaidBossSpawnManager: Couldnt update raidboss_spawnlist table " + e.getMessage(), e);
				}
			}
			statement.close();
		}
		catch (SQLException e)
		{
			_log.log(Level.WARNING, "SQL error while updating RaidBoss spawn to database: " + e.getMessage(), e);
		}
	}
	
	private void updateDbForBoss(int bossId, long respawnTime, double currentHP, double currentMP)
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection())
		{
			PreparedStatement statement = con.prepareStatement("UPDATE raidboss_spawnlist SET respawn_time = ?, currentHP = ?, currentMP = ? WHERE boss_id = ?");
			statement.setLong(1, respawnTime);
			statement.setDouble(2, currentHP);
			statement.setDouble(3, currentMP);
			statement.setInt(4, bossId);
			statement.executeUpdate();
			statement.close();
			
			RaidBossInfoManager.getInstance().updateRaidBossInfo(bossId, respawnTime);
		}
		catch (SQLException e)
		{
			_log.log(Level.WARNING, "RaidBossSpawnManager: Couldnt update raidboss_spawnlist table " + e.getMessage(), e);
		}
	}
	
	public StatusEnum getRaidBossStatusId(int bossId)
	{
		if (_bosses.containsKey(bossId))
			return _bosses.get(bossId).getRaidStatus();
		
		if (_schedules.containsKey(bossId))
			return StatusEnum.DEAD;
		
		return StatusEnum.UNDEFINED;
	}
	
	public NpcTemplate getValidTemplate(int bossId)
	{
		NpcTemplate template = NpcTable.getInstance().getTemplate(bossId);
		if (template == null)
			return null;
		
		if (!template.isType("L2RaidBoss"))
			return null;
		
		return template;
	}
	
	public void notifySpawnNightBoss(L2RaidBossInstance raidboss)
	{
		final StatsSet info = new StatsSet();
		info.set("currentHP", raidboss.getCurrentHp());
		info.set("currentMP", raidboss.getCurrentMp());
		info.set("respawnTime", 0L);
		
		raidboss.setRaidStatus(StatusEnum.ALIVE);
		
		_storedInfo.put(raidboss.getNpcId(), info);
		_bosses.put(raidboss.getNpcId(), raidboss);
		
		_log.info("RaidBossSpawnManager: Spawning Night Raid Boss " + raidboss.getName());
	}
	
	public boolean isDefined(int bossId)
	{
		return _spawns.containsKey(bossId);
	}
	
	public Map<Integer, L2RaidBossInstance> getBosses()
	{
		return _bosses;
	}
	
	public Map<Integer, L2Spawn> getSpawns()
	{
		return _spawns;
	}
	
	public void reloadBosses()
	{
		init();
	}
	
	/**
	 * Saves all raidboss status and then clears all info from memory, including all schedules.
	 */
	public void cleanUp()
	{
		updateDb();
		
		_bosses.clear();
		
		if (_schedules != null)
		{
			for (Integer bossId : _schedules.keySet())
			{
				final ScheduledFuture<?> f = _schedules.get(bossId);
				f.cancel(true);
			}
			_schedules.clear();
		}
		
		_storedInfo.clear();
		_spawns.clear();
	}
	
    private static final int[] ANNOUNCE_TIMES = {60 * 60, 45 * 60, 30 * 60, 20 * 60, 10 * 60, 5 * 60, 30, 5, 4, 3, 2, 1};

    private void scheduleSpawnAnnouncement(String bossName, long delayMillis) 
    {
        for (int announceTime : ANNOUNCE_TIMES) 
        {
            long announceDelay = delayMillis - announceTime * 1000L;
            if (announceDelay > 0) 
            {
                ThreadPoolManager.getInstance().scheduleGeneral(() ->
                {
                    if (announceTime >= 60) 
                        Broadcast.gameAnnounceToOnlinePlayers(bossName + " will be appear in " + (announceTime / 60) + " minutes."); 
                    else 
                        Broadcast.gameAnnounceToOnlinePlayers(bossName + " will be appear in " + announceTime + " seconds.");

                }, announceDelay);
            }
        }
    }

	public StatsSet getStatsSet(final int bossId)
	{
		return _storedInfo.get(bossId);
	}
	
	private static class SingletonHolder
	{
		protected static final RaidBossSpawnManager _instance = new RaidBossSpawnManager();
	}
}
