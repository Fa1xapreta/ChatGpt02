package net.sf.l2j.gameserver.instancemanager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.l2j.Config;
import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.ThreadPoolManager;
import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.datatables.MapRegionTable;
import net.sf.l2j.gameserver.datatables.SkillTable;
import net.sf.l2j.gameserver.model.L2Effect;
import net.sf.l2j.gameserver.model.L2Skill;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.serverpackets.ExShowScreenMessage;

public final class SpoilSessionManager
{
    public static final int TIMER_SKILL_ID = 92016;

    public static final int GEO_TILE_X = 24;
    public static final int GEO_TILE_Y = 12;

    private static final Logger LOG =
        Logger.getLogger(SpoilSessionManager.class.getName());

    private static final long SAVE_NS =
        TimeUnit.SECONDS.toNanos(60);

    private static final long RETRY_NS =
        TimeUnit.SECONDS.toNanos(10);

    private static final long TICKET_NS =
        TimeUnit.SECONDS.toNanos(15);

    private static final String UPSERT =
        "INSERT INTO character_spoil_sessions "
        + "(char_id, remaining_ms, cooldown_until, resume_inside, "
        + "loc_x, loc_y, loc_z) "
        + "VALUES (?, ?, ?, ?, ?, ?, ?) "
        + "ON DUPLICATE KEY UPDATE "
        + "remaining_ms=VALUES(remaining_ms), "
        + "cooldown_until=VALUES(cooldown_until), "
        + "resume_inside=VALUES(resume_inside), "
        + "loc_x=VALUES(loc_x), "
        + "loc_y=VALUES(loc_y), "
        + "loc_z=VALUES(loc_z)";

    private final ConcurrentHashMap<Integer, Session> sessions =
        new ConcurrentHashMap<>();

    private long lastCleanup = System.nanoTime();

    private static final class Session
    {
        final int id;

        L2PcInstance player;

        long remainingNs;
        long cooldown;
        long lastTick;
        long lastSave = System.nanoTime();
        long lastAttempt;
        long lastClick;
        long ticketUntil;

        boolean inside;
        boolean running;
        boolean restoreInside;
        boolean dirty;

        int x;
        int y;
        int z;

        Session(int objectId)
        {
            id = objectId;
        }
    }

    private static final class Holder
    {
        private static final SpoilSessionManager INSTANCE =
            new SpoilSessionManager();
    }

    public static SpoilSessionManager getInstance()
    {
        return Holder.INSTANCE;
    }

    private SpoilSessionManager()
    {
        ThreadPoolManager.getInstance().scheduleGeneral(
            this::update,
            1000L
        );
    }

    /*
     * Identificacao dos tiles no padrao Lineage II.
     *
     * Tile X = (worldX >> 15) + 20
     * Tile Y = (worldY >> 15) + 18
     *
     * Inclui todas as alturas do mesmo tile.
     */
    public static boolean isInsideSpoilArea(int x, int y)
    {
        return ((x >> 15) + 20) == GEO_TILE_X
            && ((y >> 15) + 18) == GEO_TILE_Y;
    }

    public static boolean isInsideSpoilArea(L2PcInstance player)
    {
        return player != null
            && isInsideSpoilArea(player.getX(), player.getY());
    }

    private static boolean hasTicket(Session s)
    {
        return s.ticketUntil != 0
            && s.ticketUntil - System.nanoTime() > 0;
    }

    public static boolean isAllowedClass(L2PcInstance player)
    {
        if (player.isGM() || !Config.ENABLE_CLASS_ONLY_SPOIL)
            return true;

        final int id = player.getClassId().getId();

        // Scavenger, Bounty Hunter e Fortune Seeker.
        return id == 54 || id == 55 || id == 117;
    }

    private Session state(L2PcInstance player)
    {
        if (player == null)
            return null;

        while (true)
        {
            final Session s;

            try
            {
                s = sessions.computeIfAbsent(
                    player.getObjectId(),
                    id ->
                    {
                        try
                        {
                            return load(id);
                        }
                        catch (SQLException e)
                        {
                            throw new IllegalStateException(
                                "Could not load Spoil session",
                                e
                            );
                        }
                    }
                );
            }
            catch (IllegalStateException e)
            {
                LOG.log(
                    Level.WARNING,
                    "Spoil load failed. Player: "
                        + player.getObjectId(),
                    e
                );

                player.sendMessage(
                    "O servico de Spoil esta indisponivel. Tente novamente mais tarde."
                );

                return null;
            }

            synchronized (s)
            {
                if (sessions.get(s.id) != s)
                    continue;

                if (s.player != null && s.player != player)
                {
                    player.sendMessage(
                        "A sessao anterior de Spoil ainda esta sendo encerrada."
                    );

                    return null;
                }

                s.player = player;
                return s;
            }
        }
    }

    private Session load(int id) throws SQLException
    {
        final Session s = new Session(id);

        try (
            Connection con =
                L2DatabaseFactory.getInstance().getConnection();

            PreparedStatement st = con.prepareStatement(
                "SELECT remaining_ms, cooldown_until, resume_inside, "
                + "loc_x, loc_y, loc_z "
                + "FROM character_spoil_sessions WHERE char_id=?"
            )
        )
        {
            st.setInt(1, id);

            try (ResultSet rs = st.executeQuery())
            {
                if (rs.next())
                {
                    s.remainingNs = TimeUnit.MILLISECONDS.toNanos(
                        Math.max(0L, rs.getLong("remaining_ms"))
                    );

                    s.cooldown = Math.max(
                        0L,
                        rs.getLong("cooldown_until")
                    );

                    s.restoreInside =
                        rs.getBoolean("resume_inside")
                        && s.remainingNs > 0;

                    s.x = rs.getInt("loc_x");
                    s.y = rs.getInt("loc_y");
                    s.z = rs.getInt("loc_z");
                }
            }
        }

        return s;
    }

    private static long milliseconds(Session s)
    {
        return s.remainingNs / 1000000L
            + (s.remainingNs % 1000000L == 0 ? 0 : 1);
    }

    private static void account(Session s)
    {
        if (s.running)
        {
            final long now = System.nanoTime();

            s.remainingNs = Math.max(
                0L,
                s.remainingNs - (now - s.lastTick)
            );

            s.lastTick = now;
            s.dirty = true;
        }
    }

    private static void mirror(Session s)
    {
        if (s.player == null)
            return;

        s.player.setSpoilTimeLeft(milliseconds(s));
        s.player.setSpoilCooldown(s.cooldown);
        s.player.setInstanceSpoil(s.remainingNs > 0);

        s.player.setLastSpoilStart(
            s.running ? System.currentTimeMillis() : 0L
        );

        if (s.running
            && s.remainingNs > 0
            && isInsideSpoilArea(s.player)
            && !s.player.isGM()
            && Config.SPOIL_FARM_TITLE_ENABLED
            && Config.SPOIL_FARM_TITLE != null
            && !Config.SPOIL_FARM_TITLE.trim().isEmpty())
        {
            s.player.applySpoilFarmAppearance(
                Config.SPOIL_FARM_TITLE,
                Config.SPOIL_FARM_TITLE_COLOR
            );
        }
        else
        {
            s.player.restoreSpoilFarmAppearance();
        }
    }

    private static void position(Session s)
    {
        if (isInsideSpoilArea(s.player))
        {
            s.x = s.player.getX();
            s.y = s.player.getY();
            s.z = s.player.getZ();
        }
    }

    private boolean save(Session s)
    {
        account(s);
        position(s);
        mirror(s);

        s.lastAttempt = System.nanoTime();
        s.dirty = true;

        try (
            Connection con =
                L2DatabaseFactory.getInstance().getConnection()
        )
        {
            if (s.remainingNs == 0
                && s.cooldown <= System.currentTimeMillis())
            {
                try (
                    PreparedStatement st = con.prepareStatement(
                        "DELETE FROM character_spoil_sessions "
                        + "WHERE char_id=?"
                    )
                )
                {
                    st.setInt(1, s.id);
                    st.executeUpdate();
                }
            }
            else
            {
                try (
                    PreparedStatement st =
                        con.prepareStatement(UPSERT)
                )
                {
                    st.setInt(1, s.id);
                    st.setLong(2, milliseconds(s));
                    st.setLong(3, s.cooldown);

                    st.setBoolean(
                        4,
                        s.remainingNs > 0
                            && (s.inside || s.restoreInside)
                    );

                    st.setInt(5, s.x);
                    st.setInt(6, s.y);
                    st.setInt(7, s.z);

                    st.executeUpdate();
                }
            }

            s.dirty = false;
            s.lastSave = System.nanoTime();

            return true;
        }
        catch (SQLException e)
        {
            LOG.log(
                Level.WARNING,
                "Spoil save failed; session retained for retry. Player: "
                    + s.id,
                e
            );

            return false;
        }
    }

    public boolean onPlayerLogin(L2PcInstance player)
    {
        final Session s = state(player);

        if (s == null)
            return false;

        synchronized (s)
        {
            mirror(s);
            removeTimer(player);

            if (s.restoreInside)
            {
                if (s.remainingNs > 0
                    && isInsideSpoilArea(s.x, s.y)
                    && isAllowedClass(player)
                    && !player.isGM())
                {
                    player.setXYZ(s.x, s.y, s.z);
                }
                else
                {
                    s.restoreInside = false;
                    save(s);
                }
            }

            return true;
        }
    }

    public void onPlayerLogout(L2PcInstance player)
    {
        if (player == null)
            return;

        final Session s = sessions.get(player.getObjectId());

        if (s == null)
            return;

        synchronized (s)
        {
            if (s.player != player)
                return;

            account(s);

            if (s.running && s.remainingNs == 0)
                expire(s, false);

            position(s);

            s.restoreInside =
                s.remainingNs > 0
                && isInsideSpoilArea(player)
                && (
                    s.inside
                    || s.restoreInside
                    || hasTicket(s)
                );

            s.running = false;
            s.inside = false;
            s.ticketUntil = 0;
            s.lastClick = 0;

            mirror(s);
            removeTimer(player);

            s.player = null;

            if (save(s))
                sessions.remove(s.id, s);
        }
    }

    public long getRemainingTime(L2PcInstance player)
    {
        final Session s = state(player);

        if (s == null)
            return -1L;

        synchronized (s)
        {
            account(s);

            if (s.running && s.remainingNs == 0)
                expire(s, true);

            mirror(s);

            return milliseconds(s);
        }
    }

    public boolean teleport(
        L2PcInstance player,
        int[] location,
        boolean returnOnly
    )
    {
        if (location == null
            || location.length < 3
            || !isInsideSpoilArea(location[0], location[1]))
        {
            player.sendMessage(
                "Destino invalido: configure o teleporte dentro da area 24_12."
            );

            return false;
        }

        if (player.isGM())
        {
            player.teleToLocation(
                location[0],
                location[1],
                location[2],
                0
            );

            return true;
        }

        final Session s = state(player);

        if (s == null)
            return false;

        synchronized (s)
        {
            if (!isAllowedClass(player))
            {
                player.sendMessage(
                    "Apenas Scavenger, Bounty Hunter ou Fortune Seeker podem usar este servico."
                );

                return false;
            }

            if (player.isInCombat()
                || player.getPvpFlag() > 0
                || player.getKarma() > 0
                || player.isAlikeDead()
                || player.isCastingNow()
                || player.isInStoreMode())
            {
                player.sendMessage(
                    "Seu estado atual nao permite a entrada."
                );

                return false;
            }

            if (isInsideSpoilArea(player))
            {
                player.sendMessage(
                    "Voce ja esta na area de Spoil."
                );

                return false;
            }

            final long now = System.nanoTime();

            if (s.lastClick != 0
                && now - s.lastClick < TimeUnit.SECONDS.toNanos(3))
            {
                player.sendMessage(
                    "Aguarde alguns segundos para tentar novamente."
                );

                return false;
            }

            s.lastClick = now;

            if (s.running)
                pauseInstance(player);

            account(s);

            if (s.remainingNs == 0)
            {
                if (returnOnly)
                {
                    player.sendMessage(
                        "Voce nao possui tempo restante na Zona de Spoil."
                    );

                    return false;
                }

                if (s.cooldown > System.currentTimeMillis())
                {
                    player.sendMessage(
                        "Aguarde o cooldown para comprar outra entrada."
                    );

                    return false;
                }

                final long duration = TimeUnit.MINUTES.toMillis(
                    Config.SPOIL_ENTRANCE_TIME
                );

                final L2Skill skill =
                    SkillTable.getInstance().getInfo(
                        TIMER_SKILL_ID,
                        1
                    );

                if (duration <= 0)
                {
                    player.sendMessage(
                        "TimeInstanceSpoil precisa ser maior que zero."
                    );

                    return false;
                }

                if (Config.ITEM_SPOIL_ENTRANCE_AMOUNT <= 0)
                {
                    player.sendMessage(
                        "ItemQuantiy precisa ser maior que zero."
                    );

                    return false;
                }

                if (ItemTable.getInstance().getTemplate(
                    Config.ITEM_SPOIL_ENTRANCE
                ) == null)
                {
                    player.sendMessage(
                        "Item de entrada nao encontrado no core: "
                        + Config.ITEM_SPOIL_ENTRANCE
                    );

                    return false;
                }

                if (skill == null)
                {
                    player.sendMessage(
                        "A skill 92016, nivel 1, nao foi carregada pelo servidor. Confira o XML."
                    );

                    return false;
                }

                // Confirma acesso ao banco antes de cobrar.
                if (!save(s))
                {
                    player.sendMessage(
                        "Nao foi possivel salvar sua sessao. Nenhum item foi cobrado."
                    );

                    return false;
                }

                if (!player.destroyItemByItemId(
                    "SpoilInstanceFee",
                    Config.ITEM_SPOIL_ENTRANCE,
                    Config.ITEM_SPOIL_ENTRANCE_AMOUNT,
                    player,
                    true
                ))
                {
                    return false;
                }

                s.remainingNs = TimeUnit.MILLISECONDS.toNanos(
                    duration
                );
            }

            s.running = false;
            s.inside = false;
            s.restoreInside = false;
            s.ticketUntil = System.nanoTime() + TICKET_NS;

            mirror(s);
            removeTimer(player);

            // Falha de gravacao mantem o credito para nova tentativa.
            save(s);

            player.teleToLocation(
                location[0],
                location[1],
                location[2],
                0
            );

            return true;
        }
    }

    public void authorizeEntry(L2PcInstance player)
    {
        final Session s = state(player);

        if (s != null)
        {
            synchronized (s)
            {
                s.ticketUntil = System.nanoTime() + TICKET_NS;
            }
        }
    }

    public void removeEntryAuthorization(L2PcInstance player)
    {
        final Session s = player == null
            ? null
            : sessions.get(player.getObjectId());

        if (s != null)
        {
            synchronized (s)
            {
                if (s.player == player)
                    s.ticketUntil = 0;
            }
        }
    }

    public boolean admitEntry(L2PcInstance player)
    {
        final Session s = state(player);

        if (s == null)
            return false;

        synchronized (s)
        {
            account(s);

            if (s.running && s.remainingNs == 0)
                expire(s, false);

            final boolean authorized =
                s.inside || s.restoreInside || hasTicket(s);

            s.ticketUntil = 0;
            s.restoreInside = false;

            if (!authorized
                || !isInsideSpoilArea(player)
                || s.remainingNs == 0
                || !isAllowedClass(player))
            {
                return false;
            }

            s.inside = true;
            mirror(s);

            return true;
        }
    }

    public void resumeInstance(L2PcInstance player)
    {
        final Session s = player == null
            ? null
            : sessions.get(player.getObjectId());

        if (s == null)
            return;

        synchronized (s)
        {
            if (s.player != player
                || !s.inside
                || player.isGM()
                || !isInsideSpoilArea(player)
                || s.running)
            {
                return;
            }

            if (s.remainingNs == 0)
            {
                expire(s, true);
                return;
            }

            s.running = true;
            s.lastTick = System.nanoTime();

            mirror(s);
            applyTimer(s);
            save(s);
        }
    }

    public void pauseInstance(L2PcInstance player)
    {
        final Session s = player == null
            ? null
            : sessions.get(player.getObjectId());

        if (s == null)
            return;

        synchronized (s)
        {
            if (s.player != player)
                return;

            final boolean changed = s.running || s.inside;

            account(s);

            if (s.running && s.remainingNs == 0)
            {
                expire(s, false);
                return;
            }

            s.running = false;
            s.inside = false;
            s.restoreInside = false;

            mirror(s);
            removeTimer(player);

            if (changed)
                save(s);
        }
    }

    public void finishInstance(L2PcInstance player)
    {
        final Session s = state(player);

        if (s != null)
        {
            synchronized (s)
            {
                expire(s, true);
            }
        }
    }

    private void expire(Session s, boolean teleport)
    {
        final boolean active =
            s.running || s.remainingNs > 0 || s.inside;

        s.remainingNs = 0;
        s.running = false;
        s.inside = false;
        s.restoreInside = false;
        s.ticketUntil = 0;

        if (active)
        {
            s.cooldown =
                System.currentTimeMillis()
                + TimeUnit.MINUTES.toMillis(
                    Math.max(0, Config.SPOIL_COOLDOWN_MINUTES)
                );
        }

        mirror(s);

        if (s.player != null)
            removeTimer(s.player);

        save(s);

        if (active && s.player != null && s.player.isOnline())
        {
            s.player.sendPacket(
                new ExShowScreenMessage(
                    "Seu tempo na Zona de Spoil acabou!",
                    6000
                )
            );

            if (teleport && isInsideSpoilArea(s.player))
                returnToTown(s.player);
        }
    }

    public static void returnToTown(L2PcInstance player)
    {
        final int[] town = Config.RETURN_SPOIL_TOWN;

        if (town != null
            && town.length >= 3
            && !isInsideSpoilArea(town[0], town[1])
            && (town[0] != 0 || town[1] != 0 || town[2] != 0))
        {
            player.teleToLocation(
                town[0],
                town[1],
                town[2],
                0
            );
        }
        else
        {
            player.teleToLocation(
                MapRegionTable.TeleportWhereType.Town
            );
        }
    }

    private static void removeTimer(L2PcInstance player)
    {
        final L2Effect effect =
            player.getFirstEffect(TIMER_SKILL_ID);

        if (effect != null)
            effect.exit();

        player.updateEffectIcons();
    }

    private static void applyTimer(Session s)
    {
        final L2PcInstance player = s.player;

        removeTimer(player);

        final L2Skill skill =
            SkillTable.getInstance().getInfo(
                TIMER_SKILL_ID,
                1
            );

        if (skill == null)
        {
            throw new IllegalStateException(
                "Missing Spoil timer skill 92016/1"
            );
        }

        skill.getEffects(player, player);

        final L2Effect effect =
            player.getFirstEffect(TIMER_SKILL_ID);

        if (effect != null)
        {
            final long seconds =
                (milliseconds(s) + 999L) / 1000L;

            if (seconds > effect.getPeriod())
            {
                effect.exit();

                throw new IllegalStateException(
                    "Spoil timer effect period is shorter than remaining time"
                );
            }

            effect.setFirstTime(
                effect.getPeriod() - (int) seconds
            );

            effect.rescheduleEffect();
            player.updateEffectIcons();
        }
    }

    private void update()
    {
        try
        {
            for (Session s : sessions.values())
            {
                synchronized (s)
                {
                    if (sessions.get(s.id) != s)
                        continue;

                    try
                    {
                        if (s.player == null)
                        {
                            if (!s.dirty
                                || (
                                    System.nanoTime() - s.lastAttempt
                                        >= RETRY_NS
                                    && save(s)
                                ))
                            {
                                sessions.remove(s.id, s);
                            }

                            continue;
                        }

                        if (!s.player.isOnline())
                        {
                            onPlayerLogout(s.player);
                            continue;
                        }

                        final L2PcInstance player = s.player;

                        if (player.isGM())
                        {
                            if (s.running || s.inside)
                                pauseInstance(player);
                        }
                        else if (!isInsideSpoilArea(player))
                        {
                            if (s.running || s.inside)
                            {
                                pauseInstance(player);
                            }
                            else if (s.restoreInside)
                            {
                                s.restoreInside = false;
                                save(s);
                            }
                        }
                        else if (player.isTeleporting())
                        {
                            // Aguarda a conclusao do teleporte.
                            if (!s.running && hasTicket(s))
                            {
                                s.ticketUntil =
                                    System.nanoTime() + TICKET_NS;
                            }
                        }
                        else if (!s.running)
                        {
                            if (admitEntry(player))
                            {
                                resumeInstance(player);
                            }
                            else
                            {
                                pauseInstance(player);

                                player.sendMessage(
                                    "Acesso negado. Entre pelo NPC e tenha tempo de Spoil disponivel."
                                );

                                returnToTown(player);
                            }
                        }
                        else if (!isAllowedClass(player))
                        {
                            pauseInstance(player);
                            returnToTown(player);
                        }
                        else
                        {
                            account(s);
                            mirror(s);

                            if (s.remainingNs == 0)
                            {
                                expire(s, true);
                            }
                            else if (player.getFirstEffect(
                                TIMER_SKILL_ID
                            ) == null)
                            {
                                applyTimer(s);
                            }
                        }

                        final long now = System.nanoTime();

                        if (s.dirty
                            && now - s.lastAttempt >= RETRY_NS
                            && (
                                !s.running
                                || now - s.lastSave >= SAVE_NS
                            ))
                        {
                            save(s);
                        }
                    }
                    catch (Exception e)
                    {
                        LOG.log(
                            Level.WARNING,
                            "Spoil update failed. Player: " + s.id,
                            e
                        );

                        account(s);

                        s.running = false;
                        s.inside = false;
                        s.restoreInside = false;

                        mirror(s);
                        save(s);

                        if (s.player != null)
                        {
                            removeTimer(s.player);

                            if (s.player.isOnline()
                                && isInsideSpoilArea(s.player))
                            {
                                returnToTown(s.player);
                            }
                        }
                    }
                }
            }

            if (System.nanoTime() - lastCleanup
                >= TimeUnit.HOURS.toNanos(1))
            {
                lastCleanup = System.nanoTime();

                try (
                    Connection con =
                        L2DatabaseFactory.getInstance()
                            .getConnection();

                    PreparedStatement st = con.prepareStatement(
                        "DELETE FROM character_spoil_sessions "
                        + "WHERE remaining_ms=0 AND cooldown_until<=?"
                    )
                )
                {
                    st.setLong(1, System.currentTimeMillis());
                    st.executeUpdate();
                }
            }
        }
        catch (Exception e)
        {
            LOG.log(
                Level.WARNING,
                "Spoil central update failed",
                e
            );
        }
        finally
        {
            ThreadPoolManager.getInstance().scheduleGeneral(
                this::update,
                1000L
            );
        }
    }
}