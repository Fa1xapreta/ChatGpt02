
package net.sf.l2j.gameserver;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;



import net.sf.l2j.Config;
import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.util.CloseUtil;

public class ServerWork
{
	private static ServerWork _instance = null;
	protected static final Logger _log = Logger.getLogger(ServerWork.class.getName());
	private Calendar NEXT;
	
	public static ServerWork getInstance()
	{
		if (_instance == null)
			_instance = new ServerWork();
		return _instance;
	}
	
	private ServerWork()
	{
	}
	
	public void StartReset()
	{
		try
		{
			Calendar currentTime = Calendar.getInstance();
			Calendar testStartTime = null;
			long flush2 = 0, timeL = 0;
			int count = 0;
			
			for (String timeOfDay : Config.WORK_TIME)
			{
				testStartTime = Calendar.getInstance();
				testStartTime.setLenient(true);
				String[] splitTimeOfDay = timeOfDay.split(":");
				testStartTime.set(Calendar.HOUR_OF_DAY, Integer.parseInt(splitTimeOfDay[0]));
				testStartTime.set(Calendar.MINUTE, Integer.parseInt(splitTimeOfDay[1]));
				testStartTime.set(Calendar.SECOND, 00);
				if (testStartTime.getTimeInMillis() < currentTime.getTimeInMillis())
				{
					testStartTime.add(Calendar.DAY_OF_MONTH, 1);
				}
				
				timeL = testStartTime.getTimeInMillis() - currentTime.getTimeInMillis();
				
				if (count == 0)
				{
					flush2 = timeL;
					NEXT = testStartTime;
				}
				
				if (timeL < flush2)
				{
					flush2 = timeL;
					NEXT = testStartTime;
				}
				
				count++;
			}
			_log.info("Server work: " + NEXT.getTime().toString());
			ThreadPoolManager.getInstance().scheduleAi(new StartEventTask(), flush2);
		}
		catch (Exception e)
		{
			System.out.println("Server work: " + e);
		}
	}
	
	class StartEventTask implements Runnable
	{
		@Override
		public void run()
		{
			setCont(getCont() + 1);
			loadServer();
		}
	}
	
	public static int _cont;
	public int getCont() {
		return _cont;
	}
	
	private static final String SERVER_LOAD = "SELECT server_days FROM server_work WHERE id = 0";

	public void loadServer()
	{

		try (Connection con = L2DatabaseFactory.getInstance().getConnection())
		{
			PreparedStatement statement = con.prepareStatement(SERVER_LOAD);
			ResultSet rset = statement.executeQuery();
			
			while (rset.next())
			{
				ServerWork._cont = rset.getInt("server_days");
			}
			
			rset.close();
			statement.close();
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Server Work: Error loading Server Work from database: ", e);
		}
	}
	
	static void setCont(int value)
	{
		ThreadPoolManager.getInstance().scheduleAi(new Runnable()
		{
			@Override
			public void run()
			{
				Connection con = null;
				try
				{
					con = L2DatabaseFactory.getInstance().getConnection();
					PreparedStatement stmt = con.prepareStatement("UPDATE server_work SET server_days=?");
					stmt.setInt(1, value);
					stmt.execute();
					stmt.close();
					stmt = null;
					_cont = value;
				}
				catch (Exception e)
				{
					_log.log(Level.SEVERE, "[Server Work]:  ", e);
				}
				finally
				{
					CloseUtil.close(con);
				}
				long days = ServerWork.getInstance().getCont();
				_log.info("----------------------------------------------------------------------------");
				_log.info("Server Work: Sucessufull.");
				_log.info(Config.ANNOUNCE_WORK_DAY + " " + days + " Day's Online.");
				_log.info("----------------------------------------------------------------------------");
				
			}
			
		}, 1);
		
		NextReset();
		
	}
	
	public static void NextReset()
	{
		ThreadPoolManager.getInstance().scheduleAi(new Runnable()
		{
			@Override
			public void run()
			{
				ServerWork.getInstance().StartReset();
			}
			
		}, 1 * 1000);
	}
}
