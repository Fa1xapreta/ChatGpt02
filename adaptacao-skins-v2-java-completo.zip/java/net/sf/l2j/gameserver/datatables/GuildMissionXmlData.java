package net.sf.l2j.gameserver.datatables;

/**
* @author FA1XAPRET4
*/
public class GuildMissionXmlData
{
    public static final String DEFAULT_XML = "guildMissions.xml";

    public static String getDefaultXmlPath()
    {
        return DEFAULT_XML;
    }
}

