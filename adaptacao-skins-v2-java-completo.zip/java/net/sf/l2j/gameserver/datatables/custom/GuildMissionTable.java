package net.sf.l2j.gameserver.datatables.custom;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Map;

import com.mysql.jdbc.Connection;

import net.sf.l2j.gameserver.model.guildmission.GuildMissionProgress;

/**
 * @author FA1XAPRET4
 */
public class GuildMissionTable
{
    private static final String CREATE_TABLE = 
        "CREATE TABLE IF NOT EXISTS clan_mission_progress (" +
        "clan_id INT NOT NULL," +
        "mission_id INT NOT NULL," +
        "completed TINYINT NOT NULL DEFAULT 0," +
        "claimed TINYINT NOT NULL DEFAULT 0," + // Adicionado
        "last_completed BIGINT NOT NULL DEFAULT 0," +
        "repeat_count INT NOT NULL DEFAULT 0," +
        "progress_data TEXT NULL," +
        "PRIMARY KEY (clan_id, mission_id));";

    // Adicionado o campo 'claimed' na consulta e o 7� '?'
    private static final String SAVE_PROGRESS = "REPLACE INTO clan_mission_progress (clan_id, mission_id, completed, last_completed, repeat_count, progress_data, claimed) " +
                                                "VALUES (?, ?, ?, ?, ?, ?, ?);";

    public void createTable(java.sql.Connection connection) throws Exception
    {
        try (Statement statement = connection.createStatement())
        {
            statement.execute(CREATE_TABLE);
        }
    }

    public void saveProgress(java.sql.Connection connection, GuildMissionProgress progress) throws Exception
    {
        try (PreparedStatement statement = connection.prepareStatement(SAVE_PROGRESS))
        {
            statement.setInt(1, progress.getClanId());
            statement.setInt(2, progress.getMissionId());
            statement.setInt(3, progress.isCompleted() ? 1 : 0);
            statement.setLong(4, progress.getLastCompleted());
            statement.setInt(5, progress.getRepeatCount());
            statement.setString(6, serializeProgress(progress.getObjectiveProgressMap()));
            statement.setInt(7, progress.isClaimed() ? 1 : 0); // Agora o index 7 existe!
            
            statement.executeUpdate();
        }
    }

    public void loadProgress(Connection connection, GuildMissionProgress progress) throws Exception
    {
        // Adicionado 'claimed'
        String query = "SELECT completed, last_completed, repeat_count, progress_data, claimed FROM clan_mission_progress WHERE clan_id = ? AND mission_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query))
        {
            statement.setInt(1, progress.getClanId());
            statement.setInt(2, progress.getMissionId());
            try (ResultSet resultSet = statement.executeQuery())
            {
                if (resultSet.next())
                {
                    progress.setCompleted(resultSet.getInt("completed") == 1);
                    progress.setClaimed(resultSet.getInt("claimed") == 1); // Lendo claimed
                    progress.setLastCompleted(resultSet.getLong("last_completed"));
                    progress.setRepeatCount(resultSet.getInt("repeat_count"));
                    
                    String data = resultSet.getString("progress_data");
                    if (data != null && !data.isEmpty())
                    {
                        deserializeProgress(data, progress);
                    }
                }
            }
        }
    }
    
    public void loadAllProgress(java.sql.Connection connection, Map<Integer, Map<Integer, GuildMissionProgress>> progressCache) throws Exception
    {
        String query = "SELECT clan_id, mission_id, completed, last_completed, repeat_count, progress_data, claimed FROM clan_mission_progress";
        
        try (PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery())
        {
            while (resultSet.next())
            {
                int clanId = resultSet.getInt("clan_id");
                int missionId = resultSet.getInt("mission_id");
                
                GuildMissionProgress progress = new GuildMissionProgress();
                progress.setClanId(clanId);
                progress.setMissionId(missionId);
                progress.setCompleted(resultSet.getInt("completed") == 1);
                progress.setClaimed(resultSet.getInt("claimed") == 1);
                progress.setLastCompleted(resultSet.getLong("last_completed"));
                progress.setRepeatCount(resultSet.getInt("repeat_count"));
                
                String data = resultSet.getString("progress_data");
                if (data != null && !data.isEmpty())
                {
                    deserializeProgress(data, progress);
                }
                
                progressCache.computeIfAbsent(clanId, k -> new java.util.HashMap<>()).put(missionId, progress);
            }
        }
    }
    
    public void loadClanProgress(java.sql.Connection con, int clanId, Map<Integer, GuildMissionProgress> clanCache) throws Exception
    {
        // Adicionado 'claimed'
        String query = "SELECT mission_id, completed, last_completed, repeat_count, progress_data, claimed FROM clan_mission_progress WHERE clan_id = ?";
        
        try (PreparedStatement statement = con.prepareStatement(query))
        {
            statement.setInt(1, clanId);
            try (ResultSet resultSet = statement.executeQuery())
            {
                while (resultSet.next())
                {
                    int missionId = resultSet.getInt("mission_id");
                    
                    GuildMissionProgress progress = new GuildMissionProgress();
                    progress.setClanId(clanId);
                    progress.setMissionId(missionId);
                    progress.setCompleted(resultSet.getInt("completed") == 1);
                    progress.setClaimed(resultSet.getInt("claimed") == 1); // Lendo claimed
                    progress.setLastCompleted(resultSet.getLong("last_completed"));
                    progress.setRepeatCount(resultSet.getInt("repeat_count"));
                    
                    String data = resultSet.getString("progress_data");
                    if (data != null && !data.isEmpty())
                    {
                        deserializeProgress(data, progress);
                    }
                    
                    clanCache.put(missionId, progress);
                }
            }
        }
    }

    private String serializeProgress(Map<Integer, Long> map)
    {
        if (map == null || map.isEmpty())
        {
            return "";
        }
        StringBuilder builder = new StringBuilder();
        for (Map.Entry<Integer, Long> entry : map.entrySet())
        {
            builder.append(entry.getKey()).append(":").append(entry.getValue()).append(";");
        }
        return builder.toString();
    }
    
    private void deserializeProgress(String data, GuildMissionProgress progress)
    {
        String[] pairs = data.split(";");
        for (String pair : pairs)
        {
            if (pair.isEmpty())
            {
                continue;
            }
            String[] kv = pair.split(":");
            if (kv.length == 2)
            {
                try
                {
                    int objectiveId = Integer.parseInt(kv[0]);
                    long value = Long.parseLong(kv[1]);
                    progress.setObjectiveProgress(objectiveId, value);
                }
                catch (NumberFormatException e)
                {
                    // Ignora erros
                }
            }
        }
    }
}
