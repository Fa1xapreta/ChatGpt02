package net.sf.l2j.gameserver.datatables.custom;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;

import net.sf.l2j.gameserver.model.holder.WeaponSkinHolder;
import net.sf.l2j.gameserver.xmlfactory.XMLDocumentFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

/**
 * Loads and provides access to weapon skin definitions from:
 *   data/xml/weaponskin.xml
 *
 * Each entry maps a unique skin ID (integer key) to a {@link WeaponSkinHolder}
 * that contains the weapon item ID to display, plus name and icon metadata.
 *
 * Usage in-game: .weapontry
 */
public class WeaponSkinTable
{
	private static final Logger _log = Logger.getLogger(WeaponSkinTable.class.getName());

	/** skinId  WeaponSkinHolder */
	private static final Map<Integer, WeaponSkinHolder> _map = new HashMap<>();

	public static WeaponSkinTable getInstance()
	{
		return SingletonHolder._instance;
	}

	protected WeaponSkinTable()
	{
		try
		{
			final File f = new File("./data/xml/weaponskin.xml");
			if (!f.exists())
			{
				_log.warning("WeaponSkinTable: weaponskin.xml not found � no weapon skins loaded.");
				return;
			}

			final Document doc = XMLDocumentFactory.getInstance().loadDocument(f);
			for (Node n = doc.getFirstChild(); n != null; n = n.getNextSibling())
			{
				if ("list".equalsIgnoreCase(n.getNodeName()))
				{
					for (Node d = n.getFirstChild(); d != null; d = d.getNextSibling())
					{
						if ("weaponskin".equalsIgnoreCase(d.getNodeName()))
						{
							final NamedNodeMap attrs = d.getAttributes();

							final int id           = Integer.parseInt(attrs.getNamedItem("id").getNodeValue());
							final int weaponItemId = Integer.parseInt(attrs.getNamedItem("weaponItemId").getNodeValue());

							final Node nameAttr = attrs.getNamedItem("name");
							final Node iconAttr = attrs.getNamedItem("icon");
							final String name = (nameAttr != null) ? nameAttr.getNodeValue() : "Weapon Skin #" + id;
							final String icon = (iconAttr != null) ? iconAttr.getNodeValue() : "icon.NOIMAGE";

							if (id <= 0 || weaponItemId <= 0 || _map.putIfAbsent(id, new WeaponSkinHolder(weaponItemId, name, icon)) != null)
								throw new IllegalArgumentException("Duplicate or invalid legacy weapon skin ID " + id);
						}
					}
				}
			}
			_log.info("WeaponSkinTable: Loaded " + _map.size() + " weapon skins.");
		}
		catch (Exception e)
		{
			throw new IllegalStateException("Invalid data/xml/weaponskin.xml", e);
		}
	}

	/** Returns the {@link WeaponSkinHolder} for the given skin ID, or {@code null} if not found. */
	public WeaponSkinHolder getSkin(int skinId)
	{
		return _map.get(skinId);
	}

	/** Returns {@code true} if a weapon skin with this ID is registered. */
	public boolean hasSkin(int skinId)
	{
		return _map.containsKey(skinId);
	}

	/** Returns the set of all registered weapon skin IDs. */
	public Set<Integer> getAllSkinIds()
	{
		return _map.keySet();
	}

	private static class SingletonHolder
	{
		protected static final WeaponSkinTable _instance = new WeaponSkinTable();
	}
}
