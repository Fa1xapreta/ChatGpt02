package net.sf.l2j.gameserver.datatables.custom;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import net.sf.l2j.gameserver.xmlfactory.XMLDocumentFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public class RaidSpawnTable
{
	private static Logger _log = Logger.getLogger(RaidSpawnTable.class.getName());

	private static final Map<Integer, RaidSpawnInfo> _map = new HashMap<>();

	public static RaidSpawnTable getInstance() 
	{
		return SingletonHolder._instance;
	}

	protected RaidSpawnTable() 
	{
		load();
	}
	
	public synchronized void reload()
	{
		load();
	}
	
	private synchronized void load()
	{
		try 
		{
			final Map<Integer, RaidSpawnInfo> loaded = new HashMap<>();
			File f = new File("./data/xml/raidspawn.xml");
			Document doc = XMLDocumentFactory.getInstance().loadDocument(f);
			for (Node n = doc.getFirstChild(); n != null; n = n.getNextSibling()) 
			{
				if ("list".equalsIgnoreCase(n.getNodeName()))
					for (Node d = n.getFirstChild(); d != null; d = d.getNextSibling()) 
					{
						List<String> raidSpawn = new ArrayList<>();
						if ("boss".equalsIgnoreCase(d.getNodeName())) 
						{
							NamedNodeMap attrs = d.getAttributes();
							int id = Integer.valueOf(getValue(attrs, "id", "0")).intValue();
							raidSpawn = parseList(getValue(attrs, "spawn", getValue(attrs, "fixedTimes", "")));
							
							final RaidSpawnInfo info = new RaidSpawnInfo(id);
							info.setFixedTimes(raidSpawn);
							info.setIntervalHours(Integer.valueOf(getValue(attrs, "intervalHours", "0")).intValue());
							info.setRandomHours(Integer.valueOf(getValue(attrs, "randomHours", "0")).intValue());
							info.setStartDead(Boolean.valueOf(getValue(attrs, "startDead", "false")).booleanValue());
							info.setStartRespawn(getValue(attrs, "startRespawn", ""));
							info.setStartDay(getValue(attrs, "startDay", ""));
							info.setStartTime(getValue(attrs, "startTime", ""));
							
							if (loaded.containsKey(Integer.valueOf(id)))
								_log.warning("RaidSpawnTable: Duplicate boss id " + id + " in raidspawn.xml. The last entry will be used.");
							
							loaded.put(Integer.valueOf(id), info);
						} 
					}  
			} 
			
			_map.clear();
			_map.putAll(loaded);
			_log.info("RaidSpawnTable: Loaded " + _map.size() + " custom boss respawn.");
		}
		catch (Exception e) 
		{
			_log.warning("RaidSpawnTable: Error while loading custom boss respawn table: " + e);
		} 
	}

	public static final List<String> parseList(String line) 
	{
		List<String> list = new ArrayList<>();
		if (line == null || line.trim().isEmpty())
			return list;
		
		for (String id : line.split(","))
		{
			if (!id.trim().isEmpty())
				list.add(id.trim());
		}
		return list;
	}

	public List<String> getBossSpawn(int bossId) 
	{
		final RaidSpawnInfo info = getBossInfo(bossId);
		return info == null ? null : info.getFixedTimes();
	}

	public RaidSpawnInfo getBossInfo(int bossId)
	{
		return _map.get(Integer.valueOf(bossId));
	}
	
	public boolean containsBoss(int bossId) 
	{
		return _map != null && _map.containsKey(Integer.valueOf(bossId));
	}
	
	private static String getValue(NamedNodeMap attrs, String name, String defaultValue)
	{
		final Node node = attrs.getNamedItem(name);
		return node == null ? defaultValue : node.getNodeValue().trim();
	}
	
	public static class RaidSpawnInfo
	{
		private final int _bossId;
		private List<String> _fixedTimes = new ArrayList<>();
		private int _intervalHours;
		private int _randomHours;
		private boolean _startDead;
		private String _startRespawn = "";
		private String _startDay = "";
		private String _startTime = "";
		
		protected RaidSpawnInfo(int bossId)
		{
			_bossId = bossId;
		}
		
		public int getBossId()
		{
			return _bossId;
		}
		
		public List<String> getFixedTimes()
		{
			return _fixedTimes;
		}
		
		public void setFixedTimes(List<String> fixedTimes)
		{
			_fixedTimes = fixedTimes;
		}
		
		public int getIntervalHours()
		{
			return _intervalHours;
		}
		
		public void setIntervalHours(int intervalHours)
		{
			_intervalHours = intervalHours;
		}
		
		public int getRandomHours()
		{
			return _randomHours;
		}
		
		public void setRandomHours(int randomHours)
		{
			_randomHours = randomHours;
		}
		
		public boolean isStartDead()
		{
			return _startDead;
		}
		
		public void setStartDead(boolean startDead)
		{
			_startDead = startDead;
		}
		
		public String getStartRespawn()
		{
			return _startRespawn;
		}
		
		public void setStartRespawn(String startRespawn)
		{
			_startRespawn = startRespawn;
		}
		
		public String getStartDay()
		{
			return _startDay;
		}
		
		public void setStartDay(String startDay)
		{
			_startDay = startDay;
		}
		
		public String getStartTime()
		{
			return _startTime;
		}
		
		public void setStartTime(String startTime)
		{
			_startTime = startTime;
		}
		
		public boolean hasFixedTimes()
		{
			return _fixedTimes != null && !_fixedTimes.isEmpty();
		}
		
		public boolean hasInterval()
		{
			return _intervalHours > 0;
		}
		
		public boolean hasStartupRule()
		{
			return (_startRespawn != null && !_startRespawn.isEmpty()) || (_startDay != null && !_startDay.isEmpty() && _startTime != null && !_startTime.isEmpty());
		}
		
		public long getNextRespawnTime(long now)
		{
			if (_startDay != null && !_startDay.isEmpty() && _startTime != null && !_startTime.isEmpty())
				return getNextDayTime(now, _startDay, _startTime);
			
			if (hasFixedTimes())
				return getNextFixedTime(now);
			
			if (hasInterval())
			{
				final Calendar time = Calendar.getInstance();
				time.setTimeInMillis(now);
				time.add(Calendar.HOUR_OF_DAY, _intervalHours);
				
				if (_randomHours > 0)
					time.add(Calendar.HOUR_OF_DAY, net.sf.l2j.util.Rnd.get(-_randomHours, _randomHours));
				
				if (time.getTimeInMillis() <= now)
					time.setTimeInMillis(now + 60000L);
				
				return time.getTimeInMillis();
			}
			
			return 0L;
		}
		
		public long getStartupRespawnTime(long now)
		{
			long respawn = parseDateTime(_startRespawn);
			if (respawn > now)
				return respawn;
			
			if (_startRespawn != null && !_startRespawn.isEmpty())
				return 0L;
			
			respawn = getNextDayTime(now, _startDay, _startTime);
			if (respawn > now)
				return respawn;
			
			if (_startDay != null && !_startDay.isEmpty() || _startTime != null && !_startTime.isEmpty())
				return 0L;
			
			return getNextRespawnTime(now);
		}
		
		private long getNextFixedTime(long now)
		{
			Calendar currentTime = Calendar.getInstance();
			currentTime.setTimeInMillis(now);
			Calendar nextStartTime = null;
			
			for (String timeOfDay : _fixedTimes)
			{
				Calendar testStartTime = getTimeOfDay(now, timeOfDay);
				if (testStartTime == null)
					continue;
				
				if (testStartTime.getTimeInMillis() < currentTime.getTimeInMillis())
					testStartTime.add(Calendar.DATE, 1);
				
				if (nextStartTime == null || testStartTime.getTimeInMillis() < nextStartTime.getTimeInMillis())
					nextStartTime = testStartTime;
			}
			
			return nextStartTime == null ? 0L : nextStartTime.getTimeInMillis();
		}
		
		private static Calendar getTimeOfDay(long now, String timeOfDay)
		{
			try
			{
				String[] splitTimeOfDay = timeOfDay.split(":");
				Calendar testStartTime = Calendar.getInstance();
				testStartTime.setTimeInMillis(now);
				testStartTime.setLenient(true);
				testStartTime.set(Calendar.HOUR_OF_DAY, Integer.parseInt(splitTimeOfDay[0]));
				testStartTime.set(Calendar.MINUTE, Integer.parseInt(splitTimeOfDay[1]));
				testStartTime.set(Calendar.SECOND, 0);
				testStartTime.set(Calendar.MILLISECOND, 0);
				return testStartTime;
			}
			catch (Exception e)
			{
				_log.warning("RaidSpawnTable: Invalid time format: " + timeOfDay);
				return null;
			}
		}
		
		private static long parseDateTime(String value)
		{
			if (value == null || value.isEmpty())
				return 0L;
			
			try
			{
				String[] dateTime = value.split(" ");
				String[] date = dateTime[0].split("-");
				String[] time = dateTime[1].split(":");
				
				Calendar calendar = Calendar.getInstance();
				calendar.set(Calendar.YEAR, Integer.parseInt(date[0]));
				calendar.set(Calendar.MONTH, Integer.parseInt(date[1]) - 1);
				calendar.set(Calendar.DATE, Integer.parseInt(date[2]));
				calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(time[0]));
				calendar.set(Calendar.MINUTE, Integer.parseInt(time[1]));
				calendar.set(Calendar.SECOND, 0);
				calendar.set(Calendar.MILLISECOND, 0);
				return calendar.getTimeInMillis();
			}
			catch (Exception e)
			{
				_log.warning("RaidSpawnTable: Invalid startRespawn format: " + value);
				return 0L;
			}
		}
		
		private static long getNextDayTime(long now, String day, String time)
		{
			if (day == null || day.isEmpty() || time == null || time.isEmpty())
				return 0L;
			
			final int dayOfWeek = parseDay(day);
			if (dayOfWeek == 0)
				return 0L;
			
			Calendar calendar = getTimeOfDay(now, time);
			if (calendar == null)
				return 0L;
			
			calendar.set(Calendar.DAY_OF_WEEK, dayOfWeek);
			if (calendar.getTimeInMillis() <= now)
				calendar.add(Calendar.DATE, 7);
			
			return calendar.getTimeInMillis();
		}
		
		private static int parseDay(String day)
		{
			final String value = day.trim().toUpperCase();
			if (value.equals("SUNDAY") || value.equals("DOMINGO"))
				return Calendar.SUNDAY;
			if (value.equals("MONDAY") || value.equals("SEGUNDA"))
				return Calendar.MONDAY;
			if (value.equals("TUESDAY") || value.equals("TERCA"))
				return Calendar.TUESDAY;
			if (value.equals("WEDNESDAY") || value.equals("QUARTA"))
				return Calendar.WEDNESDAY;
			if (value.equals("THURSDAY") || value.equals("QUINTA"))
				return Calendar.THURSDAY;
			if (value.equals("FRIDAY") || value.equals("SEXTA"))
				return Calendar.FRIDAY;
			if (value.equals("SATURDAY") || value.equals("SABADO"))
				return Calendar.SATURDAY;
			
			_log.warning("RaidSpawnTable: Invalid startDay: " + day);
			return 0;
		}
	}

	private static class SingletonHolder 
	{
		protected static final RaidSpawnTable _instance = new RaidSpawnTable();
	}
}



