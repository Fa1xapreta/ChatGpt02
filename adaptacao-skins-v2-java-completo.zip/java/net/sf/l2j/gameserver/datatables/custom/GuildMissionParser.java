package net.sf.l2j.gameserver.datatables.custom;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import net.sf.l2j.gameserver.model.GuildMission;
import net.sf.l2j.gameserver.model.guildmission.GuildMissionReward;
import net.sf.l2j.gameserver.model.guildmission.MissionCategory;
import net.sf.l2j.gameserver.model.guildmission.MissionCondition;
import net.sf.l2j.gameserver.model.guildmission.MissionObjective;
import net.sf.l2j.gameserver.model.guildmission.MissionType;

/**
* @author FA1XAPRET4
*/
public class GuildMissionParser
{
    public List<GuildMission> parse(String path)
    {
        List<GuildMission> missions = new ArrayList<>();
        try
        {
            File file = new File(path);
            if (!file.exists())
            {
                file = new File("guildMissions.xml");
            }
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(file);
            document.getDocumentElement().normalize();
            NodeList missionNodes = document.getElementsByTagName("mission");
            for (int index = 0; index < missionNodes.getLength(); index++)
            {
                Node node = missionNodes.item(index);
                if (node.getNodeType() != Node.ELEMENT_NODE)
                {
                    continue;
                }
                Element element = (Element) node;
                GuildMission mission = new GuildMission();
                mission.setId(Integer.parseInt(getValue(element, "id")));
                mission.setName(getValue(element, "name"));
                mission.setDescription(getValue(element, "description"));
                mission.setCategory(MissionCategory.valueOf(getValue(element, "category")));
                mission.setType(MissionType.valueOf(getValue(element, "type")));
                mission.setRepeatable(Boolean.parseBoolean(getValue(element, "repeatable")));
                mission.setResetHours(Integer.parseInt(getValue(element, "resetHours")));
                mission.setSchedule(getValue(element, "schedule"));
                mission.setActive(Boolean.parseBoolean(getValue(element, "active")));
                mission.setIcon(getValue(element, "icon"));
                
                String checkHwid = getValue(element, "checkHwid");
                if (!checkHwid.isEmpty())
                {
                    mission.setCheckHwid(Boolean.parseBoolean(checkHwid));
                }

                String checkIp = getValue(element, "checkIp");
                if (!checkIp.isEmpty())
                {
                    mission.setCheckIp(Boolean.parseBoolean(checkIp));
                }
        
                mission.setCondition(parseCondition(element));
                mission.setObjectives(parseObjectives(element));
                mission.setRewards(parseRewards(element));
                missions.add(mission);
            }
        }
        catch (Exception e)
        {
            throw new IllegalStateException("Unable to parse guild missions XML", e);
        }
        return missions;
    }

    private MissionCondition parseCondition(Element element)
    {
        Element conditionElement = getChild(element, "condition");
        if (conditionElement == null)
        {
            return null;
        }
        MissionCondition condition = new MissionCondition();
        condition.setMinClanLevel(parseInt(conditionElement, "minClanLevel"));
        condition.setMinMembers(parseInt(conditionElement, "minMembers"));
        condition.setRequiresCastle(Boolean.parseBoolean(getValue(conditionElement, "requiresCastle")));
        condition.setRequiresAlliance(Boolean.parseBoolean(getValue(conditionElement, "requiresAlliance")));
        condition.setRequiredQuest(getValue(conditionElement, "requiredQuest"));
        condition.setRequiredClass(getValue(conditionElement, "requiredClass"));
        condition.setRequiredLevel(parseInt(conditionElement, "requiredLevel"));
        condition.setRequiredSubClass(parseInt(conditionElement, "requiredSubClass"));
        return condition;
    }

    private List<MissionObjective> parseObjectives(Element element)
    {
        List<MissionObjective> objectives = new ArrayList<>();
        Element objectivesElement = getChild(element, "objectives");
        if (objectivesElement == null)
        {
            return objectives;
        }
        NodeList objectiveNodes = objectivesElement.getElementsByTagName("objective");
        for (int index = 0; index < objectiveNodes.getLength(); index++)
        {
            Node node = objectiveNodes.item(index);
            if (node.getNodeType() != Node.ELEMENT_NODE)
            {
                continue;
            }
            Element objectiveElement = (Element) node;
            MissionObjective objective = new MissionObjective();
            objective.setId(parseInt(objectiveElement, "id"));
            objective.setType(MissionType.valueOf(getValue(objectiveElement, "type")));
            
            // === CORRE��O AQUI: Use setTargetIds em vez de parseInt para aceitar a v�rgula ("515,516") ===
            String targetIdText = getValue(objectiveElement, "targetId");
            objective.setTargetIds(targetIdText);
            
            objective.setQuantity(parseLong(objectiveElement, "quantity"));
            objective.setMetadata(getValue(objectiveElement, "metadata"));
            objectives.add(objective);
        }
        return objectives;
    }

    private List<GuildMissionReward> parseRewards(Element element)
    {
        List<GuildMissionReward> rewards = new ArrayList<>();
        Element rewardsElement = getChild(element, "rewards");
        if (rewardsElement == null)
        {
            return rewards;
        }
        NodeList rewardNodes = rewardsElement.getElementsByTagName("reward");
        for (int index = 0; index < rewardNodes.getLength(); index++)
        {
            Node node = rewardNodes.item(index);
            if (node.getNodeType() != Node.ELEMENT_NODE)
            {
                continue;
            }
            Element rewardElement = (Element) node;
            GuildMissionReward reward = new GuildMissionReward();
            reward.setItemId(parseInt(rewardElement, "itemId"));
            reward.setItemCount(parseLong(rewardElement, "itemCount"));
            reward.setAdena(parseLong(rewardElement, "adena"));
            reward.setClanReputation(parseInt(rewardElement, "clanReputation"));
            reward.setSkillId(parseInt(rewardElement, "skillId"));
            reward.setBuffId(parseInt(rewardElement, "buffId"));
            reward.setCoins(parseLong(rewardElement, "coins"));
            reward.setCustomReward(getValue(rewardElement, "customReward"));
            rewards.add(reward);
        }
        return rewards;
    }

    private Element getChild(Element parent, String tagName)
    {
        NodeList children = parent.getChildNodes();
        for (int index = 0; index < children.getLength(); index++)
        {
            Node node = children.item(index);
            if (node.getNodeType() == Node.ELEMENT_NODE && tagName.equals(node.getNodeName()))
            {
                return (Element) node;
            }
        }
        return null;
    }

    private String getValue(Element parent, String tagName)
    {
        Element child = getChild(parent, tagName);
        return child == null ? "" : child.getTextContent().trim();
    }

    private int parseInt(Element parent, String tagName)
    {
        String value = getValue(parent, tagName);
        return value.isEmpty() ? 0 : Integer.parseInt(value);
    }

    private long parseLong(Element parent, String tagName)
    {
        String value = getValue(parent, tagName);
        return value.isEmpty() ? 0L : Long.parseLong(value);
    }
}
