package net.sf.l2j.gameserver.datatables.custom;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

public class AnnouceMultiSell
{
	private static final Logger _log = Logger.getLogger(AnnouceMultiSell.class.getName());

	private static AnnouceMultiSell _instance;

	private static final Map<Integer, Map<String, Object>> getList = new HashMap<>();

	public static AnnouceMultiSell getInstance()
	{
		if (_instance == null)
			_instance = new AnnouceMultiSell();

		return _instance;
	}

	private AnnouceMultiSell()
	{
		load();
	}
	
	public void reload()
	{
		getList.clear();
		load();
	}

	private void load()
	{
		final File file = new File("data/xml/announceMultiSell.xml");

		if (!file.exists())
		{
			_log.warning("announceMultiSell: XML file does not exist, check directory!");
			return;
		}

		try
		{
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setValidating(false);
			factory.setIgnoringComments(true);

			InputSource in = new InputSource(new InputStreamReader(new FileInputStream(file), "UTF-8"));
			in.setEncoding("UTF-8");

			Document doc = factory.newDocumentBuilder().parse(in);

			for (Node listNode = doc.getFirstChild(); listNode != null; listNode = listNode.getNextSibling())
			{
				if (!listNode.getNodeName().equalsIgnoreCase("list"))
					continue;

				for (Node multisellNode = listNode.getFirstChild(); multisellNode != null; multisellNode = multisellNode.getNextSibling())
				{
					if (!multisellNode.getNodeName().equalsIgnoreCase("multisell"))
						continue;

					int id = multisellNode.getAttributes().getNamedItem("id").getNodeValue().hashCode();
					boolean firework = Boolean.parseBoolean(multisellNode.getAttributes().getNamedItem("firework").getNodeValue());
					String msg = multisellNode.getAttributes().getNamedItem("msg").getNodeValue();
					int typemsg = Integer.parseInt(multisellNode.getAttributes().getNamedItem("typemsg").getNodeValue());

					Map<String, Object> map = new HashMap<>();
					map.put("firework", firework);
					map.put("msg", msg);
					map.put("typemsg", typemsg);

					getList.put(id, map);
				}
			}

			_log.info("announceMultiSell: Loaded " + getList.size() + " multisell announces.");
		}
		catch (Exception e)
		{
			_log.warning("announceMultiSell: Error while loading XML: " + e);
			e.printStackTrace();
		}
	}

	public boolean contains(int idMultisell)
	{
		return getList.containsKey(idMultisell);
	}

	private static Map<String, Object> getMap(int idMultisell)
	{
		return getList.get(idMultisell);
	}

	public boolean getFirework(int idMultisell)
	{
		Map<String, Object> map = getMap(idMultisell);
		return map != null && (Boolean) map.get("firework");
	}

	public String getMsg(int idMultisell)
	{
		Map<String, Object> map = getMap(idMultisell);
		return map != null ? (String) map.get("msg") : "";
	}

	public int getTypeMsg(int idMultisell)
	{
		Map<String, Object> map = getMap(idMultisell);
		return map != null ? (Integer) map.get("typemsg") : 0;
	}
}