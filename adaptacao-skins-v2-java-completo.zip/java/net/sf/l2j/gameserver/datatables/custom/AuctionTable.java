package net.sf.l2j.gameserver.datatables.custom;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.model.holder.AuctionHolder;

public class AuctionTable {
    private static final Logger log = Logger.getLogger(AuctionTable.class.getName());
    
    private final Map<Integer, AuctionHolder> items = new ConcurrentHashMap<>();
    
    private int maxId = 0;
    
    public static AuctionTable getInstance() {
        return SingletonHolder._instance;
    }
    
    protected AuctionTable() {
        load();
    }
    
    private void load() {
        try(Connection con = L2DatabaseFactory.getInstance().getConnection(); 
                PreparedStatement ps = con.prepareStatement("SELECT * FROM auction_table"); 
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                int auctionId = rs.getInt("auctionid");
                int ownerId = rs.getInt("ownerid");
                int itemId = rs.getInt("itemid");
                int count = rs.getInt("count");
                int enchant = rs.getInt("enchant");
                int costId = rs.getInt("costid");
                int costCount = rs.getInt("costcount");
                int augAttributes = 0;
                int augSkillId = 0;
                int augSkillLevel = 0;
                try {
                    augAttributes = rs.getInt("aug_attributes");
                    augSkillId = rs.getInt("aug_skill_id");
                    augSkillLevel = rs.getInt("aug_skill_lvl");
                } catch (SQLException sQLException) {}
                this.items.put(Integer.valueOf(auctionId), new AuctionHolder(auctionId, ownerId, itemId, count, enchant, costId, costCount, augAttributes, augSkillId, augSkillLevel));
                if (auctionId > this.maxId)
                    this.maxId = auctionId; 
            } 
        } catch (Exception e) {
            e.printStackTrace();
        } 
        log.info("AuctionTable: Loaded " + this.items.size() + " items.");
    }
    
    public void addItem(AuctionHolder holder) {
        this.items.put(Integer.valueOf(holder.getAuctionId()), holder);
        try(Connection con = L2DatabaseFactory.getInstance().getConnection(); 
                PreparedStatement ps = con.prepareStatement("INSERT INTO auction_table (auctionid, ownerid, itemid, count, enchant, costid, costcount, aug_attributes, aug_skill_id, aug_skill_lvl) VALUES (?,?,?,?,?,?,?,?,?,?)")) {
            ps.setInt(1, holder.getAuctionId());
            ps.setInt(2, holder.getOwnerId());
            ps.setInt(3, holder.getItemId());
            ps.setInt(4, holder.getCount());
            ps.setInt(5, holder.getEnchant());
            ps.setInt(6, holder.getCostId());
            ps.setInt(7, holder.getCostCount());
            ps.setInt(8, holder.getAugAttributes());
            ps.setInt(9, holder.getAugSkillId());
            ps.setInt(10, holder.getAugSkillLevel());
            ps.execute();
        } catch (Exception e) {
            e.printStackTrace();
        } 
    }
    
    public void deleteItem(AuctionHolder holder) {
        this.items.remove(Integer.valueOf(holder.getAuctionId()));
        try(Connection con = L2DatabaseFactory.getInstance().getConnection(); 
                PreparedStatement ps = con.prepareStatement("DELETE FROM auction_table WHERE auctionid=?")) {
            ps.setInt(1, holder.getAuctionId());
            ps.execute();
        } catch (Exception e) {
            e.printStackTrace();
        } 
    }
    
    public AuctionHolder getItem(int auctionId) {
        return this.items.get(Integer.valueOf(auctionId));
    }
    
    public Map<Integer, AuctionHolder> getItems() {
        return this.items;
    }
    
    public int getNextAuctionId() {
        return ++this.maxId;
    }
    
    private static class SingletonHolder {
        protected static final AuctionTable _instance = new AuctionTable();
    }
}
