/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.datatables.custom;

import java.io.File;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.l2j.gameserver.xmlfactory.XMLDocumentFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

/**
 * @author Tayran.JavaDev
 */
public class IconTable
{
	private static final Logger _log = Logger.getLogger(IconTable.class.getName());

	private static final Map<Integer, String> _icons = new ConcurrentHashMap<>();

	public static IconTable getInstance()
	{
		return SingletonHolder._instance;
	}

	protected IconTable()
	{
		load();
	}

	private static void load()
	{
		try
		{
			File f = new File("./data/xml/icons.xml");

			if (!f.exists())
			{
				_log.warning("Icon Table: File not found: " + f.getAbsolutePath());
				return;
			}

			Document doc = XMLDocumentFactory.getInstance().loadDocument(f);

			if (doc == null)
			{
				_log.warning("Icon Table: Failed to load icons.xml");
				return;
			}

			Node root = doc.getFirstChild();

			for (Node d = root.getFirstChild(); d != null; d = d.getNextSibling())
			{
				if (!"icon".equalsIgnoreCase(d.getNodeName()))
					continue;

				NamedNodeMap attrs = d.getAttributes();

				int itemId = Integer.parseInt(attrs.getNamedItem("itemId").getNodeValue());
				String iconName = attrs.getNamedItem("iconName").getNodeValue();

				if (itemId <= 0)
				{
					_log.warning("Icon Table: Invalid itemId: " + itemId);
					continue;
				}

				_icons.put(itemId, iconName);
			}
		}
		catch (Exception e)
		{
			_log.log(Level.WARNING, "Icon Table: Error loading icons.xml.", e);
		}

		_log.info("Icon Table: Loaded " + _icons.size() + " icons.");
	}

	/**
	 * Reload icons.xml
	 */
	public void reload()
	{
		_icons.clear();
		load();
		_log.info("Icon Table: Reload complete.");
	}

	public static String getIcon(int id)
	{
		String icon = _icons.get(id);
		return (icon != null) ? icon : "icon.NOIMAGE";
	}

	private static class SingletonHolder
	{
		protected static final IconTable _instance = new IconTable();
	}
}