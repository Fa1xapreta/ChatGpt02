package net.sf.l2j.gameserver.datatables.custom;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.logging.Logger;

import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.model.TradeList.TradeItem;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;

public class TradeHistoryTable
{
	private static final Logger _log = Logger.getLogger(TradeHistoryTable.class.getName());

	private static final String INSERT = "INSERT INTO character_trade_history (trade_id, char_id, char_name, partner_id, partner_name, direction, item_id, item_name, item_count, enchant, augmentation_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)";

	public static TradeHistoryTable getInstance()
	{
		return SingletonHolder._instance;
	}

	public void logTrade(L2PcInstance playerOne, L2PcInstance playerTwo, TradeItem[] playerOneItems, TradeItem[] playerTwoItems)
	{
		if (playerOne == null || playerTwo == null)
			return;

		String tradeId = System.currentTimeMillis() + "-" + playerOne.getObjectId() + "-" + playerTwo.getObjectId();

		try (Connection con = L2DatabaseFactory.getInstance().getConnection(); PreparedStatement ps = con.prepareStatement(INSERT))
		{
			addItems(ps, tradeId, playerOne, playerTwo, "GAVE", playerOneItems);
			addItems(ps, tradeId, playerTwo, playerOne, "RECEIVED", playerOneItems);
			addItems(ps, tradeId, playerTwo, playerOne, "GAVE", playerTwoItems);
			addItems(ps, tradeId, playerOne, playerTwo, "RECEIVED", playerTwoItems);
			ps.executeBatch();
		}
		catch (Exception e)
		{
			_log.warning("Could not save trade history: " + e.getMessage());
		}
	}

	private static void addItems(PreparedStatement ps, String tradeId, L2PcInstance player, L2PcInstance partner, String direction, TradeItem[] items) throws Exception
	{
		if (items == null)
			return;

		for (TradeItem item : items)
		{
			if (item == null || item.getItem() == null || item.getCount() <= 0)
				continue;

			ps.setString(1, tradeId);
			ps.setInt(2, player.getObjectId());
			ps.setString(3, player.getName());
			ps.setInt(4, partner.getObjectId());
			ps.setString(5, partner.getName());
			ps.setString(6, direction);
			ps.setInt(7, item.getItem().getItemId());
			ps.setString(8, item.getItem().getName());
			ps.setLong(9, item.getCount());
			ps.setInt(10, item.getEnchant());
			ps.setInt(11, item.getAugmentationId());
			ps.addBatch();
		}
	}

	private static class SingletonHolder
	{
		protected static final TradeHistoryTable _instance = new TradeHistoryTable();
	}
}
