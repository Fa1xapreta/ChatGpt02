package net.sf.l2j.gameserver.datatables.custom;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Logger;

import net.sf.l2j.L2DatabaseFactory;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;

public class VipAuditLog
{
	private static final Logger _log = Logger.getLogger(VipAuditLog.class.getName());
	private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	private static final ThreadLocal<String> CONTEXT = new ThreadLocal<>();
	private static final String INSERT = "INSERT INTO character_vip_audit (char_id, char_name, account_name, action, source, old_end, new_end, actor_name, notes) VALUES (?,?,?,?,?,?,?,?,?)";

	public static void setContext(String context)
	{
		CONTEXT.set(context);
	}

	public static void logVipTimeChange(L2PcInstance player, long oldEnd, long newEnd)
	{
		if (player == null || newEnd <= 0 || oldEnd == newEnd)
			return;

		String source = consumeContext();
		String action = oldEnd > System.currentTimeMillis() ? "EXTEND" : "START";
		log(player, action, source, oldEnd, newEnd, null);
	}

	public static void logVipEnd(L2PcInstance player, long oldEnd)
	{
		if (player == null || oldEnd <= 0)
			return;

		String source = consumeContext();
		String action = source.indexOf("EXPIRED") >= 0 || oldEnd <= System.currentTimeMillis() ? "EXPIRED" : "REMOVED";
		log(player, action, source, oldEnd, 0, null);
	}

	public static void showAdminLog(L2PcInstance admin, String charName, int page)
	{
		if (admin == null)
			return;

		page = Math.max(1, page);
		int limit = 10;
		int offset = (page - 1) * limit;
		StringBuilder rows = new StringBuilder();
		boolean hasNext = false;

		String sql = charName == null || charName.isEmpty() ? "SELECT * FROM character_vip_audit ORDER BY id DESC LIMIT ? OFFSET ?" : "SELECT * FROM character_vip_audit WHERE char_name=? ORDER BY id DESC LIMIT ? OFFSET ?";
		try (Connection con = L2DatabaseFactory.getInstance().getConnection(); PreparedStatement ps = con.prepareStatement(sql))
		{
			int index = 1;
			if (charName != null && !charName.isEmpty())
				ps.setString(index++, charName);
			ps.setInt(index++, limit + 1);
			ps.setInt(index, offset);

			try (ResultSet rs = ps.executeQuery())
			{
				int count = 0;
				while (rs.next())
				{
					count++;
					if (count > limit)
					{
						hasNext = true;
						break;
					}

					String eventTime = shortDbDateTime(rs.getString("event_time"));
					String action = displayAction(rs.getString("action"));
					String player = shorten(rs.getString("char_name"), 16);

					rows.append("<table width=280 bgcolor=000000><tr>");
					rows.append("<td width=85><font color=B09878>").append(eventTime).append("</font></td>");
					rows.append("<td width=55><font color=LEVEL>").append(action).append("</font></td>");
					rows.append("<td width=140>").append(escape(player)).append("</td>");
					rows.append("</tr></table><img src=L2UI.SquareGray width=280 height=1>");
				}
			}
		}
		catch (Exception e)
		{
			rows.append("Could not load VIP log. Check SQL table.<br>");
			_log.warning("Could not load VIP audit log: " + e.getMessage());
		}

		if (rows.length() == 0)
			rows.append("No VIP log found.<br>");

		String prev = page > 1 ? pageLink("Previous", charName, page - 1) : "";
		String next = hasNext ? pageLink("Next", charName, page + 1) : "";

		String html = "<html><body><center><font color=LEVEL>VIP Audit Log</font><br1><font color=808080>Date / Event / Player</font><br><br>" + rows + "<br><table width=260><tr><td align=center>" + prev + "</td><td align=center>Page " + page + "</td><td align=center>" + next + "</td></tr></table></center></body></html>";
		NpcHtmlMessage msg = new NpcHtmlMessage(0);
		msg.setHtml(html);
		admin.sendPacket(msg);
	}

	private static void log(L2PcInstance player, String action, String source, long oldEnd, long newEnd, String notes)
	{
		writeTxt(player, action, source, oldEnd, newEnd, notes);
		writeDb(player, action, source, oldEnd, newEnd, notes);
	}

	private static void writeTxt(L2PcInstance player, String action, String source, long oldEnd, long newEnd, String notes)
	{
		try
		{
			File file = new File("log/vip-audit.txt");
			File parent = file.getParentFile();
			if (parent != null)
				parent.mkdirs();

			try (PrintWriter out = new PrintWriter(new FileWriter(file, true)))
			{
				out.println(DATE_FORMAT.format(new Date()) + " | " + action + " | char=" + player.getName() + "(" + player.getObjectId() + ") | account=" + safeAccount(player) + " | source=" + source + " | oldEnd=" + formatTime(oldEnd) + " | newEnd=" + formatTime(newEnd) + (notes != null ? " | " + notes : ""));
			}
		}
		catch (Exception e)
		{
			_log.warning("Could not write VIP audit txt: " + e.getMessage());
		}
	}

	private static void writeDb(L2PcInstance player, String action, String source, long oldEnd, long newEnd, String notes)
	{
		try (Connection con = L2DatabaseFactory.getInstance().getConnection(); PreparedStatement ps = con.prepareStatement(INSERT))
		{
			ps.setInt(1, player.getObjectId());
			ps.setString(2, player.getName());
			ps.setString(3, safeAccount(player));
			ps.setString(4, action);
			ps.setString(5, source);
			ps.setLong(6, oldEnd);
			ps.setLong(7, newEnd);
			ps.setString(8, "");
			ps.setString(9, notes == null ? "" : notes);
			ps.executeUpdate();
		}
		catch (Exception e)
		{
			_log.warning("Could not write VIP audit db: " + e.getMessage());
		}
	}

	private static String consumeContext()
	{
		String context = CONTEXT.get();
		CONTEXT.remove();
		return context == null || context.isEmpty() ? "UNKNOWN" : context;
	}

	private static String safeAccount(L2PcInstance player)
	{
		try
		{
			return player.getAccountName();
		}
		catch (Exception e)
		{
			return "";
		}
	}

	private static String formatTime(long time)
	{
		return time <= 0 ? "0" : DATE_FORMAT.format(new Date(time));
	}

	private static String shortDbDateTime(String time)
	{
		if (time == null || time.length() < 16)
			return "--/-- --:--";
		return time.substring(8, 10) + "/" + time.substring(5, 7) + " " + time.substring(11, 16);
	}

	private static String displayAction(String action)
	{
		if (action == null)
			return "";
		return action.equals("EXPIRED") || action.equals("REMOVED") ? "END" : "START";
	}

	private static String pageLink(String text, String charName, int page)
	{
		String command = charName == null || charName.isEmpty() ? "admin_viplog " + page : "admin_viplog " + charName + " " + page;
		return "<a action=\"bypass -h " + command + "\">" + text + "</a>";
	}

	private static String shorten(String text, int maxLength)
	{
		if (text == null)
			return "";
		return text.length() <= maxLength ? text : text.substring(0, Math.max(0, maxLength - 3)) + "...";
	}

	private static String escape(String text)
	{
		return text == null ? "" : text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
	}
}


