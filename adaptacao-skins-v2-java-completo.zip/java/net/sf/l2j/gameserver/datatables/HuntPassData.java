package net.sf.l2j.gameserver.datatables;

import java.io.File;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.l2j.gameserver.xmlfactory.XMLDocumentFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public final class HuntPassData
{
	private static final Logger _log = Logger.getLogger(HuntPassData.class.getName());
	private static final String PATH = "./data/xml/huntpass.xml";
	// ============================================================
		// HUNT PASS - MOBS PERMITIDOS
		// ============================================================
		public static Set<Integer> ALLOWED_MOBS = new HashSet<>();

	public static boolean ENABLED = true;
	public static int LEVELS_PER_PAGE = 10;

	// ============================================================
	// HUNT PASS - ITEM DO PREMIUM
	// ============================================================
	public static int COIN_ITEM_ID = 9501; // Event Coin
	public static int PREMIUM_COST = 50;

	// ============================================================
	// HUNT PASS - CUSTO DO RESET
	// ============================================================
	public static int RESET_COST = 100;

	// ============================================================
	// HUNT PASS - PAGAMENTO PARA USAR O HUNT PASS
	// ============================================================
	public static int HUNT_PASS_ACCESS_ITEM_ID = 9501;
	public static int HUNT_PASS_ACCESS_COST = 1;

	// ============================================================
	// HUNT PASS - PONTUA��O
	// ============================================================
	public static int SCORE_MONSTER = 10;
	public static int SCORE_RAID = 100;
	public static int SCORE_BOSS = 200;

	public static String EXPIRATION_DATE = "31_12_2026";

	private final Map<Integer, LevelReward> _levels = new LinkedHashMap<>();

	public static final class LevelReward
	{
		public final int level;
		public final int requiredScore;
		public final int freeItemId;
		public final int freeCount;
		public final int premiumItemId;
		public final int premiumCount;

		public LevelReward(int level, int requiredScore, int freeItemId, int freeCount, int premiumItemId, int premiumCount)
		{
			this.level = level;
			this.requiredScore = requiredScore;
			this.freeItemId = freeItemId;
			this.freeCount = freeCount;
			this.premiumItemId = premiumItemId;
			this.premiumCount = premiumCount;
		}
	}

	protected HuntPassData()
	{
		load();
	}

	public static HuntPassData getInstance()
	{
		return SingletonHolder._instance;
	}

	public void load()
	{
		_levels.clear();

		try
		{
			final File file = new File(PATH);

			if (!file.exists())
			{
				_log.warning("HuntPassData: missing " + PATH + " � Hunt Pass disabled.");ENABLED = false;
				return;
			}

			final Document doc = XMLDocumentFactory.getInstance().loadDocument(file);

			for (Node n = doc.getFirstChild(); n != null; n = n.getNextSibling())
			{
				if (!"list".equalsIgnoreCase(n.getNodeName()))
					continue;

				for (Node d = n.getFirstChild(); d != null; d = d.getNextSibling())
				{
					if (d.getNodeType() != Node.ELEMENT_NODE)
						continue;

					final String name = d.getNodeName();
					final NamedNodeMap attrs = d.getAttributes();

					if ("set".equalsIgnoreCase(name))
					{
						parseSet(
							attrs.getNamedItem("name").getNodeValue(),
							attrs.getNamedItem("val").getNodeValue()
						);
					}
					else if ("reward".equalsIgnoreCase(name))
					{
						final int level = Integer.parseInt(
							attrs.getNamedItem("level").getNodeValue()
						);

						final int req = Integer.parseInt(
							attrs.getNamedItem("required_score").getNodeValue()
						);

						final int freeId = Integer.parseInt(
							attrs.getNamedItem("free_reward_item").getNodeValue()
						);

						final int freeCnt = Integer.parseInt(
							attrs.getNamedItem("free_reward_count").getNodeValue()
						);

						final int premId = Integer.parseInt(
							attrs.getNamedItem("premium_reward_item").getNodeValue()
						);

						final int premCnt = Integer.parseInt(
							attrs.getNamedItem("premium_reward_count").getNodeValue()
						);

						_levels.put(
							level,
							new LevelReward(level,req,freeId,freeCnt,premId,premCnt));
					}
				}
			}

			//_log.info("HuntPassData: loaded "+ _levels.size()+ " levels (enabled="+ ENABLED+ ", accessItemId="+ HUNT_PASS_ACCESS_ITEM_ID+ ", accessCost="+ HUNT_PASS_ACCESS_COST+ ").");
		}
		catch (Exception e)
		{
			ENABLED = false;

			_log.log(Level.WARNING,"HuntPassData: load failed � Hunt Pass disabled.",e);
		}
	}

	private static void parseSet(String name, String val)
	{
		switch (name)
		{
			case "Enabled":
				ENABLED = Boolean.parseBoolean(val);
				break;

			case "LevelsPerPage":
				LEVELS_PER_PAGE = Math.max(1, Integer.parseInt(val));
				break;

			case "CoinItemId":
				COIN_ITEM_ID = Integer.parseInt(val);
				break;

			case "PremiumCost":
				PREMIUM_COST = Integer.parseInt(val);
				break;

			case "ResetCost":
				RESET_COST = Integer.parseInt(val);
				break;

			case "HuntPass_Mobs_IDs":
				ALLOWED_MOBS.clear();
				if (val != null && !val.isEmpty())
				{
					for (String idStr : val.split(","))
					{
						try
						{
							ALLOWED_MOBS.add(Integer.parseInt(idStr.trim()));
						}
						catch (NumberFormatException e)
						{
							_log.warning("HuntPassData: Invalid mob ID in HuntPass_Mobs_IDs: " + idStr);
						}
					}
				}
				break;
				
			// ====================================================
			// ITEM PARA PAGAR O ACESSO AO HUNT PASS
			// ====================================================
			case "HuntPassAccessItemId":
				HUNT_PASS_ACCESS_ITEM_ID = Integer.parseInt(val);
				break;

			case "HuntPassAccessCost":
				HUNT_PASS_ACCESS_COST = Math.max(1, Integer.parseInt(val));
				break;

			case "ScoreMonster":
				SCORE_MONSTER = Integer.parseInt(val);
				break;

			case "ScoreRaid":
				SCORE_RAID = Integer.parseInt(val);
				break;

			case "ScoreBoss":
				SCORE_BOSS = Integer.parseInt(val);
				break;

			case "ExpirationDate":
				EXPIRATION_DATE = val.replace(' ', '_');
				break;

			default:
				break;
		}
	}

	public Map<Integer, LevelReward> getLevels()
	{
		return Collections.unmodifiableMap(_levels);
	}

	public LevelReward getLevel(int level)
	{
		return _levels.get(level);
	}

	public int getMaxLevel()
	{
		int max = 0;

		for (int lv : _levels.keySet())
		{
			if (lv > max)
				max = lv;
		}

		return max;
	}

	public int getMaxRequiredScore()
	{
		int max = 0;

		for (LevelReward lr : _levels.values())
		{
			if (lr.requiredScore > max)
				max = lr.requiredScore;
		}

		return max;
	}

	public int getMaxPage()
	{
		final int maxLv = getMaxLevel();

		if (maxLv <= 0)
			return 1;

		return (int) Math.ceil(
			maxLv / (double) LEVELS_PER_PAGE
		);
	}

	public static boolean isAllowedMob(int npcId)
	{
		return ALLOWED_MOBS.contains(npcId);
	}
	
	private static class SingletonHolder
	{
		protected static final HuntPassData _instance = new HuntPassData();
	}
}
