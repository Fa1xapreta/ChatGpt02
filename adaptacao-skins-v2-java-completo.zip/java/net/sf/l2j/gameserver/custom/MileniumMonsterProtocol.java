package net.sf.l2j.gameserver.custom;

import java.util.ArrayList;
import java.util.List;

/** Text protocol consumed by the adapted model interface. No HTML is generated. */
public final class MileniumMonsterProtocol
{
    // Keep each tutorial event well below common legacy client string buffers.
    private static final int MAX_ROW_DATA_CHARS = 1200;

    private MileniumMonsterProtocol() { }

    public static String clean(String text)
    {
        if (text == null) return "";
        return text.replaceAll("[\\p{Cntrl}|^;,<>]", " ").trim();
    }

    /** Unreal Asc()/Chr() query transport: four hexadecimal digits per UTF-16 unit. */
    public static String decodeQuery(String encoded)
    {
        if ("-".equals(encoded)) return "";
        if (encoded == null || encoded.length() > 256 || encoded.length() % 4 != 0)
            throw new IllegalArgumentException("Invalid query length");
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < encoded.length(); i += 4)
        {
            String unit = encoded.substring(i, i + 4);
            if (!unit.matches("[0-9a-fA-F]{4}")) throw new IllegalArgumentException("Invalid query encoding");
            char value = (char) Integer.parseInt(unit, 16);
            if (Character.isISOControl(value)) throw new IllegalArgumentException("Invalid query character");
            out.append(value);
        }
        return out.toString().trim();
    }

    public static List<String> rowPackets(String prefix, int request, List<String> rows, String type)
    {
        List<String> packets = new ArrayList<>();
        int offset = 0;
        while (offset < rows.size())
        {
            int first = offset;
            StringBuilder data = new StringBuilder();
            while (offset < rows.size() && data.length() + rows.get(offset).length() + 1 <= MAX_ROW_DATA_CHARS)
                data.append(rows.get(offset++)).append(';');
            if (offset == first) throw new IllegalArgumentException("A row exceeds the packet bound");
            packets.add(prefix + "|TYPE=" + type + "|REQ=" + request + "|OFFSET=" + first + "|DATA=" + data + "|");
        }
        return packets;
    }
}
