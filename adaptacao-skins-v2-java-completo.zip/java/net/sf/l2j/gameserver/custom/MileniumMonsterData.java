package net.sf.l2j.gameserver.custom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.l2j.gameserver.datatables.ItemTable;
import net.sf.l2j.gameserver.datatables.NpcTable;
import net.sf.l2j.gameserver.datatables.SpawnTable;
import net.sf.l2j.gameserver.model.L2Spawn;
import net.sf.l2j.gameserver.model.actor.L2Npc;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.actor.template.NpcTemplate;
import net.sf.l2j.gameserver.model.item.DropCategory;
import net.sf.l2j.gameserver.model.item.DropData;
import net.sf.l2j.gameserver.model.item.kind.Item;
import net.sf.l2j.gameserver.model.quest.Quest;
import net.sf.l2j.gameserver.model.quest.QuestEventType;
import net.sf.l2j.gameserver.network.serverpackets.TutorialShowHtml;


/** Read-only Monster Data endpoint backed by this server's loaded templates. */
public final class MileniumMonsterData
{
    private static final String INFO = "MOB_INFO";
    private static final String CATALOG = "MOB_CATALOG";
    private static final Map<Integer, Long> LAST_READ = new ConcurrentHashMap<>();
    private static final Logger LOG = Logger.getLogger(MileniumMonsterData.class.getName());

    private MileniumMonsterData() { }

    public static boolean handles(String command)
    {
        return command != null && (command.equals("milenium_mobinfo") || command.startsWith("milenium_mobinfo "));
    }

    public static void open(L2PcInstance player)
    {
        send(player, INFO + "|TYPE=FEATURES|VISIBLE=1|PREVIEW=1|ANIMATION=1|BROWSER=1|QUESTS=1|SHIFT=0|");
        if (player.getTarget() instanceof L2Npc)
            send(player, INFO + "|TYPE=OPEN|OBJECT=" + player.getTarget().getObjectId() + "|");
        else send(player, INFO + "|TYPE=OPEN_BROWSER|");
    }

    public static void handle(L2PcInstance player, String command)
    {
        if (player == null || !handles(command)) return;
        String[] args = command.split("\\s+", 6);
        if (args.length == 1 || args[1].equals("open")) { open(player); return; }
        boolean catalog = args[1].equals("catalog");
        int request = 0;
        try
        {
            if (args[1].equals("show")) request = requestNumber(args[3]);
            else request = requestNumber(args[2]);
            long now = System.currentTimeMillis();
            Long last = LAST_READ.put(player.getObjectId(), now);
            if (LAST_READ.size() > 10000) LAST_READ.entrySet().removeIf(e -> now - e.getValue() > 300000);
            if (last != null && now - last < 250)
            {
                error(player, catalog ? CATALOG : INFO, request, "Aguarde um instante e selecione novamente.");
                return;
            }
            if (catalog)
            {
                if (args.length != 6) throw new IllegalArgumentException();
                catalog(player, request, Integer.parseInt(args[3]), Integer.parseInt(args[4]), MileniumMonsterProtocol.decodeQuery(args[5]));
            }
            else if (args[1].equals("detail"))
            {
                if (args.length != 4) throw new IllegalArgumentException();
                NpcTemplate template = NpcTable.getInstance().getTemplate(positive(args[3]));
                if (template == null) throw new IllegalArgumentException();
                detail(player, request, template, null);
            }
            else if (args[1].equals("show"))
            {
                if (args.length != 4 && args.length != 6) throw new IllegalArgumentException();
                if (!(player.getTarget() instanceof L2Npc)) throw new IllegalArgumentException();
                L2Npc target = (L2Npc) player.getTarget();
                if (target.getObjectId() != positive(args[2])) throw new IllegalArgumentException();
                detail(player, request, target.getTemplate(), target);
                if (args.length == 6) catalog(player, requestNumber(args[4]), Integer.parseInt(args[5]), 0, "");
            }
            else throw new IllegalArgumentException();
        }
        catch (IllegalArgumentException | IndexOutOfBoundsException e)
        {
            error(player, catalog ? CATALOG : INFO, request, "Consulta invalida. Selecione novamente.");
        }
        catch (RuntimeException e)
        {
            LOG.log(Level.WARNING, "Milenium Monster Data query failed", e);
            error(player, catalog ? CATALOG : INFO, request, "Dados indisponiveis. Selecione novamente.");
        }
    }

    private static int positive(String text)
    {
        int value = Integer.parseInt(text);
        if (value < 1) throw new IllegalArgumentException();
        return value;
    }

    private static int requestNumber(String text)
    {
        int value = positive(text);
        if (value > 1000000) throw new IllegalArgumentException();
        return value;
    }

    private static void send(L2PcInstance player, String packet) { player.sendPacket(new TutorialShowHtml(packet)); }
    private static void error(L2PcInstance p, String prefix, int req, String text)
    {
        send(p, prefix + "|TYPE=ERROR|REQ=" + req + "|TEXT=" + MileniumMonsterProtocol.clean(text) + "|");
    }

    private static void catalog(L2PcInstance p, int req, int page, int mode, String query)
    {
        if (page != -1 || mode < 0 || mode > 3) throw new IllegalArgumentException();
        String search = query.toLowerCase(Locale.ROOT);
        List<NpcTemplate> matches = new ArrayList<>();
        for (NpcTemplate npc : NpcTable.getInstance().getAllNpcs())
        {
            if (npc.getNpcId() <= 0 || npc.getIdTemplate() <= 0) continue;
            boolean found = mode == 0 ? matches(search, npc.getNpcId(), npc.getName()) : false;
            if (mode == 1 || mode == 2)
            {
                if (npc.getDropData() != null)
                    for (DropCategory category : npc.getDropData())
                        if (category.isSweep() == (mode == 2))
                            for (DropData drop : category.getAllDrops())
                            {
                                Item item = ItemTable.getInstance().getTemplate(drop.getItemId());
                                if (matches(search, drop.getItemId(), item == null ? "" : item.getName())) found = true;
                            }
            }
            if (mode == 3)
                for (QuestRow quest : quests(npc)) if (matches(search, quest.id, quest.name)) found = true;
            if (found) matches.add(npc);
        }
        matches.sort(Comparator.comparing(NpcTemplate::getName, String.CASE_INSENSITIVE_ORDER).thenComparingInt(NpcTemplate::getNpcId));
        if (matches.size() > 65535) throw new IllegalArgumentException();
        List<String> rows = new ArrayList<>();
        for (NpcTemplate n : matches)
            rows.add(n.getNpcId() + "^" + n.getIdTemplate() + "^" + MileniumMonsterProtocol.clean(n.getName()) + "^" + (n.getLevel() & 255));
        send(p, CATALOG + "|TYPE=BEGIN|REQ=" + req + "|PAGE=-1|MODE=" + mode + "|TOTAL=" + rows.size() + "|ROWS=" + rows.size() + "|");
        for (String packet : MileniumMonsterProtocol.rowPackets(CATALOG, req, rows, "ROWS")) send(p, packet);
        send(p, CATALOG + "|TYPE=END|REQ=" + req + "|COUNT=" + rows.size() + "|");
    }

    private static boolean matches(String query, int id, String name)
    {
        return query.isEmpty() || Integer.toString(id).equals(query) || (name != null && name.toLowerCase(Locale.ROOT).contains(query));
    }

    private static void detail(L2PcInstance p, int req, NpcTemplate npc, L2Npc live)
    {
        List<String> drops = new ArrayList<>();
        if (npc.getDropData() != null)
            for (DropCategory category : npc.getDropData())
                for (DropData drop : category.getAllDrops())
                {
                    Item item = ItemTable.getInstance().getTemplate(drop.getItemId());
                    String icon = item == null ? "" : item.getIcon();
                    String name = item == null ? "Item #" + drop.getItemId() : item.getName();
                    String chance = BigDecimal.valueOf(drop.getChance(), 4).stripTrailingZeros().toPlainString();
                    drops.add((category.isSweep() ? "S" : "D") + "," + drop.getItemId() + "," + drop.getMinDrop() + "," + drop.getMaxDrop() + "," + chance + "," + MileniumMonsterProtocol.clean(icon) + "," + MileniumMonsterProtocol.clean(name));
                }
        List<String> questRows = new ArrayList<>();
        for (QuestRow quest : quests(npc)) questRows.add(quest.id + "^" + MileniumMonsterProtocol.clean(quest.name) + "^" + quest.roles);
        if (drops.size() > 2048 || questRows.size() > 2048) throw new IllegalArgumentException();
        int[] loc = location(p, npc, live);
        int level = npc.getLevel() & 255;
        String type = npc.getType().toLowerCase(Locale.ROOT);
        String kind = type.contains("grandboss") ? "EPIC BOSS" : type.contains("raidboss") ? "RAID BOSS" : type.contains("monster") || type.contains("attackable") ? "MONSTER" : "NPC";
        send(p, INFO + "|TYPE=BEGIN|REQ=" + req + "|OBJECT=" + (live == null ? 0 : live.getObjectId()) + "|NPC=" + npc.getNpcId() + "|DISPLAY=" + npc.getIdTemplate() + "|NAME=" + MileniumMonsterProtocol.clean(npc.getName()) + "|KIND=" + kind + "|LEVEL=" + level
            + "|HP=" + Math.round(npc.getBaseHpMax(level)) + "|MP=" + Math.round(npc.getBaseMpMax(level)) + "|PATK=" + Math.round(npc.getBasePAtk()) + "|PDEF=" + Math.round(npc.getBasePDef()) + "|MATK=" + Math.round(npc.getBaseMAtk()) + "|MDEF=" + Math.round(npc.getBaseMDef())
            + "|EXP=" + npc.getRewardExp() + "|SP=" + npc.getRewardSp() + "|ROWS=" + drops.size() + "|QUESTS=" + questRows.size() + "|X=" + loc[0] + "|Y=" + loc[1] + "|Z=" + loc[2] + "|HASSITE=" + loc[3] + "|HEIGHT=" + npc.getCollisionHeight() + "|PREVIEW=1|ANIMATION=1|");
        for (String packet : MileniumMonsterProtocol.rowPackets(INFO, req, drops, "ITEMS")) send(p, packet);
        for (String packet : MileniumMonsterProtocol.rowPackets(INFO, req, questRows, "QUESTS")) send(p, packet);
        send(p, INFO + "|TYPE=END|REQ=" + req + "|COUNT=" + drops.size() + "|QUESTCOUNT=" + questRows.size() + "|");
    }

    private static int[] location(L2PcInstance p, NpcTemplate npc, L2Npc live)
    {
        if (live != null) return new int[] {live.getX(), live.getY(), live.getZ(), 1};
        L2Spawn closest = null;
        double best = Double.MAX_VALUE;
        for (L2Spawn spawn : SpawnTable.getInstance().getSpawnTable())
            if (spawn.getNpcId() == npc.getNpcId())
            {
                double dx = (double) p.getX() - spawn.getLocx(), dy = (double) p.getY() - spawn.getLocy();
                double d = dx * dx + dy * dy;
                if (d < best) { best = d; closest = spawn; }
            }
        return closest == null ? new int[4] : new int[] {closest.getLocx(), closest.getLocy(), closest.getLocz(), 1};
    }

    private static final class QuestRow
    {
        final int id;
        final String name;
        int roles;
        QuestRow(Quest q) { id = q.getQuestId(); name = q.getName(); }
    }

    private static List<QuestRow> quests(NpcTemplate npc)
    {
        Map<Integer, QuestRow> rows = new LinkedHashMap<>();
        if (npc.getEventQuests() != null)
        {
            for (Map.Entry<QuestEventType, List<Quest>> entry : npc.getEventQuests().entrySet())
            {
                int role = entry.getKey() == QuestEventType.QUEST_START ? 1
                    : (entry.getKey() == QuestEventType.ON_TALK
                        || entry.getKey() == QuestEventType.ON_FIRST_TALK) ? 2
                    : entry.getKey() == QuestEventType.ON_KILL ? 4
                    : 8;
                for (Quest q : entry.getValue())
                {
                    if (q.getQuestId() <= 0 || q.getQuestId() > 1000000) continue;
                    rows.computeIfAbsent(q.getQuestId(), ignored -> new QuestRow(q)).roles |= role;
                }
            }
        }
        return new ArrayList<>(rows.values());
    }
}
