package net.sf.l2j.gameserver;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

import net.sf.l2j.Config;

/**
 * Checagem de licenca do servidor.
 *
 * Comportamento:
 *  - Valida a licenca online (key + IP) no site lineage2arts.com.
 *  - Se o site responder que a licenca e INVALIDA  -> bloqueia o servidor.
 *  - Se NAO conseguir contato com o site (sem internet, site fora, etc.)
 *    -> NAO derruba o servidor: usa a ultima validacao em cache (ate 7 dias)
 *       ou, se nao houver cache, inicia mesmo assim apenas avisando.
 */
public class LicenseCheck {

    // Tenta HTTPS; se falhar, cai automaticamente para HTTP.
    private static final String VALIDATE_URL_HTTPS = "https://lineage2arts.com/api/validate-license.php";
    private static final String VALIDATE_URL_HTTP  = "http://lineage2arts.com/api/validate-license.php";

    private static final int TIMEOUT_MS = 8000;

    // Cache local da ultima validacao bem-sucedida.
    private static final File CACHE_FILE = new File("./config/.license_cache");
    // Tolerancia: quantos dias o servidor pode rodar offline usando o cache.
    private static final long CACHE_TOLERANCE_MS = 7L * 24 * 60 * 60 * 1000; // 7 dias

    public static void validate() {
        String key = Config.LICENSE_KEY;
        String ip = Config.EXTERNAL_HOSTNAME;

        if (ip == null || ip.trim().isEmpty()) {
            System.out.println("===============================================");
            System.err.println("[KEY] ERRO: Config HOSTNAME esta vazio em network.properties");
            System.err.println("[KEY] Verifique a configuracao do IP do servidor");
            System.out.println("===============================================");
            System.exit(1);
        }

        // TRUE = valida, FALSE = invalida, NULL = sem resposta do servidor
        Boolean online = check(key, ip);

        if (online == null) {
            // Sem contato com o site. NAO derruba o servidor.
            if (isCacheValid(key, ip)) {
                System.out.println("===============================================");
                System.out.println("[KEY] Servidor de licenca inacessivel.");
                System.out.println("[KEY] Usando validacao em cache (modo offline).");
                System.out.println("===============================================");
                return;
            }
            System.out.println("===============================================");
            System.err.println("[KEY] AVISO: Nao foi possivel validar a licenca online");
            System.err.println("[KEY] e nao ha cache valido. Iniciando assim mesmo.");
            System.err.println("[KEY] Verifique a conexao com lineage2arts.com");
            System.out.println("===============================================");
            return;
        }

        if (!online) {
            // O site respondeu que a licenca e invalida. Bloqueia.
            System.out.println("===============================================");
            System.err.println("[KEY] ERRO: Licenca invalida ou IP nao autorizado");
            System.err.println("[KEY] IP detectado: " + ip);
            System.err.println("[KEY] Obtenha uma key valida em:");
            System.err.println("[KEY] www.lineage2arts.com/membros");
            System.out.println("===============================================");
            System.exit(1);
        }

        // Licenca valida: atualiza o cache.
        saveCache(key, ip);
        System.out.println("===============================================");
        System.out.println("[KEY] Licenca valida. Servidor iniciando...");
        System.out.println("===============================================");
    }

    /** Tenta validar via HTTPS; se nao obtiver resposta, tenta via HTTP. */
    private static Boolean check(String key, String ip) {
        Boolean https = request(VALIDATE_URL_HTTPS, key, ip);
        if (https != null) {
            return https;
        }
        Boolean http = request(VALIDATE_URL_HTTP, key, ip);
        return http;
    }

    /**
     * Faz a requisicao a uma URL.
     * Retorna TRUE/FALSE conforme a resposta do servidor, ou NULL se nao
     * foi possivel obter uma resposta confiavel.
     */
    private static Boolean request(String urlStr, String key, String ip) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            // User-Agent: necessario para o Cloudflare nao bloquear como bot.
            conn.setRequestProperty("User-Agent", "L2Arts-GameServer/1.0");
            conn.setRequestProperty("Accept", "application/json");
            conn.setConnectTimeout(TIMEOUT_MS);
            conn.setReadTimeout(TIMEOUT_MS);
            conn.setInstanceFollowRedirects(true);
            conn.setDoOutput(true);

            String json = String.format("{\"key\":\"%s\",\"ip\":\"%s\"}", escapeJson(key), escapeJson(ip));

            try (OutputStream os = conn.getOutputStream()) {
                os.write(json.getBytes(StandardCharsets.UTF_8));
            }

            int status = conn.getResponseCode();

            // Erro de servidor (500+) -> resposta nao confiavel.
            if (status >= 500) {
                return null;
            }

            String response;
            try (InputStream is = (status >= 200 && status < 400)
                    ? conn.getInputStream() : conn.getErrorStream()) {
                response = readStream(is);
            }

            Map<String, String> parsed = parseJson(response);
            if (!parsed.containsKey("valid")) {
                // Resposta inesperada -> nao confiavel.
                return null;
            }
            return "true".equalsIgnoreCase(parsed.get("valid"));

        } catch (Exception e) {
            // Falha de rede (timeout, DNS, SSL, sem internet) -> sem resposta.
            System.err.println("[License] Sem contato com servidor de licenca: "
                    + e.getClass().getSimpleName() + " - " + e.getMessage());
            return null;
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    /** Salva key + ip + timestamp da ultima validacao bem-sucedida. */
    private static void saveCache(String key, String ip) {
        try {
            File dir = CACHE_FILE.getParentFile();
            if (dir != null && !dir.exists()) {
                dir.mkdirs();
            }
            String content = key + "|" + ip + "|" + System.currentTimeMillis();
            Files.write(CACHE_FILE.toPath(), content.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            System.err.println("[License] Nao foi possivel gravar cache: " + e.getMessage());
        }
    }

    /** Verifica se ha cache valido para a mesma key+ip e dentro da tolerancia. */
    private static boolean isCacheValid(String key, String ip) {
        try {
            if (!CACHE_FILE.exists()) {
                return false;
            }
            String content = new String(Files.readAllBytes(CACHE_FILE.toPath()), StandardCharsets.UTF_8).trim();
            String[] parts = content.split("\\|");
            if (parts.length != 3) {
                return false;
            }
            if (!parts[0].equals(key) || !parts[1].equals(ip)) {
                return false; // key ou ip mudaram -> cache nao serve
            }
            long age = System.currentTimeMillis() - Long.parseLong(parts[2]);
            return age >= 0 && age <= CACHE_TOLERANCE_MS;
        } catch (Exception e) {
            return false;
        }
    }

    private static String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static String readStream(InputStream is) throws IOException {
        if (is == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                sb.append(line);
            }
        }
        return sb.toString();
    }

    private static Map<String, String> parseJson(String json) {
        Map<String, String> map = new HashMap<>();
        if (json == null) {
            return map;
        }
        String content = json.trim();
        // Remove BOM (caractere invisivel que alguns servidores adicionam).
        if (content.startsWith("\uFEFF")) {
            content = content.substring(1).trim();
        }
        if (!content.startsWith("{")) {
            return map;
        }
        if (content.endsWith("}")) {
            content = content.substring(1, content.length() - 1);
        }
        for (String pair : content.split(",")) {
            String[] kv = pair.split(":", 2);
            if (kv.length == 2) {
                String k = kv[0].trim().replaceAll("^\"|\"$", "");
                String v = kv[1].trim().replaceAll("^\"|\"$", "");
                map.put(k, v);
            }
        }
        return map;
    }
}