package net.sf.l2j.gameserver.handler.itemhandlers;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.handler.IItemHandler;
import net.sf.l2j.gameserver.model.actor.L2Playable;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.item.instance.ItemInstance;
import net.sf.l2j.gameserver.model.zone.ZoneId;
import net.sf.l2j.gameserver.network.serverpackets.NpcHtmlMessage;

public class SubClassOverClick implements IItemHandler
{
	public static final int TICKET_ID = 15516;

	@Override
	public void useItem(L2Playable playable, ItemInstance item, boolean forceUse)
	{
		if (!(playable instanceof L2PcInstance) || item.getItemId() != TICKET_ID)
			return;

		L2PcInstance player = (L2PcInstance) playable;
		if (!canUseTicket(player))
			return;

		NpcHtmlMessage html = new NpcHtmlMessage(0);
		html.setFile("data/html/mods/ClickClassOver/SubClassActive.htm");
		html.replace("%ticket_object_id%", item.getObjectId());
		player.sendPacket(html);
	}

	public static boolean canUseTicket(L2PcInstance player)
	{
		if (!Config.PREMIUM_SERVICES_ENABLED || !Config.PREMIUM_SUB_DOMINATOR_ENABLED)
		{
			player.sendMessage("Overlord subclass service is disabled.");
			return false;
		}

		if (player.isAlikeDead() || player.isParalyzed() || player.isMoving() || player.isInCombat()
			|| player.isInOlympiadMode() || player.isInObserverMode() || player.isInStoreMode()
			|| player.isProcessingTransaction() || player.isInArenaEvent() || player.isArenaProtection()
			|| player.isInsideZone(ZoneId.ARENA_EVENT) || player.isInsideZone(ZoneId.SIEGE)
			|| player.isCursedWeaponEquipped() || player.isInJail() || player.getKarma() > 0)
		{
			player.sendMessage("You cannot use the Overlord ticket right now.");
			return false;
		}

		if (player.isSubClassActive())
		{
			player.sendMessage("Switch to your main class before adding a subclass.");
			return false;
		}

		return true;
	}
}
