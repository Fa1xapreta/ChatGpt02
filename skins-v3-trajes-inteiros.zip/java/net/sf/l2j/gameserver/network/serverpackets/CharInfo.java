/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.network.serverpackets;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.datatables.NpcTable;
import net.sf.l2j.gameserver.datatables.custom.SkinTable;
import net.sf.l2j.gameserver.model.holder.DressMeHolder;
import net.sf.l2j.gameserver.model.holder.SkinHeadVisual;
import net.sf.l2j.gameserver.instancemanager.CursedWeaponsManager;
import net.sf.l2j.gameserver.model.L2Party;
import net.sf.l2j.gameserver.model.Location;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.entity.events.fortress.FOSEvent;
import net.sf.l2j.gameserver.model.entity.events.teamvsteam.TvTEvent;
import net.sf.l2j.gameserver.model.itemcontainer.Inventory;
import net.sf.l2j.gameserver.model.zone.ZoneId;
import net.sf.l2j.gameserver.skills.AbnormalEffect;

public class CharInfo extends L2GameServerPacket
{
	private final L2PcInstance _activeChar;
	private final Inventory _inv;
	private final int _fakeArmorItemId;
	private final int _fakeWeaponItemId;

	private final int _x, _y, _z;
	private final int _mAtkSpd, _pAtkSpd;
	private final int _runSpd, _walkSpd;
	private final float _moveMultiplier;
	private final DressMeHolder _skin;
	private final SkinHeadVisual _skinHead;

	public CharInfo(L2PcInstance cha)
	{
		_activeChar = cha;
		_inv = _activeChar.getInventory();

		_skin = SkinTable.getInstance().getSkin(_activeChar.getVisibleArmorSkinId());
		_skinHead = _skin == null ? null : new SkinHeadVisual(_activeChar, _skin);

		_fakeArmorItemId = _activeChar.getFakeArmorItemId();
		_fakeWeaponItemId = _activeChar.getVisibleWeaponSkinItemId();

		_x = _activeChar.getX();
		_y = _activeChar.getY();
		_z = _activeChar.getZ();

		_mAtkSpd = _activeChar.getMAtkSpd();
		_pAtkSpd = _activeChar.getPAtkSpd();

		_moveMultiplier = _activeChar.getMovementSpeedMultiplier();
		_runSpd = (int) (_activeChar.getRunSpeed() / _moveMultiplier);
		_walkSpd = (int) (_activeChar.getWalkSpeed() / _moveMultiplier);
	}

	public L2PcInstance getPkContourTarget()
	{
		return _activeChar;
	}
	


	private int getVisibleAbnormalEffect(int abnormalEffect)
	{
		final L2PcInstance player = getClient().getActiveChar();
		if (player != null && player.getAntilagController().isHideAllSkillsAnim())
			return 0;

		return abnormalEffect;
	}

	@Override
	protected final void writeImpl()
	{
		boolean gmSeeInvis = false;
		boolean tournament_observer = false;
		boolean tournament_pt = false;
		boolean tournament_start = false;
		boolean Olympiad_start = false;
		boolean Olympiad_observer = false;
		boolean tournament_zone = false;
		L2PcInstance player = getClient().getActiveChar();

		if (_activeChar.getAppearance().getInvisible())
		{
			L2PcInstance tmp = getClient().getActiveChar();
			if (tmp != null && tmp.isGM())
				gmSeeInvis = true;
		}

		final L2Party party = _activeChar.getParty();
		if (_activeChar.getAppearance().getInvisible())
		{
			L2PcInstance tmp = getClient().getActiveChar();
			if (tmp != null)
			{
				if (_activeChar.isArenaProtection() && tmp.isArenaObserv())
					tournament_observer = true;
				else if (_activeChar.isArenaProtection() && party != null && !tmp.isArenaAttack() && tmp.isInArenaEvent() && party.getPartyMembers().contains(tmp))
					tournament_pt = true;
				else if (_activeChar.isArenaProtection() && tmp.isArenaAttack() && !tmp.isInObserverMode())
					tournament_start = true;
				else if ((_activeChar.isInsideZone(ZoneId.TOURNAMENT) && !_activeChar.isGM() && !_activeChar.isOlympiadProtection()) && tmp.isInsideZone(ZoneId.TOURNAMENT) && !tmp.isInObserverMode() && !tmp.isOlympiadProtection())
					tournament_zone = true;
				else if (tmp.isGM())
					gmSeeInvis = true;
			}
		}

		writeC(0x03);
		writeD(_x);
		writeD(_y);
		writeD(_z);
		writeD(0);
		writeD(_activeChar.getObjectId());

		if (_activeChar.isInDMEvent() || _activeChar.isInLMEvent())
			writeS("Enemy");
		else if (_activeChar.isInsideZone(ZoneId.AUTO_PVP_ZONE) && Config.AUTO_PVP_ZONE_NAME)
			writeS(Config.PVPEVENT_NAME);//name
		else
			writeS(_activeChar.getName());

		writeD(_activeChar.getRace().ordinal());
		writeD(_activeChar.getAppearance().getSex() ? 1 : 0);

		if (_activeChar.getClassIndex() == 0)
			writeD(_activeChar.getClassId().getId());
		else
			writeD(_activeChar.getBaseClass());

		if (_skin == null)
		{
			writeD(_inv.getPaperdollItemId(Inventory.PAPERDOLL_HAIRALL));
			writeD(_fakeArmorItemId == 0 ? _inv.getPaperdollItemId(Inventory.PAPERDOLL_HEAD) : 0);
			
			if (player != null && player.isHideWepSkin())
				writeD(_inv.getPaperdollItemId(Inventory.PAPERDOLL_RHAND));
			else
				writeD(_fakeWeaponItemId == 0 ? _inv.getPaperdollItemId(Inventory.PAPERDOLL_RHAND) : _fakeWeaponItemId);
			
			writeD(_inv.getPaperdollItemId(Inventory.PAPERDOLL_LHAND));
			writeD(_fakeArmorItemId == 0 ? _inv.getPaperdollItemId(Inventory.PAPERDOLL_GLOVES) : 0);
			writeD(_fakeArmorItemId == 0 ? _inv.getPaperdollItemId(Inventory.PAPERDOLL_CHEST) : _fakeArmorItemId);
			writeD(_fakeArmorItemId == 0 ? _inv.getPaperdollItemId(Inventory.PAPERDOLL_LEGS) : 0);
			writeD(_fakeArmorItemId == 0 ? _inv.getPaperdollItemId(Inventory.PAPERDOLL_FEET) : 0);
			writeD(_inv.getPaperdollItemId(Inventory.PAPERDOLL_BACK));
			
			if (player.isHideWepSkin())
				writeD(_inv.getPaperdollItemId(Inventory.PAPERDOLL_RHAND));
			else
				writeD(_fakeWeaponItemId == 0 ? _inv.getPaperdollItemId(Inventory.PAPERDOLL_RHAND) : _fakeWeaponItemId);
			
			writeD(_inv.getPaperdollItemId(Inventory.PAPERDOLL_HAIR));
			writeD(_inv.getPaperdollItemId(Inventory.PAPERDOLL_FACE));
		}
		else
		{
			writeD(_skinHead.hairAll);
			writeD(_skinHead.head);
			
			if (player.isHideWepSkin())
				writeD(_inv.getPaperdollItemId(Inventory.PAPERDOLL_RHAND));
			else
				writeD(_fakeWeaponItemId == 0 ? _inv.getPaperdollItemId(Inventory.PAPERDOLL_RHAND) : _fakeWeaponItemId);
			
			writeD(_inv.getPaperdollItemId(Inventory.PAPERDOLL_LHAND));
			writeD(_skin.getVisibleGlovesId(_inv.getPaperdollItemId(Inventory.PAPERDOLL_GLOVES)));
			writeD(_skin.getChestId() == 0 ? _inv.getPaperdollItemId(Inventory.PAPERDOLL_CHEST) : _skin.getChestId());
			writeD(_skin.getVisibleLegsId(_inv.getPaperdollItemId(Inventory.PAPERDOLL_LEGS)));
			writeD(_skin.getVisibleFeetId(_inv.getPaperdollItemId(Inventory.PAPERDOLL_FEET)));
			writeD(_inv.getPaperdollItemId(Inventory.PAPERDOLL_BACK));
			
			if (player.isHideWepSkin())
				writeD(_inv.getPaperdollItemId(Inventory.PAPERDOLL_RHAND));
			else
				writeD(_fakeWeaponItemId == 0 ? _inv.getPaperdollItemId(Inventory.PAPERDOLL_RHAND) : _fakeWeaponItemId);
			
			writeD(_skinHead.hair);
			writeD(_skinHead.face);
		}

		// c6 new h's
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeD(_activeChar.isCustomMount()? ((_inv.getPaperdollAugmentationId(Inventory.PAPERDOLL_RHAND)& 0xFFFF0000)| (_activeChar.getCustomMountVisualIndex() & 0xFFFF)): _inv.getPaperdollAugmentationId(Inventory.PAPERDOLL_RHAND));
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeD(_inv.getPaperdollAugmentationId(Inventory.PAPERDOLL_LHAND));
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);

		writeD(_activeChar.getPvpFlag()); // 0-non-pvp 1-pvp = violett name

		writeD(_activeChar.getKarma());

		writeD(_mAtkSpd);
		writeD(_pAtkSpd);
		writeD(_activeChar.getPvpFlag()); // 0-non-pvp 1-pvp = violett name

		writeD(_activeChar.getKarma());

		writeD(_runSpd);
		writeD(_walkSpd);
		writeD(_runSpd); // swim run speed
		writeD(_walkSpd); // swim walk speed
		writeD(_runSpd); // fl run speed
		writeD(_walkSpd); // fl walk speed
		writeD(_runSpd); // fly run speed
		writeD(_walkSpd); // fly walk speed
		writeF(_activeChar.getMovementSpeedMultiplier());
		writeF(_activeChar.getAttackSpeedMultiplier());

		if (_activeChar.getMountType() != 0)
		{
			writeF(NpcTable.getInstance().getTemplate(_activeChar.getMountNpcId()).getCollisionRadius());
			writeF(NpcTable.getInstance().getTemplate(_activeChar.getMountNpcId()).getCollisionHeight());
		}
		else
		{
			writeF(_activeChar.getBaseTemplate().getCollisionRadius());
			writeF(_activeChar.getBaseTemplate().getCollisionHeight());
		}

		writeD(_activeChar.getAppearance().getHairStyle());
		writeD(_activeChar.getAppearance().getHairColor());
		writeD(_activeChar.getAppearance().getFace());

		if (gmSeeInvis && !_activeChar.isNoCarrier())
			writeS("Invisible");
		else if (_activeChar.isNoCarrier() && !_activeChar.isFakeOffline())
			writeS(Config.NO_CARRIER_TITLE);
		else if (_activeChar.isAutoFarm() && !_activeChar.isInsideZone(ZoneId.AUTO_PVP_ZONE) && !_activeChar.isInsideZone(ZoneId.TOWN))
			writeS("[AUTO FARMING]");
		else if (_activeChar.isInsideZone(ZoneId.AUTO_PVP_ZONE) && Config.AUTO_PVP_ZONE_NAME)
			writeS(Config.PVPEVENT_TITLE);//title
		else if (_activeChar.isInTVTEvent())
		{
			byte playerTeamId = TvTEvent.getParticipantTeamId(_activeChar.getObjectId());

			if (playerTeamId == 0)
				writeS("TvT [ Kills: " + _activeChar.getPointScore()+" ]");

			if (playerTeamId == 1)
				writeS("TvT [ Kills: " + _activeChar.getPointScore()+" ]");
		}
		else if (_activeChar.isInFOSEvent())
		{
			byte playerTeamId = FOSEvent.getParticipantTeamId(_activeChar.getObjectId());

			if (playerTeamId == 0)
				writeS("Fos [ Kills: " + _activeChar.getFOSPointScore()+" ]");

			if (playerTeamId == 1)
				writeS("Fos [ Kills: " + _activeChar.getFOSPointScore()+" ]");
		}
		else if (_activeChar.isInDMEvent())
			writeS("DM [ Kills: " + _activeChar.getDMPointScore()+" ]");
		else
			writeS(_activeChar.getTitle());

		if (_activeChar.isInsideZone(ZoneId.AUTO_PVP_ZONE) || _activeChar.isInTVTEvent() || _activeChar.isInCTFEvent() || _activeChar.isInFOSEvent() || _activeChar.isInDMEvent() || _activeChar.isInLMEvent() /*|| _activeChar.isInsideZone(ZoneId.ZONE_PVP)*/)
		{
			writeD(0x00);
			writeD(0x00);
			writeD(0x00);
			writeD(0x00);
		}
		else
		{
			writeD(_activeChar.getClanId());
			writeD(_activeChar.getClanCrestId());
			writeD(_activeChar.getAllyId());
			writeD(_activeChar.getAllyCrestId());
		}

		writeD(0);

		writeC(_activeChar.isSitting() ? 0 : 1); // standing = 1 sitting = 0
		writeC(_activeChar.isRunning() ? 1 : 0); // running = 1 walking = 0
		writeC(_activeChar.isInCombat() ? 1 : 0);
		writeC(_activeChar.isAlikeDead() ? 1 : 0);

		if (gmSeeInvis || tournament_pt || tournament_start || tournament_observer || Olympiad_start || Olympiad_observer || tournament_zone)
			writeC(0);
		else if (player.isHideGiran() && player.isInsideZone(ZoneId.FAKE_ONLINE_ZONE))
			writeC(1);
		else
			writeC(_activeChar.getAppearance().getInvisible() ? 1 : 0); // invisible = 1 visible =0

		writeC(_activeChar.getMountType()); // 1 on strider 2 on wyvern 0 no mount
		writeC(_activeChar.getPrivateStoreType()); // 1 - sellshop

		writeH(_activeChar.getCubics().size());
		for (int id : _activeChar.getCubics().keySet())
			writeH(id);

		writeC(_activeChar.isInPartyMatchRoom() ? 1 : 0);

		if (gmSeeInvis) {
			writeD(getVisibleAbnormalEffect(_activeChar.getAbnormalEffect() | AbnormalEffect.STEALTH.getMask()));
		}
		else if(player.isGM())
		{
			if(_activeChar.isFakeOffline())
				writeD(AbnormalEffect.SLEEP.getMask());
			else
				writeD(getVisibleAbnormalEffect(_activeChar.getAbnormalEffect()));
		}
		else
		{
			writeD(getVisibleAbnormalEffect(_activeChar.getAbnormalEffect()));
		}

		writeC(_activeChar.getRecomLeft());
		writeH(_activeChar.getRecomHave()); // Blue value for name (0 = white, 255 = pure blue)
		writeD(_activeChar.getClassId().getId());

		writeD(_activeChar.getMaxCp());
		writeD((int) _activeChar.getCurrentCp());
		if (player.isDisableGlowWeapon())
			writeC(0); 
		else 
			writeC(_activeChar.isMounted() ? 0 : _activeChar.getEnchantEffect());

		// Wide Aura: use the same blue ground-circle effect as PLAYER_SPAWN_PROTECTION.
		// The viewer controls this locally; only parties with at least two members get the aura.
		if (player != null && !player.isDisablepartyAura() && player.getParty() != null
			&& player.getParty().getMemberCount() > 1 && player.getParty() == _activeChar.getParty())
		{
			if (_activeChar.getParty().isLeader(_activeChar))
				writeC(0x02);
			else
				writeC(0x01); // Blue team circle around feet, same visual as spawn protection.
		}
		else
			writeC(0x00);

		writeD(_activeChar.getClanCrestLargeId());
		writeC(_activeChar.isNoble() ? 1 : 0); // Symbol on char menu ctrl+I

		if (player.isDisableHeroAura())
			writeC(0);
		else 
			writeC((_activeChar.isHero() || (_activeChar.isGM() && Config.GM_HERO_AURA) || _activeChar.getIsPVPHero()) ? 1 : 0); // Hero Aura


		writeC(_activeChar.isFishing() ? 1 : 0); // 0x01: Fishing Mode (Cant be undone by setting back to 0)

		Location loc = _activeChar.getFishingLoc();
		if (loc != null)
		{
			writeD(loc.getX());
			writeD(loc.getY());
			writeD(loc.getZ());
		}
		else
		{
			writeD(0);
			writeD(0);
			writeD(0);
		}

		writeD(_activeChar.getAppearance().getNameColor());

		writeD(0x00);

		writeD(_activeChar.getPledgeClass());
		writeD(_activeChar.getPledgeType());

		if (_activeChar.isAutoFarm())
			writeD(0x1CFADA);
		else if (_activeChar.isInTVTEvent())
		{
			byte playerTeamId = TvTEvent.getParticipantTeamId(_activeChar.getObjectId());
			if (playerTeamId == 0)
				writeD(Integer.decode("0x" + net.sf.l2j.gameserver.model.entity.events.teamvsteam.TvTConfig.TVT_EVENT_TEAM_1_TITLE_COLOR));
			else if (playerTeamId == 1)
				writeD(Integer.decode("0x" + net.sf.l2j.gameserver.model.entity.events.teamvsteam.TvTConfig.TVT_EVENT_TEAM_2_TITLE_COLOR));
			else
				writeD(_activeChar.getAppearance().getTitleColor());
		}
		else if (_activeChar.isInMultiTVTEvent())
		{
			byte playerTeamId = net.sf.l2j.gameserver.model.entity.events.multiteamvsteam.MultiTvTEvent.getParticipantTeamId(_activeChar.getObjectId());
			if (playerTeamId == 0)
				writeD(Integer.decode("0x" + net.sf.l2j.gameserver.model.entity.events.multiteamvsteam.MultiTvTConfig.MULTI_TVT_EVENT_TEAM_1_TITLE_COLOR));
			else if (playerTeamId == 1)
				writeD(Integer.decode("0x" + net.sf.l2j.gameserver.model.entity.events.multiteamvsteam.MultiTvTConfig.MULTI_TVT_EVENT_TEAM_2_TITLE_COLOR));
			else if (playerTeamId == 2)
				writeD(Integer.decode("0x" + net.sf.l2j.gameserver.model.entity.events.multiteamvsteam.MultiTvTConfig.MULTI_TVT_EVENT_TEAM_3_TITLE_COLOR));
			else if (playerTeamId == 3)
				writeD(Integer.decode("0x" + net.sf.l2j.gameserver.model.entity.events.multiteamvsteam.MultiTvTConfig.MULTI_TVT_EVENT_TEAM_4_TITLE_COLOR));
			else
				writeD(_activeChar.getAppearance().getTitleColor());
		}
		else
			writeD(_activeChar.getAppearance().getTitleColor());

		if (_activeChar.isCursedWeaponEquipped())
			writeD(CursedWeaponsManager.getInstance().getCurrentStage(_activeChar.getCursedWeaponEquippedId()) - 1);
		else
			writeD(0x00);
	}
}