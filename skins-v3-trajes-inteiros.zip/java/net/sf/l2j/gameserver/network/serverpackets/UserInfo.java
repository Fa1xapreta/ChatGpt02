/*
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */
package net.sf.l2j.gameserver.network.serverpackets;

import net.sf.l2j.Config;
import net.sf.l2j.gameserver.datatables.NpcTable;
import net.sf.l2j.gameserver.datatables.custom.SkinTable;
import net.sf.l2j.gameserver.model.holder.DressMeHolder;
import net.sf.l2j.gameserver.model.holder.SkinHeadVisual;
import net.sf.l2j.gameserver.instancemanager.CursedWeaponsManager;
import net.sf.l2j.gameserver.model.Location;
import net.sf.l2j.gameserver.model.actor.L2Summon;
import net.sf.l2j.gameserver.model.actor.instance.L2PcInstance;
import net.sf.l2j.gameserver.model.actor.template.NpcTemplate;
import net.sf.l2j.gameserver.model.entity.events.fortress.FOSEvent;
import net.sf.l2j.gameserver.model.entity.events.teamvsteam.TvTEvent;
import net.sf.l2j.gameserver.model.itemcontainer.Inventory;
import net.sf.l2j.gameserver.model.zone.ZoneId;
import net.sf.l2j.gameserver.skills.AbnormalEffect;

public class UserInfo extends L2GameServerPacket
{
	private final L2PcInstance _activeChar;
	private final int _runSpd, _walkSpd;
	private int _relation;

	private final int _fakeArmorObjectId;
	private final int _fakeArmorItemId;
	private final int _fakeWeaponObjectId;
	private final int _fakeWeaponItemId;
	private final DressMeHolder _skin;
	private final SkinHeadVisual _skinHead;

	private final float _moveMultiplier;

	public UserInfo(L2PcInstance character)
	{
		_activeChar = character;

		_skin = SkinTable.getInstance().getSkin(_activeChar.getVisibleArmorSkinId());
		_skinHead = _skin == null ? null : new SkinHeadVisual(_activeChar, _skin);

		_moveMultiplier = _activeChar.getMovementSpeedMultiplier();
		_runSpd = (int) (_activeChar.getRunSpeed() / _moveMultiplier);
		_walkSpd = (int) (_activeChar.getWalkSpeed() / _moveMultiplier);
		_relation = _activeChar.isClanLeader() ? 0x40 : 0;

		if (_activeChar.getSiegeState() == 1)
			_relation |= 0x180;
		if (_activeChar.getSiegeState() == 2)
			_relation |= 0x80;

		_fakeArmorObjectId = _activeChar.getFakeArmorObjectId();
		_fakeArmorItemId = _activeChar.getFakeArmorItemId();
		_fakeWeaponObjectId = _activeChar.getFakeWeaponObjectId();
		_fakeWeaponItemId = _activeChar.getVisibleWeaponSkinItemId();
	}



	private int getVisibleAbnormalEffect(int abnormalEffect)
	{
		if (_activeChar.getAntilagController().isHideAllSkillsAnim())
			return 0;

		return abnormalEffect;
	}

	@Override
	protected final void writeImpl()
	{   
		boolean gmSeeInvis = false;
		
		if (_activeChar.getAppearance().getInvisible())
		{
			L2PcInstance tmp = getClient().getActiveChar();
			if (tmp != null && tmp.isGM())
				gmSeeInvis = true;
		}
		
		writeC(0x04);

		writeD(_activeChar.getX());
		writeD(_activeChar.getY());
		writeD(_activeChar.getZ());
		writeD(_activeChar.getHeading());
		writeD(_activeChar.getObjectId());

		String name = _activeChar.getName();
		if (_activeChar.getPoly().isMorphed())
		{
			NpcTemplate polyObj = NpcTable.getInstance().getTemplate(_activeChar.getPoly().getPolyId());
			if (polyObj != null)
				name = polyObj.getName();
		}
		writeS(name);

		writeD(_activeChar.getRace().ordinal());
		writeD(_activeChar.getAppearance().getSex() ? 1 : 0);

		if (_activeChar.getClassIndex() == 0)
			writeD(_activeChar.getClassId().getId());
		else
			writeD(_activeChar.getBaseClass());

		writeD(_activeChar.getLevel());
		writeQ(_activeChar.getExp());
		writeD(_activeChar.getSTR());
		writeD(_activeChar.getDEX());
		writeD(_activeChar.getCON());
		writeD(_activeChar.getINT());
		writeD(_activeChar.getWIT());
		writeD(_activeChar.getMEN());
		writeD(_activeChar.getMaxHp());
		writeD((int) _activeChar.getCurrentHp());
		writeD(_activeChar.getMaxMp());
		writeD((int) _activeChar.getCurrentMp());
		writeD(_activeChar.getSp());
		writeD(_activeChar.getCurrentLoad());
		writeD(_activeChar.getMaxLoad());

		//writeD(_activeChar.getActiveWeaponItem() != null ? 40 : 20); // 20 no weapon, 40 weapon equipped
		writeD((_activeChar.getActiveWeaponItem() != null || _fakeWeaponItemId != 0) ? 40 : 20); // 20 no weapon, 40 weapon equipped


		if (_skin == null)
		{
			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_HAIRALL));
			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_REAR));
			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_LEAR));
			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_NECK));
			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_RFINGER));
			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_LFINGER));
			writeD(_fakeArmorObjectId == 0 ? _activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_HEAD) : 0);
			
			if (_activeChar.isHideWepSkin())
				writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_RHAND));
			else
				writeD(_fakeWeaponObjectId == 0 ? _activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_RHAND) : _fakeWeaponObjectId);
			
			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_LHAND));
			writeD(_fakeArmorObjectId == 0 ? _activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_GLOVES) : 0);
			writeD(_fakeArmorObjectId == 0 ? _activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_CHEST) : _fakeArmorObjectId);
			writeD(_fakeArmorObjectId == 0 ? _activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_LEGS) : 0);
			writeD(_fakeArmorObjectId == 0 ? _activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_FEET) : 0);
			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_BACK));

			if (_activeChar.isHideWepSkin())
				writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_RHAND));
			else
				writeD(_fakeWeaponObjectId == 0 ? _activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_RHAND) : _fakeWeaponObjectId);

			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_HAIR));
			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_FACE));

			writeD(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_HAIRALL));
			writeD(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_REAR));
			writeD(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_LEAR));
			writeD(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_NECK));
			writeD(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_RFINGER));
			writeD(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_LFINGER));
			writeD(_fakeArmorItemId == 0 ? _activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_HEAD) : 0);

			if (_activeChar.isHideWepSkin())
				writeD(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_RHAND));
			else
				writeD(_fakeWeaponItemId == 0 ? _activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_RHAND) : _fakeWeaponItemId);

			writeD(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_LHAND));
			writeD(_fakeArmorItemId == 0 ? _activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_GLOVES) : 0);
			writeD(_fakeArmorItemId == 0 ? _activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_CHEST) : _fakeArmorItemId);
			writeD(_fakeArmorItemId == 0 ? _activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_LEGS) : 0);
			writeD(_fakeArmorItemId == 0 ? _activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_FEET) : 0);
			writeD(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_BACK));

			if (_activeChar.isHideWepSkin())
				writeD(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_RHAND));
			else
				writeD(_fakeWeaponItemId == 0 ? _activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_RHAND) : _fakeWeaponItemId);

			writeD(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_HAIR));
			writeD(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_FACE));
		}
		else
		{
			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_HAIRALL));
			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_REAR));
			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_LEAR));
			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_NECK));
			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_RFINGER));
			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_LFINGER));
			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_HEAD));
			
			if (_activeChar.isHideWepSkin())
				writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_RHAND));
			else
				writeD(_fakeWeaponObjectId == 0 ? _activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_RHAND) : _fakeWeaponObjectId);
			
			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_LHAND));
			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_GLOVES));
			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_CHEST));
			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_LEGS));
			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_FEET));
			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_BACK));

			if (_activeChar.isHideWepSkin())
				writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_RHAND));
			else
				writeD(_fakeWeaponObjectId == 0 ? _activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_RHAND) : _fakeWeaponObjectId);

			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_HAIR));
			writeD(_activeChar.getInventory().getPaperdollObjectId(Inventory.PAPERDOLL_FACE));

			writeD(_skinHead.hairAll);
			writeD(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_REAR));
			writeD(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_LEAR));
			writeD(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_NECK));
			writeD(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_RFINGER));
			writeD(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_LFINGER));
			writeD(_skinHead.head);

			if (_activeChar.isHideWepSkin())
				writeD(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_RHAND));
			else
				writeD(_fakeWeaponItemId == 0 ? _activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_RHAND) : _fakeWeaponItemId);

			writeD(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_LHAND));
			writeD(_skin.getVisibleGlovesId(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_GLOVES)));
			writeD(_skin.getChestId() == 0 ? _activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_CHEST) : _skin.getChestId());
			writeD(_skin.getVisibleLegsId(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_LEGS)));
			writeD(_skin.getVisibleFeetId(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_FEET)));
			writeD(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_BACK));

			if (_activeChar.isHideWepSkin())
				writeD(_activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_RHAND));
			else
				writeD(_fakeWeaponItemId == 0 ? _activeChar.getInventory().getPaperdollItemId(Inventory.PAPERDOLL_RHAND) : _fakeWeaponItemId);

			writeD(_skinHead.hair);
			writeD(_skinHead.face);
		}

		// c6 new h's
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeD(_activeChar.isCustomMount()? ((_activeChar.getInventory().getPaperdollAugmentationId(Inventory.PAPERDOLL_RHAND) & 0xFFFF0000)| (_activeChar.getCustomMountVisualIndex() & 0xFFFF)): _activeChar.getInventory().getPaperdollAugmentationId(Inventory.PAPERDOLL_RHAND));
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeD(_activeChar.getInventory().getPaperdollAugmentationId(Inventory.PAPERDOLL_LHAND));
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		writeH(0x00);
		// end of c6 new h's
		writeD(_activeChar.getPAtk(null));
		writeD(_activeChar.getPAtkSpd());
		writeD(_activeChar.getPDef(null));
		writeD(_activeChar.getEvasionRate(null));
		writeD(_activeChar.getAccuracy());
		writeD(_activeChar.getCriticalHit(null, null));
		writeD(_activeChar.getMAtk(null, null));

		writeD(_activeChar.getMAtkSpd());
		writeD(_activeChar.getPAtkSpd());

		writeD(_activeChar.getMDef(null, null));

		writeD(_activeChar.getPvpFlag()); // 0-non-pvp 1-pvp = violett name

		writeD(_activeChar.getKarma());

		writeD(_runSpd);
		writeD(_walkSpd);
		writeD(_runSpd); // swim run speed
		writeD(_walkSpd); // swim walk speed
		writeD(0);
		writeD(0);
		writeD(_activeChar.isFlying() ? _runSpd : 0); // fly speed
		writeD(_activeChar.isFlying() ? _walkSpd : 0); // fly speed
		writeF(_moveMultiplier);
		writeF(_activeChar.getAttackSpeedMultiplier());

		L2Summon pet = _activeChar.getPet();
		if (_activeChar.getMountType() != 0 && pet != null)
		{
			writeF(pet.getTemplate().getCollisionRadius());
			writeF(pet.getTemplate().getCollisionHeight());
		}
		else
		{
			writeF(_activeChar.getBaseTemplate().getCollisionRadius());
			writeF(_activeChar.getBaseTemplate().getCollisionHeight());
		}

		writeD(_activeChar.getAppearance().getHairStyle());
		writeD(_activeChar.getAppearance().getHairColor());
		writeD(_activeChar.getAppearance().getFace());
		writeD(_activeChar.isGM() ? 1 : 0); // builder level

		if (_activeChar.isInTVTEvent())
		{
			byte playerTeamId = TvTEvent.getParticipantTeamId(_activeChar.getObjectId());

			if (playerTeamId == 0)
				writeS("TvT [ Kills: " + _activeChar.getPointScore()+" ]");

			if (playerTeamId == 1)
				writeS("TvT [ Kills: " + _activeChar.getPointScore()+" ]");
		}
		else if (_activeChar.isInFOSEvent())
		{
			byte playerTeamId = FOSEvent.getParticipantTeamId(_activeChar.getObjectId());

			if (playerTeamId == 0)
				writeS("Fos [ Kills: " + _activeChar.getFOSPointScore()+" ]");

			if (playerTeamId == 1)
				writeS("Fos [ Kills: " + _activeChar.getFOSPointScore()+" ]");
		}
		else if (_activeChar.isInDMEvent())
			writeS("DM [ Kills: " + _activeChar.getDMPointScore()+" ]");
		else if (_activeChar.isAutoFarm() && !_activeChar.isInsideZone(ZoneId.AUTO_PVP_ZONE) && !_activeChar.isInsideZone(ZoneId.TOWN))
			writeS("[AUTO FARMING]");
		else if (gmSeeInvis)
			writeS("Invisible");
		else
			writeS(_activeChar.getPoly().isMorphed() ? "Morphed" : _activeChar.getTitle());

		writeD(_activeChar.getClanId());
		writeD(_activeChar.getClanCrestId());
		writeD(_activeChar.getAllyId());
		writeD(_activeChar.getAllyCrestId()); // ally crest id
		// 0x40 leader rights
		// siege flags: attacker - 0x180 sword over name, defender - 0x80 shield, 0xC0 crown (|leader), 0x1C0 flag (|leader)
		writeD(_relation);
		writeC(_activeChar.getMountType()); // mount type
		writeC(_activeChar.getPrivateStoreType());
		writeC(_activeChar.hasDwarvenCraft() ? 1 : 0);
		writeD(_activeChar.getPkKills());
		writeD(_activeChar.getPvpKills());

		writeH(_activeChar.getCubics().size());
		for (int id : _activeChar.getCubics().keySet())
			writeH(id);

		writeC(_activeChar.isInPartyMatchRoom() ? 1 : 0);

		if (_activeChar.getAppearance().getInvisible() && _activeChar.isGM())
			writeD(getVisibleAbnormalEffect(_activeChar.getAbnormalEffect() | AbnormalEffect.STEALTH.getMask()));
		else
			writeD(getVisibleAbnormalEffect(_activeChar.getAbnormalEffect()));

		writeC(0x00);

		writeD(_activeChar.getClanPrivileges());

		writeH(_activeChar.getRecomLeft()); // c2 recommendations remaining
		writeH(_activeChar.getRecomHave()); // c2 recommendations received
		writeD(_activeChar.isCustomMount()? 1000000 + _activeChar.getCustomMountVisualIndex(): (_activeChar.getMountNpcId() > 0? _activeChar.getMountNpcId() + 1000000: 0));
		writeH(_activeChar.getInventoryLimit());

		writeD(_activeChar.getClassId().getId());
		writeD(0x00); // special effects? circles around player...
		writeD(_activeChar.getMaxCp());
		writeD((int) _activeChar.getCurrentCp());
		if (_activeChar.isDisableGlowWeapon())
		{
			writeC(0);
		} 
		else 
		{
			writeC(_activeChar.isMounted() ? 0 : _activeChar.getEnchantEffect());
		}

		// Wide Aura: use the same blue ground-circle effect as PLAYER_SPAWN_PROTECTION.
		// The viewer controls this locally; only parties with at least two members get the aura.
		final L2PcInstance viewer = getClient().getActiveChar();
		if (viewer != null && !viewer.isDisablepartyAura() && viewer.getParty() != null
			&& viewer.getParty().getMemberCount() > 1 && viewer.getParty() == _activeChar.getParty())
		{
			if (_activeChar.getParty().isLeader(_activeChar))
				writeC(0x02);
			else
				writeC(0x01); // Blue team circle around feet, same visual as spawn protection.
		}
		else
			writeC(0x00);

		writeD(_activeChar.getClanCrestLargeId());
		writeC(_activeChar.isNoble() ? 1 : 0); // 0x01: symbol on char menu ctrl+I
		if (_activeChar.isDisableHeroAura())
		{
			writeC(0);
		}
		else
		{
			writeC((_activeChar.isHero() || (_activeChar.isGM() && Config.GM_HERO_AURA) || _activeChar.getIsPVPHero()) ? 1 : 0); // Hero Aura
		}

		writeC(_activeChar.isFishing() ? 1 : 0); // Fishing Mode

		Location loc = _activeChar.getFishingLoc();
		if (loc != null)
		{
			writeD(loc.getX());
			writeD(loc.getY());
			writeD(loc.getZ());
		}
		else
		{
			writeD(0);
			writeD(0);
			writeD(0);
		}

		writeD(_activeChar.getAppearance().getNameColor());

		// new c5
		writeC(_activeChar.isRunning() ? 0x01 : 0x00); // changes the Speed display on Status Window

		writeD(_activeChar.getPledgeClass()); // changes the text above CP on Status Window
		writeD(_activeChar.getPledgeType());
		
		if (_activeChar.isAutoFarm())
			writeD(0x1CFADA);
		else if (_activeChar.isInTVTEvent())
		{
			byte playerTeamId = TvTEvent.getParticipantTeamId(_activeChar.getObjectId());
			if (playerTeamId == 0)
				writeD(Integer.decode("0x" + net.sf.l2j.gameserver.model.entity.events.teamvsteam.TvTConfig.TVT_EVENT_TEAM_1_TITLE_COLOR));
			else if (playerTeamId == 1)
				writeD(Integer.decode("0x" + net.sf.l2j.gameserver.model.entity.events.teamvsteam.TvTConfig.TVT_EVENT_TEAM_2_TITLE_COLOR));
			else
				writeD(_activeChar.getAppearance().getTitleColor());
		}
		else if (_activeChar.isInMultiTVTEvent())
		{
			byte playerTeamId = net.sf.l2j.gameserver.model.entity.events.multiteamvsteam.MultiTvTEvent.getParticipantTeamId(_activeChar.getObjectId());
			if (playerTeamId == 0)
				writeD(Integer.decode("0x" + net.sf.l2j.gameserver.model.entity.events.multiteamvsteam.MultiTvTConfig.MULTI_TVT_EVENT_TEAM_1_TITLE_COLOR));
			else if (playerTeamId == 1)
				writeD(Integer.decode("0x" + net.sf.l2j.gameserver.model.entity.events.multiteamvsteam.MultiTvTConfig.MULTI_TVT_EVENT_TEAM_2_TITLE_COLOR));
			else if (playerTeamId == 2)
				writeD(Integer.decode("0x" + net.sf.l2j.gameserver.model.entity.events.multiteamvsteam.MultiTvTConfig.MULTI_TVT_EVENT_TEAM_3_TITLE_COLOR));
			else if (playerTeamId == 3)
				writeD(Integer.decode("0x" + net.sf.l2j.gameserver.model.entity.events.multiteamvsteam.MultiTvTConfig.MULTI_TVT_EVENT_TEAM_4_TITLE_COLOR));
			else
				writeD(_activeChar.getAppearance().getTitleColor());
		}
		else
			writeD(_activeChar.getAppearance().getTitleColor());

		if (_activeChar.isCursedWeaponEquipped())
			writeD(CursedWeaponsManager.getInstance().getCurrentStage(_activeChar.getCursedWeaponEquippedId()) - 1);
		else
			writeD(0x00);
	}
}