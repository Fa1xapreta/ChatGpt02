package net.sf.l2j.gameserver.model.holder;

public class DressMeHolder 
{
	private int _chestId;
	private int _legsId;
	private int _glovesId;
	private int _feetId;
	private int _hairId;
	private final int _headId;
	private final boolean _alwaysShowHair;
	private final HeadSlot _headSlot;
	private final ChestMode _chestMode;

	public enum ChestMode
	{
		PIECE, FULL_ARMOR, ALL_DRESS
	}

	public enum HeadSlot
	{
		AUTO, HAIR, FACE, HAIRALL
	}

	public DressMeHolder(int hairId, int chestId, int legsId, int glovesId, int feetId) 
	{
		this(hairId, chestId, legsId, glovesId, feetId, 0, false);
	}

	public DressMeHolder(int hairId, int chestId, int legsId, int glovesId, int feetId, int headId, boolean alwaysShowHair)
	{
		this(hairId, chestId, legsId, glovesId, feetId, headId, alwaysShowHair, HeadSlot.AUTO);
	}

	public DressMeHolder(int hairId, int chestId, int legsId, int glovesId, int feetId, int headId, boolean alwaysShowHair, HeadSlot headSlot)
	{
		this(hairId, chestId, legsId, glovesId, feetId, headId, alwaysShowHair, headSlot, ChestMode.PIECE);
	}

	public DressMeHolder(int hairId, int chestId, int legsId, int glovesId, int feetId, int headId, boolean alwaysShowHair, HeadSlot headSlot, ChestMode chestMode)
	{
		_chestMode = chestMode;
		_headSlot = headSlot;
		_headId = headId;
		_alwaysShowHair = alwaysShowHair;
		_hairId = hairId;
		_chestId = chestId;
		_legsId = legsId;
		_glovesId = glovesId;
		_feetId = feetId;
	}

	public int getChestId() 
	{
		return _chestId;
	}

	public int getLegsId() 
	{
		return _legsId;
	}

	public int getGlovesId() 
	{
		return _glovesId;
	}

	public int getFeetId() 
	{
		return _feetId;
	}

	public int getHairId()
	{
		return _hairId;
	}

	public HeadSlot getHeadSlot()
	{
		return _headSlot;
	}

	public int getHeadId()
	{
		return _headId;
	}

	public boolean isAlwaysShowHair()
	{
		return _alwaysShowHair;
	}

	public int getVisibleLegsId(int equippedId)
	{
		return _legsId != 0 ? _legsId : _chestMode == ChestMode.PIECE ? equippedId : 0;
	}

	public int getVisibleGlovesId(int equippedId)
	{
		return _glovesId != 0 ? _glovesId : _chestMode == ChestMode.ALL_DRESS ? 0 : equippedId;
	}

	public int getVisibleFeetId(int equippedId)
	{
		return _feetId != 0 ? _feetId : _chestMode == ChestMode.ALL_DRESS ? 0 : equippedId;
	}
}
