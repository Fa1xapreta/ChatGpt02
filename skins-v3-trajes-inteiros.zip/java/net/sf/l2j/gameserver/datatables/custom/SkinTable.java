package net.sf.l2j.gameserver.datatables.custom;

import java.io.File;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;

import net.sf.l2j.gameserver.model.holder.DressMeHolder;
import net.sf.l2j.gameserver.xmlfactory.XMLDocumentFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public class SkinTable 
{
	private static Logger _log = Logger.getLogger(SkinTable.class.getName());

	private final Map<Integer, DressMeHolder> _map = new HashMap<>();
	private final Set<Integer> _modelWeapons = new HashSet<>();
	private final Set<Integer> _pendingModelWeapons = new HashSet<>();
	private final Set<Integer> _modelItems = new HashSet<>();

	public static SkinTable getInstance() 
	{
		return SingletonHolder._instance;
	}

	protected SkinTable() 
	{
		try 
		{
			File f = new File("./data/xml/skin.xml");
			Document doc = f.isFile() ? XMLDocumentFactory.getInstance().loadDocument(f) : null;
			for (Node n = doc == null ? null : doc.getFirstChild(); n != null; n = n.getNextSibling())
			{
				if ("list".equalsIgnoreCase(n.getNodeName()))
				{
					for (Node d = n.getFirstChild(); d != null; d = d.getNextSibling()) 
					{
						if ("skin".equalsIgnoreCase(d.getNodeName())) 
						{
							NamedNodeMap attrs = d.getAttributes();
							int id = Integer.valueOf(attrs.getNamedItem("id").getNodeValue()).intValue();
							int hairId = Integer.valueOf(attrs.getNamedItem("hairId").getNodeValue()).intValue();
							int chestId = Integer.valueOf(attrs.getNamedItem("chestId").getNodeValue()).intValue();
							int legsId = Integer.valueOf(attrs.getNamedItem("legsId").getNodeValue()).intValue();
							int glovesId = Integer.valueOf(attrs.getNamedItem("glovesId").getNodeValue()).intValue();
							int feetId = Integer.valueOf(attrs.getNamedItem("feetId").getNodeValue()).intValue();
							if (_map.putIfAbsent(id, new DressMeHolder(hairId, chestId, legsId, glovesId, feetId)) != null)
								throw new IllegalArgumentException("Duplicate legacy skin ID " + id);
						} 
					}  
				}
			} 
			_log.info("SkinTable: Loaded " + _map.size() + " skins.");
		} 
		catch (Exception e) 
		{
			throw new IllegalStateException("Invalid data/xml/skin.xml", e);
		}
		try
		{
			loadModel();
		}
		catch (Exception e)
		{
			throw new IllegalStateException("Invalid data/xml/skins.xml", e);
		}
	}

	private void loadModel() throws Exception
	{
		final File file = new File("./data/xml/skins.xml");
		if (!file.isFile())
			return;

		final Document doc = XMLDocumentFactory.getInstance().loadDocument(file);
		final NodeList skins = doc.getDocumentElement().getElementsByTagName("skin");
		final Set<Integer> skinIds = new HashSet<>();
		for (int index = 0; index < skins.getLength(); index++)
		{
			final Element skin = (Element) skins.item(index);
			final int id = Integer.parseInt(skin.getAttribute("id"));
			if (id <= 0 || !skinIds.add(id))
				throw new IllegalArgumentException("Invalid or duplicate skin ID " + id);

			final Map<String, Integer> slots = new HashMap<>();
			DressMeHolder.HeadSlot headSlot = DressMeHolder.HeadSlot.AUTO;
			DressMeHolder.ChestMode chestMode = DressMeHolder.ChestMode.PIECE;
			final boolean pending = Boolean.parseBoolean(skin.getAttribute("pendingClientMapping"));
			final NodeList visuals = skin.getElementsByTagName("visual");
			for (int visualIndex = 0; visualIndex < visuals.getLength(); visualIndex++)
			{
				final Element visual = (Element) visuals.item(visualIndex);
				final String slot = visual.getAttribute("slot");
				final int visualItemId = Integer.parseInt(visual.getAttribute("itemId"));
				if (visual.hasAttribute("chestMode"))
				{
					if (!"CHEST".equals(slot))
						throw new IllegalArgumentException("chestMode is only valid on CHEST for skin " + id);
					chestMode = DressMeHolder.ChestMode.valueOf(visual.getAttribute("chestMode"));
				}
				if (visual.hasAttribute("headSlot"))
				{
					if (!"HAIR".equals(slot))
						throw new IllegalArgumentException("headSlot is only valid on HAIR for skin " + id);
					headSlot = DressMeHolder.HeadSlot.valueOf(visual.getAttribute("headSlot"));
				}
				if (visualItemId <= 0 || slots.putIfAbsent(slot, visualItemId) != null)
					throw new IllegalArgumentException("Invalid or duplicate slot " + slot + " for skin " + id);
			}

			switch (skin.getAttribute("type"))
			{
				case "WEAPON":
					if (slots.size() != 1 || !slots.containsKey("RHAND"))
						throw new IllegalArgumentException("Expected RHAND for weapon skin " + id);
					final int weaponId = slots.get("RHAND");
					if (_modelWeapons.contains(weaponId) || _pendingModelWeapons.contains(weaponId))
						throw new IllegalArgumentException("Duplicate weapon skin visual " + weaponId);
					(pending ? _pendingModelWeapons : _modelWeapons).add(weaponId);
					break;
				case "ARMOR":
					if (slots.isEmpty() || !Arrays.asList("HEAD", "HAIR", "CHEST", "LEGS", "GLOVES", "FEET").containsAll(slots.keySet()))
						throw new IllegalArgumentException("Invalid armor slots for skin " + id);
					if (!skin.hasAttribute("activationItemId"))
						break;
					final int itemId = Integer.parseInt(skin.getAttribute("activationItemId"));
					final DressMeHolder holder = new DressMeHolder(slots.getOrDefault("HAIR", 0), slots.getOrDefault("CHEST", 0),
						slots.getOrDefault("LEGS", 0), slots.getOrDefault("GLOVES", 0), slots.getOrDefault("FEET", 0),
						slots.getOrDefault("HEAD", 0), Boolean.parseBoolean(skin.getAttribute("alwaysShowHair")), headSlot, chestMode);
					if (itemId <= 0 || _map.containsKey(itemId) || !_modelItems.add(itemId))
						throw new IllegalArgumentException("Duplicate or invalid skin activation item " + itemId);
					if (!pending)
						_map.put(itemId, holder);
					else
						_log.warning("Skin " + id + " requires client visual IDs before activation.");
					break;
				default:
					throw new IllegalArgumentException("Unknown skin type for ID " + id);
			}
		}
	}

	public boolean isModelArmorItem(int itemId)
	{
		return _modelItems.contains(itemId);
	}

	public boolean isPendingModelWeaponVisual(int itemId)
	{
		return _pendingModelWeapons.contains(itemId);
	}

	public boolean isModelWeaponVisual(int itemId)
	{
		return _modelWeapons.contains(itemId);
	}

	public DressMeHolder getSkin(int item) 
	{
		return _map.get(Integer.valueOf(item));
	}

	public boolean getSkinId(int skinId) 
	{
		return _map.containsKey(Integer.valueOf(skinId));
	}
	

	/**
	 * Returns the set of all skin IDs currently loaded from skin.xml.
	 * Used by the SkinTry item handler to build the preview list.
	 */
	public Set<Integer> getAllSkinIds()
	{
		return Collections.unmodifiableSet(_map.keySet());
	}

	private static class SingletonHolder 
	{
		protected static final SkinTable _instance = new SkinTable();
	}
}