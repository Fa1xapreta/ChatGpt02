@echo off
setlocal
pushd "%~dp0"
if not exist "UCC.exe" goto missing
if not exist "..\Interface\Classes\TimeZoneWnd.uc" goto missing
if exist "Interface.u" (
    copy /Y "Interface.u" "Interface.pre-diagnostico.u" >nul
    if errorlevel 1 goto backup_failed
    del "Interface.u"
    if exist "Interface.u" goto backup_failed
)
echo N|UCC.exe make -NoBind -log=UCC-TimeZone.log > "UCC-TimeZone-console.txt" 2>&1
set "UCC_RESULT=%ERRORLEVEL%"
echo ExitCode=%UCC_RESULT%>> "UCC-TimeZone-console.txt"
type "UCC-TimeZone-console.txt"
if exist "Interface.u" (
    echo Interface.u gerada na pasta System.
) else (
    echo Nenhuma Interface.u foi gerada. Veja UCC-TimeZone-console.txt e UCC-TimeZone.log.
)
popd
pause
exit /b %UCC_RESULT%
:missing
echo Coloque este arquivo na pasta System do compilador.
popd
pause
exit /b 1
:backup_failed
echo Erro ao preparar a copia de seguranca da Interface.u.
popd
pause
exit /b 1
