class L2UITimerObject extends UIScript;

var int _time;
var int _timerID;
var int _curCount;
var int _maxCount;
var int _delay;
var bool _isKillOnEnd;

delegate _DelegateOnStart()
{}

delegate _DelegateOnTime(int Count)
{}

delegate _DelegateOnEnd()
{}

function float _Position()
{
	return float(_curCount) / float(_maxCount);
}

function _Play(optional int Delay)
{
	if(Delay != 0)
	{
		_delay = Delay;
	}
	L2UITimer(GetScript("L2UITimer"))._Play(_timerID);
}

function _Pause()
{
	L2UITimer(GetScript("L2UITimer"))._Pause(_timerID);
}

function _Stop()
{
	L2UITimer(GetScript("L2UITimer"))._Stop(_timerID);
}

function _Kill()
{
	L2UITimer(GetScript("L2UITimer"))._Kill(_timerID);
}

function _Reset()
{
	L2UITimer(GetScript("L2UITimer"))._Stop(_timerID);
	L2UITimer(GetScript("L2UITimer"))._Play(_timerID);
}

static function L2UITimerObject Inst()
{
	return new class'L2UITimerObject';
}

defaultproperties
{
}
