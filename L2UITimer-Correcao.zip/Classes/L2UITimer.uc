class L2UITimer extends UIScript;

var private array<L2UITimerObject> timerObjects;
var private int lastTimerID;
var private array<int> returnedIndex;

function L2UITimerObject _AddTimer(optional int Time, optional int maxCount)
{
	local L2UITimerObject timerObject;

	timerObject = _AddNewTimerObject(Time, maxCount, 0, false);
	_Play(timerObject._timerID);
	return timerObject;
}

function L2UITimerObject _AddNewTimerObject(optional int Time, optional int maxCount, optional int Delay, optional bool isKillOnEnd)
{
	local int Len;

	if(Time == 0)
	{
		Time = 1000;
	}
	Len = timerObjects.Length;
	// timerObjects[Len] = new class'L2UITimerObject';
	timerObjects[Len] = class'L2UITimerObject'.static.Inst(); // Puxando por static para nÃ£o critar caso perca a referencia
	timerObjects[Len]._time = Time;
	timerObjects[Len]._timerID = GetEmptyTimerID();
	timerObjects[Len]._isKillOnEnd = isKillOnEnd;
	timerObjects[Len]._delay = Delay;
    
	if(maxCount == 0)
	{
		timerObjects[Len]._maxCount = 1;		
	}
	else
	{
		timerObjects[Len]._maxCount = maxCount;
	}
	return timerObjects[Len];
}

function bool _Play(int TimerID)
{
	local int Index;
	local L2UITimerObject timerObject;

	if(! FindIndex(TimerID, Index))
	{
		return false;
	}
	timerObject = timerObjects[Index];
	m_hOwnerWnd.KillTimer(timerObject._timerID);
    
	if(timerObject._delay == 0)
	{
		m_hOwnerWnd.SetTimer(timerObject._timerID, timerObject._time);		
	}
	else
	{
		m_hOwnerWnd.SetTimer(timerObject._timerID, timerObject._delay);
	}
	return true;
}

function bool _Pause(int TimerID)
{
	local int Index;

	if(! FindIndex(TimerID, Index))
	{
		return false;
	}
	m_hOwnerWnd.KillTimer(timerObjects[Index]._timerID);
	return true;
}

function bool _Stop(int TimerID)
{
	local int Index;

	if(! FindIndex(TimerID, Index))
	{
		return false;
	}
	m_hOwnerWnd.KillTimer(timerObjects[Index]._timerID);
	timerObjects[Index]._curCount = 0;
	return true;
}

function bool _Kill(int TimerID)
{
	local int Index;

	if(! FindIndex(TimerID, Index))
	{
		return false;
	}
	KillWithIndex(Index);
	return true;
}

function _KillAllTimer(optional bool isKillALll)
{
	local int i;

	for(i = 0; i < timerObjects.Length; i++)
	{
		m_hOwnerWnd.KillTimer(timerObjects[i]._timerID);
		timerObjects[i] = none;
	}
	timerObjects.Length = 0;
	returnedIndex.Length = 0;
	lastTimerID = 0;
}

event OnExitState(name a_CurrentStateName)
{
	local int i, Len;

	Len = timerObjects.Length - 1;
	returnedIndex.Length = 0;

	for(i = Len; i >= 0; i--)
	{
		m_hOwnerWnd.KillTimer(timerObjects[i]._timerID);
		timerObjects[i]._curCount = 0;
        
		if(timerObjects[i]._isKillOnEnd)
		{
			ReturnTimerID(timerObjects[i]._timerID);
			timerObjects[i] = none;
			timerObjects.Remove(i, 1);
		}
	}
}

event OnTimer(int TimerID)
{
	local int Index;
	local L2UITimerObject timerObject;

	if(! FindIndex(TimerID, Index))
	{
		return;
	}
	timerObject = timerObjects[Index];
    
	if(timerObject._delay > 0)
	{
		timerObject._delay = 0;
		m_hOwnerWnd.KillTimer(timerObject._timerID);
		m_hOwnerWnd.SetTimer(timerObject._timerID, timerObject._time);
		return;
	}
    
	if(timerObject._curCount == 0)
	{
		timerObject._DelegateOnStart();
	}
	timerObject._DelegateOnTime(timerObject._curCount);
	timerObject._curCount++;
    
	if(timerObject._curCount == timerObject._maxCount)
	{
		if(timerObject._isKillOnEnd)
		{
			KillWithIndex(Index);			
		}
		else
		{
			m_hOwnerWnd.KillTimer(timerObject._timerID);
		}
		timerObject._DelegateOnEnd();
	}
}

private function int GetEmptyTimerID()
{
	local int TimerID;

	if(returnedIndex.Length > 0)
	{
		TimerID = returnedIndex[0];
		returnedIndex.Remove(0, 1);
		return TimerID;
	}
	lastTimerID++;
	return lastTimerID - 1;
}

private function ReturnTimerID(int TimerID)
{
	returnedIndex[returnedIndex.Length] = TimerID;
}

private function KillWithIndex(int Index)
{
	m_hOwnerWnd.KillTimer(timerObjects[Index]._timerID);
	ReturnTimerID(timerObjects[Index]._timerID);
	timerObjects.Remove(Index, 1);
}

private function bool FindIndex(int TimerID, out int Index)
{
	local int i;

	for(i = 0; i < timerObjects.Length; i++)
	{
		if(timerObjects[i]._timerID == TimerID)
		{
			Index = i;
			return true;
		}
	}
	return false;
}

private function bool FindTimerObject(int TimerID, out L2UITimerObject timerObject)
{
	local int Index;

	if(! FindIndex(TimerID, Index))
	{
		return false;
	}
	timerObject = timerObjects[Index];
	return true;
}

defaultproperties
{
}
